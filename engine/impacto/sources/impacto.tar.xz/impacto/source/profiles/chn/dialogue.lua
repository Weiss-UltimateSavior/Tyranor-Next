root.Sprites["ADVBox"] = {
    Sheet = "MesBox",
    Bounds = { X = 0, Y = 0, Width = 1920, Height = 281 }
};

root.Dialogue = {
    TipsMessageModeIdx = 7,

    REVMessageModeIdx = 9,
    REVColor = 0,
    REVNameColor = 24,
    REVOutlineMode = 2,
    REVNameOutlineMode = 2,
    ADVBoxSprite = "ADVBox",
    ADVBoxPos = { X = 0, Y = 781 },
    FadeOutDuration = 0.33,
    FadeInDuration = 0.33,
    TextFadeInDuration = 0.33,
    TextFadeOutDuration = 0.33,
    DialogueBoxCurrentType = DialogueBoxType.Plain,
    NVLBoxMaxOpacity = 0.55,

    NametagCurrentType = NametagType.None,

    WaitIconSpriteAnim = "WaitIconSpriteAnimationDef",
    WaitIconCurrentType = WaitIconType.SpriteAnimation,
    KeyWaitIconPos = { X = 0, Y = 0 }, -- TODO
    WaitIconOffset = { X = 0, Y = 0 },

    DialogueFont = "Default",
    SetFontSizeRatio = 1000.0,
    DefaultFontSize = 48,
    ColorTable = {
        {0xFFFFFF, 0x000000}, {0x5080FF, 0x000000},
        {0xFF7080, 0x000000}, {0xFFA0F8, 0x000000},
        {0x46FF80, 0x000000}, {0x90FFFF, 0x000000},
        {0xFFFF70, 0x000000}, {0x80FFC0, 0x000000},
        {0xFFB080, 0x000000}, {0xB080FF, 0x000000},
        {0x000000, 0x808080}, {0x000000, 0x5080FF},
        {0x000000, 0xFF7080}, {0x000000, 0xFFA0F8},
        {0x000000, 0x268840}, {0x000000, 0x409999},
        {0x000000, 0x888830}, {0x000000, 0x80FFC0},
        {0x000000, 0xFFB080}, {0x000000, 0xB080FF},
        {0xD0D0D0, 0x000000}, {0xD0D0FF, 0x000000},
        {0xFFD0D0, 0x000000}, {0xFFD0FF, 0x000000},
        {0xD0FFD0, 0x000000}, {0xD0FFFF, 0x000000},
        {0xFFFFD0, 0x000000}, {0xE8FFD0, 0x000000},
        {0xFFE8D0, 0x000000}, {0xD0E8FF, 0x000000},
        {0xFFFFFF, 0x808080}, {0xFFFFFF, 0x5080FF},
        {0xFFFFFF, 0xFF7080}, {0xFFFFFF, 0xFFA0F8},
        {0xFFFFFF, 0x46FF80}, {0xFFFFFF, 0x90FFFF},
        {0xFFFFFF, 0xFFFF70}, {0xFFFFFF, 0x80FFC0},
        {0xFFFFFF, 0xFFB080}, {0xFFFFFF, 0xB080FF},
        {0xFFEEEE, 0x000000}, {0xFFCCCC, 0x000000},
        {0xFFAAAA, 0x000000}, {0xFF9999, 0x000000},
        {0xFF8888, 0x000000}, {0xFFFF00, 0x000000},
        {0xFEF000, 0x000000}, {0xFF7777, 0x000000},
        {0xFF6666, 0x000000}, {0xFF5555, 0x000000},
        {0xFF4444, 0x000000}, {0xFF3333, 0x000000},
        {0xFF2222, 0x000000}, {0xFF0000, 0x000000},
        {0xDD0000, 0x000000}, {0xBB0000, 0x000000},
        {0xB00000, 0x000000}, {0xAA0000, 0x000000},
        {0x950000, 0x000000}, {0x808080, 0x000000},
        {0xAAAAAA, 0x000000}, {0xAAC1C9, 0x000000},
        {0x000000, 0x000000}, {0x000000, 0x000000},
        {0x000000, 0x000000}, {0x000000, 0x000000},
        {0x000000, 0x000000}, {0xF80B0B, 0x000000},
        {0xF8910B, 0x000000}, {0x33F12A, 0x000000}
    },
    MaxPageSize = 2000,
    PageCount = 3,
    ColorTagIsUint8 = false
};

MakeAnimation({
    Name = "WaitIconSpriteAnimationDef",
    Sheet = "MesBox",
    FirstFrameX = 0,
    FirstFrameY = 1919,
    FrameWidth = 64,
    ColWidth = 64,
    FrameHeight = 64,
    RowHeight = 64,
    Frames = 44,
    Duration = 5.0,
    Rows = 2,
    Columns = 32,
    PrimaryDirection = AnimationDirections.Right,
    SecondaryDirection = AnimationDirections.Down
});
