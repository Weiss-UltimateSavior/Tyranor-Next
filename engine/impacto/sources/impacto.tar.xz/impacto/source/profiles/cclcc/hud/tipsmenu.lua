root.TipsMenu = {
    Type = TipsMenuType.CCLCC,
    DrawType = DrawComponentType.SystemMenu,
    FadeInDuration = 0.4,
    FadeOutDuration = 0.4,
    TransitionInDuration = 0.4,
    TransitionOutDuration = 0.4,
    BackgroundSprite = "TipsBookLayer",
    TipsGuideSprite = "TipsGuide",
    TipsGuidePosition = { X = 0, Y = 989},
    TipsNewSprite = "TipsNewSprite",
    TipsHighlightedSprite = "TipsHighlightedSprite",

    TipsEntryBounds = { X = 80, Y = 382, Width = 781, Height = 40},
    TipsEntryYPadding = 10,
    TipEntryNewOffset = { X = 0, Y = 1 },
    TipsEntryHighlightOffset = { X = 41, Y = 3 },
    TipsEntryNumberOffset = { X = 41, Y = 12 },
    TipsEntryNameOffset = {X = 94, Y = 10},
    TipsEntryNumberFontSize = 26,
    TipsEntryNameFontSize = 30,
    TipsTabBounds = {X = 0, Y = 382, Width = 890, Height = 545 },
    TipsHighlightedTabSprite = "TipsHighlightedTabSprite",
    TipsTabNameDisplay = {X = 266, Y = 285},
    TipsHighlightedTabAdder = 161,

    TipsTextTableIndex = 2,
    TipsTextEntryLockedIndex = 7,
    TipsTextSortStringIndex = 10,
    TipsTextPageHeight = 485,

    CategoryPos = { X = 826 * 1.5, Y = 76 },
    CategoryFontSize = 40,
    NamePos = { X = 680 * 1.5, Y = 160 },
    NameFontSize = 54,
    NumberPos = { X = 1198 * 1.5, Y = 52 * 1.5 },
    NumberFontSize = 62,
    PronunciationPos = { X = 680 * 1.5, Y = 246 },
    PronunciationFontSize = 34,

    TipsEntryNameUnreadColor = 0x117733, 
    TipsMenuDarkTextColor = 0x3e3e3c,

    TipsScrollThumbSprite = "TipsScrollThumb",
    TipsScrollThumbLength = 40,
    TipsScrollYStart = 385,
    TipsScrollYEnd = 930,
    TipsScrollEntriesX = 896,
    TipsScrollDetailsX = 1783,

    TipsMask = "TipsMask",
};

root.Sprites["TipsBookLayer"] = {
    Sheet = "Tips",
    Bounds = { X = 0, Y = 0, Width = 1920, Height = 1080 }
};

root.Sprites["TipsGuide"] = {
    Sheet = "Tips",
    Bounds = { X = 0, Y = 1152, Width = 1925, Height = 55 }
};

-- Start of Tips Tab Name Sprites
root.Sprites["TipsHighlightedTabSprite"] = {
    Sheet = "Tips",
    Bounds = { X = 1355, Y = 1212, Width = 160, Height = 44 }
};

root.Sprites["TipsNewSprite"] = {
    Sheet = "Tips",
    Bounds = { X = 1314, Y = 1212, Width = 40, Height = 40 }
};

root.Sprites["TipsHighlightedSprite"] = {
    Sheet = "Tips",
    Bounds = { X = 517, Y = 1208, Width = 740, Height = 40 }
};

root.Sprites["TipsScrollThumb"] = {
    Sheet = "Tips",
    Bounds = { X = 2016, Y = 994, Width = 11, Height = 40 }
};
