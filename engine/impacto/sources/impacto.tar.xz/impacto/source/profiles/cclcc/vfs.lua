root.Vfs = {
    Mounts = {
        ["bg"] = {root.BasePaths.RootGamedataDir .. "/cclcc/bg.mpk"},
        ["bgeffect"] = {root.BasePaths.RootGamedataDir .. "/cclcc/bgeffect.mpk"},
        ["bgm"] = {root.BasePaths.RootGamedataDir .. "/cclcc/bgm.mpk"},
        ["chara"] = {root.BasePaths.RootGamedataDir .. "/cclcc/chara.mpk"},
        ["manual"] = {root.BasePaths.RootGamedataDir .. "/cclcc/manual.mpk"},
        ["mask"] = {root.BasePaths.RootGamedataDir .. "/cclcc/mask.mpk"},
        ["movie"] = {
            {
                Path = root.BasePaths.RootGamedataDir .. "/cclcc/movie",
                Whitelist = ".*movie.*\\.mp4",
            },
        },
        ["script"] = {
            {
                Path = root.BasePaths.RootGamedataDir .. "/cclcc/script",
                Whitelist = ".*script.*\\.scx",
            },
        },
        ["se"] = {root.BasePaths.RootGamedataDir .. "/cclcc/se.mpk"},
        ["sysse"] = {root.BasePaths.RootGamedataDir .. "/cclcc/sysse.mpk"},
        ["system"] = {root.BasePaths.RootGamedataDir .. "/cclcc/system.mpk"},
        ["voice"] = {root.BasePaths.RootGamedataDir .. "/cclcc/voice.mpk"}
    }
};
