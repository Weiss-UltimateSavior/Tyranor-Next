root.SystemMenu = {
    Type = SystemMenuType.CCLCC,
    DrawType = DrawComponentType.SystemMenu,

    FadeInDuration = 32 / 60,
    FadeOutDuration = 32 / 60,

    FadeInDirectDuration = 16 / 60;
    FadeOutDirectDuration = 16 / 60;

    ItemsFadeInDuration = 32 / 60,
    ItemsFadeOutDuration = 32 / 60,

    Seed = 0,

    MenuEntriesNum = 9,
    MenuEntriesHNum = 9,

    FocusTint = 0xff9cb6,
    MenuEntriesPositions = { 
        {X=41, Y=-4},
        {X=41, Y=87},
        {X=41, Y=119},
        {X=41, Y=284},
        {X=41, Y=365},
        {X=41, Y=458},
        {X=41, Y=574},
        {X=41, Y=649},
        {X=41, Y=725},
    },
    MenuEntriesFadeXOffset = 200,

    MenuEntriesButtonBounds = { 
        {X=120, Y= 74, Width=228, Height=60},
        {X=120, Y=172, Width=260, Height=60},
        {X=120, Y=268, Width=260, Height=60},
        {X=120, Y=362, Width=128, Height=60},
        {X=120, Y=454, Width=128, Height=60},
        {X=120, Y=552, Width=228, Height=60},
        {X=120, Y=650, Width=186, Height=60},
        {X=120, Y=742, Width=128, Height=60},
        {X=120, Y=838, Width=316, Height=60},
    },
    MenuEntriesSprites = {},
    MenuEntriesHighlightedSprites = {},

    MenuButtonGuide = "SystemMenuButtonGuide",
    MenuButtonGuidePos = { X = 0, Y = 989 };
    MenuButtonGuideFadeXOffset = -200,

    SystemMenuBG = "SystemMenuBG",
    SystemMenuFrame = "SystemMenuFrame",
    OverlaySprite = "OverlaySprite",

    BGDispOffsetTopLeft = {X=-1200, Y= -330},
    BGDispOffsetBottomLeft = {X=-1200, Y= 2080},
    BGDispOffsetTopRight = {X=2520, Y= -330},
    BGDispOffsetBottomRight = {X=2520, Y= 2080},

    FrameOffsetTopLeft = {X=-144, Y= -131},
    FrameOffsetBottomLeft = {X=-144, Y= 1252},
    FrameOffsetTopRight = {X=2108, Y= -131},
    FrameOffsetBottomRight = {X=2108, Y= 1252},

    AngleMultiplier = {X=-196608 / 5760, Y=-131072 / 5760, Z=163840 / 5760},
    BGRandPosRange = {X=4095,Y=4095},

    BGTranslationOffset = {X=1452,Y=395},

    SmokePosition = { X = 0, Y = 582 },
    SmokeOpacityNormal = 0.25,
    SmokeOpacitySystemMenu = 96 / 256,
    SmokeAnimationDurations = {
        1920 / 60,
        1920 / 60 / 2,
    },
    SmokeSprites = {
        "TitleMenuSmoke1",
        "TitleMenuSmoke2"
    },
};

root.Sprites["SystemMenuBG"] = {
    Sheet = "MenuBG",
    Bounds = {X = -600, Y = -165, Width = 1860, Height = 1205}
};

root.Sprites["SystemMenuBacklog"] = {
    Sheet = "MenuChip",
    Bounds = {X = 2752, Y = 0, Width = 420, Height = 202}
};
root.SystemMenu.MenuEntriesSprites[#root.SystemMenu.MenuEntriesSprites + 1] = "SystemMenuBacklog";

root.Sprites["SystemMenuQuickSave"] = {
    Sheet = "MenuChip",
    Bounds = {X = 2252, Y = 274, Width = 498, Height = 225}
};
root.SystemMenu.MenuEntriesSprites[#root.SystemMenu.MenuEntriesSprites + 1] = "SystemMenuQuickSave";

root.Sprites["SystemMenuQuickLoad"] = {
    Sheet = "MenuChip",
    Bounds = {X = 2252, Y = 1092, Width = 498, Height = 348}
};
root.SystemMenu.MenuEntriesSprites[#root.SystemMenu.MenuEntriesSprites + 1] = "SystemMenuQuickLoad";

root.Sprites["SystemMenuSave"] = {
    Sheet = "MenuChip",
    Bounds = {X = 2752, Y = 204, Width = 420, Height = 241}
};
root.SystemMenu.MenuEntriesSprites[#root.SystemMenu.MenuEntriesSprites + 1] = "SystemMenuSave";

root.Sprites["SystemMenuLoad"] = {
    Sheet = "MenuChip",
    Bounds = {X = 2252, Y = 0, Width = 498, Height = 305}
};
root.SystemMenu.MenuEntriesSprites[#root.SystemMenu.MenuEntriesSprites + 1] = "SystemMenuLoad";

root.Sprites["SystemMenuTips"] = {
    Sheet = "MenuChip",
    Bounds = {X = 2252, Y = 501, Width = 498, Height = 305}
};
root.SystemMenu.MenuEntriesSprites[#root.SystemMenu.MenuEntriesSprites + 1] = "SystemMenuTips";

root.Sprites["SystemMenuConfig"] = {
    Sheet = "MenuChip",
    Bounds = {X = 2752, Y = 447, Width = 420, Height = 253}
};
root.SystemMenu.MenuEntriesSprites[#root.SystemMenu.MenuEntriesSprites + 1] = "SystemMenuConfig";

root.Sprites["SystemMenuHelp"] = {
    Sheet = "MenuChip",
    Bounds = {X = 2752, Y = 702, Width = 420, Height = 259}
};
root.SystemMenu.MenuEntriesSprites[#root.SystemMenu.MenuEntriesSprites + 1] = "SystemMenuHelp";

root.Sprites["SystemMenuReturnTitle"] = {
    Sheet = "MenuChip",
    Bounds = {X = 2252, Y = 808, Width = 498, Height = 282}
};
root.SystemMenu.MenuEntriesSprites[#root.SystemMenu.MenuEntriesSprites + 1] = "SystemMenuReturnTitle";

for i=1, #root.SystemMenu.MenuEntriesSprites do
    local name = root.SystemMenu.MenuEntriesSprites[i] .. "Highlighted"
    root.Sprites[name] = {
        Sheet = "MenuChip",
        Bounds = {
            X = root.Sprites[root.SystemMenu.MenuEntriesSprites[i]].Bounds.X + 922,
            Y = root.Sprites[root.SystemMenu.MenuEntriesSprites[i]].Bounds.Y,
            Width = root.Sprites[root.SystemMenu.MenuEntriesSprites[i]].Bounds.Width,
            Height = root.Sprites[root.SystemMenu.MenuEntriesSprites[i]].Bounds.Height
        }
    }
    root.SystemMenu.MenuEntriesHighlightedSprites[#root.SystemMenu.MenuEntriesHighlightedSprites + 1] = name
end

root.Sprites["SystemMenuButtonGuide"] = {
    Sheet = "MenuChip",
    Bounds = {X = 0, Y = 1385, Width = 1920, Height = 59}
};

root.Sprites["SystemMenuFrame"] = {
    Sheet = "MenuChip",
    Bounds = {X = 0, Y = 0, Width = 2252, Height = 1383}
};

root.Sprites["OverlaySprite"] = {
    Sheet = "MenuChip",
    Bounds = { X = 155, Y = 142, Width = 1898, Height = 1058 },
};

root.Sprites["TitleMenuSmoke1"] = {
    Sheet = "MenuChip",
    Bounds = { X = 0, Y = 1548, Width = 1920, Height = 498 },
};

root.Sprites["TitleMenuSmoke2"] = {
    Sheet = "MenuChip",
    Bounds = { X = 2002, Y = 1548, Width = 1920, Height = 498 },
};
