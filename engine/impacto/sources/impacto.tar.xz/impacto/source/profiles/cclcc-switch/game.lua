
root.ActiveRenderer = RendererType.OpenGL;

root.LayerCount = 100;
root.GameFeatures = GameFeature.Sc3VirtualMachine |
                    GameFeature.Renderer2D |
                    GameFeature.Input |
                    GameFeature.Audio |
                    GameFeature.Video |
                    GameFeature.Subtitles |
                    GameFeature.DebugMenu |
                    GameFeature.Achievements |
                    GameFeature.Overlay;
root.DesignWidth = 1920;
root.DesignHeight = 1080;

root.WindowName = "CHAOS;CHILD Love Chu☆Chu!!";
root.WindowIconPath = "resources/cclcc/icondata/icon.png";
root.CursorArrowPath = "resources/cclcc/icondata/cursor_arrow.png";
root.CursorPointerPath = "resources/cclcc/icondata/cursor_pointer.png";

root.CharaIsMvl = true;
root.UseMoviePriority = true;
root.UseBgChaEffects = false;
root.UseBgFrameEffects = false;
root.UseWaveEffects = true;

root.ScreenCaptureCount = 2;

root.Vm = {
    StartScript = 2,
    StartScriptBuffer = 0,
    GameInstructionSet = InstructionSet.LCCSwitch,
    
    UseMsbStrings = true;
    UseReturnIds = true;
    UseSeparateMsbArchive = true;
    StringEncodingType = StringUnitEncoding.Uint32,
    StringIdSize = 4,

    ScrWorkChaStructSize = 24,
    ScrWorkChaOffsetStructSize = 10,
    ScrWorkBgStructSize = 24,
    ScrWorkBgOffsetStructSize = 10,
    ScrWorkCaptureStructSize = 20,
    ScrWorkCaptureOffsetStructSize = 10,
    ScrWorkCaptureEffectInfoStructSize = 3,
    ScrWorkBgEffStructSize = 30,
    ScrWorkBgEffOffsetStructSize = 18,
    ScrWorkMesStructSize = 7,
    MaxLinkedBgBuffers = 2
};

root.PlatformId = 0x100000; -- switch, important for scripts

include(root.BasePaths.RootProfilesDir .. '/common/animation.lua');
include(root.BasePaths.RootProfilesDir .. '/common/achievementnotification.lua');
include(root.BasePaths.RootProfilesDir .. '/common/charset.lua');
include(root.BasePaths.RootProfilesDir .. '/common/scriptinput.lua');
include(root.BasePaths.RootProfilesDir .. '/common/scriptvars-switch.lua');

include(root.BasePaths.RootProfilesDir .. '/cclcc-switch/scriptvars.lua');
include(root.BasePaths.RootProfilesDir .. '/cclcc-switch/sprites.lua');
include(root.BasePaths.RootProfilesDir .. '/cclcc/savedata.lua');
include(root.BasePaths.RootProfilesDir .. '/cclcc-switch/savedata.lua');
include(root.BasePaths.RootProfilesDir .. '/cclcc/tipssystem.lua');
include(root.BasePaths.RootProfilesDir .. '/cclcc-switch/vfs.lua');
include(root.BasePaths.RootProfilesDir .. '/cclcc/charset.lua');
include(root.BasePaths.RootProfilesDir .. '/cclcc/gamespecific.lua');
include(root.BasePaths.RootProfilesDir .. '/cclcc-switch/font.lua');
include(root.BasePaths.RootProfilesDir .. '/cclcc/dialogue.lua');
include(root.BasePaths.RootProfilesDir .. '/cclcc-switch/dialogue.lua');
include(root.BasePaths.RootProfilesDir .. '/cclcc/configsystem.lua');
include(root.BasePaths.RootProfilesDir .. '/cclcc-switch/bgeff.lua');
include(root.BasePaths.RootProfilesDir .. '/cclcc/waveeffects.lua');
include(root.BasePaths.RootProfilesDir .. '/cclcc-switch/hud/saveicon.lua');
include(root.BasePaths.RootProfilesDir .. '/cclcc/hud/loadingdisplay.lua');
include(root.BasePaths.RootProfilesDir .. '/cclcc/hud/datedisplay.lua');
include(root.BasePaths.RootProfilesDir .. '/cclcc/hud/titlemenu.lua');
include(root.BasePaths.RootProfilesDir .. '/cclcc/hud/backlogmenu.lua');
include(root.BasePaths.RootProfilesDir .. '/cclcc/hud/sysmesboxdisplay.lua');
include(root.BasePaths.RootProfilesDir .. '/cclcc/hud/selectiondisplay.lua');
include(root.BasePaths.RootProfilesDir .. '/cclcc/hud/optionsmenu.lua');
include(root.BasePaths.RootProfilesDir .. '/cclcc/hud/tipsmenu.lua');
include(root.BasePaths.RootProfilesDir .. '/cclcc-switch/hud/tipsmenu.lua');
include(root.BasePaths.RootProfilesDir .. '/cclcc/hud/extramenus.lua');
include(root.BasePaths.RootProfilesDir .. '/cclcc-switch/hud/extramenus.lua');
include(root.BasePaths.RootProfilesDir .. '/cclcc/hud/tipsnotification.lua');
include(root.BasePaths.RootProfilesDir .. '/cclcc-switch/hud/tipsnotification.lua');
include(root.BasePaths.RootProfilesDir .. '/cclcc/hud/systemmenu.lua');
include(root.BasePaths.RootProfilesDir .. '/cclcc/hud/savemenu.lua');
include(root.BasePaths.RootProfilesDir .. '/cclcc-switch/hud/helpmenu.lua');
include(root.BasePaths.RootProfilesDir .. '/cclcc-switch/hud/titlemenu.lua');
