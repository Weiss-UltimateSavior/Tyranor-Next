root.Sprites["ADVBox"] = {
    Sheet = "Data",
    Bounds = { X = 769, Y = 811, Width = 1278, Height = 212 },
};
root.Sprites["SecondaryADVBox"] = {
    Sheet = "Data",
    Bounds = { X = 769, Y = 423, Width = 1278, Height = 212 },
};
root.Sprites["ErinBox"] = {
    Sheet = "Data",
    Bounds = { X = 35, Y = 142, Width = 732, Height = 225 },
};
root.Sprites["AutoSkipArrowsSprite"] = {
    Sheet = "Data",
    Bounds = { X = 173, Y = 1, Width = 64, Height = 64 },
};
root.Sprites["AutoIconSprite"] = {
    Sheet = "Data",
    Bounds = { X = 239, Y = 1, Width = 64, Height = 64 },
};
root.Sprites["SkipIconSprite"] = {
    Sheet = "Data",
    Bounds = { X = 305, Y = 1, Width = 64, Height = 64 },
};

root.Dialogue = {
    TipsMessageModeIdx = 7,
    TipsColorIndex = 0,
    ErinBoxSprite = "ErinBox",
    ErinBoxPos = { X = -25, Y = -23 },
    REVMessageModeIdx = 9,
    REVColor = 0,
    REVNameColor = 24,
    REVOutlineMode = 2,
    REVNameOutlineMode = 2,
    ADVBoxSprite = "ADVBox",
    SecondaryADVBoxSprite =  "SecondaryADVBox",
    ADVBoxPos = { X = 0, Y = 508 },
    FadeOutDuration = 0.33,
    FadeInDuration = 0.33,
    TextFadeInDuration = 0.33,
    TextFadeOutDuration = 0.33,
    DialogueBoxCurrentType = DialogueBoxType.CHLCC,
    NVLBoxMaxOpacity = 0.55,

    WaitIconSpriteAnimation = "WaitIconSpriteAnimationDef",
    WaitIconCurrentType = WaitIconType.SpriteAnimation,
    KeyWaitIconPos = { X = 1038, Y = 640 },
    WaitIconOffset = { X = 4, Y = -28 },
    WaitIconDrawableWithoutTextbox = false,

    AutoIconCurrentType = AutoIconType.CHLCC,
    AutoIconSprite = "AutoIconSprite",
    AutoIconOffset = { X = 1167, Y = 630 },
    AutoIconRotationDuration = 119 / 60,

    SkipIconCurrentType = SkipIconType.CHLCC,
    SkipIconSprite = "SkipIconSprite",
    SkipIconOffset = { X = 1167, Y = 527 },
    SkipIconRotationDuration = 39 / 60,

    AutoSkipArrowsSprite = "AutoSkipArrowsSprite",
    DialogueFont = "Default",
    SetFontSizeRatio = 1000.0,
    DefaultFontSize = 32,
    ColorTable = {
        {0xFFFFFF, 0x000000}, {0x5080FF, 0x000000},
        {0xFF7080, 0x000000}, {0xFFA0F8, 0x000000},
        {0x46FF80, 0x000000}, {0x90FFFF, 0x000000},
        {0xFFFF70, 0x000000}, {0x80FFC0, 0x000000},
        {0xFFB080, 0x000000}, {0xB080FF, 0x000000},
        {0x000000, 0x808080}, {0x000000, 0x5080FF},
        {0x000000, 0xFF7080}, {0x000000, 0xFFA0F8},
        {0x000000, 0x268840}, {0x000000, 0x409999},
        {0x000000, 0x888830}, {0x000000, 0x80FFC0},
        {0x000000, 0xFFB080}, {0x000000, 0xB080FF},
        {0xD0D0D0, 0x000000}, {0xD0D0FF, 0x000000},
        {0xFFD0D0, 0x000000}, {0xFFD0FF, 0x000000},
        {0xD0FFD0, 0x000000}, {0xD0FFFF, 0x000000},
        {0xFFFFD0, 0x000000}, {0xE8FFD0, 0x000000},
        {0xFFE8D0, 0x000000}, {0xD0E8FF, 0x000000},
        {0xFFFFFF, 0x808080}, {0xFFFFFF, 0x5080FF},
        {0xFFFFFF, 0xFF7080}, {0xFFFFFF, 0xFFA0F8},
        {0xFFFFFF, 0x46FF80}, {0xFFFFFF, 0x90FFFF},
        {0xFFFFFF, 0xFFFF70}, {0xFFFFFF, 0x80FFC0},
        {0xFFFFFF, 0xFFB080}, {0xFFFFFF, 0xB080FF},
        {0xFFEEEE, 0x000000}, {0xFFCCCC, 0x000000},
        {0xFFAAAA, 0x000000}, {0xFF9999, 0x000000},
        {0xFF8888, 0x000000}, {0xFFFF00, 0x000000},
        {0xFEF000, 0x000000}, {0xFF7777, 0x000000},
        {0xFF6666, 0x000000}, {0xFF5555, 0x000000},
        {0xFF4444, 0x000000}, {0xFF3333, 0x000000},
        {0xFF2222, 0x000000}, {0xFF0000, 0x000000},
        {0xDD0000, 0x000000}, {0xBB0000, 0x000000},
        {0xB00000, 0x000000}, {0xAA0000, 0x000000},
        {0x950000, 0x000000}, {0x808080, 0x000000},
        {0xAAAAAA, 0x000000}, {0xAAC1C9, 0x000000},
        {0x000000, 0x000000}, {0x000000, 0x000000},
        {0x000000, 0x000000}, {0x000000, 0x000000},
        {0x000000, 0x000000}, {0xF80B0B, 0x000000},
        {0xF8910B, 0x000000}, {0x33F12A, 0x000000},
        {0x00FF00, 0x000000}
    },
    MaxPageSize = 2000,
    PageCount = 3,
    ColorTagIsUint8 = false,

    OldNametagPositioning = true,
    NametagCurrentType = NametagType.CHLCC,
    NametagPosition = { X = -1, Y = 465 },
    NametagSprite = "NametagSprite",
    SecondaryNametagSprite = "SecondaryNametagSprite",

    TextModesInfo = {},
};

MakeAnimation({
    Name = "WaitIconSpriteAnimationDef",
    Sheet = "Data",
    FirstFrameX = 1,
    FirstFrameY = 97,
    FrameWidth = 32,
    ColWidth = 32,
    FrameHeight = 32,
    RowHeight = 34,
    Frames = 8,
    Duration = (4 * 8) / 60,
    Rows = 8,
    Columns = 1,
    PrimaryDirection = AnimationDirections.Down,
});

root.Sprites["NametagSprite"] = {
    Sheet = "Data",
    Bounds = { X = 35, Y = 97, Width = 266, Height = 44 }
}

root.Sprites["SecondaryNametagSprite"] = {
    Sheet = "Data",
    Bounds = { X = 502, Y = 97, Width = 266, Height = 44 }
}
