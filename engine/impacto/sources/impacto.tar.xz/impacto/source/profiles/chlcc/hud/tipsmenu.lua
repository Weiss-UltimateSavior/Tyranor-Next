root.TipsMenu = {
    DrawType = DrawComponentType.SystemMenu,
    Type = TipsMenuType.CHLCC,
    TransitionDuration = 64 / 60,
    BackgroundColor = 0x007efe,
    CircleSprite = "CircleTips",
    MenuTitleTextRightPos = { X = 787, Y = 209 },
    MenuTitleTextLeftPos = { X = 257, Y = 1 },
    MenuTitleTextAngle = 4.45,
    MenuTitleText = "MenuTitleTextTips",
    TipsTree = "TipsTree",
    TreePosition = { X = 53, Y = 0 },
    TipsGradient = "TipsGradient",
    GradientPosition = { X = 75, Y = 0 },
    EndOfGradientColor = 0x2691ff,
    ButtonPromptSprite = "ButtonPromptTips",
    ButtonPromptPosition = { X = 685, Y = 651 },
    CurrentTipBackgroundSprite = "CurrentTipBackgroundSprite",
    CurrentTipBackgroundPosition = { X = 381, Y = 42 },
    SelectWordSprites = {},
    SelectWordPos = {
        { X = 78, Y = 49 },
        { X = 91, Y = 49 },
        { X = 105, Y = 49 },
        { X = 117, Y = 49 },
        { X = 131, Y = 49 },
        { X = 144, Y = 49 },
        { X = 156, Y = 49 },
        { X = 183, Y = 49 },
        { X = 199, Y = 49 },
        { X = 215, Y = 49 }
    },
    SelectWordDuration = 110/60,
    SelectWordInterval = 5/60,
    CategoryString = "【 】",
    TipsStringTable = 2,
    CategoryStringIndex = 5, 
    SortStringIndex = 10, 
    LockedTipsIndex = 7, 
    NumberLabelStrIndex = 8, 
    PageSeparatorIndex = 9, 
    NewLabelStrIndex = 11,
    UnreadLabelStrIndex = 12,
    TipListEntryBounds = { X = 75, Y = 130, Width = 286, Height = 24 },
    TipListEntryTextOffsetX = 6;
    TipListEntryFontSize = 20,
    TipListYPadding = 24,
    TipsListBounds = { X = 75, Y = 130, Width = 286, Height = 504 },
    TipsListRenderBounds = { X = 30, Y = 130, Width = 380, Height = 504 },
    NumberLabelPosition = { X = 396, Y = 52 },
    NumberLabelFontSize = 22,
    NumberBounds = { X = 409, Y = 52, Width = 0, Height = 0 },
    NumberFontSize = 22,
    CurrentPageSprites = {},
    TotalPageSprites = {},
    PageSeparatorSprite = "PageSeparatorSprite",
    CurrentPagePosition = { X = 1155, Y = 586 },
    TotalPagesPosition = { X = 1195, Y = 611 },
    PageSeparatorPosition = { X = 1181, Y = 611 },
    DefaultColorIndex = 0,
    UnreadColorIndex = 70,
    PronunciationFontSize = 18,
    NameFontSize = 30,
    TipListEntryNameXOffset = 55,
    NameInitialBounds = { X = 1210, Y = 80, Width = 0, Height = 0 },
    PronunciationInitialBounds = { X = 1210, Y = 110, Width = 0, Height = 0 },
    TipsListEntryDotOffset = { X = -17, Y = -4},
    TipsListNewDotOffset= { X = -40, Y = -4},
    TipScrollbarPos = { X = 359, Y = 127},

    TipsEntryHighlightBarSprite = "TipsEntryHighlightBar",
    TipsEntryHighlightDotSprite = "TipsEntryHighlightDot",
    TipsEntryNewDotSprite = "TipsEntryNewDot",
    TipsLeftLineSprite = "TipsLeftLine",
    TipsLeftLineEndSprite = "TipsLeftLineEnd",
    TipsLeftLineHoleSprite = "TipsLeftLineHole",
    TipsLeftLineHoleEndSprite = "TipsLeftLineHoleEnd",
    TipsListBgBarSprite = "TipsListBgBar",
    TipsListBgBarHoleSprite = "TipsListBgBarHole",
    TipsScrollThumbSprite = "TipsScrollThumb",
    TipsScrollTrackSprite = "TipsScrollTrack",

}

root.Sprites["CircleTips"] = {
    Sheet = "Tips",
    Bounds = { X = 1, Y = 917, Width = 106, Height = 106 }
}

root.Sprites["MenuTitleTextTips"] = {
    Sheet = "Tips",
    Bounds = { X = 1151, Y = 1, Width = 120, Height = 742 }
}

root.Sprites["TipsTree"] = {
    Sheet = "Tips",
    Bounds = { X = 851, Y = 273, Width = 182, Height = 131 }
}

--Purposefully cut the texture to create smaller Rect below
root.Sprites["TipsGradient"] = {
    Sheet = "Tips",
    Bounds = { X = 852, Y = 1, Width = 295, Height = 132 }
}

root.Sprites["ButtonPromptTips"] = {
    Sheet = "Tips",
    Bounds = { X = 3, Y = 611, Width = 595, Height = 28 }
}

root.Sprites["CurrentTipBackgroundSprite"] = {
    Sheet = "Tips",
    Bounds = { X = 1, Y = 1, Width = 846, Height = 605 }
}

local selectWordBounds = {
    { X = 1, Y = 643, Width = 16, Height = 57 },
    { X = 20, Y = 643, Width = 17, Height = 57 },
    { X = 38, Y = 643, Width = 15, Height = 57 },
    { X = 55, Y = 643, Width = 17, Height = 57 },
    { X = 74, Y = 643, Width = 16, Height = 57 },
    { X = 92, Y = 643, Width = 15, Height = 57 },
    { X = 109, Y = 643, Width = 30, Height = 57 },
    { X = 141, Y = 643, Width = 19, Height = 57 },
    { X = 162, Y = 643, Width = 19, Height = 57 },
    { X = 181, Y = 643, Width = 18, Height = 57 }
}

for i, bounds in ipairs(selectWordBounds) do
    root.Sprites["SelectWord" .. i - 1] = {
        Sheet = "Tips",
        Bounds = bounds
    }
    root.TipsMenu.SelectWordSprites[i] = "SelectWord" .. i - 1;
end

root.Sprites["TipsEntryHighlightBar"] = {
    Sheet = "Tips",
    Bounds = { X = 851, Y = 510, Width = 286, Height = 24 }
}
root.Sprites["TipsEntryHighlightDot"] = {
    Sheet = "Tips",
    Bounds = { X = 636, Y = 609, Width = 32, Height = 32 }
}
root.Sprites["TipsEntryNewDot"] = {
    Sheet = "Tips",
    Bounds = { X = 602, Y = 609, Width = 32, Height = 32 }
}
root.Sprites["TipsLeftLine"] = {
    Sheet = "Tips",
    Bounds = { X = 851, Y = 406, Width = 32, Height = 24 }
}
root.Sprites["TipsLeftLineHole"] = {
    Sheet = "Tips",
    Bounds = { X = 851, Y = 432, Width = 32, Height = 24 }
}
root.Sprites["TipsLeftLineHoleEnd"] = {
    Sheet = "Tips",
    Bounds = { X = 851, Y = 458, Width = 32, Height = 24 }
}
root.Sprites["TipsLeftLineEnd"] = {
    Sheet = "Tips",
    Bounds = { X = 851, Y = 484, Width = 286, Height = 8 }
}
root.Sprites["TipsListBgBar"] = {
    Sheet = "Tips",
    Bounds = { X = 851, Y = 134, Width = 286, Height = 24 }
}
root.Sprites["TipsListBgBarHole"] = {
    Sheet = "Tips",
    Bounds = { X = 851, Y = 160, Width = 286, Height = 24 }
}
root.Sprites["TipsScrollThumb"] = {
    Sheet = "Tips",
    Bounds = { X = 1275, Y = 512, Width = 14, Height = 60 }
}
root.Sprites["TipsScrollTrack"] = {
    Sheet = "Tips",
    Bounds = { X = 1281, Y = 0, Width = 2, Height = 499 }
}

for i = 0, 9 do
    root.Sprites["CurrentPageSprites" .. i] = {
        Sheet = "Data",
        Bounds = { X = 371 + (i * 36), Y = 1, Width = 34, Height = 48 }
    }
    root.TipsMenu.CurrentPageSprites[i + 1] = "CurrentPageSprites" .. i ;
end

for i = 0, 9 do
    root.Sprites["TotalPageSprites" .. i] = {
        Sheet = "Data",
        Bounds = { X = 190 + (i * 18), Y = 67, Width = 16, Height = 22 }
    }
    root.TipsMenu.TotalPageSprites[i + 1] = "TotalPageSprites" .. i ;
end

root.Sprites["PageSeparatorSprite"] = {
    Sheet = "Data",
    Bounds = { X = 173, Y = 67, Width = 16, Height = 22 }
}