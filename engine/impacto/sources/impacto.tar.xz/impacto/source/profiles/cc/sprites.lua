root.SpriteSheets = {
    ["BacklogMask"] = {
        Path = { Mount = "system", Id = 2 },
        DesignWidth = 1920,
        DesignHeight = 1080
    },
    ["Data"] = {
        Path = { Mount = "system", Id = 5 },
        DesignWidth = 3072,
        DesignHeight = 1536
    },
  	["MesBox"] = {
        Path = { Mount = "system", Id = 20 },
        DesignWidth = 1920,
        DesignHeight = 600
    },
    ["Font"] = {
        Path = { Mount = "system", Id = 8 },
        DesignWidth = 3072,
        DesignHeight = 6000
    },
    ["Menu"] = {
        Path = { Mount = "system", Id = 8 },
        DesignWidth = 2048,
        DesignHeight = 1024
    },
    ["Title"] = {
        Path = { Mount = "system", Id = 29 },
        DesignWidth = 3456,
        DesignHeight = 1728
    },
    ["TitleChip"] = {
        Path = { Mount = "system", Id = 30 },
        DesignWidth = 2528,
        DesignHeight = 2048
    },
    ["MenuChip"] = {
        Path = { Mount = "system", Id = 19 },
        DesignWidth = 4096,
        DesignHeight = 3072
    },
    ["SysMesBox"] = {
        Path = { Mount = "system", Id = 26 },
        DesignWidth = 2048,
        DesignHeight = 1528
    },
    ["Backlog"] = {
        Path = { Mount = "system", Id = 1 },
        DesignWidth = 2048,
        DesignHeight = 2048
    },
    ["NamePlate"] = {
        Path = { Mount = "system", Id = 23 },
        DesignWidth = 4096,
        DesignHeight = 2268
    }
};

root.Sprites = {};