#include "savesystem.h"

#include "../../io/stream.h"
#include "../../io/physicalfilestream.h"
#include "../../mem.h"
#include "../../vm/vm.h"
#include "../../profile/data/savesystem.h"
#include "../../profile/scriptvars.h"
#include "../../profile/vm.h"
#include "../../renderer/renderer.h"
#include "../../profile/configsystem.h"
#include "../../effects/wave.h"
#include "../../audio/audiosystem.h"

#include "mapsystem.h"
#include "yesnotrigger.h"

#include <cstdint>
#include <ctime>
#include <system_error>
#include <ranges>

namespace Impacto {
namespace CCLCC {

using namespace Impacto::Vm;
using namespace Impacto::Effects;
using namespace Impacto::Profile::SaveSystem;
using namespace Impacto::Profile::ScriptVars;
using namespace Impacto::Profile::Vm;
using namespace Impacto::Profile::ConfigSystem;

uint32_t SaveSystem::CalculateChecksum(std::span<const uint8_t> bufferData,
                                       uint16_t initSum, uint16_t initXor,
                                       bool swapSrcBytes) {
  // Initialize checksum variables

  uint32_t checksumSum = initSum;

  uint32_t checksumXor = initXor;

  for (size_t i = 0; i < bufferData.size() - 1; i += 2) {
    uint16_t dataShort;
    memcpy(&dataShort, &bufferData[i], 2);
    if (swapSrcBytes) {
      dataShort = SDL_Swap16(dataShort);
    }
    checksumSum = checksumSum + dataShort;
    checksumXor = checksumXor ^ dataShort;
  }

  uint32_t result = (checksumSum << 16) | (checksumXor & 0xFFFF);
  return result;
}

void SaveSystem::InitializeSystemData() {
  auto& l = GetSaveLayout();
  auto systemData = GetSystemData();
  std::fill(systemData.begin(), systemData.end(), 0x00);

  Io::MemoryStream stream =
      Io::MemoryStream(systemData.data(), systemData.size(), false);

  stream.Seek(l.ConfigOffset, SEEK_SET);
  Io::WriteLE(&stream, (Uint16)(Default::TextSpeed * 60));
  Io::WriteLE(&stream, (Uint16)(Default::AutoSpeed * 60));
  Io::WriteLE(&stream, (Uint8)(Default::GroupVolumes[Audio::ACG_Voice] *
                               128));  // VOICE2vol
  Io::WriteLE(&stream, (Uint8)(Default::GroupVolumes[Audio::ACG_Voice] *
                               128));  // VOICEvol
  Io::WriteLE(&stream, (Uint8)(Default::GroupVolumes[Audio::ACG_BGM] * 256));
  Io::WriteLE(&stream,
              (Uint8)(Default::GroupVolumes[Audio::ACG_SE] * 128));  // SEvol
  Io::WriteLE(
      &stream,
      (Uint8)(Default::GroupVolumes[Audio::ACG_SE] * 0.6 * 128));  // SYSSEvol
  Io::WriteLE(&stream, (Uint8)(Default::GroupVolumes[Audio::ACG_Movie] * 128));
  Io::WriteLE(&stream, Default::SyncVoice);
  Io::WriteLE(&stream, !Default::SkipRead);

  stream.Seek(l.VoiceOffset, SEEK_SET);
  for (size_t i = 0; i < 33; i++) Io::WriteLE(&stream, !Default::VoiceMuted[i]);
  for (size_t i = 0; i < 33; i++)
    Io::WriteLE(&stream, (Uint8)(Default::VoiceVolume[i] * 128));

  stream.Seek(l.SkipVoiceOffset, SEEK_SET);
  Io::WriteLE(&stream, Default::SkipVoice);
  Io::WriteLE(&stream, Default::ShowTipsNotification);

  stream.Seek(l.AdvanceTextOffset, SEEK_SET);
  Io::WriteLE(&stream, Default::AdvanceTextOnDirectionalInput);
  Io::WriteLE(&stream, Default::DirectionalInputForTrigger);
  Io::WriteLE(&stream, Default::TriggerStopSkip);

  InitSaveSlots();

  const RectF viewport = Window->GetViewport();
  WorkingSaveThumbnail.Sheet = SpriteSheet(viewport.Width, viewport.Height);
  WorkingSaveThumbnail.Bounds.SetSize(viewport.GetSize());

  Texture workingSaveTexture = Texture();
  workingSaveTexture.LoadSolidColor(
      static_cast<int>(WorkingSaveThumbnail.Bounds.Width),
      static_cast<int>(WorkingSaveThumbnail.Bounds.Height), 0x000000);
  WorkingSaveThumbnail.Sheet.Texture = workingSaveTexture.Submit();
}

void SaveSystem::LoadEntryBuffer(Io::MemoryStream& stream, SaveFileEntry& entry,
                                 SaveType saveType, Texture& tex) {
  auto& l = GetSaveLayout();
  entry.Status = Io::ReadLE<uint8_t>(&stream);
  Io::ReadLE<uint8_t>(&stream);
  uint16_t checksumSum = Io::ReadLE<uint16_t>(&stream);
  uint16_t checksumXor = Io::ReadLE<uint16_t>(&stream);

  entry.Checksum = checksumSum << 16 | checksumXor;
  Io::ReadLE<uint16_t>(&stream);
  uint16_t saveYear = Io::ReadLE<uint16_t>(&stream);
  uint8_t saveDay = Io::ReadLE<uint8_t>(&stream);
  uint8_t saveMonth = Io::ReadLE<uint8_t>(&stream);
  uint8_t saveSecond = Io::ReadLE<uint8_t>(&stream);
  uint8_t saveMinute = Io::ReadLE<uint8_t>(&stream);
  uint8_t saveHour = Io::ReadLE<uint8_t>(&stream);
  std::tm t{};
  t.tm_sec = saveSecond;
  t.tm_min = saveMinute;
  t.tm_hour = saveHour;
  t.tm_mday = saveDay;
  t.tm_mon = saveMonth - 1;
  t.tm_year = saveYear - 1900;
  entry.SaveDate = t;

  Io::ReadLE<uint8_t>(&stream);
  entry.PlayTime = Io::ReadLE<uint32_t>(&stream);
  entry.SwTitle = Io::ReadLE<uint32_t>(&stream);
  Io::ReadLE<uint32_t>(&stream);
  entry.Flags = Io::ReadLE<uint8_t>(&stream);
  stream.Seek(7, SEEK_CUR);
  entry.SaveType = Io::ReadLE<uint32_t>(&stream);
  assert(stream.Position == 0x28);
  stream.Seek(0x58, SEEK_CUR);
  ReadWorkScriptData(stream, entry);

  assert(stream.Position == l.MainThreadOffset);
  entry.MainThreadExecPriority = Io::ReadLE<uint32_t>(&stream);
  entry.MainThreadGroupId = Io::ReadLE<uint32_t>(&stream);
  entry.MainThreadWaitCounter = Io::ReadLE<uint32_t>(&stream);
  entry.MainThreadScriptParam = Io::ReadLE<uint32_t>(&stream);
  entry.MainThreadIp = Io::ReadLE<uint32_t>(&stream);
  entry.MainThreadLoopCounter = Io::ReadLE<uint32_t>(&stream);
  entry.MainThreadLoopAdr = Io::ReadLE<uint32_t>(&stream);
  entry.MainThreadCallStackDepth = Io::ReadLE<uint32_t>(&stream);
  for (int j = 0; j < 8; j++) {
    entry.MainThreadReturnIds[j] = Io::ReadLE<uint32_t>(&stream);
  }
  for (int j = 0; j < 8; j++) {
    entry.MainThreadReturnBufIds[j] = Io::ReadLE<uint32_t>(&stream);
  }
  Io::ReadLE<uint32_t>(&stream);
  assert(stream.Position == l.MainThreadBufIdOffset);
  entry.MainThreadScriptBufferId = Io::ReadLE<uint32_t>(&stream);
  Io::ReadArrayBE<int>(entry.MainThreadVariables.data(), &stream, 16);
  entry.MainThreadDialoguePageId = Io::ReadLE<uint32_t>(&stream);
  assert(stream.Position == l.WaveOffset);
  ReadWaveData(stream, entry);
  assert(stream.Position == l.MapLoadOffset);
  Io::ReadArrayLE<uint8_t>(entry.GetMapLoadData().data(), &stream,
                           entry.GetMapLoadData().size());
  Io::ReadArrayLE<uint8_t>(entry.GetYesNoData().data(), &stream,
                           entry.GetYesNoData().size());

  auto width = static_cast<float>(l.ThumbnailWidth);
  auto height = static_cast<float>(l.ThumbnailHeight);
  Sprite& thumbnail = entry.SaveThumbnail;
  thumbnail.Sheet = SpriteSheet(width, height);
  thumbnail.Bounds = RectF(0.0f, 0.0f, width, height);

  tex.Init(TexFmt_RGB, l.ThumbnailWidth, l.ThumbnailHeight);

  stream.Seek(l.ThumbnailPadding, SEEK_CUR);
  Io::ReadArrayLE<uint8_t>(entry.GetThumbnailData().data(), &stream,
                           entry.GetThumbnailData().size());

  for (size_t i = 0; i < entry.GetThumbnailData().size() / 2; i++) {
    uint16_t pixel = entry.GetThumbnailData()[i * 2] |
                     (entry.GetThumbnailData()[i * 2 + 1] << 8);
    uint8_t r = (pixel & 0xF800) >> 8;
    uint8_t g = (uint8_t)((pixel & 0x07E0) >> 3);
    uint8_t b = (pixel & 0x001F) << 3;
    tex.Buffer[3 * i] = r;
    tex.Buffer[3 * i + 1] = g;
    tex.Buffer[3 * i + 2] = b;
  }
}

void SaveSystem::FlushWorkingSaveEntry(SaveType type, int id,
                                       int autoSaveType) {
  auto* entry = GetSaveEntry<SaveFileEntry>(type, id);
  if (entry != nullptr && !(entry->Flags & WriteProtect)) {
    Renderer->FreeTexture(entry->SaveThumbnail.Sheet.Texture);
    uint8_t savedFlags = entry->Flags;
    UpdateWorkingSaveEntry(entry);
    entry->Flags = savedFlags;
    if (type == SaveType::Quick) {
      entry->SaveType = autoSaveType;
      UpdateQuickSaveRecentSortedId(id);
    }
    entry->SaveDate = CurrentDateTime();
    auto captureBuffer =
        Renderer->GetSpriteSheetImage(WorkingSaveThumbnail.Sheet);

    auto& l = GetSaveLayout();
    auto width = static_cast<float>(l.ThumbnailWidth);
    auto height = static_cast<float>(l.ThumbnailHeight);
    Texture tex;
    tex.Init(TexFmt_RGBA, l.ThumbnailWidth, l.ThumbnailHeight);
    entry->SaveThumbnail.Sheet = SpriteSheet(width, height);
    entry->SaveThumbnail.Bounds = RectF(0.0f, 0.0f, width, height);

    int result =
        ResizeImage(WorkingSaveThumbnail.Bounds, entry->SaveThumbnail.Bounds,
                    captureBuffer, tex.Buffer);
    if (result < 0) {
      ImpLog(LogLevel::Error, LogChannel::General,
             "Failed to resize save thumbnail\n");
    }
    entry->SaveThumbnail.Sheet.Texture = tex.Submit();
  }
}

void SaveSystem::SaveEntryBuffer(Io::MemoryStream& memoryStream,
                                 SaveFileEntry& entry, SaveType saveType) {
  [[maybe_unused]] auto& l = GetSaveLayout();
  Io::WriteLE<uint16_t>(&memoryStream, entry.Status);
  Io::WriteLE<uint32_t>(&memoryStream, entry.Checksum);
  Io::WriteLE<uint16_t>(&memoryStream, 0);

  Io::WriteLE<uint16_t>(&memoryStream,
                        (uint16_t)(entry.SaveDate.tm_year + 1900));
  Io::WriteLE<uint8_t>(&memoryStream, (uint8_t)entry.SaveDate.tm_mday);
  Io::WriteLE<uint8_t>(&memoryStream, (uint8_t)(entry.SaveDate.tm_mon + 1));
  Io::WriteLE<uint8_t>(&memoryStream, (uint8_t)entry.SaveDate.tm_sec);
  Io::WriteLE<uint8_t>(&memoryStream, (uint8_t)entry.SaveDate.tm_min);
  Io::WriteLE<uint8_t>(&memoryStream, (uint8_t)entry.SaveDate.tm_hour);
  Io::WriteLE<uint8_t>(&memoryStream, 0);

  Io::WriteLE<uint32_t>(&memoryStream, entry.PlayTime);
  Io::WriteLE<uint32_t>(&memoryStream, entry.SwTitle);
  Io::WriteLE<uint32_t>(&memoryStream, 0);
  Io::WriteLE<uint8_t>(&memoryStream, entry.Flags);
  memoryStream.Seek(7, SEEK_CUR);
  Io::WriteLE<uint32_t>(&memoryStream, entry.SaveType);
  assert(memoryStream.Position == 0x28);
  memoryStream.Seek(0x58, SEEK_CUR);
  WriteWorkScriptData(memoryStream, entry);
  assert(memoryStream.Position == l.MainThreadOffset);
  Io::WriteLE<uint32_t>(&memoryStream, entry.MainThreadExecPriority);
  Io::WriteLE<uint32_t>(&memoryStream, entry.MainThreadGroupId);
  Io::WriteLE<uint32_t>(&memoryStream, entry.MainThreadWaitCounter);
  Io::WriteLE<uint32_t>(&memoryStream, entry.MainThreadScriptParam);
  Io::WriteLE<uint32_t>(&memoryStream, entry.MainThreadIp);
  Io::WriteLE<uint32_t>(&memoryStream, entry.MainThreadLoopCounter);
  Io::WriteLE<uint32_t>(&memoryStream, entry.MainThreadLoopAdr);
  Io::WriteLE<uint32_t>(&memoryStream, entry.MainThreadCallStackDepth);
  for (int j = 0; j < 8; j++) {
    Io::WriteLE<uint32_t>(&memoryStream, entry.MainThreadReturnIds[j]);
  }
  for (int j = 0; j < 8; j++) {
    Io::WriteLE<uint32_t>(&memoryStream, entry.MainThreadReturnBufIds[j]);
  }
  Io::WriteLE<uint32_t>(&memoryStream, 0);
  assert(memoryStream.Position == l.MainThreadBufIdOffset);
  Io::WriteLE<uint32_t>(&memoryStream, entry.MainThreadScriptBufferId);
  Io::WriteArrayBE<int>(entry.MainThreadVariables.data(), &memoryStream, 16);
  Io::WriteLE<uint32_t>(&memoryStream, entry.MainThreadDialoguePageId);
  assert(memoryStream.Position == l.WaveOffset);
  WriteWaveData(memoryStream, entry);

  assert(memoryStream.Position == l.MapLoadOffset);
  Io::WriteArrayLE<uint8_t>(entry.GetMapLoadData().data(), &memoryStream,
                            entry.GetMapLoadData().size());
  Io::WriteArrayLE<uint8_t>(entry.GetYesNoData().data(), &memoryStream,
                            entry.GetYesNoData().size());

  memoryStream.Seek(l.ThumbnailPadding, SEEK_CUR);
  Io::WriteArrayLE<uint8_t>(entry.GetThumbnailData().data(), &memoryStream,
                            entry.GetThumbnailData().size());
}

void SaveSystem::SaveThumbnailData() {
  auto& l = GetSaveLayout();
  auto saveThumbnailSize = l.ThumbnailWidth * l.ThumbnailHeight * 2;
  std::vector<uint8_t> thumbnailBuffer(saveThumbnailSize * 2);

  for (auto* entryArray : {FullSaveEntries, QuickSaveEntries}) {
    for (int i = 0; i < MaxSaveEntries; i++) {
      SaveFileEntry* entry = static_cast<SaveFileEntry*>(entryArray[i]);
      if (entry->Status == 0) continue;

      Renderer->GetSpriteSheetImage(entry->SaveThumbnail.Sheet,
                                    thumbnailBuffer);

      for (size_t j = 0; j < thumbnailBuffer.size(); j += 4) {
        uint8_t r = thumbnailBuffer[j];
        uint8_t g = thumbnailBuffer[j + 1];
        uint8_t b = thumbnailBuffer[j + 2];
        uint16_t pixel = ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3);
        pixel = SDL_Swap16BE(pixel);
        entry->GetThumbnailData()[j / 2] = pixel >> 8;
        entry->GetThumbnailData()[j / 2 + 1] = pixel & 0xFF;
      }
    }
  }
}

SaveError SaveSystem::LoadSystemData() {
  auto& l = GetSaveLayout();
  auto systemData = GetSystemData();
  Io::MemoryStream stream =
      Io::MemoryStream(systemData.data(), systemData.size(), false);

  /*
  uint16_t systemSum = Io::ReadLE<uint16_t>(&stream);
  uint16_t systemXor = Io::ReadLE<uint16_t>(&stream);
  */
  stream.Seek(0x14, SEEK_SET);

  stream.Seek(0x80, SEEK_SET);
  Io::ReadArrayLE<uint8_t>(&FlagWork[l.SysFlagWorkDst1], &stream, 50);
  Io::ReadArrayLE<uint8_t>(&FlagWork[l.SysFlagWorkDst2], &stream, 40);
  stream.Seek(0xDC, SEEK_SET);
  Io::ReadArrayLE<int>(&ScrWork[l.SysScrWorkDst1], &stream, l.SysScrWorkLen1);
  Io::ReadArrayLE<int>(&ScrWork[2000], &stream, 100);

  // Config settings
  stream.Seek(l.ConfigOffset, SEEK_SET);
  TextSpeed = Io::ReadLE<Uint16>(&stream) / 60.0f;
  AutoSpeed = Io::ReadLE<Uint16>(&stream) / 60.0f;
  stream.Seek(1, SEEK_CUR);  // VOICE2vol
  Audio::GroupVolumes[Audio::ACG_Voice] = Io::ReadLE<Uint8>(&stream) / 128.0f;
  Audio::GroupVolumes[Audio::ACG_BGM] = Io::ReadLE<Uint8>(&stream) / 256.0f;
  Audio::GroupVolumes[Audio::ACG_SE] = Io::ReadLE<Uint8>(&stream) / 128.0f;
  stream.Seek(1, SEEK_CUR);  // SYSSEvol
  Audio::GroupVolumes[Audio::ACG_Movie] = Io::ReadLE<Uint8>(&stream) / 128.0f;
  SyncVoice = Io::ReadLE<bool>(&stream);
  SkipRead = !Io::ReadLE<bool>(&stream);

  stream.Seek(l.VoiceOffset, SEEK_SET);
  for (size_t i = 0; i < 33; i++) VoiceMuted[i] = !Io::ReadLE<bool>(&stream);
  for (size_t i = 0; i < 33; i++)
    VoiceVolume[i] = Io::ReadLE<Uint8>(&stream) / 128.0f;

  stream.Seek(l.SkipVoiceOffset, SEEK_SET);
  SkipVoice = Io::ReadLE<bool>(&stream);
  ShowTipsNotification = Io::ReadLE<bool>(&stream);

  stream.Seek(l.AdvanceTextOffset, SEEK_SET);
  AdvanceTextOnDirectionalInput = Io::ReadLE<bool>(&stream);
  DirectionalInputForTrigger = Io::ReadLE<bool>(&stream);
  TriggerStopSkip = Io::ReadLE<bool>(&stream);

  if (l.QuickSortedIdIsLoaded) {
    stream.Seek(l.QuickSortedIdOffset, SEEK_SET);
    Io::ReadArrayLE<uint8_t>(QuickSaveRecentSortedId.data(), &stream,
                             QuickSaveRecentSortedId.size());
  }

  // EV Flags
  stream.Seek(l.EVFlagsOffset, SEEK_SET);
  auto EVFlags = GetEVFlags();
  size_t max = EVFlags.size() >> 3;
  for (size_t i = 0; i < max; i++) {
    auto val = Io::ReadU8(&stream);
    EVFlags[8 * i] = val & 1;
    EVFlags[8 * i + 1] = (val & 2) != 0;
    EVFlags[8 * i + 2] = (val & 4) != 0;
    EVFlags[8 * i + 3] = (val & 8) != 0;
    EVFlags[8 * i + 4] = (val & 0x10) != 0;
    EVFlags[8 * i + 5] = (val & 0x20) != 0;
    EVFlags[8 * i + 6] = (val & 0x40) != 0;
    EVFlags[8 * i + 7] = val >> 7;
  }

  stream.Seek(l.BgmFlagsOffset, SEEK_SET);
  ReadBGMFlags(stream);

  stream.Seek(l.MessageFlagsOffset, SEEK_SET);
  auto messageFlags = GetMessageFlags();
  Io::ReadArrayLE<uint8_t>(messageFlags.data(), &stream, messageFlags.size());

  // EPnewList goes here

  stream.Seek(l.ExtraDataOffset, SEEK_SET);
  auto gameExtraData = GetGameExtraData();
  Io::ReadArrayLE<uint8_t>(gameExtraData.data(), &stream, gameExtraData.size());

  return SaveError::OK;
}

void SaveSystem::SaveSystemData() {
  auto& l = GetSaveLayout();
  auto systemData = GetSystemData();
  Io::MemoryStream systemSaveStream =
      Io::MemoryStream(systemData.data(), systemData.size(), false);

  systemSaveStream.Seek(0x14, SEEK_SET);

  systemSaveStream.Seek(0x80, SEEK_SET);
  Io::WriteArrayLE<uint8_t>(&FlagWork[l.SysFlagWorkDst1], &systemSaveStream,
                            50);
  Io::WriteArrayLE<uint8_t>(&FlagWork[l.SysFlagWorkDst2], &systemSaveStream,
                            40);
  systemSaveStream.Seek(0xDC, SEEK_SET);
  Io::WriteArrayLE<int>(&ScrWork[l.SysScrWorkDst1], &systemSaveStream,
                        l.SysScrWorkLen1);
  Io::WriteArrayLE<int>(&ScrWork[2000], &systemSaveStream, 100);

  // Config settings
  systemSaveStream.Seek(l.ConfigOffset, SEEK_SET);
  Io::WriteLE(&systemSaveStream, (Uint16)(TextSpeed * 60));
  Io::WriteLE(&systemSaveStream, (Uint16)(AutoSpeed * 60));
  Io::WriteLE(
      &systemSaveStream,
      (Uint8)(Audio::GroupVolumes[Audio::ACG_Voice] * 128));  // VOICE2vol
  Io::WriteLE(
      &systemSaveStream,
      (Uint8)(Audio::GroupVolumes[Audio::ACG_Voice] * 128));  // VOICEvol
  Io::WriteLE(&systemSaveStream,
              (Uint8)(Audio::GroupVolumes[Audio::ACG_BGM] * 256));
  Io::WriteLE(&systemSaveStream,
              (Uint8)(Audio::GroupVolumes[Audio::ACG_SE] * 128));  // SEvol
  Io::WriteLE(
      &systemSaveStream,
      (Uint8)(Audio::GroupVolumes[Audio::ACG_SE] * 0.6 * 128));  // SYSSEvol
  Io::WriteLE(&systemSaveStream,
              (Uint8)(Audio::GroupVolumes[Audio::ACG_Movie] * 128));
  Io::WriteLE(&systemSaveStream, SyncVoice);
  Io::WriteLE(&systemSaveStream, !SkipRead);

  systemSaveStream.Seek(l.VoiceOffset, SEEK_SET);
  for (size_t i = 0; i < 33; i++)
    Io::WriteLE(&systemSaveStream, !VoiceMuted[i]);
  for (size_t i = 0; i < 33; i++)
    Io::WriteLE(&systemSaveStream, (Uint8)(VoiceVolume[i] * 128));

  systemSaveStream.Seek(l.SkipVoiceOffset, SEEK_SET);
  Io::WriteLE(&systemSaveStream, SkipVoice);
  Io::WriteLE(&systemSaveStream, ShowTipsNotification);

  systemSaveStream.Seek(l.AdvanceTextOffset, SEEK_SET);
  Io::WriteLE(&systemSaveStream, AdvanceTextOnDirectionalInput);
  Io::WriteLE(&systemSaveStream, DirectionalInputForTrigger);
  Io::WriteLE(&systemSaveStream, TriggerStopSkip);

  systemSaveStream.Seek(l.QuickSortedIdOffset, SEEK_SET);
  Io::WriteArrayLE<uint8_t>(QuickSaveRecentSortedId.data(), &systemSaveStream,
                            QuickSaveRecentSortedId.size());

  // EV Flags
  systemSaveStream.Seek(l.EVFlagsOffset, SEEK_SET);
  auto EVFlags = GetEVFlags();
  size_t max = EVFlags.size() >> 3;
  for (size_t i = 0; i < max; i++) {
    const uint8_t evByte = (static_cast<uint8_t>(EVFlags[8 * i])) |
                           (static_cast<uint8_t>(EVFlags[8 * i + 1]) << 1) |
                           (static_cast<uint8_t>(EVFlags[8 * i + 2]) << 2) |
                           (static_cast<uint8_t>(EVFlags[8 * i + 3]) << 3) |
                           (static_cast<uint8_t>(EVFlags[8 * i + 4]) << 4) |
                           (static_cast<uint8_t>(EVFlags[8 * i + 5]) << 5) |
                           (static_cast<uint8_t>(EVFlags[8 * i + 6]) << 6) |
                           (static_cast<uint8_t>(EVFlags[8 * i + 7]) << 7);
    Io::WriteLE<uint8_t>(&systemSaveStream, evByte);
  }

  systemSaveStream.Seek(l.BgmFlagsOffset, SEEK_SET);
  WriteBGMFlags(systemSaveStream);

  systemSaveStream.Seek(l.MessageFlagsOffset, SEEK_SET);
  auto messageFlags = GetMessageFlags();
  Io::WriteArrayLE<uint8_t>(messageFlags.data(), &systemSaveStream,
                            messageFlags.size());

  // EPnewList goes here

  systemSaveStream.Seek(l.ExtraDataOffset, SEEK_SET);
  auto gameExtraData = GetGameExtraData();
  Io::WriteArrayLE<uint8_t>(gameExtraData.data(), &systemSaveStream,
                            gameExtraData.size());
}

void SaveSystem::SetSaveFlags(SaveType type, int id, uint8_t flags) {
  auto* entry = GetSaveEntry<SaveFileEntry>(type, id);

  if (type == SaveType::Quick) {
    uint8_t currentFlags = entry->Flags;
    if ((currentFlags ^ flags) & WriteProtect) {
      if (flags & WriteProtect) {
        LockedQuickSaveCount++;
      } else {
        LockedQuickSaveCount--;
      }

      SetFlag(SF_SAVEALLPROTECTED, LockedQuickSaveCount == MaxSaveEntries);
    }
  }
  entry->Flags = flags;
}

tm const& SaveSystem::GetSaveDate(SaveType type, int id) const {
  return GetSaveEntry<SaveFileEntry>(type, id)->SaveDate;
}

uint32_t SaveSystem::GetSavePlayTime(SaveType type, int id) const {
  return GetSaveEntry<SaveFileEntry>(type, id)->PlayTime;
}

uint8_t SaveSystem::GetSaveFlags(SaveType type, int id) const {
  return GetSaveEntry<SaveFileEntry>(type, id)->Flags;
}

void SaveSystem::SaveMemory() {
  if (WorkingSaveEntry) {
    auto& l = GetSaveLayout();

    WorkingSaveEntry->Status = 1;

    const tm timeinfo = CurrentDateTime();
    WorkingSaveEntry->SaveDate = timeinfo;
    WorkingSaveEntry->PlayTime = ScrWork[SW_PLAYTIME];
    WorkingSaveEntry->SwTitle = ScrWork[SW_TITLE];

    std::copy(
        FlagWork.begin() + 50,
        FlagWork.begin() + 50 + WorkingSaveEntry->GetFlagWorkScript1().size(),
        WorkingSaveEntry->GetFlagWorkScript1().begin());
    std::copy(FlagWork.begin() + l.FlagWork2Src,
              FlagWork.begin() + l.FlagWork2Src +
                  WorkingSaveEntry->GetFlagWorkScript2().size(),
              WorkingSaveEntry->GetFlagWorkScript2().begin());
    std::copy(
        ScrWork.begin() + 1000,
        ScrWork.begin() + 1000 + WorkingSaveEntry->GetScrWorkScript1().size(),
        WorkingSaveEntry->GetScrWorkScript1().begin());
    std::copy(
        ScrWork.begin() + 4300,
        ScrWork.begin() + 4300 + WorkingSaveEntry->GetScrWorkScript2().size(),
        WorkingSaveEntry->GetScrWorkScript2().begin());

    int threadId = ScrWork[SW_MAINTHDP];
    Sc3VmThread* thd = &ThreadPool[threadId & 0x7FFFFFFF];
    if (thd->GroupId - 5 < 3) {
      WorkingSaveEntry->MainThreadExecPriority = thd->ExecPriority;
      WorkingSaveEntry->MainThreadWaitCounter = thd->WaitCounter;
      WorkingSaveEntry->MainThreadScriptParam = thd->ScriptParam;
      WorkingSaveEntry->MainThreadGroupId = thd->GroupId;
      WorkingSaveEntry->MainThreadScriptBufferId = thd->ScriptBufferId;
      // Checkpoint id should already be set by SetCheckpointId
      WorkingSaveEntry->MainThreadCallStackDepth = thd->CallStackDepth;
      for (size_t i = 0; i < thd->CallStackDepth; i++) {
        WorkingSaveEntry->MainThreadReturnBufIds[i] =
            thd->ReturnScriptBufferIds[i];
        WorkingSaveEntry->MainThreadReturnIds[i] = thd->ReturnIds[i];
      }
      memcpy(WorkingSaveEntry->MainThreadVariables.data(), thd->Variables,
             16 * sizeof(int));
      WorkingSaveEntry->MainThreadDialoguePageId = thd->DialoguePageId;
    }
    UI::CCLCC::MapSystem::GetInstance().MapSave(
        WorkingSaveEntry->GetMapLoadData().data());
    UI::CCLCC::YesNoTrigger::GetInstance().Save(
        WorkingSaveEntry->GetYesNoData().data());
    WaveSave(WorkingSaveEntry->GetWaveData());
  }
}

void SaveSystem::LoadMemoryNew(LoadProcess load) {
  if (!WorkingSaveEntry || WorkingSaveEntry->Status == 0) {
    ImpLog(LogLevel::Error, LogChannel::IO,
           "Failed to load entry: save is empty\n");
    return;
  }
  if (load == LoadProcess::Vars) {
    auto& l = GetSaveLayout();

    ScrWork[SW_PLAYTIME] = WorkingSaveEntry->PlayTime;
    ScrWork[SW_TITLE] = WorkingSaveEntry->SwTitle;
    ScrWork[SW_AUTOSAVERESTART] = WorkingSaveEntry->SaveType;

    std::ranges::copy(WorkingSaveEntry->GetFlagWorkScript1(),
                      FlagWork.begin() + 50);
    std::ranges::copy(WorkingSaveEntry->GetFlagWorkScript2(),
                      FlagWork.begin() + l.FlagWork2Src);
    std::ranges::copy(WorkingSaveEntry->GetScrWorkScript1(),
                      ScrWork.begin() + 1000);
    std::ranges::copy(WorkingSaveEntry->GetScrWorkScript2(),
                      ScrWork.begin() + 4300);

    UI::CCLCC::MapSystem::GetInstance().MapLoad(
        WorkingSaveEntry->GetMapLoadData().data());
    UI::CCLCC::YesNoTrigger::GetInstance().Load(
        WorkingSaveEntry->GetYesNoData().data());
    WaveLoad(WorkingSaveEntry->GetWaveData());

    LoadScrWork();
  } else if (ScrWork[SW_MAINTHDP] != 0) {
    int threadId = ScrWork[SW_MAINTHDP];
    Sc3VmThread* thd = &ThreadPool[threadId & 0x7FFFFFFF];

    if (thd->GroupId - 5 < 3) {
      thd->ExecPriority = WorkingSaveEntry->MainThreadExecPriority;
      thd->WaitCounter = WorkingSaveEntry->MainThreadWaitCounter;
      thd->ScriptParam = WorkingSaveEntry->MainThreadScriptParam;
      thd->GroupId = WorkingSaveEntry->MainThreadGroupId;
      thd->ScriptBufferId = WorkingSaveEntry->MainThreadScriptBufferId;
      thd->IpOffset =
          ScriptGetRetAddress(WorkingSaveEntry->MainThreadScriptBufferId,
                              WorkingSaveEntry->MainThreadIp);
      thd->CallStackDepth = WorkingSaveEntry->MainThreadCallStackDepth;

      for (size_t i = 0; i < thd->CallStackDepth; i++) {
        thd->ReturnScriptBufferIds[i] =
            WorkingSaveEntry->MainThreadReturnBufIds[i];
        thd->ReturnIds[i] = (uint16_t)WorkingSaveEntry->MainThreadReturnIds[i];
      }

      memcpy(thd->Variables, WorkingSaveEntry->MainThreadVariables.data(),
             16 * sizeof(int));
      thd->DialoguePageId = WorkingSaveEntry->MainThreadDialoguePageId;
    }
  }
}

uint8_t SaveSystem::GetSaveStatus(SaveType type, int id) const {
  return GetSaveEntry<SaveFileEntry>(type, id)->Status;
}

int SaveSystem::GetSaveTitle(SaveType type, int id) const {
  return GetSaveEntry<SaveFileEntry>(type, id)->SwTitle;
}

uint32_t SaveSystem::GetTipStatus(size_t tipId) const {
  auto gameExtraData = GetGameExtraData();
  tipId *= 3;
  uint8_t lockStatus = (gameExtraData[tipId >> 3] & Flbit[tipId & 7]) != 0;
  uint8_t newStatus =
      (gameExtraData[(tipId + 1) >> 3] & Flbit[(tipId + 1) & 7]) != 0;
  uint8_t unreadStatus =
      (gameExtraData[(tipId + 2) >> 3] & Flbit[(tipId + 2) & 7]) != 0;
  return (lockStatus | (unreadStatus << 1)) | (newStatus << 2);
}

void SaveSystem::SetTipStatus(size_t tipId, bool isLocked, bool isUnread,
                              bool isNew) {
  auto gameExtraData = GetGameExtraData();
  tipId *= 3;
  if (isLocked) {
    gameExtraData[tipId >> 3] &= ~(Flbit[tipId & 7]);
  } else {
    gameExtraData[tipId >> 3] |= Flbit[tipId & 7];
  }
  if (isUnread) {
    gameExtraData[(tipId + 2) >> 3] &= ~(Flbit[(tipId + 2) & 7]);
  } else {
    gameExtraData[(tipId + 2) >> 3] |= Flbit[(tipId + 2) & 7];
  }
  if (isNew) {
    gameExtraData[(tipId + 1) >> 3] &= ~(Flbit[(tipId + 1) & 7]);
  } else {
    gameExtraData[(tipId + 1) >> 3] |= Flbit[(tipId + 1) & 7];
  }
}

void SaveSystem::SetLineRead(const size_t scriptId, const size_t lineId) {
  const std::optional<size_t> offset = GetLineBitOffset(scriptId, lineId);

  if (!offset.has_value()) return;
  auto messageFlags = GetMessageFlags();

  // TODO: update some ScrWorks (2003, 2005 & 2006)

  messageFlags[*offset >> 3] |= Flbit[*offset & 0b111];
}

bool SaveSystem::IsLineRead(const size_t scriptId, const size_t lineId) const {
  const std::optional<size_t> offset = GetLineBitOffset(scriptId, lineId);
  if (!offset.has_value()) return false;
  auto messageFlags = GetMessageFlags();

  const uint8_t flbit = Flbit[*offset & 0b111];
  const uint8_t viewed = messageFlags[*offset >> 3];

  return static_cast<bool>(flbit & viewed);
}

void SaveSystem::GetReadMessagesCount(int* totalMessageCount,
                                      int* readMessageCount) const {
  *totalMessageCount = 0;
  *readMessageCount = 0;

  for (size_t scriptId = 0; scriptId < ScriptMessageData.size(); scriptId++) {
    ScriptMessageDataPair script = ScriptMessageData[scriptId];
    *totalMessageCount += script.LineCount;

    for (size_t lineId = 0; lineId < script.LineCount; lineId++) {
      *readMessageCount += IsLineRead(scriptId, lineId);
    }
  }
}

void SaveSystem::GetViewedEVsCount(int* totalEVCount,
                                   int* viewedEVCount) const {
  auto EVFlags = GetEVFlags();
  for (int i = 0; i < MaxAlbumEntries; i++) {
    if (AlbumEvData[i][0] == 0xFFFF) break;
    for (int j = 0; j < MaxAlbumSubEntries; j++) {
      if (AlbumEvData[i][j] == 0xFFFF) break;
      *totalEVCount += 1;
      *viewedEVCount += EVFlags[AlbumEvData[i][j]];
    }
  }
}
void SaveSystem::GetEVStatus(int evId, int* totalVariations,
                             int* viewedVariations) const {
  auto EVFlags = GetEVFlags();
  *totalVariations = 0;
  *viewedVariations = 0;
  for (int i = 0; i < MaxAlbumSubEntries; i++) {
    if (AlbumEvData[evId][i] == 0xFFFF) break;
    *totalVariations += 1;
    *viewedVariations += EVFlags[AlbumEvData[evId][i]];
  }
}

void SaveSystem::SetEVStatus(int id) {
  auto EVFlags = GetEVFlags();
  EVFlags[id] = true;
}

bool SaveSystem::GetEVVariationIsUnlocked(size_t evId,
                                          size_t variationIdx) const {
  if (AlbumEvData[evId][variationIdx] == 0xFFFF) return false;
  auto EVFlags = GetEVFlags();

  return EVFlags[AlbumEvData[evId][variationIdx]];
}

bool SaveSystem::GetBgmFlag(int id) const {
  auto BGMFlags = GetBGMFlags();
  return BGMFlags[id];
}
void SaveSystem::SetBgmFlag(int id, bool flag) {
  auto BGMFlags = GetBGMFlags();
  BGMFlags[id] = flag;
}

void SaveSystem::SetCheckpointId(int id) {
  if (WorkingSaveEntry) WorkingSaveEntry->MainThreadIp = id;
}

Sprite& SaveSystem::GetSaveThumbnail(SaveType type, int id) {
  return GetSaveEntry<SaveFileEntry>(type, id)->SaveThumbnail;
}

void SaveSystem::WaveSave(std::span<int> data) {
  size_t offset = 0;
  for (size_t i = 0; i < 20; i++) {
    data[offset++] = WaveBG.WaveData[i].Flags;
    data[offset++] = WaveBG.WaveData[i].Amplitude;
    data[offset++] = WaveBG.WaveData[i].TemporalFrequency;
    data[offset++] = WaveBG.WaveData[i].Phase;
    data[offset++] = WaveBG.WaveData[i].SpatialFrequency;
  }
  data[offset++] = WaveBG.WaveCount;

  for (size_t i = 0; i < 20; i++) {
    data[offset++] = WaveCHA.WaveData[i].Flags;
    data[offset++] = WaveCHA.WaveData[i].Amplitude;
    data[offset++] = WaveCHA.WaveData[i].TemporalFrequency;
    data[offset++] = WaveCHA.WaveData[i].Phase;
    data[offset++] = WaveCHA.WaveData[i].SpatialFrequency;
  }
  data[offset++] = WaveCHA.WaveCount;

  for (size_t i = 0; i < 20; i++) {
    data[offset++] = WaveEFF.WaveData[i].Flags;
    data[offset++] = WaveEFF.WaveData[i].Amplitude;
    data[offset++] = WaveEFF.WaveData[i].TemporalFrequency;
    data[offset++] = WaveEFF.WaveData[i].Phase;
    data[offset++] = WaveEFF.WaveData[i].SpatialFrequency;
  }
  data[offset++] = WaveEFF.WaveCount;
}

void SaveSystem::WaveLoad(std::span<const int> data) const {
  size_t offset = 0;
  for (size_t i = 0; i < 20; i++) {
    WaveBG.WaveData[i].Flags = data[offset++];
    WaveBG.WaveData[i].Amplitude = data[offset++];
    WaveBG.WaveData[i].TemporalFrequency = data[offset++];
    WaveBG.WaveData[i].Phase = data[offset++];
    WaveBG.WaveData[i].SpatialFrequency = data[offset++];
  }
  WaveBG.WaveCount = data[offset++];

  for (size_t i = 0; i < 20; i++) {
    WaveCHA.WaveData[i].Flags = data[offset++];
    WaveCHA.WaveData[i].Amplitude = data[offset++];
    WaveCHA.WaveData[i].TemporalFrequency = data[offset++];
    WaveCHA.WaveData[i].Phase = data[offset++];
    WaveCHA.WaveData[i].SpatialFrequency = data[offset++];
  }
  WaveCHA.WaveCount = data[offset++];

  for (size_t i = 0; i < 20; i++) {
    WaveEFF.WaveData[i].Flags = data[offset++];
    WaveEFF.WaveData[i].Amplitude = data[offset++];
    WaveEFF.WaveData[i].TemporalFrequency = data[offset++];
    WaveEFF.WaveData[i].Phase = data[offset++];
    WaveEFF.WaveData[i].SpatialFrequency = data[offset++];
  }
  WaveEFF.WaveCount = data[offset++];
}

}  // namespace CCLCC
}  // namespace Impacto