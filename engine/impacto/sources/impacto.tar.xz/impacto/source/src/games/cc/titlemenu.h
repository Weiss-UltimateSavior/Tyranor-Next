#pragma once

#include "../../animation.h"
#include "../../ui/menu.h"
#include "../../ui/widgets/group.h"
#include "../../ui/widgets/button.h"
#include "../../ui/widgets/cc/titlebutton.h"

namespace Impacto {
namespace UI {
namespace CC {

class TitleMenu : public Menu {
 public:
  TitleMenu();

  void Show() override;
  void Hide() override;
  void UpdateInput(float dt) override;
  void Update(float dt) override;
  void Render() override;

  Animation PressToStartAnimation;
  Animation ItemsFadeInAnimation;
  Animation SecondaryItemsFadeInAnimation;
  Animation SmokeAnimation;
  Animation MoveLeftAnimation;

  void MenuButtonOnClick(Widgets::Button* target);
  void ContinueButtonOnClick(Widgets::Button* target);
  void ExtraButtonOnClick(Widgets::Button* target);

 private:
  Widgets::Group* CurrentSubMenu = 0;

  Widgets::Group* MainItems;
  Widgets::CC::TitleButton* NewGame;
  Widgets::CC::TitleButton* Continue;
  Widgets::CC::TitleButton* Extra;
  Widgets::CC::TitleButton* Config;
  Widgets::CC::TitleButton* Help;

  Widgets::Group* ContinueItems;
  Widgets::CC::TitleButton* Load;
  Widgets::CC::TitleButton* QuickLoad;
  // void ShowContinueItems();
  // void HideContinueItems();

  Widgets::Group* ExtraItems;
  Widgets::CC::TitleButton* Tips;
  Widgets::CC::TitleButton* Library;
  Widgets::CC::TitleButton* EndingList;
  // void ShowExtraItems();
  // void HideExtraItems();

  void DrawMainBackground(float opacity = 1.0f);
  void DrawStartButton();
  void DrawSmoke(float opacity);
};

namespace TitleMenuMode {
namespace PS4 {
enum Mode : uint8_t {
  Invisible = 0,
  PressToStart = 1,
  StartTransition = 2,
  Main = 3,
  FadingOut = 4,
  SubMenu = 5,
  InitialFade = 11,
  ClearList = 13
};
}
namespace Switch {
enum Mode : uint8_t {
  Invisible = 0,
  PressToStart = 2,
  StartTransition = 3,
  Main = 10,
  SubMenu = 11,
  FadingOut = 12,
  ClearList = 13,
  FadingIn = 16,
  InitialFade = 18,
};
}

}  // namespace TitleMenuMode

}  // namespace CC
}  // namespace UI
}  // namespace Impacto