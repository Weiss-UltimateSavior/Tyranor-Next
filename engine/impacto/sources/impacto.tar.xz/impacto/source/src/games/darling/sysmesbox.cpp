#include "sysmesbox.h"

#include "../../profile/ui/sysmesbox.h"
#include "../../profile/games/darling/sysmesbox.h"
#include "../../profile/dialogue.h"
#include "../../profile/scriptvars.h"
#include "../../mem.h"
#include "../../renderer/renderer.h"

namespace Impacto {
namespace UI {
namespace Darling {

using namespace Impacto::UI::Widgets;
using namespace Impacto::Profile::ScriptVars;
using namespace Impacto::Profile::SysMesBox;
using namespace Impacto::Profile::Darling::SysMesBox;

void SysMesBox::ChoiceItemOnClick(Button* target) {
  ScrWork[SW_SYSSEL] = target->Id;
  ChoiceMade = true;
}

void SysMesBox::Show() {
  MessageItems = std::make_unique<Widgets::Group>(this);
  ChoiceItems = std::make_unique<Widgets::Group>(this);

  Sprite nullSprite = Sprite();
  nullSprite.Bounds = RectF(0.0f, 0.0f, 0.0f, 0.0f);

  auto onClick = [this](auto* btn) { return ChoiceItemOnClick(btn); };

  float diff = 0.0f;
  float maxWidth = FLT_MIN;
  for (int i = 0; i < MessageCount; i++) {
    if (maxWidth < MessageWidths[i]) maxWidth = MessageWidths[i];
  }
  if (maxWidth < BoxMinimumWidth) maxWidth = BoxMinimumWidth;

  for (int i = 0; i < MessageCount; i++) {
    if (Messages[i].empty()) continue;

    diff = Messages[i][0].Position.x - (TextX - (maxWidth / 2.0f));
    for (ProcessedTextGlyph& glyph : Messages[i]) {
      glyph.MoveTo(
          {glyph.Position.x - diff, TextMiddleY + (i * TextLineHeight)});
    }

    Label* message =
        new Label(Messages[i],
                  {TextX - maxWidth / 2.0f, TextMiddleY + i * TextLineHeight},
                  RendererOutlineMode::Full);

    MessageItems->Add(message, FDIR_DOWN);
  }

  float totalChoiceWidth = 0.0f;
  for (int i = 0; i < ChoiceCount; i++) {
    totalChoiceWidth += ChoiceWidths[i] + ChoicePadding;
  }
  if (maxWidth < totalChoiceWidth) maxWidth = totalChoiceWidth;
  if (maxWidth < MinMaxMesWidth) maxWidth = MinMaxMesWidth;

  ChoiceX = (maxWidth / 2.0f) - totalChoiceWidth + ChoiceXBase;

  float tempChoiceX = ChoiceX;

  for (int i = 0; i < ChoiceCount; i++) {
    diff = Choices[i][0].Position.x - tempChoiceX;
    for (ProcessedTextGlyph& glyph : Choices[i]) {
      glyph.MoveTo({glyph.Position.x - diff, ChoiceY});
    }

    Button* choice = new Button(
        i, nullSprite, nullSprite, SelectionHighlight,
        glm::vec2(Choices[i][0].DestRect.X, Choices[i][0].DestRect.Y));

    choice->SetText(Choices[i], ChoiceWidths[i],
                    Profile::Dialogue::DefaultFontSize,
                    RendererOutlineMode::Full);
    choice->OnClickHandler = onClick;

    ChoiceItems->Add(choice, FDIR_LEFT);

    tempChoiceX += ChoiceWidths[i] + ChoicePadding;
  }

  FadeAnimation.StartIn();
  MessageItems->Show();
  MessageItems->HasFocus = false;
  if (ChoiceCount != 0) ChoiceItems->Show();
  State = Showing;

  if (UI::FocusedMenu != 0) {
    LastFocusedMenu = UI::FocusedMenu;
    LastFocusedMenu->IsFocused = false;
  }
  IsFocused = true;
  UI::FocusedMenu = this;
}

void SysMesBox::Hide() {
  FadeAnimation.StartOut();
  State = Hiding;
  if (LastFocusedMenu != 0) {
    UI::FocusedMenu = LastFocusedMenu;
    LastFocusedMenu->IsFocused = true;
  } else {
    UI::FocusedMenu = 0;
  }
  IsFocused = false;
}

void SysMesBox::Update(float dt) {
  UpdateInput(dt);

  FadeAnimation.Update(dt);
  if (State != Hidden) {
    if (FadeAnimation.IsIn()) State = Shown;
    if (FadeAnimation.IsOut()) State = Hidden;

    if (IsFocused) {
      MessageItems->Update(dt);
      ChoiceItems->Update(dt);
      ChoiceItems->UpdateInput(dt);
    }
  }
}

void SysMesBox::Render() {
  if (State == Hidden) return;

  glm::vec4 col(1.0f, 1.0f, 1.0f, FadeAnimation.Progress);

  float maxWidth = FLT_MIN;
  for (int i = 0; i < MessageCount; i++) {
    if (maxWidth < MessageWidths[i]) maxWidth = MessageWidths[i];
  }
  if (maxWidth < BoxMinimumWidth) maxWidth = BoxMinimumWidth;

  float leftStartX = BoxMiddleBaseX - (maxWidth / 2.0f);
  Renderer->DrawSprite(BoxPartLeft, glm::vec2(leftStartX, BoxY), col);

  BoxPartMiddle.BaseScale =
      glm::vec2((maxWidth - BoxRightBaseWidth) / BoxMiddleBaseWidth, 1.0f);
  Renderer->DrawSprite(BoxPartMiddle,
                       glm::vec2(leftStartX + BoxRightRemainPad, BoxY), col);

  Renderer->DrawSprite(
      BoxPartRight, glm::vec2(leftStartX + maxWidth + BoxRightBaseWidth, BoxY),
      col);

  MessageItems->Tint.a = FadeAnimation.Progress;
  MessageItems->Render();
  ChoiceItems->Tint.a = FadeAnimation.Progress;
  ChoiceItems->Render();
}

void SysMesBox::Init() {
  ChoiceMade = false;
  MessageCount = 0;
  ChoiceCount = 0;

  FadeAnimation.DurationIn = FadeInDuration;
  FadeAnimation.DurationOut = FadeOutDuration;
  FadeAnimation.Direction = AnimationDirection::In;
  FadeAnimation.LoopMode = AnimationLoopMode::Stop;
}

void SysMesBox::AddMessage(Vm::BufferOffsetContext ctx) {
  Impacto::Vm::Sc3VmThread dummy;
  dummy.IpOffset = ctx.IpOffset;
  dummy.ScriptBufferId = ctx.BufferId;
  Messages[MessageCount] =
      TextLayoutPlainLine(&dummy, 255, *Profile::Dialogue::DialogueFont,
                          TextFontSize, Profile::Dialogue::ColorTable[0], 1.0f,
                          glm::vec2(TextX, 0.0f), TextAlignment::Left);
  MessageWidths[MessageCount] = GetTextWidth(Messages[MessageCount]);
  MessageCount++;
}

void SysMesBox::AddChoice(Vm::BufferOffsetContext ctx) {
  Impacto::Vm::Sc3VmThread dummy;
  dummy.IpOffset = ctx.IpOffset;
  dummy.ScriptBufferId = ctx.BufferId;
  Choices[ChoiceCount] =
      TextLayoutPlainLine(&dummy, 255, *Profile::Dialogue::DialogueFont,
                          TextFontSize, Profile::Dialogue::ColorTable[0], 1.0f,
                          glm::vec2(TextX, 0.0f), TextAlignment::Left);
  ChoiceWidths[ChoiceCount] = GetTextWidth(Choices[ChoiceCount]);
  ChoiceCount++;
}

}  // namespace Darling
}  // namespace UI
}  // namespace Impacto