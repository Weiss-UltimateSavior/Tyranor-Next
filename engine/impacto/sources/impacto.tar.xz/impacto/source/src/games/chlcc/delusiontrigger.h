#pragma once

#include "../../spriteanimation.h"
#include "../../ui/menu.h"
#include "../../ui/widgets/clickarea.h"

namespace Impacto {
namespace UI {
namespace CHLCC {
class DelusionTextSystem {
 public:
  static int constexpr MaxCharsPerLine = 90;
  std::array<std::array<const Sprite*, MaxCharsPerLine>, 3> GlyphLines;
  std::array<uint8_t, 300> LineOffsets{};

  std::optional<int> DelusionSelectedLine;
  float TextLineXOffset = 0;
  size_t TextIndex = 0;
  Animation DelusionTextFade;

  DelusionTextSystem();

  void Init();
  void Update(float dt);
  void Render();
  void Clear();

 private:
  void InitLineOffsets();
  void InitLines();
  void ScrollLine(size_t lineIndex);
  void FillLine(size_t& counter, std::span<const Sprite*> line);
};

class DelusionTrigger {
 public:
  enum DelusionState { DS_Neutral, DS_Positive, DS_Negative };
  DelusionTrigger();

  void Show();
  void Hide();
  void Update(float dt);
  void UpdateHeartButtons();
  void Render();
  void Load();
  void Reset();

  static DelusionTrigger& GetInstance() {
    static DelusionTrigger impl;
    return impl;
  };

  UI::MenuState State = UI::Hidden;

 protected:
  void UpdateShowing(float dt);
  void UpdateShown(float dt);
  void UpdateHiding(float dt);
  void PlayClickSound();
  void TriggerLeft();
  void TriggerRight();
  void HeartButtonOnClick(Widgets::ClickArea* target);
  bool AreHeartButtonsVisible() const;
  void RenderHeartButton(Sprite const& sprite, glm::vec2 pos, bool hovered,
                         float alpha) const;
  void UpdateBgFadeCT();

  int& DelusionState;

  int MaskScaleFactor;
  int SpinAngle;
  int SpinRate;
  int UnderlayerAlpha;
  int BackgroundAlpha;

  int AnimCounter;
  int AnimationState;

  glm::vec4 TriggerOnTint;
  int TriggerOnTintAlpha;

  int UnderlayerXOffset, UnderlayerXRate;
  int ShakeState;
  int MaskOffsetX;
  Animation HeartButtonFade;
  Animation HeartPulseAnimation;
  Animation LeftHeartFade;
  Animation RightHeartFade;
  Widgets::ClickArea LeftHeartClickArea;
  Widgets::ClickArea RightHeartClickArea;

  DelusionTextSystem TextSystem;

  friend DelusionTextSystem;
};

}  // namespace CHLCC
}  // namespace UI
}  // namespace Impacto
