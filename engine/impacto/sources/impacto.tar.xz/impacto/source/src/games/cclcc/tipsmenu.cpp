#include "tipsmenu.h"

#include "../../renderer/renderer.h"
#include "../../mem.h"
#include "../../vm/vm.h"
#include "../../inputsystem.h"
#include "../../profile/scriptvars.h"
#include "../../profile/vm.h"
#include "../../profile/dialogue.h"
#include "../../profile/ui/backlogmenu.h"
#include "../../profile/ui/tipsmenu.h"
#include "../../profile/games/cclcc/tipsmenu.h"
#include "../../profile/games/cclcc/systemmenu.h"
#include "../../io/memorystream.h"
#include "../../data/tipssystem.h"
#include "../../vm/interface/input.h"
#include "../../profile/game.h"
#include "../../audio/audiosystem.h"

#include "../../ui/widgets/cclcc/tipstabgroup.h"
namespace Impacto {
namespace UI {
namespace CCLCC {

using namespace Impacto::Profile::TipsMenu;
using namespace Impacto::Profile::CCLCC::TipsMenu;
using namespace Impacto::Profile::ScriptVars;

using namespace Impacto::Vm::Interface;

using namespace Impacto::UI::Widgets;
using namespace Impacto::UI::Widgets::CCLCC;

TipsMenu::TipsMenu() : CommonMenu(FadeAnimation), TipViewItems(this) {
  TransitionAnimation.DurationIn = TransitionInDuration;
  TransitionAnimation.DurationOut = TransitionOutDuration;

  Name = new Label();
  Pronunciation = new Label();
  Category = new Label();
  Number = new Label();

  Name->Bounds.SetPos(NamePos);
  Pronunciation->Bounds.SetPos(PronunciationPos);
  Category->Bounds.SetPos(CategoryPos);
  Number->Bounds.SetPos(NumberPos);

  TipViewItems.Add(Name);
  TipViewItems.Add(Pronunciation);
  TipViewItems.Add(Category);
  TipViewItems.Add(Number);

  TextPage.Clear();

  TipsScrollStartPos = {TipsScrollDetailsX, TipsScrollYStart};

  TipsScrollTrackBounds = {TipsScrollThumbSprite.Bounds.Width,
                           TipsScrollYEnd - TipsScrollYStart};
}

void TipsMenu::Show() {
  if (State != Shown) {
    LastYPos = 0;
    State = Showing;

    if (UI::FocusedMenu != 0) {
      LastFocusedMenu = UI::FocusedMenu;
      LastFocusedMenu->IsFocused = false;
    }
    UI::FocusedMenu = this;

    for (int i = 0; i < TabCount; i++) {
      TipsTabs[i]->UpdateTipsEntries(SortedTipIds);
      if (TipsTabs[i]->GetTipEntriesCount() > 0) {
        CurrentTabType = static_cast<TipsTabType>(i);
      }
    }

    CommonMenu::OnShow(FadeInDuration, FadeOutDuration, FadeAnimation);

    Name->Bounds.SetPos(NamePos);
    Pronunciation->Bounds.SetPos(PronunciationPos);
    Category->Bounds.SetPos(CategoryPos);
    Number->Bounds.SetPos(NumberPos);

    TipsTabs[CurrentTabType]->Show();
    TipViewItems.Show();
    if (ScrWork[SW_SYSSUBMENUCT] != 32) {
      TipsTabs[CurrentTabType]->Move({0, Profile::Game::DesignHeight / 2});
      TipViewItems.Move({0, Profile::Game::DesignHeight / 2});
      TextPage.Move({0, Profile::Game::DesignHeight / 2});
      TransitionAnimation.StartIn();
    } else {
      TransitionAnimation.Progress = 1.0f;
      LastYPos = Profile::Game::DesignHeight / 2;
    }
    FadeAnimation.StartIn();
  }
}
void TipsMenu::Hide() {
  if (State != Hidden) {
    State = Hiding;
    FadeAnimation.StartOut();
    // Switch has this sfx played in the script
    if (Profile::Vm::GameInstructionSet != Vm::InstructionSet::LCCSwitch) {
      Audio::PlayInGroup(Audio::ACG_SE, "sysse", 3, false, 0);
    }
    if (ScrWork[SW_SYSSUBMENUCT] != 0) {
      TransitionAnimation.StartOut();
    } else {
      TransitionAnimation.Progress = 0.0f;
    }
    if (LastFocusedMenu != 0) {
      UI::FocusedMenu = LastFocusedMenu;
    } else {
      UI::FocusedMenu = 0;
    }
  }
}

void TipsMenu::UpdateInput(float dt) {
  if (State == Shown) {
    Menu::UpdateInput(dt);
    if (PADinputButtonWentDown & PAD1R1) {
      TipsTabType type =
          static_cast<TipsTabType>((CurrentTabType + 1) % TabCount);
      while (!TipsTabs[type]->GetTipEntriesCount()) {
        type = static_cast<TipsTabType>((type + 1) % TabCount);
      }
      SetActiveTab(type);
    } else if (PADinputButtonWentDown & PAD1L1) {
      TipsTabType type =
          static_cast<TipsTabType>((CurrentTabType + TabCount - 1) % TabCount);
      while (!TipsTabs[type]->GetTipEntriesCount()) {
        type = static_cast<TipsTabType>((type + TabCount - 1) % TabCount);
      }
      SetActiveTab(type);
    }

    if (CurrentlyDisplayedTipId != -1) {
      int scrollDistance = 10;
      if (Input::CurMousePos != Input::PrevMousePos) {
        const TextModeInfo& textModeInfo =
            TextModesInfo[Profile::Dialogue::TipsMessageModeIdx];
        RectF pageBounds =
            RectF(textModeInfo.WindowPos.x, textModeInfo.WindowPos.y,
                  textModeInfo.MaxLineWidth, TipsTextPageHeight);
        MouseInTextBounds = pageBounds.ContainsPoint(Input::CurMousePos);
      }

      bool upScroll = PADinputButtonIsDown & PADcustom[32];
      bool downScroll = PADinputButtonIsDown & PADcustom[33];

      int remainingScroll = (int)(TipsScrollbar->EndValue - TipPageY);
      if (upScroll && downScroll) {
      } else if (upScroll && TipPageY > 0) {
        if (scrollDistance > TipPageY) {
          scrollDistance = (int)TipPageY;
        }
        TipPageY -= scrollDistance;

      } else if (downScroll && remainingScroll > 0) {
        if (scrollDistance > remainingScroll) {
          scrollDistance = remainingScroll;
        }
        TipPageY += scrollDistance;
      }
    }
  }
}

void TipsMenu::Update(float dt) {
  if (!HasInitialized) return;
  if (LastSubMenuCt > ScrWork[SW_SYSSUBMENUCT] &&
      ScrWork[SW_SYSSUBMENUCT] < 32 && State != Hidden && State != Hiding) {
    Hide();
  } else if (LastSubMenuCt < ScrWork[SW_SYSSUBMENUCT] &&
             ScrWork[SW_SYSSUBMENUCT] > 0 && State != Shown &&
             State != Showing && (ScrWork[SW_SYSSUBMENUNO] == 2)) {
    Show();
  }

  if (State != Hidden) {
    FadeAnimation.Update(dt);
    TransitionAnimation.Update(dt);
    if (State == Shown) {
      for (int i = 0; i < TabCount; i++) {
        TipsTabs[i]->Update(dt);
      }
    }
  }

  if (State == Shown && ScrWork[SW_SYSSUBMENUNO] == 2) {
    float oldPageY = TipPageY;
    UpdateInput(dt);
    if (TipsScrollbar) {
      TipsScrollbar->UpdateInput(dt);
      if ((PADinputMouseWentDown & PAD1A) && TipsScrollbar->IsScrollHeld()) {
        Audio::PlayInGroup(Audio::ACG_SE, "sysse", 2, false, 0);
      }
      TipsScrollbar->Update(dt);
      if (oldPageY != TipPageY) {
        TextPage.Move({0, oldPageY - TipPageY});
      }
    }
  }

  if (State == Showing && FadeAnimation.Progress == 1.0f &&
      TransitionAnimation.Progress == 1.0f && ScrWork[SW_SYSSUBMENUCT] == 32) {
    State = Shown;
    IsFocused = true;
  } else if (State == Hiding && FadeAnimation.Progress == 0.0f &&
             TransitionAnimation.Progress == 0.0f &&
             ScrWork[SW_SYSSUBMENUCT] == 0) {
    State = Hidden;
    IsFocused = false;
    if (UI::FocusedMenu) UI::FocusedMenu->IsFocused = true;
    CurrentlyDisplayedTipId = -1;
    TipsTabs[CurrentTabType]->Hide();
    TipViewItems.Hide();
    TipsScrollbar.reset();
  }

  auto Move = [this](glm::vec2 offset) {
    LastYPos += offset.y;
    TipViewItems.Move(-offset);
    TipsTabs[CurrentTabType]->Move(-offset);
    TextPage.Move(-offset);
    if (TipsScrollbar) {
      TipsScrollbar->Move(-offset);
    }
  };

  if (TransitionAnimation.State == AnimationState::Playing) {
    float move = glm::mix(0.0f, Profile::Game::DesignHeight / 2,
                          TransitionAnimation.Progress) -
                 LastYPos;
    Move({0, move});

  } else if (TransitionAnimation.IsIn() && LastYPos != 0) {
    float move = Profile::Game::DesignHeight / 2 - LastYPos;
    Move({0, move});
  } else if (TransitionAnimation.IsOut() &&
             LastYPos != Profile::Game::DesignHeight / 2 && LastYPos != 0) {
    float move = -LastYPos;
    Move({0, move});
  }
  LastSubMenuCt = ScrWork[SW_SYSSUBMENUCT];
}

void TipsMenu::Render() {
  if (!HasInitialized) return;
  if (State == Hidden) return;

  glm::vec4 fade(1.0f, 1.0f, 1.0f,
                 glm::smoothstep(0.0f, 1.0f, FadeAnimation.Progress));
  glm::vec4 maskTint = fade;
  maskTint.a *= 0.85f;

  if (OpenedAsDirect) CommonMenu::DrawBgSprite<false>(State, FadeAnimation);

  Renderer->DrawSprite(
      BackgroundSprite,
      glm::vec2(0.0f, Profile::Game::DesignHeight / 2 - LastYPos), fade);
  TipsTabs[CurrentTabType]->Tint.a = fade.a;
  TipsTabs[CurrentTabType]->Render();

  if (CurrentlyDisplayedTipId != -1) {
    TipViewItems.Tint.a = fade.a;
    TipViewItems.Render();

    Profile::Dialogue::DialogueFont->DrawProcessedText(
        TextPage.Glyphs, FadeAnimation.Progress, FadeAnimation.Progress,
        RendererOutlineMode::None, &TipsMaskSheet);

    TipsScrollbar->Render();
  }

  if (ScrWork[SW_SYSSUBMENUNO] == 2) {
    CommonMenu::DrawOverlay();
    if (GetFlag(SF_TITLEMODE)) {
      CommonMenu::DrawSmoke(Profile::CCLCC::SystemMenu::SmokeOpacityNormal *
                            (1.0f - FadeAnimation.Progress));
    }
  }

  UI::DrawButtonPrompt(
      TipsGuideSprite,
      glm::vec2(
          TipsGuidePosition.x,
          TipsGuidePosition.y + Profile::Game::DesignHeight / 2 - LastYPos),
      fade);
}

void TipsMenu::Init() {
  auto* TipRecords = TipsSystem::GetTipRecords();
  SortedTipIds.clear();
  std::transform(
      TipRecords->begin(), TipRecords->end(), std::back_inserter(SortedTipIds),
      [](TipsSystem::TipsDataRecord const& record) { return record.Id; });
  std::sort(SortedTipIds.begin(), SortedTipIds.end(),
            TipsSystem::TipsComparator(TipsTextTableIndex,
                                       TipsTextSortStringIndex, 3));
  for (int i = 0; i < TabCount; i++) {
    TipsTabType type = static_cast<TipsTabType>(i);
    TipsTabs[i] = new TipsTabGroup(
        type, [this, type](Button*) { SetActiveTab(type); },
        [this](Button* target) { SwitchToTipId(target->Id); });
  }
  HasInitialized = true;
}

void TipsMenu::SwitchToTipId(int id) {
  if (id - 1 == CurrentlyDisplayedTipId) return;
  int actualId = SortedTipIds[id - 1];
  auto [buffers, tipsScrBufId] = TipsSystem::GetTipsScriptBufferCtx();
  auto* record = TipsSystem::GetTipRecord(actualId);
  if (record->IsLocked) {
    Audio::PlayInGroup(Audio::ACG_SE, "sysse", 4, false, 0);
    return;
  }
  CurrentlyDisplayedTipId = id - 1;

  TipsSystem::SetTipUnreadState(actualId, false);
  auto categoryStr = TipsSystem::GetTextStringStream(actualId, 0);
  auto nameStr = TipsSystem::GetTextStringStream(actualId, 1);
  auto pronunciationStr = TipsSystem::GetTextStringStream(actualId, 2);
  Category->SetText(categoryStr, CategoryPos, (float)CategoryFontSize,
                    RendererOutlineMode::None, {TipsMenuDarkTextColor, 0});
  Name->SetText(nameStr, NamePos, (float)NameFontSize,
                RendererOutlineMode::None, {TipsMenuDarkTextColor, 0});
  Pronunciation->SetText(pronunciationStr, PronunciationPos,
                         (float)PronunciationFontSize,
                         RendererOutlineMode::None, 0);

  {
    using Buffer =
        std::variant<std::array<uint16_t, 4>, std::array<uint32_t, 4>>;

    Buffer sc3StringBuffer =
        Profile::Vm::StringEncodingType ==
                Profile::Vm::StringUnitEncoding::Uint32
            ? Buffer(std::in_place_type<std::array<uint32_t, 4>>)
            : Buffer(std::in_place_type<std::array<uint16_t, 4>>);

    auto lambda = [&]<typename T>() {
      auto& buf = std::get<std::array<T, 4>>(sc3StringBuffer);
      TextGetSc3String(fmt::format("{:03d}", id), buf);
      return Vm::Sc3Stream(buf.data());
    };

    auto stream = Profile::Vm::StringEncodingType ==
                          Profile::Vm::StringUnitEncoding::Uint32
                      ? lambda.template operator()<uint32_t>()
                      : lambda.template operator()<uint16_t>();

    Number->SetText(stream, NumberPos, (float)NumberFontSize,
                    RendererOutlineMode::None, 0);
  }

  Vm::Sc3VmThread dummy;
  dummy.ScriptBufferId = tipsScrBufId;
  dummy.UseMSBBuffers = Profile::Vm::UseMsbStrings;
  dummy.SetStringIp(TipsSystem::GetTextStringStream(actualId, 4).Data());
  TextPage.Clear();
  TextPage.AddString(&dummy);
  TipViewItems.HasFocus = true;

  const TextModeInfo& textModeInfo =
      TextModesInfo[Profile::Dialogue::TipsMessageModeIdx];
  const RectF pageBounds =
      RectF(textModeInfo.WindowPos.x, textModeInfo.WindowPos.y,
            textModeInfo.MaxLineWidth, TipsTextPageHeight);

  int scrollDistance =
      static_cast<int>(TextPage.Bounds.Height - pageBounds.Height);

  TipPageY = 0;
  TipsScrollbar = std::make_unique<Widgets::Scrollbar>(
      0, TipsScrollStartPos, 0.0f, std::max(0.0f, (float)scrollDistance),
      &TipPageY, SBDIR_VERTICAL, TipsScrollThumbSprite, TipsScrollTrackBounds,
      TipsScrollThumbLength, pageBounds, 5.0f);
  TipsScrollbar->SetScrollAreaBounds(pageBounds);
  TipsScrollbar->HasFocus = false;  // We want to manually control kb/pad input

  Audio::PlayInGroup(Audio::ACG_SE, "sysse", 2, false, 0);
}

void TipsMenu::SetActiveTab(TipsTabType type) {
  if (type == CurrentTabType || !TipsTabs[type]->GetTipEntriesCount()) return;

  if (PADinputMouseWentDown & PAD1A) {
    Audio::PlayInGroup(Audio::ACG_SE, "sysse", 2, false, 0);
  } else {
    Audio::PlayInGroup(Audio::ACG_SE, "sysse", 1, false, 0);
  }

  TipsTabs[CurrentTabType]->Hide();
  TipsTabs[type]->Show();
  CurrentTabType = type;
}

}  // namespace CCLCC
}  // namespace UI
}  // namespace Impacto