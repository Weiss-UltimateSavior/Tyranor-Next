#pragma once

#include "../../data/savesystem.h"
#include "../../io/memorystream.h"

namespace Impacto {
namespace CHLCC {

using namespace Impacto::SaveSystem;

constexpr size_t SaveEntrySize = 0x2000;
constexpr size_t SaveFileSize = SaveEntrySize * MaxSaveEntries * 2 + 0x3b06;

// CHLCC PS3 Save thumbnails are 160x90 RGB24
constexpr size_t SaveThumbnailWidth = 160;
constexpr size_t SaveThumbnailHeight = 90;
constexpr size_t SaveThumbnailSize =
    SaveThumbnailWidth * SaveThumbnailHeight * 3;
// Each entry has padding of Width * Height for some reason
constexpr size_t ThumbnailPaddingSize =
    SaveThumbnailWidth * SaveThumbnailHeight;
constexpr size_t ThumbnailFileSize =
    (SaveThumbnailSize + ThumbnailPaddingSize) * MaxSaveEntries * 2;

class SaveFileEntry : public SaveFileEntryBase {
 public:
  std::array<uint8_t, 50> FlagWorkScript1{};   // 50 bytes from &FlagWork[50]
  std::array<uint8_t, 100> FlagWorkScript2{};  // 100 bytes from &FlagWork[300]
  std::array<int, 300> ScrWorkScript1{};       // 1200 bytes from &ScrWork[300]
  std::array<int, 1300> ScrWorkScript2{};      // 5200 bytes from &ScrWork[2300]
  std::array<uint16_t, 102>
      WaveData{};  // 2 wave types * 10 waves * 5 fields + 2 counts
  std::array<uint8_t, SaveThumbnailSize> ThumbnailData;
};

class SaveSystem : public SaveSystemBase {
 public:
  SaveError CheckSaveFile() const override;
  SaveError MountSaveFile(std::vector<QueuedTexture>& textures) override;

  SaveError LoadSystemData() override;
  void SaveSystemData() override;
  void InitializeSystemData() override;

  void SaveThumbnailData() override;
  Sprite& GetSaveThumbnail(SaveType type, int id) override;

  void LoadEntryBuffer(Io::MemoryStream& memoryStream, SaveFileEntry& entry);
  void SaveEntryBuffer(Io::MemoryStream& memoryStream, SaveFileEntry& entry);
  void LoadEntry(SaveType type, int id) override;
  void FlushWorkingSaveEntry(SaveType type, int id, int autoSaveType) override;

  void SaveMemory() override;

  SaveError WriteSaveFile() override;
  uint32_t GetSavePlayTime(SaveType type, int id) const override;
  uint8_t GetSaveFlags(SaveType type, int id) const override;
  void SetSaveFlags(SaveType type, int id, uint8_t flags) override;
  tm const& GetSaveDate(SaveType type, int id) const override;
  uint8_t GetSaveStatus(SaveType type, int id) const override;
  int GetSaveTitle(SaveType type, int id) const override;

  uint32_t GetTipStatus(size_t tipId) const override;
  void SetTipStatus(size_t tipId, bool isLocked, bool isUnread,
                    bool isNew) override;

  void SetLineRead(size_t scriptId, size_t lineId) override;
  bool IsLineRead(size_t scriptId, size_t lineId) const override;
  void GetReadMessagesCount(int* totalMessageCount,
                            int* readMessageCount) const override;

  void GetViewedEVsCount(int* totalEVCount, int* viewedEVCount) const override;
  void GetEVStatus(int evId, int* totalVariations,
                   int* viewedVariations) const override;
  void SetEVStatus(int id) override;
  bool GetEVVariationIsUnlocked(size_t evId,
                                size_t variationIdx) const override;

  bool GetBgmFlag(int id) const override;
  void SetBgmFlag(int id, bool flag) override;

  void SetCheckpointId(int id) override {}
  void WaveSave(std::span<uint16_t> data);
  void WaveLoad(std::span<const uint16_t> data) const;

 private:
  std::array<uint8_t, 1024> GameExtraData;
  std::array<uint8_t, 10000> MessageFlags;
  std::array<uint8_t, 0x3afc> SystemData;
  std::array<bool, 1200> EVFlags;
  std::array<uint8_t, 100> BGMFlags;
  uint8_t QuickSaveCount{};
};

}  // namespace CHLCC
}  // namespace Impacto