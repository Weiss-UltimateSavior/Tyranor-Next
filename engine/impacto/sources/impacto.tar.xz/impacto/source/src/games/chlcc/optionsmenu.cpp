#include "optionsmenu.h"

#include "../../ui/widgets/chlcc/optionsbutton.h"
#include "../../ui/widgets/chlcc/optionsslider.h"

#include "../../renderer/renderer.h"
#include "../../mem.h"
#include "../../profile/scriptvars.h"
#include "../../profile/ui/backlogmenu.h"
#include "../../profile/ui/optionsmenu.h"
#include "../../profile/games/chlcc/optionsmenu.h"
#include "../../profile/games/chlcc/commonmenu.h"
#include "../../data/tipssystem.h"
#include "../../vm/interface/input.h"
#include "../../inputsystem.h"
#include "../../profile/game.h"

#include "../../profile/configsystem.h"
#include "../../audio/audiosystem.h"

namespace Impacto {
namespace UI {
namespace CHLCC {

using namespace Impacto::Profile::CHLCC::CommonMenu;
using namespace Impacto::Profile::OptionsMenu;
using namespace Impacto::Profile::CHLCC::OptionsMenu;
using namespace Impacto::Profile::ScriptVars;
using namespace Impacto::Profile::ConfigSystem;

using namespace Impacto::Vm::Interface;

using namespace Impacto::UI::Widgets;
using namespace Impacto::UI::Widgets::CHLCC;

static std::unique_ptr<Widgets::Group> CreateTextPage(
    OptionsMenu* const menu,
    const std::function<void(OptionsEntry*)>& highlight) {
  std::unique_ptr<Group> textPage = std::make_unique<Group>(menu);
  RectF highlightBounds(0.0f, 0.0f, SelectedLabelSprite.ScaledWidth(),
                        SelectedLabelSprite.ScaledHeight());

  const auto addButton =
      [&]<typename T>(
          size_t id, T& value, std::span<const T> values,
          std::span<const std::reference_wrapper<const Sprite>> sprites) {
        highlightBounds.X = TextPageEntryPositions[id].x;
        highlightBounds.Y = TextPageEntryPositions[id].y;
        textPage->Add(
            new OptionsButton<T>(value, values, sprites,
                                 highlightBounds.GetPos() +
                                     glm::vec2(highlightBounds.Width, 0.0f),
                                 highlightBounds, highlight),
            FDIR_DOWN);
      };

  // Basic settings
  {
    constexpr static std::array<std::reference_wrapper<const Sprite>, 2>
        sprites{SettingDoSprite, SettingDontSprite};
    addButton(0, TriggerStopSkip, std::span<const bool>(TriggerStopSkipValues),
              sprites);
  }
  {
    constexpr static std::array<std::reference_wrapper<const Sprite>, 2>
        sprites{SettingDoSprite, SettingDontSprite};
    addButton(1, ShowTipsNotification,
              std::span<const bool>(ShowTipsNotificationValues), sprites);
  }
  {
    constexpr static std::array<std::reference_wrapper<const Sprite>, 4>
        sprites{SettingOnTriggerAndSceneSprite, SettingDontSprite,
                SettingOnTriggerSprite, SettingOnSceneSprite};
    addButton(2, AutoQuickSave, std::span<const uint8_t>(AutoQuickSaveValues),
              sprites);
  }
  {
    constexpr static std::array<std::reference_wrapper<const Sprite>, 2>
        sprites{SettingTypeASprite, SettingTypeBSprite};
    addButton(3, ControllerType, std::span<const uint8_t>(ControllerTypeValues),
              sprites);
  }

  highlightBounds.X = TextPageEntryPositions[4].x;
  highlightBounds.Y = TextPageEntryPositions[4].y;
  textPage->Add(
      new OptionsSlider(
          ImageSize, 0.0f, 1.0f, SliderBarBaseSprite, SliderBarFillSprite,
          highlightBounds.GetPos() + glm::vec2(highlightBounds.Width, 0.0f),
          highlightBounds, highlight),
      FDIR_DOWN);

  // Text settings
  {
    constexpr static std::array<std::reference_wrapper<const Sprite>, 4>
        sprites{SettingNormalSprite, SettingFastSprite, SettingInstantSprite,
                SettingSlowSprite};
    addButton(5, TextSpeed, std::span<const float>(TextSpeedValues), sprites);
  }
  {
    constexpr static std::array<std::reference_wrapper<const Sprite>, 3>
        sprites{SettingNormalSprite, SettingFastSprite, SettingSlowSprite};
    addButton(6, AutoSpeed, std::span<const float>(AutoSpeedValues), sprites);
  }
  {
    constexpr static std::array<std::reference_wrapper<const Sprite>, 2>
        sprites{SettingReadSprite, SettingAllSprite};
    addButton(7, SkipRead, std::span<const bool>(SkipReadValues), sprites);
  }

  return textPage;
}

static std::unique_ptr<Widgets::Group> CreateSoundPage(
    OptionsMenu* const menu,
    const std::function<void(OptionsEntry*)>& highlight) {
  std::unique_ptr<Group> soundPage = std::make_unique<Group>(menu);
  RectF highlightBounds(0.0f, 0.0f, SelectedLabelSprite.ScaledWidth(),
                        SelectedLabelSprite.ScaledHeight());

  const auto addButton =
      [&]<typename T>(
          size_t id, T& value, std::span<const T> values,
          std::span<const std::reference_wrapper<const Sprite>> sprites) {
        highlightBounds.X = SoundPageEntryPositions[id].x;
        highlightBounds.Y = SoundPageEntryPositions[id].y;
        const glm::vec2 topRight =
            highlightBounds.GetPos() + glm::vec2(highlightBounds.Width, 0.0f);
        soundPage->Add(new OptionsButton<T>(value, values, sprites, topRight,
                                            highlightBounds, highlight),
                       FDIR_DOWN);
      };
  const auto addSlider = [&](size_t id, float& value, float min, float max) {
    highlightBounds.X = SoundPageEntryPositions[id].x;
    highlightBounds.Y = SoundPageEntryPositions[id].y;
    const glm::vec2 topRight =
        highlightBounds.GetPos() + glm::vec2(highlightBounds.Width, 0.0f);
    soundPage->Add(new OptionsSlider(value, min, max, SliderBarBaseSprite,
                                     SliderBarFillSprite, topRight,
                                     highlightBounds, highlight),
                   FDIR_DOWN);
  };

  addSlider(0, Audio::GroupVolumes[Audio::ACG_Voice], 0.0f, 1.0f);
  addSlider(1, Audio::GroupVolumes[Audio::ACG_BGM], 0.0f, 0.5f);
  addSlider(2, Audio::GroupVolumes[Audio::ACG_SE], 0.0f, 1.0f);
  addSlider(3, Audio::GroupVolumes[Audio::ACG_Movie], 0.0f, 1.0f);
  {
    constexpr static std::array<std::reference_wrapper<const Sprite>, 2>
        sprites{SettingDoSprite, SettingDontSprite};
    addButton(4, SyncVoice, std::span<const bool>(SyncVoiceValues), sprites);
  }
  {
    constexpr static std::array<std::reference_wrapper<const Sprite>, 2>
        sprites{SettingDontSprite, SettingDoSprite};
    addButton(5, SkipVoice, std::span<const bool>(SkipVoiceValues), sprites);
  }

  return soundPage;
}

static std::unique_ptr<Widgets::Group> CreateVoicePage(
    OptionsMenu* const menu,
    const std::function<void(OptionsEntry*)>& highlight) {
  std::unique_ptr<Group> voicePage = std::make_unique<Group>(menu);
  RectF highlightBounds(0.0f, 0.0f, SelectedLabelSprite.ScaledWidth(),
                        SelectedLabelSprite.ScaledHeight());

  for (size_t i = 0; i < VoicePageEntryPositions.size(); i++) {
    highlightBounds.X = VoicePageEntryPositions[i].x;
    highlightBounds.Y = VoicePageEntryPositions[i].y;
    const glm::vec2 topRight =
        highlightBounds.GetPos() + glm::vec2(highlightBounds.Width, 0.0f);

    voicePage->Add(
        new OptionsSlider(Profile::ConfigSystem::VoiceVolume[i], 0.0f, 1.0f,
                          SliderBarBaseSprite, SliderBarFillSprite, topRight,
                          highlightBounds, highlight, VoiceMutedSprite),
        FDIR_DOWN);
  }

  return voicePage;
}

OptionsMenu::OptionsMenu() : UI::OptionsMenu(), CommonMenu(true) {
  RememberLastPage = true;
  RememberHighlightedEntries = true;

  PageTransitionAnimation.SetDuration(PageTransitionDuration);
  PageTransitionAnimation.SkipOnSkipMode = false;

  SelectedAnimation.DurationIn = SelectedSlideDuration;
  SelectedAnimation.LoopMode = AnimationLoopMode::Loop;
  SelectedAnimation.SkipOnSkipMode = false;
  SelectedAnimation.StartIn();

  std::function<void(OptionsEntry*)> highlight = [this](auto* entry) {
    return Highlight(entry);
  };

  Pages.reserve(3);
  Pages.emplace_back(CreateTextPage(this, highlight));
  Pages.emplace_back(CreateSoundPage(this, highlight));
  Pages.emplace_back(CreateVoicePage(this, highlight));

  HighlightedEntriesPerPage.reserve(Pages.size());
  for (std::unique_ptr<Group>& page : Pages) {
    HighlightedEntriesPerPage.push_back(page->GetFirstFocusableChild());
  }

  SelectedLabelPos = HighlightedEntriesPerPage[CurrentPage]->Bounds.GetPos();
}

void OptionsMenu::Show() {
  if (State == Hidden) {
    MenuTransition.StartIn();
    FromSystemMenuTransition->StartIn();
  }

  UI::OptionsMenu::Show();
}

void OptionsMenu::Hide() {
  if (State == Shown) {
    SetFlag(SF_SUBMENUEXIT, true);
    MenuTransition.StartOut();
    FromSystemMenuTransition->StartOut();
  }

  UI::OptionsMenu::Hide();

  if (State == Hiding) {
    Pages[CurrentPage]->VisibilityState = Shown;
  }
}

void OptionsMenu::RenderPage(const size_t pageId, const glm::vec2 offset) {
  switch (pageId) {
    case static_cast<int>(PageType::Text):
      Renderer->DrawSprite(BasicSettingsSprite, BasicSettingsPos + offset);
      Renderer->DrawSprite(TextSettingsSprite, TextSettingsPos + offset);
      break;
    case static_cast<int>(PageType::Sound):
      Renderer->DrawSprite(SoundSettingsSprite, SoundSettingsPos + offset);
      break;
    case static_cast<int>(PageType::Voice):
      Renderer->DrawSprite(VoiceSettingsSprite, VoiceSettingsPos + offset);
      break;
    default:
      ImpLogSlow(LogLevel::Warning, LogChannel::General,
                 "Unexpected options menu page {:d}", pageId);
      break;
  }

  Pages[pageId]->Move(offset);
  Pages[pageId]->Render();
  Pages[pageId]->Move(-offset);
}

void OptionsMenu::Render() {
  if (State == Hidden) return;
  CommonMenu::DrawSubmenu(BackgroundColor, CircleSprite, MenuTitleText,
                          MenuTitleTextAngle);
  if (FadeAnimation.Progress < 0.22f) return;

  DrawButtonPrompt(ButtonPromptSprite, ButtonPromptPosition);

  glm::vec2 showPageOffset = MenuTransition.GetPageOffset();
  if ((CurrentlyFocusedElement != nullptr || !MenuTransition.IsIn()) &&
      PageTransitionAnimation.IsStopped()) {
    for (float x = SelectedSprite.ScaledWidth() * -SelectedAnimation.Progress;
         x < Profile::Game::DesignWidth; x += SelectedSprite.ScaledWidth()) {
      Renderer->DrawSprite(SelectedSprite,
                           glm::vec2(x, SelectedLabelPos.y) + showPageOffset);
    }

    Renderer->DrawSprite(SelectedLabelSprite,
                         SelectedLabelPos + showPageOffset);
    const glm::vec2 dotOffset =
        CurrentPage == static_cast<size_t>(PageType::Voice)
            ? SelectedDotVoicesOffset
            : SelectedDotOffset;
    Renderer->DrawSprite(SelectedDotSprite,
                         SelectedLabelPos + dotOffset + showPageOffset);
  }

  if (PageTransitionAnimation.IsStopped()) {
    RenderPage(CurrentPage, showPageOffset);
  } else {
    Pages[PreviousPage]->VisibilityState = Shown;
    RenderPage(PreviousPage, PageTransitionGoingOffset + showPageOffset);
    RenderPage(CurrentPage, PageTransitionComingOffset + showPageOffset);
  }
}

void OptionsMenu::UpdatePageInput(float dt) {
  UI::OptionsMenu::UpdatePageInput(dt);

  if (PageTransitionAnimation.IsPlaying()) return;

  if (Input::MouseWheelDeltaY > 0.0f || Input::TouchFlickUp) {
    GoToPage((CurrentPage + Pages.size() - 1) % Pages.size());
  } else if (Input::MouseWheelDeltaY < 0.0f || Input::TouchFlickDown) {
    GoToPage((CurrentPage + 1) % Pages.size());
  }
}

void OptionsMenu::UpdateVisibility() {
  const int sysMenuCt = ScrWork[SW_SYSMENUCT];
  const int systemMenuCHG = ScrWork[SW_SYSTEMMENUCHG];

  if ((!GetFlag(SF_OPTIONMENU) || sysMenuCt < 10000 ||
       (sysMenuCt == 10000 && systemMenuCHG != 0 && systemMenuCHG != 64)) &&
      State == Shown) {
    Hide();
  } else if (GetFlag(SF_OPTIONMENU) && sysMenuCt > 0 && State == Hidden) {
    Show();
  }

  if (FadeAnimation.IsOut() && !GetFlag(SF_OPTIONMENU) && systemMenuCHG == 0 &&
      (sysMenuCt == 0 || GetFlag(SF_SYSTEMMENU)) && State == Hiding) {
    State = Hidden;
  } else if (FadeAnimation.IsIn() && sysMenuCt == 10000 &&
             (systemMenuCHG == 0 || systemMenuCHG == 64) &&
             GetFlag(SF_OPTIONMENU) && State == Showing) {
    State = Shown;
  }
}

void OptionsMenu::UpdateSelectedLabel(float dt) {
  SelectedAnimation.Update(dt);

  if (CurrentlyFocusedElement == nullptr ||
      SelectedLabelPos.y == CurrentlyFocusedElement->Bounds.Y)
    return;

  const float currentY = SelectedLabelPos.y;
  const float targetY = CurrentlyFocusedElement->Bounds.Y;

  // Not exactly how the binary does it, but this is smoother
  const float entriesLeft =
      std::abs(currentY - targetY) / SelectedLabelModalDistancePerEntry;
  const float speedMultiplier =
      1.0f + 3.0f * glm::smoothstep(0.0f, 4.0f, entriesLeft);
  const float pixelsMoved = SelectedLabelBaseSpeed * speedMultiplier * dt;

  if (SelectedLabelPos.y < CurrentlyFocusedElement->Bounds.Y) {
    SelectedLabelPos.y = std::min(SelectedLabelPos.y + pixelsMoved,
                                  CurrentlyFocusedElement->Bounds.Y);
  } else {
    SelectedLabelPos.y = std::max(SelectedLabelPos.y - pixelsMoved,
                                  CurrentlyFocusedElement->Bounds.Y);
  }
}

void OptionsMenu::UpdatePageTransitionAnimation(float dt) {
  PageTransitionAnimation.Update(dt);

  if (PageTransitionAnimation.IsStopped()) return;

  constexpr glm::vec2 anchor = {1.0f, 0.0f};

  float angle = (1.0f - PageTransitionAnimation.Progress) * PageRotationAngle;
  PageTransitionComingOffset =
      (glm::vec2(std::cos(angle), std::sin(angle)) - anchor) *
      Profile::Game::DesignHeight;

  angle = -PageTransitionAnimation.Progress * PageRotationAngle;
  PageTransitionGoingOffset =
      (glm::vec2(std::cos(angle), std::sin(angle)) - anchor) *
      Profile::Game::DesignHeight;

  if (PageTransitionAnimation.Direction == AnimationDirection::Out) {
    std::swap(PageTransitionGoingOffset, PageTransitionComingOffset);
  }
}

void OptionsMenu::Update(float dt) {
  UI::OptionsMenu::Update(dt);

  if (State != Hidden) {
    FromSystemMenuTransition->Update(dt);
    if (FadeAnimation.Direction == AnimationDirection::Out &&
        FadeAnimation.Progress <= 0.72f) {
      TitleFade.StartOut();
      FromSystemMenuTransition->StartOut();
    } else if (FadeAnimation.IsIn() &&
               (TitleFade.Direction == AnimationDirection::In ||
                TitleFade.IsOut())) {
      TitleFade.StartIn();
      FromSystemMenuTransition->StartIn();
    }
    TitleFade.Update(dt);

    UpdateTitles(MenuTitleTextRightPosition, glm::vec2(0));
    MenuTransition.Update(dt);
    UpdatePageTransitionAnimation(dt);
    UpdateSelectedLabel(dt);
  }
}

void OptionsMenu::UpdateValues() {
  for (std::unique_ptr<Group>& page : Pages) {
    for (Widget* entry : page->Children) {
      static_cast<OptionsEntry*>(entry)->UpdateValue();
    }
  }
}

void OptionsMenu::UpdateInput(float dt) {
  if (State != Shown || PageTransitionAnimation.IsPlaying()) return;

  UI::OptionsMenu::UpdateInput(dt);
}

void OptionsMenu::GoToPage(size_t pageNumber) {
  if (pageNumber == CurrentPage || PageTransitionAnimation.IsPlaying()) return;

  PreviousPage = CurrentPage;
  UI::OptionsMenu::GoToPage(pageNumber);

  AnimationDirection direction = PreviousPage > CurrentPage
                                     ? AnimationDirection::In
                                     : AnimationDirection::Out;
  if (PreviousPage == Pages.size() - 1 && CurrentPage == 0)
    direction = AnimationDirection::Out;
  else if (PreviousPage == 0 && CurrentPage == Pages.size() - 1)
    direction = AnimationDirection::In;

  PageTransitionAnimation.Start(direction, true);
}

void OptionsMenu::ResetToDefault() {
  switch (CurrentPage) {
    case static_cast<size_t>(PageType::Text): {
      TriggerStopSkip = Default::TriggerStopSkip;
      ShowTipsNotification = Default::ShowTipsNotification;
      AutoQuickSave = Default::AutoQuickSave;
      ControllerType = Default::ControllerType;
      ImageSize = Default::ImageSize;

      TextSpeed = Default::TextSpeed;
      AutoSpeed = Default::AutoSpeed;
      SkipRead = Default::SkipRead;
    } break;

    case static_cast<size_t>(PageType::Sound): {
      std::ranges::copy(Default::GroupVolumes, Audio::GroupVolumes.begin());
      SyncVoice = Default::SyncVoice;
      SkipVoice = Default::SkipVoice;
    } break;

    case static_cast<size_t>(PageType::Voice): {
      std::ranges::copy(Default::VoiceVolume, VoiceVolume.begin());
    } break;

    default:
      break;
  }

  UpdateValues();
}

}  // namespace CHLCC
}  // namespace UI
}  // namespace Impacto