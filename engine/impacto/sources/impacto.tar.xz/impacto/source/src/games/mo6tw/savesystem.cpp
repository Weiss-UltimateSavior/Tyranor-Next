#include "savesystem.h"

#include <time.h>
#include "../../io/memorystream.h"
#include "../../io/physicalfilestream.h"
#include "../../mem.h"
#include "../../vm/vm.h"
#include "../../profile/data/savesystem.h"
#include "../../profile/scriptvars.h"
#include "../../renderer/renderer.h"

namespace Impacto {
namespace MO6TW {

using namespace Impacto::Vm;
using namespace Impacto::Profile::SaveSystem;
using namespace Impacto::Profile::ScriptVars;

SaveFileEntry* WorkingSaveEntry = 0;

SaveError SaveSystem::LoadSystemData() {
  Io::MemoryStream stream =
      Io::MemoryStream(SystemData.data(), SystemData.size(), false);

  stream.Seek(0x14, SEEK_SET);

  Io::ReadArrayLE<uint8_t>(&FlagWork[100], &stream, 50);
  Io::ReadArrayLE<uint8_t>(&FlagWork[460], &stream, 40);
  Io::ReadArrayLE<uint8_t>((uint8_t*)&ScrWork[600], &stream, 1600);

  stream.Seek(0x7DA, SEEK_SET);
  for (int i = 0; i < 150; i++) {
    auto val = Io::ReadU8(&stream);
    EVFlags[8 * i] = val & 1;
    EVFlags[8 * i + 1] = (val & 2) != 0;
    EVFlags[8 * i + 2] = (val & 4) != 0;
    EVFlags[8 * i + 3] = (val & 8) != 0;
    EVFlags[8 * i + 4] = (val & 0x10) != 0;
    EVFlags[8 * i + 5] = (val & 0x20) != 0;
    EVFlags[8 * i + 6] = (val & 0x40) != 0;
    EVFlags[8 * i + 7] = val >> 7;
  }

  stream.Seek(0xbc2, SEEK_SET);
  Io::ReadArrayLE<uint8_t>(BGMFlags, &stream, 100);

  stream.Seek(0xc26, SEEK_SET);
  Io::ReadArrayLE<uint8_t>(MessageFlags, &stream, 10000);

  stream.Seek(0x3336, SEEK_SET);
  Io::ReadArrayLE<uint8_t>(GameExtraData, &stream, 1024);

  stream.Seek(0x3b06, SEEK_SET);  // TODO: Actually load system data

  return SaveError::OK;
}

void SaveSystem::SaveSystemData() {
  Io::MemoryStream stream =
      Io::MemoryStream(SystemData.data(), SystemData.size(), false);

  stream.Seek(0xbc2, SEEK_SET);
  stream.Write(&BGMFlags, sizeof(uint8_t), 100);

  stream.Seek(0xc26, SEEK_SET);
  stream.Write(&MessageFlags, sizeof(uint8_t), 10000);

  stream.Seek(0x3336, SEEK_SET);
  stream.Write(&GameExtraData, sizeof(uint8_t), 1024);

  stream.Seek(0x3b06, SEEK_SET);  // TODO: Actually save system data
}

SaveError SaveSystem::MountSaveFile(std::vector<QueuedTexture>& textures) {
  Io::PhysicalFileStream* stream;
  Io::Stream* instream;
  IoError err = Io::PhysicalFileStream::Create(SaveFilePath, &instream);
  switch (err) {
    case IoError_NotFound:
      return SaveError::NotFound;
    case IoError_Fail:
    case IoError_Eof:
      return SaveError::Corrupted;
    case IoError_OK:
      break;
  };
  stream = (Io::PhysicalFileStream*)instream;

  const RectF viewport = Window->GetViewport();
  WorkingSaveEntry = new SaveFileEntry();
  WorkingSaveThumbnail.Sheet = SpriteSheet(viewport.Width, viewport.Height);
  WorkingSaveThumbnail.Bounds =
      RectF(0.0f, 0.0f, viewport.Width, viewport.Height);

  QueuedTexture txt = {
      .Id = std::ref(WorkingSaveThumbnail.Sheet.Texture),
  };
  txt.Tex.LoadSolidColor((int)WorkingSaveThumbnail.Bounds.Width,
                         (int)WorkingSaveThumbnail.Bounds.Height, 0x000000);
  textures.push_back(txt);

  Io::ReadArrayLE<uint8_t>(SystemData.data(), stream, SystemData.size());

  for (int i = 0; i < MaxSaveEntries; i++) {
    QuickSaveEntries[i] = new SaveFileEntry();

    QuickSaveEntries[i]->Status = Io::ReadLE<uint8_t>(stream);
    QuickSaveEntries[i]->Checksum = Io::ReadLE<uint16_t>(stream);
    Io::ReadLE<uint8_t>(stream);
    uint8_t saveMonth = Io::ReadLE<uint8_t>(stream);
    uint8_t saveDay = Io::ReadLE<uint8_t>(stream);
    uint8_t saveHour = Io::ReadLE<uint8_t>(stream);
    uint8_t saveMinute = Io::ReadLE<uint8_t>(stream);
    uint8_t saveYear = Io::ReadLE<uint8_t>(stream);
    uint8_t saveSecond = Io::ReadLE<uint8_t>(stream);
    std::tm t{};
    t.tm_sec = saveSecond;
    t.tm_min = saveMinute;
    t.tm_hour = saveHour;
    t.tm_mday = saveDay;
    t.tm_mon = saveMonth - 1;
    t.tm_year = saveYear + 100;
    QuickSaveEntries[i]->SaveDate = t;

    Io::ReadLE<uint16_t>(stream);
    QuickSaveEntries[i]->PlayTime = Io::ReadLE<uint32_t>(stream);
    QuickSaveEntries[i]->SwTitle = Io::ReadLE<uint16_t>(stream);
    Io::ReadLE<uint8_t>(stream);
    stream->Seek(31, SEEK_CUR);
    Io::ReadArrayLE<uint8_t>(
        ((SaveFileEntry*)QuickSaveEntries[i])->FlagWorkScript1, stream, 50);
    Io::ReadArrayLE<uint8_t>(
        ((SaveFileEntry*)QuickSaveEntries[i])->FlagWorkScript2, stream, 100);
    Io::ReadArrayLE<int>(((SaveFileEntry*)QuickSaveEntries[i])->ScrWorkScript1,
                         stream, 300);
    Io::ReadArrayLE<int>(((SaveFileEntry*)QuickSaveEntries[i])->ScrWorkScript2,
                         stream, 1100);
    QuickSaveEntries[i]->MainThreadExecPriority = Io::ReadLE<uint32_t>(stream);
    QuickSaveEntries[i]->MainThreadGroupId = Io::ReadLE<uint32_t>(stream);
    QuickSaveEntries[i]->MainThreadWaitCounter = Io::ReadLE<uint32_t>(stream);
    QuickSaveEntries[i]->MainThreadScriptParam = Io::ReadLE<uint32_t>(stream);
    QuickSaveEntries[i]->MainThreadIp = Io::ReadLE<uint32_t>(stream);
    QuickSaveEntries[i]->MainThreadLoopCounter = Io::ReadLE<uint32_t>(stream);
    QuickSaveEntries[i]->MainThreadLoopAdr = Io::ReadLE<uint32_t>(stream);
    QuickSaveEntries[i]->MainThreadCallStackDepth =
        Io::ReadLE<uint32_t>(stream);
    for (int j = 0; j < 8; j++) {
      QuickSaveEntries[i]->MainThreadReturnIds[j] =
          Io::ReadLE<uint32_t>(stream);
      QuickSaveEntries[i]->MainThreadReturnBufIds[j] =
          Io::ReadLE<uint32_t>(stream);
    }
    Io::ReadArrayLE<int>(QuickSaveEntries[i]->MainThreadVariables.data(),
                         stream, 16);
    // QuickSaveEntries[i]->MainThreadDialoguePageId =
    //    Io::ReadLE<uint32_t>(stream);
    stream->Seek(204, SEEK_CUR);
  }

  stream->Seek(0x3028, SEEK_CUR);

  for (int i = 0; i < MaxSaveEntries; i++) {
    FullSaveEntries[i] = new SaveFileEntry();

    FullSaveEntries[i]->Status = Io::ReadLE<uint8_t>(stream);
    FullSaveEntries[i]->Checksum = Io::ReadLE<uint16_t>(stream);
    Io::ReadLE<uint8_t>(stream);
    uint8_t saveMonth = Io::ReadLE<uint8_t>(stream);
    uint8_t saveDay = Io::ReadLE<uint8_t>(stream);
    uint8_t saveHour = Io::ReadLE<uint8_t>(stream);
    uint8_t saveMinute = Io::ReadLE<uint8_t>(stream);
    uint8_t saveYear = Io::ReadLE<uint8_t>(stream);
    uint8_t saveSecond = Io::ReadLE<uint8_t>(stream);
    std::tm t{};
    t.tm_sec = saveSecond;
    t.tm_min = saveMinute;
    t.tm_hour = saveHour;
    t.tm_mday = saveDay;
    t.tm_mon = saveMonth - 1;
    t.tm_year = saveYear + 100;
    FullSaveEntries[i]->SaveDate = t;
    Io::ReadLE<uint16_t>(stream);
    FullSaveEntries[i]->PlayTime = Io::ReadLE<uint32_t>(stream);
    FullSaveEntries[i]->SwTitle = Io::ReadLE<uint16_t>(stream);
    Io::ReadLE<uint8_t>(stream);
    stream->Seek(31, SEEK_CUR);
    Io::ReadArrayLE<uint8_t>(
        ((SaveFileEntry*)FullSaveEntries[i])->FlagWorkScript1, stream, 50);
    Io::ReadArrayLE<uint8_t>(
        ((SaveFileEntry*)FullSaveEntries[i])->FlagWorkScript2, stream, 100);
    Io::ReadArrayLE<int>(((SaveFileEntry*)FullSaveEntries[i])->ScrWorkScript1,
                         stream, 300);
    Io::ReadArrayLE<int>(((SaveFileEntry*)FullSaveEntries[i])->ScrWorkScript2,
                         stream, 1100);
    FullSaveEntries[i]->MainThreadExecPriority = Io::ReadLE<uint32_t>(stream);
    FullSaveEntries[i]->MainThreadGroupId = Io::ReadLE<uint32_t>(stream);
    FullSaveEntries[i]->MainThreadWaitCounter = Io::ReadLE<uint32_t>(stream);
    FullSaveEntries[i]->MainThreadScriptParam = Io::ReadLE<uint32_t>(stream);
    FullSaveEntries[i]->MainThreadIp = Io::ReadLE<uint32_t>(stream);
    FullSaveEntries[i]->MainThreadLoopCounter = Io::ReadLE<uint32_t>(stream);
    FullSaveEntries[i]->MainThreadLoopAdr = Io::ReadLE<uint32_t>(stream);
    FullSaveEntries[i]->MainThreadCallStackDepth = Io::ReadLE<uint32_t>(stream);
    for (int j = 0; j < 8; j++) {
      FullSaveEntries[i]->MainThreadReturnIds[j] = Io::ReadLE<uint32_t>(stream);
      FullSaveEntries[i]->MainThreadReturnBufIds[j] =
          Io::ReadLE<uint32_t>(stream);
    }
    Io::ReadArrayLE<int>(FullSaveEntries[i]->MainThreadVariables.data(), stream,
                         16);
    // FullSaveEntries[i]->MainThreadDialoguePageId =
    // Io::ReadLE<uint32_t>(stream);
    stream->Seek(204, SEEK_CUR);
  }

  stream->~PhysicalFileStream();

  return SaveError::OK;
}

// uint16_t CalculateChecksum(int id) {
//  return 0;
//}

void SaveSystem::FlushWorkingSaveEntry(SaveType type, int id,
                                       int autoSaveType) {
  auto* entry = GetSaveEntry<SaveFileEntry>(type, id);

  if (WorkingSaveEntry != 0) {
    if (entry != 0 && !(entry->Flags & WriteProtect)) {
      Renderer->FreeTexture(entry->SaveThumbnail.Sheet.Texture);
      if (type == SaveType::Quick) {
        entry->SaveType = autoSaveType;
        UpdateQuickSaveRecentSortedId(id);
      }
      entry->Status = 1;

      entry->SaveDate = CurrentDateTime();
      entry->PlayTime = WorkingSaveEntry->PlayTime;
      entry->SwTitle = WorkingSaveEntry->SwTitle;

      memcpy(entry->FlagWorkScript1, WorkingSaveEntry->FlagWorkScript1, 50);
      memcpy(entry->FlagWorkScript2, WorkingSaveEntry->FlagWorkScript2, 100);
      memcpy(entry->ScrWorkScript1, WorkingSaveEntry->ScrWorkScript1, 1200);
      memcpy(entry->ScrWorkScript2, WorkingSaveEntry->ScrWorkScript2, 5200);

      entry->MainThreadExecPriority = WorkingSaveEntry->MainThreadExecPriority;
      entry->MainThreadWaitCounter = WorkingSaveEntry->MainThreadWaitCounter;
      entry->MainThreadScriptParam = WorkingSaveEntry->MainThreadScriptParam;
      entry->MainThreadGroupId = WorkingSaveEntry->MainThreadGroupId;
      entry->MainThreadGroupId = WorkingSaveEntry->MainThreadGroupId;
      entry->MainThreadIp = WorkingSaveEntry->MainThreadIp;
      entry->MainThreadCallStackDepth =
          WorkingSaveEntry->MainThreadCallStackDepth;

      for (int j = 0; j < 8; j++) {
        entry->MainThreadReturnIds[j] =
            WorkingSaveEntry->MainThreadReturnIds[j];
        entry->MainThreadReturnBufIds[j] =
            WorkingSaveEntry->MainThreadReturnBufIds[j];
      }

      std::ranges::copy(WorkingSaveEntry->MainThreadVariables,
                        entry->MainThreadVariables.begin());
      entry->MainThreadDialoguePageId =
          WorkingSaveEntry->MainThreadDialoguePageId;
    }
  }
}

SaveError SaveSystem::WriteSaveFile() {
  using CF = Io::PhysicalFileStream::CreateFlagsMode;
  Io::PhysicalFileStream* stream;
  Io::Stream* instream;
  {
    IoError err = Io::PhysicalFileStream::Create(
        SaveFilePath, &instream, CF::CREATE | CF::CREATE_DIRS | CF::WRITE);
    if (err != IoError_OK) {
      ImpLog(LogLevel::Error, LogChannel::IO, "Failed to create save file\n");
      return SaveError::Failed;
    }
  }
  stream = (Io::PhysicalFileStream*)instream;

  Io::WriteArrayLE<uint8_t>(SystemData.data(), stream, SystemData.size());
  auto writeEntry = [&](SaveFileEntry* entry) {
    if (entry == nullptr || entry->Status == 0) {
      stream->Seek(0x1814, SEEK_CUR);
      return SaveError::OK;
    }
    auto writeErr = stream->Write(&entry->Status, sizeof(uint8_t), 1);
    if (writeErr != IoError_OK) {
      ImpLog(LogLevel::Error, LogChannel::IO,
             "Failed to write save entry to file\n");
      return SaveError::Failed;
    }
    // TODO: Add error checking
    stream->Write(&entry->Checksum, sizeof(uint16_t), 1);
    stream->Seek(1, SEEK_CUR);
    uint8_t mon = (uint8_t)(entry->SaveDate.tm_mon + 1);
    stream->Write(&mon, sizeof(uint8_t), 1);
    stream->Write(&entry->SaveDate.tm_mday, sizeof(uint8_t), 1);
    stream->Write(&entry->SaveDate.tm_hour, sizeof(uint8_t), 1);
    stream->Write(&entry->SaveDate.tm_min, sizeof(uint8_t), 1);
    uint8_t year = (uint8_t)(entry->SaveDate.tm_year - 100);
    stream->Write(&year, sizeof(uint8_t), 1);
    stream->Write(&entry->SaveDate.tm_sec, sizeof(uint8_t), 1);
    stream->Seek(2, SEEK_CUR);
    stream->Write(&entry->PlayTime, sizeof(uint32_t), 1);
    stream->Write(&entry->SwTitle, sizeof(uint16_t), 1);
    stream->Seek(32, SEEK_CUR);
    stream->Write(((SaveFileEntry*)entry)->FlagWorkScript1, sizeof(uint8_t),
                  50);
    stream->Write(((SaveFileEntry*)entry)->FlagWorkScript2, sizeof(uint8_t),
                  100);
    stream->Write(((SaveFileEntry*)entry)->ScrWorkScript1, sizeof(int), 300);
    stream->Write(((SaveFileEntry*)entry)->ScrWorkScript2, sizeof(int), 1100);
    stream->Write(&entry->MainThreadExecPriority, sizeof(uint32_t), 1);
    stream->Write(&entry->MainThreadGroupId, sizeof(uint32_t), 1);
    stream->Write(&entry->MainThreadWaitCounter, sizeof(uint32_t), 1);
    stream->Write(&entry->MainThreadScriptParam, sizeof(uint32_t), 1);
    stream->Write(&entry->MainThreadIp, sizeof(uint32_t), 1);
    stream->Write(&entry->MainThreadLoopCounter, sizeof(uint32_t), 1);
    stream->Write(&entry->MainThreadLoopAdr, sizeof(uint32_t), 1);
    stream->Write(&entry->MainThreadCallStackDepth, sizeof(uint32_t), 1);
    for (int j = 0; j < 8; j++) {
      stream->Write(&entry->MainThreadReturnIds[j], sizeof(uint32_t), 1);
      stream->Write(&entry->MainThreadReturnBufIds[j], sizeof(uint32_t), 1);
    }
    stream->Write(&entry->MainThreadVariables, sizeof(int), 16);
    stream->Seek(204, SEEK_CUR);
    return SaveError::OK;
  };

  for (int i = 0; i < MaxSaveEntries; i++) {
    int reverseI = MaxSaveEntries - i - 1;
    auto err = writeEntry(static_cast<SaveFileEntry*>(
        QuickSaveEntries[QuickSaveRecentSortedId[reverseI]]));
    if (err != SaveError::OK) return err;
  }

  stream->Seek(0x3028, SEEK_CUR);

  for (int i = 0; i < MaxSaveEntries; i++) {
    auto err = writeEntry(static_cast<SaveFileEntry*>(FullSaveEntries[i]));
    if (err != SaveError::OK) return err;
  }

  delete stream;
  return SaveError::OK;
}

void SaveSystem::SaveMemory() {
  if (WorkingSaveEntry != 0) {
    WorkingSaveEntry->Status = 1;

    WorkingSaveEntry->PlayTime = ScrWork[2304];
    WorkingSaveEntry->SwTitle = ScrWork[2300];

    memcpy(WorkingSaveEntry->FlagWorkScript1, &FlagWork[50], 50);
    memcpy(WorkingSaveEntry->FlagWorkScript2, &FlagWork[300], 100);
    memcpy(WorkingSaveEntry->ScrWorkScript1, &ScrWork[300], 1200);
    memcpy(WorkingSaveEntry->ScrWorkScript2, &ScrWork[2300], 5200);

    int threadId = ScrWork[SW_MAINTHDP];
    Sc3VmThread* thd = &ThreadPool[threadId & 0x7FFFFFFF];
    if (thd != 0 &&
        (thd->GroupId == 4 || thd->GroupId == 5 || thd->GroupId == 6)) {
      WorkingSaveEntry->MainThreadExecPriority = thd->ExecPriority;
      WorkingSaveEntry->MainThreadWaitCounter = thd->WaitCounter;
      WorkingSaveEntry->MainThreadScriptParam = thd->ScriptParam;
      WorkingSaveEntry->MainThreadGroupId = thd->GroupId << 16;
      WorkingSaveEntry->MainThreadGroupId |= thd->ScriptBufferId;
      WorkingSaveEntry->MainThreadIp = thd->IpOffset;
      WorkingSaveEntry->MainThreadCallStackDepth = thd->CallStackDepth;

      for (size_t j = 0; j < thd->CallStackDepth; j++) {
        WorkingSaveEntry->MainThreadReturnIds[j] = thd->ReturnAddresses[j];
        WorkingSaveEntry->MainThreadReturnBufIds[j] =
            thd->ReturnScriptBufferIds[j];
      }

      memcpy(WorkingSaveEntry->MainThreadVariables.data(), thd->Variables,
             16 * sizeof(int));
      WorkingSaveEntry->MainThreadDialoguePageId = thd->DialoguePageId;
    }
  }
}

void SaveSystem::LoadEntry(SaveType type, int id) {
  auto* entry = GetSaveEntry<SaveFileEntry>(type, id);

  if (entry != 0)
    if (entry->Status) {
      ScrWork[SW_PLAYTIME] = entry->PlayTime;
      ScrWork[SW_TITLE] = entry->SwTitle;

      memcpy(&FlagWork[50], entry->FlagWorkScript1, 50);
      memcpy(&FlagWork[300], entry->FlagWorkScript2, 100);
      memcpy(&ScrWork[300], entry->ScrWorkScript1, 1200);
      memcpy(&ScrWork[2300], entry->ScrWorkScript2, 5200);

      // TODO: What to do about this mess I wonder...
      ScrWork[SW_SVSENO] = ScrWork[SW_SEREQNO];
      ScrWork[SW_SVSENO + 1] = ScrWork[SW_SEREQNO + 1];
      ScrWork[SW_SVSENO + 2] = ScrWork[SW_SEREQNO + 2];
      ScrWork[SW_SVBGMNO] = ScrWork[SW_BGMREQNO];
      ScrWork[SW_SVSCRNO1] = ScrWork[SW_SCRIPTNO2];
      ScrWork[SW_SVSCRNO2] = ScrWork[SW_SCRIPTNO3];
      ScrWork[SW_SVSCRNO3] = ScrWork[SW_SCRIPTNO4];
      ScrWork[SW_SVSCRNO4] = ScrWork[SW_SCRIPTNO5];
      ScrWork[SW_SVBGNO1] = ScrWork[SW_BG1NO];
      ScrWork[SW_SVBGNO1 + 1] = ScrWork[2427];
      ScrWork[SW_SVBGNO1 + 2] = ScrWork[2447];
      ScrWork[SW_SVBGNO1 + 3] = ScrWork[2467];
      ScrWork[SW_SVBGNO1 + 4] = ScrWork[2487];
      ScrWork[SW_SVBGNO1 + 5] = ScrWork[2507];
      ScrWork[SW_SVBGNO1 + 6] = ScrWork[2527];
      ScrWork[SW_SVBGNO1 + 7] = ScrWork[2547];
      ScrWork[SW_SVCHANO1] = ScrWork[SW_CHA1NO];
      ScrWork[SW_SVCHANO1 + 1] = ScrWork[2629];
      ScrWork[SW_SVCHANO1 + 2] = ScrWork[2649];
      ScrWork[SW_SVCHANO1 + 3] = ScrWork[2669];
      ScrWork[SW_SVCHANO1 + 4] = ScrWork[2689];
      ScrWork[SW_SVCHANO1 + 5] = ScrWork[2709];
      ScrWork[SW_SVCHANO1 + 6] = ScrWork[2729];
      ScrWork[SW_SVCHANO1 + 7] = ScrWork[2749];
      ScrWork[SW_SVCHANO1 + 8] = ScrWork[2769];
      ScrWork[SW_SVCHANO1 + 9] = ScrWork[2789];
      ScrWork[SW_SVCHANO1 + 10] = ScrWork[2809];
      ScrWork[SW_SVCHANO1 + 11] = ScrWork[2829];
      ScrWork[SW_SVCHANO1 + 12] = ScrWork[2849];
      ScrWork[SW_SVCHANO1 + 13] = ScrWork[2869];
      ScrWork[SW_SVCHANO1 + 14] = ScrWork[2889];
      ScrWork[SW_SVCHANO1 + 15] = ScrWork[2909];
      ScrWork[2034] = ScrWork[3200];
      ScrWork[2035] = ScrWork[3201];
      ScrWork[2036] = ScrWork[3202];
      ScrWork[2037] = ScrWork[3203];
      ScrWork[2038] = ScrWork[3204];
      ScrWork[2039] = ScrWork[3205];
      ScrWork[2040] = ScrWork[3206];
      ScrWork[2041] = ScrWork[3207];
      ScrWork[2042] = ScrWork[3208];
      ScrWork[2043] = ScrWork[3209];
      ScrWork[2044] = ScrWork[3210];
      ScrWork[2045] = ScrWork[3211];
      ScrWork[2046] = ScrWork[3212];
      ScrWork[2047] = ScrWork[3213];
      ScrWork[2048] = ScrWork[3214];
      ScrWork[2049] = ScrWork[3215];
      ScrWork[2050] = ScrWork[3216];
      ScrWork[2051] = ScrWork[3220];
      ScrWork[2052] = ScrWork[3221];
      ScrWork[2053] = ScrWork[3222];
      ScrWork[2054] = ScrWork[3223];
      ScrWork[2055] = ScrWork[3224];
      ScrWork[2056] = ScrWork[3225];
      ScrWork[2057] = ScrWork[3226];
      ScrWork[2058] = ScrWork[3227];
      ScrWork[2059] = ScrWork[3228];
      ScrWork[2060] = ScrWork[3229];
      ScrWork[2061] = ScrWork[3230];
      ScrWork[2062] = ScrWork[3231];
      ScrWork[2063] = ScrWork[3232];
      ScrWork[2064] = ScrWork[3233];
      ScrWork[2065] = ScrWork[3234];
      ScrWork[2066] = ScrWork[3235];
      ScrWork[2067] = ScrWork[3236];

      int threadId = ScrWork[SW_MAINTHDP];
      Sc3VmThread* thd = &ThreadPool[threadId & 0x7FFFFFFF];
      if (thd != 0 &&
          (thd->GroupId == 4 || thd->GroupId == 5 || thd->GroupId == 6)) {
        thd->ExecPriority = entry->MainThreadExecPriority;
        thd->WaitCounter = entry->MainThreadWaitCounter;
        thd->ScriptParam = entry->MainThreadScriptParam;
        thd->GroupId = entry->MainThreadGroupId >> 16;
        thd->ScriptBufferId = entry->MainThreadGroupId & 0xFFFF;
        thd->IpOffset = entry->MainThreadIp;
        // thd->CallStackDepth = entry->MainThreadCallStackDepth;

        thd->CallStackDepth++;
        thd->ReturnScriptBufferIds[0] = entry->MainThreadReturnBufIds[0];
        thd->ReturnAddresses[0] = entry->MainThreadReturnIds[0];

        memcpy(thd->Variables, entry->MainThreadVariables.data(),
               16 * sizeof(int));
        thd->DialoguePageId = entry->MainThreadDialoguePageId;
      }
    }
}

uint32_t SaveSystem::GetSavePlayTime(SaveType type, int id) const {
  return GetSaveEntry<SaveFileEntry>(type, id)->PlayTime;
}

uint8_t SaveSystem::GetSaveFlags(SaveType type, int id) const {
  return GetSaveEntry<SaveFileEntry>(type, id)->Flags;
}

void SaveSystem::SetSaveFlags(SaveType type, int id, uint8_t flags) {
  auto* entry = GetSaveEntry<SaveFileEntry>(type, id);
  entry->Flags = flags;
}

tm const& SaveSystem::GetSaveDate(SaveType type, int id) const {
  return GetSaveEntry<SaveFileEntry>(type, id)->SaveDate;
}

uint8_t SaveSystem::GetSaveStatus(SaveType type, int id) const {
  return GetSaveEntry<SaveFileEntry>(type, id)->Status;
}

int SaveSystem::GetSaveTitle(SaveType type, int id) const {
  return GetSaveEntry<SaveFileEntry>(type, id)->SwTitle;
}

uint32_t SaveSystem::GetTipStatus(size_t tipId) const {
  tipId *= 3;
  uint8_t lockStatus = (GameExtraData[tipId >> 3] & Flbit[tipId & 7]) != 0;
  uint8_t newStatus =
      (GameExtraData[(tipId + 1) >> 3] & Flbit[(tipId + 1) & 7]) != 0;
  uint8_t unreadStatus =
      (GameExtraData[(tipId + 2) >> 3] & Flbit[(tipId + 2) & 7]) != 0;
  return (lockStatus | (unreadStatus << 1)) | (newStatus << 2);
}

void SaveSystem::SetTipStatus(size_t tipId, bool isLocked, bool isUnread,
                              bool isNew) {
  tipId *= 3;
  if (isLocked) {
    GameExtraData[tipId >> 3] &= ~(Flbit[tipId & 7]);
  } else {
    GameExtraData[tipId >> 3] |= Flbit[tipId & 7];
  }
  if (isUnread) {
    GameExtraData[(tipId + 2) >> 3] &= ~(Flbit[(tipId + 2) & 7]);
  } else {
    GameExtraData[(tipId + 2) >> 3] |= Flbit[(tipId + 2) & 7];
  }
  if (isNew) {
    GameExtraData[(tipId + 1) >> 3] &= ~(Flbit[(tipId + 1) & 7]);
  } else {
    GameExtraData[(tipId + 1) >> 3] |= Flbit[(tipId + 1) & 7];
  }
}

void SaveSystem::SetLineRead(const size_t scriptId, const size_t lineId) {
  const std::optional<size_t> offset = GetLineBitOffset(scriptId, lineId);
  if (!offset.has_value()) return;

  // TODO: update some ScrWorks (2003, 2005 & 2006)

  MessageFlags[*offset >> 3] |= Flbit[*offset & 0b111];
}

bool SaveSystem::IsLineRead(const size_t scriptId, const size_t lineId) const {
  const std::optional<size_t> offset = GetLineBitOffset(scriptId, lineId);
  if (!offset.has_value()) return false;

  const uint8_t flbit = Flbit[*offset & 0b111];
  const uint8_t viewed = MessageFlags[*offset >> 3];

  return static_cast<bool>(flbit & viewed);
}

void SaveSystem::GetReadMessagesCount(int* totalMessageCount,
                                      int* readMessageCount) const {
  *totalMessageCount = 0;
  *readMessageCount = 0;

  for (size_t scriptId = 0; scriptId < StoryScriptIDs.size(); scriptId++) {
    ScriptMessageDataPair script = ScriptMessageData[StoryScriptIDs[scriptId]];
    *totalMessageCount += script.LineCount;

    for (size_t lineId = 0; lineId < script.LineCount; lineId++) {
      *readMessageCount += IsLineRead(scriptId, lineId);
    }
  }
}

void SaveSystem::GetViewedEVsCount(int* totalEVCount,
                                   int* viewedEVCount) const {
  for (int i = 0; i < MaxAlbumEntries; i++) {
    if (AlbumEvData[i][0] == 0xFFFF) break;
    for (int j = 0; j < MaxAlbumSubEntries; j++) {
      if (AlbumEvData[i][j] == 0xFFFF) break;
      *totalEVCount += 1;
      *viewedEVCount += EVFlags[AlbumEvData[i][j]];
    }
  }
}

void SaveSystem::GetEVStatus(int evId, int* totalVariations,
                             int* viewedVariations) const {
  *totalVariations = 0;
  *viewedVariations = 0;
  for (int i = 0; i < MaxAlbumSubEntries; i++) {
    if (AlbumEvData[evId][i] == 0xFFFF) break;
    *totalVariations += 1;
    *viewedVariations += EVFlags[AlbumEvData[evId][i]];
  }
}

void SaveSystem::SetEVStatus(int id) { EVFlags[id] = true; }

bool SaveSystem::GetEVVariationIsUnlocked(size_t evId,
                                          size_t variationIdx) const {
  if (AlbumEvData[evId][variationIdx] == 0xFFFF) return false;
  return EVFlags[AlbumEvData[evId][variationIdx]];
}

bool SaveSystem::GetBgmFlag(int id) const { return BGMFlags[id]; }
void SaveSystem::SetBgmFlag(int id, bool flag) { BGMFlags[id] = flag; }

Sprite& SaveSystem::GetSaveThumbnail(SaveType type, int id) {
  return GetSaveEntry<SaveFileEntry>(type, id)->SaveThumbnail;
}

}  // namespace MO6TW
}  // namespace Impacto