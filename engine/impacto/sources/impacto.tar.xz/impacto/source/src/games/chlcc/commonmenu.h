#pragma once

#include <vector>
#include "../../impacto.h"
#include "../../animation.h"
#include "../../spritesheet.h"
#include "../../ui/buttonprompt.h"

#include "animations/selectprompt.h"
#include "animations/menutransition.h"

namespace Impacto {
namespace UI {
namespace CHLCC {

class CommonMenu {
 public:
  CommonMenu(bool canGoFromSysMenu);

 protected:
  void DrawSubmenu(uint32_t backgroundColor, const Sprite& currentCircleSprite,
                   const Sprite& menuTitleSprite, float menuTitleAngle,
                   bool drawLeftTitle = false);
  void DrawSysMenu(glm::vec4 backgroundColor, const Sprite& currentCircleSprite,
                   const Sprite& menuTitleSprite, float menuTitleAngle);
  void DrawCircles(const Sprite& currentCircleSprite) const;
  void DrawErin() const;
  void DrawRedBar() const;
  void DrawRightTitle(const Sprite& titleSprite, float titleAngle) const;
  void DrawLeftTitle(const Sprite& titleSprite,
                     glm::vec4 tint = glm::vec4(1.0f)) const;
  void DrawBackgroundFilter();

  virtual void DrawButtonPrompt(
      const ButtonPrompt& buttonPrompt, glm::vec2 buttonPromptPos,
      std::optional<Animation> animation = std::nullopt);
  virtual void UpdateTitles(glm::vec2 rightTitlepos, glm::vec2 leftTitlePos,
                            bool vertical = true);

  Animation TitleFade;
  std::optional<Animation> FromSystemMenuTransition = std::nullopt;
  SelectPromptAnimation SelectAnimation;
  MenuTransitionAnimation MenuTransition;

  glm::vec2 RedTitleLabelPos;
  glm::vec2 RightTitlePos;
  glm::vec2 LeftTitlePos;
};

}  // namespace CHLCC
}  // namespace UI
}  // namespace Impacto