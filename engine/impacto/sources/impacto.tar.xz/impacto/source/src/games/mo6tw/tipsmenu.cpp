#include "tipsmenu.h"
#include <fmt/format.h>

#include "../../renderer/renderer.h"
#include "../../mem.h"
#include "../../vm/vm.h"
#include "../../profile/scriptvars.h"
#include "../../profile/dialogue.h"
#include "../../profile/ui/backlogmenu.h"
#include "../../profile/ui/tipsmenu.h"
#include "../../profile/games/mo6tw/tipsmenu.h"
#include "../../profile/vm.h"
#include "../../ui/widgets/mo6tw/tipsentrybutton.h"
#include "../../data/tipssystem.h"
#include "../../vm/interface/input.h"

namespace Impacto {
namespace UI {
namespace MO6TW {

using namespace Impacto::Profile::TipsMenu;
using namespace Impacto::Profile::MO6TW::TipsMenu;
using namespace Impacto::Profile::ScriptVars;

using namespace Impacto::Vm::Interface;

using namespace Impacto::UI::Widgets;
using namespace Impacto::UI::Widgets::MO6TW;

void TipsMenu::TipOnClick(Button* target) {
  auto tipEntry = static_cast<TipsEntryButton*>(target);
  if (!tipEntry->TipEntryRecord->IsLocked) SwitchToTipId(target->Id);
}

TipsMenu::TipsMenu() : ItemsList(CDIR_HORIZONTAL), TipViewItems(this) {
  FadeAnimation.Direction = AnimationDirection::In;
  FadeAnimation.LoopMode = AnimationLoopMode::Stop;
  FadeAnimation.DurationIn = FadeInDuration;
  FadeAnimation.DurationOut = FadeOutDuration;

  TipViewItems.FocusLock = false;
  TipViewItems.VisibilityState = Shown;

  Name = new Label();
  Name->Bounds = NameInitialBounds;
  TipViewItems.Add(Name);

  Pronunciation = new Label();
  Pronunciation->Bounds = PronunciationInitialBounds;
  TipViewItems.Add(Pronunciation);

  Category = new Label();
  Category->Bounds = CategoryInitialBounds;
  TipViewItems.Add(Category);

  TextPage.Glyphs.reserve(Profile::Dialogue::MaxPageSize);
  TextPage.Clear();
}

void TipsMenu::Show() {
  if (State != Shown) {
    State = Showing;
    FadeAnimation.StartIn();
    if (UI::FocusedMenu != 0) {
      LastFocusedMenu = UI::FocusedMenu;
      LastFocusedMenu->IsFocused = false;
    }
    IsFocused = true;
    UI::FocusedMenu = this;
  }
}
void TipsMenu::Hide() {
  if (State != Hidden) {
    State = Hiding;
    FadeAnimation.StartOut();
    if (LastFocusedMenu != 0) {
      UI::FocusedMenu = LastFocusedMenu;
      LastFocusedMenu->IsFocused = true;
    } else {
      UI::FocusedMenu = 0;
    }
    IsFocused = false;
    CurrentlyDisplayedTipId = -1;
  }
}

void TipsMenu::UpdateInput(float dt) {
  if (State == Shown) {
    Menu::UpdateInput(dt);
    ItemsList.UpdateInput(dt);
    if (CurrentlyDisplayedTipId != -1) {
      if (PADinputButtonWentDown & PAD1X) {
        AdvanceTipPage(TipAdvanceMode::NextLooped);
      }
    }
  }
}

void TipsMenu::Update(float dt) {
  UpdateInput(dt);

  FadeAnimation.Update(dt);
  if (ScrWork[SW_TIPSALPHA] < 256 && State == Shown) {
    Hide();
  } else if (ScrWork[SW_TIPSALPHA] == 256 && State == Hidden) {
    Show();
  }

  if (ScrWork[SW_TIPSALPHA] == 256 && FadeAnimation.IsIn())
    State = Shown;
  else if (ScrWork[SW_TIPSALPHA] == 0 && FadeAnimation.IsOut())
    State = Hidden;

  if (State != Hidden) {
    ItemsList.Tint.a = FadeAnimation.Progress;
    TipViewItems.Tint.a = FadeAnimation.Progress;
  }

  if (State == Shown) {
    ItemsList.Update(dt);
    TipViewItems.Update(dt);
  }
}

void TipsMenu::Render() {
  if (State != Hidden && ScrWork[SW_TIPSALPHA] > 0) {
    glm::vec4 col(1.0f, 1.0f, 1.0f, FadeAnimation.Progress);
    Renderer->DrawSprite(BackgroundSprite, glm::vec2(0.0f), col);
    ItemsList.Render();

    if (CurrentlyDisplayedTipId != -1) {
      TipViewItems.Render();
      TextPage.Render(col.a, RendererOutlineMode::Full);
      if (ThumbnailSprite) {
        Renderer->DrawSprite(*ThumbnailSprite, ThumbnailPosition, col);
      }
    }
  }
}

void TipsMenu::Init() {
  auto onClick = [this](auto* btn) { return TipOnClick(btn); };
  int currentPage = 0, currentCategoryId = -1;

  // String of characters by which tips are sorted, taken from _system script
  auto [buffers, bufferId, sortStrAddr] =
      Vm::ScriptGetTextTableStrAddress(SortStringTable, SortStringIndex);
  uint8_t* sortString = &buffers[bufferId][sortStrAddr];
  auto recordCount = TipsSystem::GetTipCount();

  float currentY = TipListInitialY;

  ItemsList.Clear();
  TipViewItems.Clear();

  Group* pageItems = new Group(this);
  for (size_t i = 0; i < recordCount; i++) {
    auto record = TipsSystem::GetTipRecord(i);

    // In this case the tips are split into pages in UI with maximum of 5
    // categories per page, with each category being a character from
    // the sort string and containing all tips the names of which begin with
    // that character
    auto page = record->CategoryLetterIndex / TipListCategoriesPerPage;
    if (page != currentPage) {
      if (currentPage == 0) pageItems->Show();
      currentPage = page;
      currentY = TipListInitialY;
      ItemsList.Add(pageItems);
      pageItems = new Group(this);
    }

    // Start new category
    // We take a character from the sort string and use that as the category
    // name inside a predefined template
    if (record->CategoryLetterIndex != currentCategoryId) {
      currentCategoryId = record->CategoryLetterIndex;
      CategoryString[1] = UnalignedRead<uint16_t>(
          &sortString[currentCategoryId * sizeof(uint16_t)]);

      Label* categoryLabel = new Label();
      Vm::Sc3Stream categoryStrStream(
          reinterpret_cast<uint8_t*>(CategoryString));
      categoryLabel->SetText(
          categoryStrStream, {TipListEntryBounds.X, currentY},
          TipListEntryFontSize, RendererOutlineMode::Full, 0);
      pageItems->Add(categoryLabel);
      currentY += TipListYPadding;
    }

    // Actual tip entry button
    TipListEntryBounds.Y = currentY;
    TipsEntryButton* button =
        new TipsEntryButton(record->Id, record, TipListEntryBounds,
                            Profile::BacklogMenu::EntryHighlight);
    button->OnClickHandler = onClick;

    pageItems->Add(button, FDIR_DOWN);
    currentY += TipListYPadding;
  }

  // Add last category
  ItemsList.Add(pageItems);

  // Number label
  NumberText = new Label(Vm::ScriptGetTextTableStrAddress(NumberLabelStrTable,
                                                          NumberLabelStrIndex),
                         NumberLabelPosition, NumberLabelFontSize,
                         RendererOutlineMode::Full, DefaultColorIndex);
  TipViewItems.Add(NumberText);
  // Tip number
  Number = new Label();
  Number->Bounds = NumberBounds;
  TipViewItems.Add(Number);
  // Tip page separator
  PageSeparator = new Label(
      Vm::ScriptGetTextTableStrAddress(PageSeparatorTable, PageSeparatorIndex),
      PageSeparatorPosition, PageSeparatorFontSize, RendererOutlineMode::Full,
      DefaultColorIndex);
  TipViewItems.Add(PageSeparator);
  // Current tip page
  CurrentPage = new Label();
  CurrentPage->Bounds = CurrentPageBounds;
  TipViewItems.Add(CurrentPage);
  // Total tip pages
  TotalPages = new Label();
  TotalPages->Bounds = TotalPagesBounds;
  TipViewItems.Add(TotalPages);
}

void TipsMenu::SwitchToTipId(int id) {
  CurrentlyDisplayedTipId = id;
  CurrentTipPage = 1;
  TipsSystem::SetTipUnreadState(id, false);
  TipsSystem::SetTipNewState(id, false);
  auto [buffers, tipsScriptBufferId] = TipsSystem::GetTipsScriptBufferCtx();

  auto tipRecord = TipsSystem::GetTipRecord(id);
  Name->SetText(Vm::BufferOffsetContext{.Buffers = buffers,
                                        .BufferId = tipsScriptBufferId,
                                        .IpOffset = tipRecord->StringAdr[0]},
                NameInitialBounds.GetPos(), NameFontSize,
                RendererOutlineMode::Full, DefaultColorIndex);
  Pronunciation->SetText(
      Vm::BufferOffsetContext{.Buffers = buffers,
                              .BufferId = tipsScriptBufferId,
                              .IpOffset = tipRecord->StringAdr[1]},
      PronunciationInitialBounds.GetPos(), PronunciationFontSize,
      RendererOutlineMode::Full, DefaultColorIndex);

  Vm::Sc3VmThread dummy;
  dummy.IpOffset = tipRecord->StringAdr[2];
  dummy.ScriptBufferId = tipsScriptBufferId;
  dummy.UseMSBBuffers = Profile::Vm::UseMsbStrings;
  float categoryWidth = TextGetPlainLineWidth(
      &dummy, *Profile::Dialogue::DialogueFont, CategoryFontSize);
  Category->Bounds.X = CategoryEndX - categoryWidth;
  Category->SetText(
      Vm::BufferOffsetContext{.Buffers = buffers,
                              .BufferId = tipsScriptBufferId,
                              .IpOffset = tipRecord->StringAdr[2]},
      {CategoryEndX - categoryWidth, CategoryInitialBounds.Y}, CategoryFontSize,
      RendererOutlineMode::Full, DefaultColorIndex);
  if (tipRecord->ThumbnailIndex != 0xFFFF)
    ThumbnailSprite = &TipThumbnails[tipRecord->ThumbnailIndex];
  else
    ThumbnailSprite = &TipTextOnlyThumbnail;

  Number->SetText(fmt::format("{:4d}", tipRecord->Id + 1),
                  NumberBounds.GetPos(), NumberFontSize,
                  RendererOutlineMode::Full, DefaultColorIndex);

  CurrentPage->SetText(fmt::to_string(CurrentTipPage),
                       CurrentPageBounds.GetPos(), PageSeparatorFontSize,
                       RendererOutlineMode::Full, DefaultColorIndex);

  TotalPages->SetText(fmt::to_string(tipRecord->NumberOfContentStrings),
                      TotalPagesBounds.GetPos(), PageSeparatorFontSize,
                      RendererOutlineMode::Full, DefaultColorIndex);

  TextPage.Clear();
  dummy.IpOffset = tipRecord->StringAdr[3];
  dummy.ScriptBufferId = tipsScriptBufferId;
  TextPage.AddString(&dummy);
}

void TipsMenu::AdvanceTipPage(TipAdvanceMode mode) {
  auto currentRecord = TipsSystem::GetTipRecord(CurrentlyDisplayedTipId);
  const int numberOfContentStrings =
      static_cast<int>(currentRecord->NumberOfContentStrings);
  if (numberOfContentStrings == 1) return;
  CurrentTipPage += mode == TipAdvanceMode::PrevClamped ? -1 : 1;
  switch (mode) {
    case TipAdvanceMode::PrevClamped: {
      CurrentTipPage = std::max(CurrentTipPage, 1);
      break;
    }
    case TipAdvanceMode::NextClamped: {
      CurrentTipPage = std::min(CurrentTipPage, numberOfContentStrings);
      break;
    }
    case TipAdvanceMode::NextLooped: {
      if (CurrentTipPage > numberOfContentStrings) CurrentTipPage = 1;
      break;
    }
  }

  TextPage.Clear();
  Vm::Sc3VmThread dummy;
  dummy.ScriptBufferId = TipsSystem::GetTipsScriptBufferCtx().BufferId;
  dummy.IpOffset = currentRecord->StringAdr[2 + CurrentTipPage];
  TextPage.AddString(&dummy);
  CurrentPage->SetText(fmt::to_string(CurrentTipPage),
                       CurrentPageBounds.GetPos(), PageSeparatorFontSize,
                       RendererOutlineMode::Full, DefaultColorIndex);
}

}  // namespace MO6TW
}  // namespace UI
}  // namespace Impacto