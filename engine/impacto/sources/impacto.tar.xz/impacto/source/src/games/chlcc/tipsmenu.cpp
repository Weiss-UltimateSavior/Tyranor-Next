#include "tipsmenu.h"

#include "../../renderer/renderer.h"
#include "../../mem.h"
#include "../../profile/scriptvars.h"
#include "../../profile/dialogue.h"
#include "../../profile/vm.h"
#include "../../profile/ui/tipsmenu.h"
#include "../../profile/games/chlcc/tipsmenu.h"
#include "../../profile/games/chlcc/commonmenu.h"

#include "../../data/tipssystem.h"
#include "../../vm/interface/input.h"
#include "../../ui/widgets/chlcc/tipsentrybutton.h"
#include "../../inputsystem.h"

#include <numeric>

namespace Impacto {
namespace UI {
namespace CHLCC {

using namespace Impacto::Profile::CHLCC::CommonMenu;

using namespace Impacto::Profile::TipsMenu;
using namespace Impacto::Profile::CHLCC::TipsMenu;
using namespace Impacto::Profile::ScriptVars;

using namespace Impacto::Vm::Interface;

using namespace Impacto::UI::Widgets;
using namespace Impacto::UI::Widgets::CHLCC;

static float GetEndScroll(Group* tipsItemsGroup) {
  if (tipsItemsGroup->Children.empty() || tipsItemsGroup->Children.size() == 1)
    return 0.0f;
  const Widget* lastItem = tipsItemsGroup->Children.back();
  const float lastItemEndPos = lastItem->Bounds.Height + lastItem->Bounds.Y;
  const float pagePos =
      lastItemEndPos - TipsListBounds.Height - TipsListBounds.Y;
  if (pagePos < 0.0f) return 0.0f;
  return round(pagePos / TipListYPadding) * TipListYPadding;
}

void TipsMenu::HandlePageChange(Widget* cur, Widget* next) {
  if (cur != next) {
    static_cast<Group*>(cur)->MoveTo(TipsListBounds.GetPos());
    cur->Hide();
    next->Show();
    CurrentlyFocusedElement =
        static_cast<Group*>(next)->GetFirstFocusableChild();
    CurrentlyFocusedElement->HasFocus = true;
    TipsEntryScrollPos = 0.0f;
    TipsEntriesScrollbar = Scrollbar(
        0, {TipsListBounds.X + TipsListBounds.Width - 3.0f, TipsListBounds.Y},
        0.0f, GetEndScroll(static_cast<Group*>(next)), &TipsEntryScrollPos,
        SBDIR_VERTICAL, TipsScrollTrack, TipsScrollThumb, {0.0f, -4.0f},
        TipsScrollThumb.ScaledHeight(), TipsListBounds);
    TipsEntriesScrollbar->SetScrollAreaBounds(TipsListBounds);
    TipsEntriesScrollbar->Step = TipListYPadding;
  }
}

TipsMenu::TipsMenu()
    : CommonMenu(true),
      ItemsList(
          Widgets::CarouselDirection::CDIR_HORIZONTAL,
          [this](Widget* cur, Widget* next) { HandlePageChange(cur, next); },
          [this](Widget* cur, Widget* next) { HandlePageChange(cur, next); }),
      TipViewItems(this) {
  TipViewItems.FocusLock = false;

  TextPage.Glyphs.reserve(Profile::Dialogue::MaxPageSize);
  TextPage.Clear();
}

void TipsMenu::Show() {
  if (State != Shown) {
    if (State != Showing) {
      MenuTransition.StartIn();
      FromSystemMenuTransition->StartIn();
      SelectAnimation.StartIn(true);
    }
    State = Showing;
    if (UI::FocusedMenu != 0) {
      LastFocusedMenu = UI::FocusedMenu;
      LastFocusedMenu->IsFocused = false;
    }
    UI::FocusedMenu = this;
    TipsEntryScrollPos = 0.0f;
    (*ItemsList.GetCurrent())->Show();
    (*ItemsList.GetCurrent())->HasFocus = false;
    TipViewItems.Bounds = RectF{};
    TipViewItems.Show();
    if (TipsEntriesScrollbar) {
      TipsEntriesScrollbar->MoveTo(
          {TipsListBounds.X + TipsListBounds.Width - 3.0f, TipsListBounds.Y});
    }
  }
}
void TipsMenu::Hide() {
  if (State != Hidden) {
    if (State != Hiding) {
      MenuTransition.StartOut();
      FromSystemMenuTransition->StartOut();
    }
    State = Hiding;
    if (LastFocusedMenu != 0) {
      UI::FocusedMenu = LastFocusedMenu;
    } else {
      UI::FocusedMenu = 0;
    }
    IsFocused = false;
  }
}

void TipsMenu::Render() {
  if (State == Hidden) return;
  CommonMenu::DrawSubmenu(BackgroundColor, CircleSprite, MenuTitleText,
                          MenuTitleTextAngle);
  const glm::vec2 animationOffset = MenuTransition.GetPageOffset();

  if (MenuTransition.State != AnimationState::Stopped) {
    Group* currentPage = static_cast<Group*>(*ItemsList.GetCurrent());
    const glm::vec2 pgOffset = [&] {
      glm::vec2 fOffset = TipsListBounds.GetPos() + animationOffset;
      return glm::vec2{std::round(fOffset.x),
                       std::round(fOffset.y - TipsEntryScrollPos)};
    }();
    const glm::vec2 renderBoundsOffset =
        TipsListRenderBounds.GetPos() + animationOffset;
    const glm::vec2 tipsRenderBoundsOffset =
        TextModesInfo[Profile::Dialogue::TipsMessageModeIdx].WindowPos +
        animationOffset;

    currentPage->MoveTo(pgOffset);
    currentPage->RenderingBounds.X = std::round(renderBoundsOffset.x);
    currentPage->RenderingBounds.Y = std::round(renderBoundsOffset.y);
    TipViewItems.MoveTo(animationOffset);
    TextPage.MoveTo(tipsRenderBoundsOffset);
    if (TipsEntriesScrollbar) {
      const glm::vec2 scrollbarOffset =
          animationOffset +
          glm::vec2{TipsListBounds.X + TipsListBounds.Width, TipsListBounds.Y};
      TipsEntriesScrollbar->MoveTo(scrollbarOffset);
    }
  }

  DrawTipsTree();
  SelectAnimation.Draw(SelectWordSprites, SelectWordPos, animationOffset);
  DrawLeftTitle(MenuTitleText);

  if (MenuTransition.Progress > 0.34) {
    // Alpha goes from 0 to 1 in half the time
    const float alpha = std::clamp(MenuTransition.Progress * 2.0f, 0.0f, 1.0f);
    ItemsList.Tint.a = alpha;
    ItemsList.Render();
    if (CurrentlyDisplayedTipId != -1) {
      TipViewItems.Tint.a = alpha;
      TipViewItems.Render();
      TextPage.Render(alpha, RendererOutlineMode::BottomRight);
    }
    if (TipsEntriesScrollbar) {
      TipsEntriesScrollbar->Tint.a = alpha;
      TipsEntriesScrollbar->Render();
    }
  }

  DrawButtonPrompt(ButtonPromptSprite, ButtonPromptPosition);
}

void TipsMenu::UpdateInput(float dt) {
  if (State == Shown) {
    ItemsList.UpdateInput(dt);
    if (Input::CurrentInputDevice == Input::Device::Touch) {
      if (Input::TouchFlickRight) ItemsList.Previous();
      if (Input::TouchFlickLeft) ItemsList.Next();
    }

    TipViewItems.UpdateInput(dt);
    UpdatePageInput(dt);
    if (CurrentlyDisplayedTipId != -1) {
      if (PADinputButtonWentDown & PAD1X) {
        AdvanceTipPage(TipAdvanceMode::NextLooped);
      }

      if (Input::CurrentInputDevice == Input::Device::Mouse ||
          Input::CurrentInputDevice == Input::Device::Touch) {
        const RectF tipBox(CurrentTipBackgroundPosition.x,
                           CurrentTipBackgroundPosition.y,
                           CurrentTipBackgroundSprite.Bounds.Width,
                           CurrentTipBackgroundSprite.Bounds.Height);

        if (tipBox.ContainsPoint(Input::CurMousePos)) {
          if (Input::MouseWheelDeltaY > 0.0f) {
            AdvanceTipPage(TipAdvanceMode::PrevClamped);
          } else if (Input::MouseWheelDeltaY < 0.0f) {
            AdvanceTipPage(TipAdvanceMode::NextClamped);
          }
        }
        if (tipBox.ContainsPoint(Input::InitMousePos)) {
          if (Input::TouchFlickDown) {
            AdvanceTipPage(TipAdvanceMode::PrevClamped);
          } else if (Input::TouchFlickUp) {
            AdvanceTipPage(TipAdvanceMode::NextClamped);
          }
        }
      }

      PrevPageTipClickArea.UpdateInput(dt);
      NextPageTipClickArea.UpdateInput(dt);
    }
  }
}

void TipsMenu::Update(float dt) {
  const int sysMenuCt = ScrWork[SW_SYSMENUCT];
  const int systemMenuCHG = ScrWork[SW_SYSTEMMENUCHG];

  if ((!GetFlag(SF_TIPSMENU) || sysMenuCt < 10000 ||
       (sysMenuCt == 10000 && systemMenuCHG != 0 && systemMenuCHG != 64)) &&
      State == Shown) {
    Hide();
  } else if (GetFlag(SF_TIPSMENU) && sysMenuCt > 0 && State == Hidden) {
    Show();
  }

  if (MenuTransition.IsOut() && !GetFlag(SF_TIPSMENU) && systemMenuCHG == 0 &&
      (sysMenuCt == 0 || GetFlag(SF_SYSTEMMENU)) && State == Hiding) {
    State = Hidden;

    (*ItemsList.GetCurrent())->Hide();
    TipViewItems.Hide();

    for (const auto tipNewId : TipsSystem::GetNewTipsIndices()) {
      TipsSystem::SetTipNewState(tipNewId, false);
    }
    TipsSystem::GetNewTipsIndices().resize(0);
    CurrentlyDisplayedTipId = -1;
    if (LastFocusedMenu) LastFocusedMenu->IsFocused = true;
  } else if (MenuTransition.IsIn() && sysMenuCt == 10000 &&
             (systemMenuCHG == 0 || systemMenuCHG == 64) &&
             GetFlag(SF_TIPSMENU) && State == Showing) {
    State = Shown;
    IsFocused = true;
    (*ItemsList.GetCurrent())->HasFocus = true;
    AdvanceFocus(FDIR_DOWN);
  }

  if (State != Hidden) {
    MenuTransition.Update(dt);
    FromSystemMenuTransition->Update(dt);
    SelectAnimation.Update(dt);
    if (MenuTransition.Direction == AnimationDirection::Out &&
        MenuTransition.Progress <= 0.72f) {
      TitleFade.StartOut();
    } else if (MenuTransition.IsIn() &&
               (TitleFade.Direction == AnimationDirection::In ||
                TitleFade.IsOut())) {
      TitleFade.StartIn();
    }
    TitleFade.Update(dt);
    UpdateTitles(MenuTitleTextRightPosition, MenuTitleTextLeftPosition);
    if (TipsEntriesScrollbar) {
      TipsEntriesScrollbar->Update(dt);
    }

    if (CurrentlyDisplayedTipId != -1) {
      PrevPageTipClickArea.Update(dt);
      NextPageTipClickArea.Update(dt);
    }
  }

  if (State == Shown) {
    UpdateInput(dt);
    ItemsList.Update(dt);
    TipViewItems.Update(dt);
  }
}

void TipsMenu::TipOnClick(Button* target) {
  auto tipEntry = static_cast<TipsEntryButton*>(target);
  if (!tipEntry->TipEntryRecord->IsLocked) {
    CurrentlyFocusedElement = target;
    SwitchToTipId(tipEntry->TipEntryRecord->Id);
  }
}

void TipsMenu::Init() {
  auto onClick = [this](auto* btn) { return TipOnClick(btn); };
  int currentCategoryId = -1;

  // String of characters by which tips are sorted, taken from _system script
  auto [buffers, bufferId, catStrAddr] =
      Vm::ScriptGetTextTableStrAddress(TipsStringTable, CategoryStringIndex);
  uint8_t* categoryString = &buffers[bufferId][catStrAddr];
  ItemsList.Clear();
  TipViewItems.Clear();
  Group* allTipsGroup = new Group(this);
  allTipsGroup->Bounds = TipsListBounds;
  allTipsGroup->RenderingBounds = TipsListRenderBounds;
  // Add a bit of margins

  ItemsList.Add(allTipsGroup);
  TipsEntryScrollPos = 0;
  // Sorting tip records
  auto& records = *TipsSystem::GetTipRecords();
  const auto recordCount = TipsSystem::GetTipCount();
  auto indexes = [recordCount] {
    std::vector<int> result(recordCount);
    std::iota(result.begin(), result.end(), 0);
    std::ranges::sort(result, TipsSystem::TipsComparator(TipsStringTable,
                                                         SortStringIndex, 2));
    return result;
  }();
  auto sortedView = std::ranges::views::transform(
      indexes, [&records](size_t i) -> TipsSystem::TipsDataRecord& {
        return records[i];
      });
  std::vector<int> sortedIndicesMap(recordCount);
  for (int i = 0; i < std::ssize(sortedView); i++) {
    sortedIndicesMap[sortedView[i].Id] = i;
  }

  auto createCategory = [&](auto labelText, float yPos) {
    Label* categoryLabel = new Label();
    categoryLabel->SetText(labelText, {TipListEntryBounds.X + 5.0f, yPos},
                           TipListEntryFontSize,
                           RendererOutlineMode::BottomRight, 0);
    categoryLabel->Bounds.X -= 5.0f;
    categoryLabel->Bounds.Width += 5.0f;
    return categoryLabel;
  };
  {
    float currentY = TipListEntryBounds.Y;
    for (auto& record : sortedView) {
      //  Each category is a character from the sort string and contains all
      //  tips the names of which begin with that character

      // Start new category
      // We take a character from the sort string and use that as the
      // category name inside a predefined template
      if (record.CategoryLetterIndex != currentCategoryId) {
        currentCategoryId = record.CategoryLetterIndex;
        std::ranges::copy(CategoryString,
                          std::back_inserter(CategoryStringBuffer));
        if (currentCategoryId != std::numeric_limits<uint16_t>::max()) {
          CategoryStringBuffer[1] = UnalignedRead<uint16_t>(
              &categoryString[currentCategoryId * sizeof(uint16_t)]);
        }
        Vm::Sc3Stream categoryStrStream(
            reinterpret_cast<uint8_t*>(CategoryStringBuffer.data()));
        allTipsGroup->Add(createCategory(categoryStrStream, currentY));
        currentY += TipListYPadding;
      }

      // Actual tip entry button
      RectF bounds = TipListEntryBounds;
      bounds.Y = currentY;
      TipsEntryButton* button = new TipsEntryButton(
          sortedIndicesMap[record.Id], &record, bounds, TipsEntryHighlightBar);
      button->OnClickHandler = onClick;

      allTipsGroup->Add(button, FDIR_DOWN);
      currentY += TipListYPadding;
    }
  }
  {
    float currentY = TipListEntryBounds.Y;
    auto* newTipsGroup = new Group(this);
    newTipsGroup->Add(createCategory(
        Vm::ScriptGetTextTableStrAddress(TipsStringTable, NewLabelStrIndex),
        currentY));
    currentY += TipListYPadding;

    auto newRecordsView =
        std::ranges::views::transform(
            TipsSystem::GetNewTipsIndices(),
            [&records](size_t i) -> TipsSystem::TipsDataRecord& {
              return records[i];
            }) |
        std::views::reverse;
    for (auto& record : newRecordsView) {
      // assert(!record.IsLocked && record.IsNew);
      RectF bounds = TipListEntryBounds;
      bounds.Y = currentY;
      TipsEntryButton* button = new TipsEntryButton(
          sortedIndicesMap[record.Id], &record, bounds, TipsEntryHighlightBar);
      button->OnClickHandler = onClick;

      newTipsGroup->Add(button, FDIR_DOWN);
      currentY += TipListYPadding;
    }
    if (newTipsGroup->Children.size() > 1) {
      ItemsList.Add(newTipsGroup);
      newTipsGroup->Bounds = TipsListBounds;
      newTipsGroup->RenderingBounds = TipsListRenderBounds;
    } else {
      delete newTipsGroup;
      newTipsGroup = nullptr;
    }
  }

  {
    float currentY = TipListEntryBounds.Y;

    Group* unreadTipsGroup = new Group(this);
    unreadTipsGroup->Add(createCategory(
        Vm::ScriptGetTextTableStrAddress(TipsStringTable, UnreadLabelStrIndex),
        currentY));
    currentY += TipListYPadding;
    for (auto& record : sortedView) {
      if (!record.IsUnread || record.IsLocked) {
        continue;
      }
      RectF bounds = TipListEntryBounds;
      bounds.Y = currentY;
      TipsEntryButton* button = new TipsEntryButton(
          sortedIndicesMap[record.Id], &record, bounds, TipsEntryHighlightBar);
      button->OnClickHandler = onClick;

      unreadTipsGroup->Add(button, FDIR_DOWN);
      currentY += TipListYPadding;
    }
    if (unreadTipsGroup->Children.size() > 1) {
      ItemsList.Add(unreadTipsGroup);
      unreadTipsGroup->Bounds = TipsListBounds;
      unreadTipsGroup->RenderingBounds = TipsListRenderBounds;
    } else {
      delete unreadTipsGroup;
    }
  }

  TipsEntriesScrollbar =
      Scrollbar(0, {TipsListBounds.X + TipsListBounds.Width, TipsListBounds.Y},
                0.0f, GetEndScroll(allTipsGroup), &TipsEntryScrollPos,
                SBDIR_VERTICAL, TipsScrollTrack, TipsScrollThumb, {0.0f, 0.0f},
                TipsScrollThumb.ScaledHeight(), TipsListBounds);
  TipsEntriesScrollbar->SetScrollAreaBounds(TipsListBounds);
  TipsEntriesScrollbar->Step = TipListYPadding;
  Name = new Label();
  TipViewItems.Add(Name);

  Pronunciation = new Label();
  TipViewItems.Add(Pronunciation);

  // Number label
  NumberText = new Label(
      Vm::ScriptGetTextTableStrAddress(TipsStringTable, NumberLabelStrIndex),
      NumberLabelPosition, NumberLabelFontSize,
      RendererOutlineMode::BottomRight, DefaultColorIndex);
  TipViewItems.Add(NumberText);
  // Tip number
  Number = new Label();
  TipViewItems.Add(Number);
  // Tip page separator
  auto* const pageSeparator =
      new Label(PageSeparatorSprite, PageSeparatorPosition);
  TipViewItems.Add(pageSeparator);
  // Current tip page
  CurrentPage = new Label();
  CurrentPage->Bounds.SetPos(CurrentPagePosition);
  TipViewItems.Add(CurrentPage);
  // Total tip pages
  TotalPages = new Label();
  TotalPages->Bounds.SetPos(TotalPagesPosition);
  TipViewItems.Add(TotalPages);

  // use size from CurrentPageSprite and use Y coord from CurrentPagePos
  const glm::vec2 pageNumberSize = CurrentPageSprites[0].Bounds.GetSize();
  RectF pagerBounds = RectF(CurrentPagePosition.x, CurrentPagePosition.y,
                            pageNumberSize.x, pageNumberSize.y);
  const std::function<void(ClickArea*)> onClickPrev = [this](auto* btn) {
    return AdvanceTipPage(TipAdvanceMode::PrevClamped);
  };
  PrevPageTipClickArea = ClickArea(0, pagerBounds, onClickPrev);

  pagerBounds.X = TotalPagesPosition.x;
  const std::function<void(ClickArea*)> onClickNext = [this](auto* btn) {
    return AdvanceTipPage(TipAdvanceMode::NextClamped);
  };
  NextPageTipClickArea = ClickArea(1, pagerBounds, onClickNext);
}

void TipsMenu::UpdatePageInput(float dt) {
  using namespace Vm::Interface;
  if (!IsFocused) return;
  auto prevEntry = CurrentlyFocusedElement;
  const float oldScrollPos = TipsEntryScrollPos;

  auto checkScrollBounds = [&]() {
    return !TipsListBounds.Contains(CurrentlyFocusedElement->Bounds);
  };

  UI::TipsMenu::UpdateInput(dt);

  auto* curPage = static_cast<Group*>(*ItemsList.GetCurrent());

  if (CurrentlyFocusedElement != prevEntry && checkScrollBounds()) {
    if (CurrentlyFocusedElement == curPage->GetFirstFocusableChild()) {
      TipsEntryScrollPos = 0;
    } else if (CurrentlyFocusedElement == curPage->Children.back()) {
      TipsEntryScrollPos = TipsEntriesScrollbar->EndValue;
    } else {
      TipsEntryScrollPos +=
          CurrentlyFocusedElement->Bounds.Y - prevEntry->Bounds.Y;
    }
  }

  if (TipsEntriesScrollbar) {
    TipsEntriesScrollbar->UpdateInput(dt);
  }

  if (oldScrollPos != TipsEntryScrollPos) {
    float delta = oldScrollPos - TipsEntryScrollPos;
    if (std::fmod(std::abs(delta), TipListYPadding) >
        std::numeric_limits<float>::epsilon()) {
      const float newDelta =
          std::round(delta / TipListYPadding) * TipListYPadding;
      TipsEntryScrollPos = oldScrollPos - newDelta;
      delta = newDelta;
    }
    curPage->Move({0, delta});

    if (TipsEntriesScrollbar && TipsEntriesScrollbar->IsScrollHeld() &&
        CurrentlyFocusedElement) {
      // advance focus during drag
      FocusDirection dir = (delta < 0) ? FDIR_DOWN : FDIR_UP;
      Widget* startElement = CurrentlyFocusedElement;
      while (!TipsListBounds.Contains(CurrentlyFocusedElement->Bounds)) {
        AdvanceFocus(dir);
        if (CurrentlyFocusedElement == startElement) break;
      }
    }
  }

  if (!TipsEntriesScrollbar || !TipsEntriesScrollbar->IsScrollHeld())
    curPage->UpdateInput(dt);
}

void TipsMenu::DrawTipsTree() {
  const glm::vec2 animationOffset = MenuTransition.GetPageOffset();
  glm::vec2 currentTipBackgroundPosition(
      CurrentTipBackgroundPosition.x,
      CurrentTipBackgroundPosition.y + animationOffset.y);
  Renderer->DrawSprite(CurrentTipBackgroundSprite,
                       currentTipBackgroundPosition);
  glm::vec2 gradientPosition(GradientPosition.x,
                             GradientPosition.y + animationOffset.y);
  Renderer->DrawSprite(TipsGradient, gradientPosition);
  const float gradientEndY =
      TipsListBounds.Y + TipsListBounds.Height + animationOffset.y - 5.0f;
  Renderer->DrawQuad(
      RectF(GradientPosition.x, gradientEndY, TipsGradient.Bounds.Width, 91.0f),
      RgbIntToFloat(EndOfGradientColor));
  glm::vec2 treePosition(TreePosition.x, TreePosition.y + animationOffset.y);
  Renderer->DrawSprite(TipsTree, treePosition);

  const auto* const currentPage =
      static_cast<Widgets::Group*>(*ItemsList.GetCurrent());
  size_t i = 0;
  for (const auto* const widget : currentPage->Children) {
    const glm::vec2 pos = widget->Bounds.GetPos();
    const glm::vec2 linePos = pos + glm::vec2{-22, 0};
    const float bottomEdge =
        animationOffset.y + TipsListBounds.Y + TipsListBounds.Height;
    const bool lastViewable = bottomEdge - pos.y < TipListYPadding + 1.0f &&
                              bottomEdge - pos.y > 0.0f;

    std::reference_wrapper<const Sprite> barSprite = TipsListBgBar;
    std::reference_wrapper<const Sprite> lineSprite = TipsLeftLine;
    if (const auto* const btn = dynamic_cast<const TipsEntryButton*>(widget)) {
      barSprite = TipsListBgBarHole;
      lineSprite = TipsLeftLineHole;
      if (btn == currentPage->Children.back()) {
        lineSprite = TipsLeftLineHoleEnd;
      }
    }

    Renderer->EnableScissor();
    Renderer->SetScissorRect(currentPage->RenderingBounds);
    Renderer->DrawSprite(barSprite, pos);
    Renderer->DrawSprite(lineSprite, linePos);
    Renderer->DisableScissor();
    if (lastViewable && widget != currentPage->Children.back())
      Renderer->DrawSprite(TipsLeftLineEnd,
                           linePos + glm::vec2{0, TipListYPadding});
    ++i;
  }
  // Fill in the rest of the bg if tips is less than full page
  if (i * TipListYPadding < TipsListBounds.Height) {
    const float remainder = TipsListBounds.Height - (i * TipListYPadding);
    const float start =
        TipsListBounds.Y + animationOffset.y + (i * TipListYPadding);
    RectF dest{
        GradientPosition.x + animationOffset.x,
        start,
        TipsListBounds.Width,
        remainder,
    };
    Renderer->DrawQuad(dest, RgbIntToFloat(EndOfGradientColor));
  }
}

void TipsMenu::SwitchToTipId(int id) {
  CurrentlyDisplayedTipId = id;
  CurrentTipPage = 1;
  TipsSystem::SetTipUnreadState(id, false);
  TipsSystem::SetTipNewState(id, false);
  auto [buffers, tipsScriptBufferId] = TipsSystem::GetTipsScriptBufferCtx();

  auto tipRecord = TipsSystem::GetTipRecord(id);
  auto nameStr = TipsSystem::GetTextStringStream(id, 0);
  auto pronunciationStr = TipsSystem::GetTextStringStream(id, 1);
  Name->SetText(nameStr, {0.0f, 0.0f}, NameFontSize,
                RendererOutlineMode::BottomRight, DefaultColorIndex);
  Pronunciation->SetText(pronunciationStr, {0.0f, 0.0f}, PronunciationFontSize,
                         RendererOutlineMode::BottomRight, DefaultColorIndex);
  // Right alignment
  Name->MoveTo(NameInitialBounds.GetPos() -
               glm::vec2{Name->Bounds.Width, 0.0f});
  Pronunciation->MoveTo(PronunciationInitialBounds.GetPos() -
                        glm::vec2{Pronunciation->Bounds.Width, 0.0f});

  const int sortedTipId =
      static_cast<TipsEntryButton*>(CurrentlyFocusedElement)->Id;
  Number->SetText(fmt::format("{:4d}", sortedTipId + 1), NumberBounds.GetPos(),
                  NumberFontSize, RendererOutlineMode::BottomRight,
                  DefaultColorIndex);

  CurrentPage->SetSprite(CurrentPageSprites[CurrentTipPage]);
  TotalPages->SetSprite(TotalPageSprites[tipRecord->NumberOfContentStrings]);

  TextPage.Clear();
  Vm::Sc3VmThread dummy;
  dummy.ScriptBufferId = tipsScriptBufferId;
  dummy.UseMSBBuffers = Profile::Vm::UseMsbStrings;
  dummy.IpOffset = tipRecord->StringAdr[3];
  TextPage.AddString(&dummy);
}

void TipsMenu::AdvanceTipPage(TipAdvanceMode mode) {
  auto currentRecord = TipsSystem::GetTipRecord(CurrentlyDisplayedTipId);
  const int numberOfContentStrings =
      static_cast<int>(currentRecord->NumberOfContentStrings);
  if (numberOfContentStrings == 1) return;
  CurrentTipPage += mode == TipAdvanceMode::PrevClamped ? -1 : 1;
  switch (mode) {
    case TipAdvanceMode::PrevClamped: {
      CurrentTipPage = std::max(CurrentTipPage, 1);
      break;
    }
    case TipAdvanceMode::NextClamped: {
      CurrentTipPage = std::min(CurrentTipPage, numberOfContentStrings);
      break;
    }
    case TipAdvanceMode::NextLooped: {
      if (CurrentTipPage > numberOfContentStrings) CurrentTipPage = 1;
      break;
    }
  }

  TextPage.Clear();
  auto [buffers, tipsScriptBufferId] = TipsSystem::GetTipsScriptBufferCtx();
  Vm::Sc3VmThread dummy;
  dummy.ScriptBufferId = tipsScriptBufferId;
  dummy.UseMSBBuffers = Profile::Vm::UseMsbStrings;
  dummy.IpOffset = currentRecord->StringAdr[3 + CurrentTipPage - 1];
  TextPage.AddString(&dummy);
  CurrentPage->SetSprite(CurrentPageSprites[CurrentTipPage]);
}

}  // namespace CHLCC
}  // namespace UI
}  // namespace Impacto