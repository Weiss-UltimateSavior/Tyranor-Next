#include "musicmenu.h"

#include "../../profile/games/chlcc/musicmenu.h"
#include "../../profile/scriptvars.h"
#include "../../renderer/renderer.h"
#include "../../ui/ui.h"
#include "../../data/savesystem.h"
#include "../../vm/interface/input.h"
#include "../../profile/game.h"
#include "../../inputsystem.h"
#include "../../audio/audiosystem.h"
#include "../../ui/widgets/chlcc/trackselectbutton.h"
#include "../../profile/games/chlcc/commonmenu.h"

namespace Impacto {
namespace UI {
namespace CHLCC {

using namespace Impacto::Profile::CHLCC::CommonMenu;
using namespace Impacto::Profile::CHLCC::MusicMenu;
using namespace Impacto::Profile::ScriptVars;

using namespace Impacto::UI::Widgets;

using namespace Impacto::Vm::Interface;

constexpr bool isRepeat(MusicPlaybackMode playbackMode) {
  return (playbackMode & MusicPlaybackMode::RepeatOne) ==
         MusicPlaybackMode::RepeatOne;
}

constexpr bool isPlaylist(MusicPlaybackMode playbackMode) {
  return (playbackMode & MusicPlaybackMode::Playlist) ==
         MusicPlaybackMode::Playlist;
}

void MusicMenu::MusicButtonOnClick(Button* target) {
  if (target->IsLocked) return;

  SwitchToTrack(target->Id);
}

void MusicMenu::ToggleRepeatMode() {
  PlaybackMode ^= MusicPlaybackMode::RepeatOne;
  PlayModeRepeatSprite =
      isRepeat(PlaybackMode) ? PlaymodeRepeatHighlight : PlaymodeRepeat;
  UpdateLooping();
}

void MusicMenu::ToggleAllMode() {
  PlaybackMode ^= MusicPlaybackMode::Playlist;
  PlayModeAllSprite =
      isPlaylist(PlaybackMode) ? PlaymodeAllHighlight : PlaymodeAll;
  UpdateLooping();
}

void MusicMenu::UpdateLooping() {
  if (PlaybackMode == MusicPlaybackMode::RepeatOne) {
    Audio::Channels[Audio::AC_BGM0]->SetLooping(true);
  } else {
    Audio::Channels[Audio::AC_BGM0]->SetLooping(false);
  }
}

static float GetEndScroll(Group* itemsGroup) {
  if (itemsGroup->Children.empty() || itemsGroup->Children.size() == 1)
    return 0.0f;
  const Widget* lastItem = itemsGroup->Children.back();
  const float lastItemEndPos = lastItem->Bounds.Height + lastItem->Bounds.Y;
  const float pagePos =
      lastItemEndPos - TrackListBounds.Height - TrackListBounds.Y;
  if (pagePos < 0.0f) return 0.0f;
  return round(pagePos / TrackOffset.y) * TrackOffset.y;
}

MusicMenu::MusicMenu() : CommonMenu(false) {
  NowPlayingAnimation.Direction = AnimationDirection::In;
  NowPlayingAnimation.LoopMode = AnimationLoopMode::Stop;
  NowPlayingAnimation.SetDuration(NowPlayingAnimationDuration);

  auto toggleRepeatClick = [this](auto* btn) { return ToggleRepeatMode(); };
  PlayModeRepeatClickArea =
      ClickArea(0,
                {PlaymodeRepeatPos.x, PlaymodeRepeatPos.y,
                 PlaymodeRepeat.ScaledWidth(), PlaymodeRepeat.ScaledHeight()},
                toggleRepeatClick);

  auto toggleAllClick = [this](auto* btn) { return ToggleAllMode(); };
  PlayModeAllClickArea =
      ClickArea(1,
                {PlaymodeAllPos.x, PlaymodeAllPos.y, PlaymodeAll.ScaledWidth(),
                 PlaymodeAll.ScaledHeight()},
                toggleAllClick);

  MainItems = new Group(this);

  for (int idx = 0; idx < MusicTrackCount; idx++) {
    auto button = new Widgets::CHLCC::TrackSelectButton(
        idx, TrackHighlight, TrackButtonPosTemplate + (float)idx * TrackOffset,
        TrackNumRelativePos, TrackNameOffset, ArtistOffset);
    MainItems->Add(button, FDIR_DOWN);

    // Page scrolling
    if (idx >= SelectableItemsPerPage) {
      button->SetFocus(MainItems->Children[idx - SelectableItemsPerPage],
                       FDIR_LEFT);
      MainItems->Children[idx - SelectableItemsPerPage]->SetFocus(button,
                                                                  FDIR_RIGHT);
    } else {
      button->SetFocus(MainItems->Children.front(), FDIR_LEFT);
    }
  }

  MainScrollbar = Scrollbar(
      0, ScrollbarPosition, 0.0f, GetEndScroll(MainItems), &ScrollY,
      ScrollbarDirection::SBDIR_VERTICAL, ScrollThumbSprite, ScrollTrackBounds,
      ScrollThumbSprite.ScaledHeight(), TrackListBounds, 1.0f);
  MainScrollbar.SetScrollAreaBounds(TrackListBounds);
  MainScrollbar.Step = TrackOffset.y;

  // Everything in last page points to last element
  for (int idx = MusicTrackCount - 1 - SelectableItemsPerPage;
       idx < MusicTrackCount; idx++) {
    MainItems->Children[idx]->SetFocus(MainItems->Children.back(), FDIR_RIGHT);
  }

  MainItems->Children.front()->SetFocus(MainItems->Children.back(), FDIR_UP);
  MainItems->Children.front()->SetFocus(MainItems->Children.back(), FDIR_LEFT);
  MainItems->Children.back()->SetFocus(MainItems->Children.front(), FDIR_DOWN);
  MainItems->Children.back()->SetFocus(MainItems->Children.front(), FDIR_RIGHT);
}

void MusicMenu::Init() {
  for (const auto presetFlag : PresetBgmFlags) {
    SaveSystem::SetBgmFlag(presetFlag, true);
  }
  if (GetFlag(SF_CLR_AYASE)) {
    SaveSystem::SetBgmFlag(AyaseEndingBgmId, true);
  }

  const std::array<int, 7> endingFlags = {
      SF_CLR_RIMI, SF_CLR_NANAMI, SF_CLR_YUA,  SF_CLR_MIA,
      SF_CLR_SENA, SF_CLR_KOZUE,  SF_CLR_SEIRA};
  const bool gotRequiredEndings = std::ranges::all_of(endingFlags, GetFlag);
  if (gotRequiredEndings) {
    SaveSystem::SetBgmFlag(NormalEndingBgmId, true);
  }

  for (size_t i = 0; i < DstBgmPairedFlag.size(); i++) {
    const int dstFlagId = DstBgmPairedFlag[i];
    const bool flagValue = SaveSystem::GetBgmFlag(dstFlagId) ||
                           SaveSystem::GetBgmFlag(SrcBgmPairedFlag[i]);
    SaveSystem::SetBgmFlag(dstFlagId, flagValue);
  }
}

void MusicMenu::Show() {
  if (State != Shown) {
    if (State != Showing) {
      MenuTransition.StartIn();
      SelectAnimation.StartIn(true);
    }
    State = Showing;
    UpdateEntries();
    MainItems->Show();
    CurrentlyPlayingTrackName.Show();
    CurrentlyPlayingTrackArtist.Show();
    if (UI::FocusedMenu != 0) {
      LastFocusedMenu = UI::FocusedMenu;
      LastFocusedMenu->IsFocused = false;
    }
    ScrollY = 0.0f;
    IsFocused = true;
    UI::FocusedMenu = this;
    MainItems->Children.front()->HasFocus = true;
    CurrentlyFocusedElement = MainItems->Children.front();
    PlayModeRepeatSprite = PlaymodeRepeat;
    PlayModeAllSprite = PlaymodeAll;
    PlaybackMode = MusicPlaybackMode::One;
  }
}

void MusicMenu::Hide() {
  if (State != Hidden) {
    if (State != Hiding) {
      MenuTransition.StartOut();
      MenuTransition.StartOut();
    }
    CurrentlyPlayingTrackId.reset();
    NowPlayingAnimation.StartOut();
    Audio::Channels[Audio::AC_BGM0]->Stop(0.0f);
    State = Hiding;
    if (LastFocusedMenu != 0) {
      UI::FocusedMenu = LastFocusedMenu;
      LastFocusedMenu->IsFocused = true;
    } else {
      UI::FocusedMenu = 0;
    }
    IsFocused = false;
    InputEnabled = false;
  }
}

void MusicMenu::Render() {
  if (State == Hidden) return;
  CommonMenu::DrawSubmenu(BackgroundColor, CircleSprite, SoundLibraryTitle,
                          SoundLibraryTitleAngle);

  if (MenuTransition.Progress <= 0.22f) return;

  glm::vec2 offset = MenuTransition.GetPageOffset();
  if (MenuTransition.IsPlaying()) {
    glm::vec2 offsetScroll = glm::vec2(0.0f, -ScrollY) + offset;

    // add a little 1-2 pixel offsets so out of bounds elements won't pass
    // Intersection check in case they are lying on the bound
    const RectF bounds = RectF(0.0f, TrackButtonPosTemplate.y + offset.y + 1,
                               Profile::Game::DesignWidth,
                               VisibleItemsPerPage * TrackOffset.y - 2);
    MainItems->RenderingBounds = bounds;
    MainItems->HoverBounds = bounds;

    MainScrollbar.MoveTo(ScrollbarPosition + offset);

    MainItems->MoveTo(offsetScroll);
  }
  MainItems->Render();
  MainScrollbar.Render();

  DrawLeftTitle(SoundLibraryTitle);

  SelectAnimation.Draw(SelectSoundSprites, SelectSoundPos, offset);

  Renderer->DrawSprite(TrackTree, TrackTreePos + offset);
  Renderer->DrawSprite(PlayModeRepeatSprite, PlaymodeRepeatPos + offset);
  Renderer->DrawSprite(PlayModeAllSprite, PlaymodeAllPos + offset);
  glm::vec2 nowPlayingOffset =
      glm::vec2(15 * 16 * (1 - NowPlayingAnimation.Progress), offset.y) +
      NowPlayingPos;
  glm::vec4 tint(glm::vec3(1.0f), NowPlayingAnimation.Progress);
  CurrentlyPlayingTrackName.MoveTo(nowPlayingOffset + PlayingTrackOffset);
  CurrentlyPlayingTrackName.Tint = tint;
  CurrentlyPlayingTrackName.Render();
  CurrentlyPlayingTrackArtist.MoveTo(nowPlayingOffset +
                                     PlayingTrackArtistOffset);
  CurrentlyPlayingTrackArtist.Tint = tint;
  CurrentlyPlayingTrackArtist.Render();
  Renderer->DrawSprite(NowPlaying, nowPlayingOffset, tint);
  if (CurrentlyPlayingTrackId.has_value()) {
    auto currentTrackId = CurrentlyPlayingTrackId.value();
    auto targetCenter = MainItems->Children[currentTrackId]->Bounds.Center();
    auto targetPos = MainItems->Children[currentTrackId]->Bounds.GetPos() +
                     HighlightStarRelativePos;
    if (MainItems->RenderingBounds.ContainsPoint(targetCenter)) {
      Renderer->DrawSprite(HighlightStar, targetPos);
    }
  }
  DrawButtonPrompt(ButtonPromptSprite, ButtonPromptPosition);
}

void MusicMenu::Update(float dt) {
  if ((!GetFlag(SF_SOUNDMENU) || ScrWork[SW_SYSMENUCT] < 10000) &&
      State == Shown) {
    Hide();
  } else if (GetFlag(SF_SOUNDMENU) && ScrWork[SW_SYSMENUCT] > 0 &&
             State == Hidden) {
    Show();
  }

  if (MenuTransition.IsOut() &&
      (ScrWork[SW_SYSMENUCT] == 0 || GetFlag(SF_SYSTEMMENU)) &&
      State == Hiding) {
    MainItems->Hide();
    CurrentlyPlayingTrackName.Hide();
    CurrentlyPlayingTrackArtist.Hide();
    State = Hidden;
  } else if (MenuTransition.IsIn() && ScrWork[SW_SYSMENUCT] == 10000 &&
             State == Showing) {
    State = Shown;
    InputEnabled = true;
  }

  if (State != Hidden) {
    SelectAnimation.Update(dt);
    MenuTransition.Update(dt);
    if (MenuTransition.Direction == AnimationDirection::Out &&
        MenuTransition.Progress <= 0.72f) {
      TitleFade.StartOut();
    } else if (MenuTransition.IsIn() &&
               (TitleFade.Direction == AnimationDirection::In ||
                TitleFade.IsOut())) {
      TitleFade.StartIn();
    }
    if (State == Shown) {
      UpdateInput(dt);
    }
    TitleFade.Update(dt);
    NowPlayingAnimation.Update(dt);
    MainScrollbar.Update(dt);
    PlayModeRepeatClickArea.Update(dt);
    PlayModeAllClickArea.Update(dt);
    UpdateTitles(SoundLibraryTitleRightPos, SoundLibraryTitleLeftPos);
    if (InputEnabled) MainItems->Update(dt);
    if (!CurrentlyPlayingTrackId.has_value()) return;
    if (PlaybackMode != MusicPlaybackMode::RepeatOne &&
        CurrentlyPlayingTrackId < 40 &&
        abs(Audio::Channels[Audio::AC_BGM0]->PositionInSeconds() -
            PreviousPosition) > 1.0f) {
      CurrentlyPlayingTrackId.reset();
      NowPlayingAnimation.StartOut();
      Audio::Channels[Audio::AC_BGM0]->Stop(2.0f);
    }
    if (Audio::Channels[Audio::AC_BGM0]->GetState() == Audio::ACS_Stopped) {
      std::optional<int> trackId;
      if (PlaybackMode == MusicPlaybackMode::One) {
        trackId = std::nullopt;
      } else {
        trackId = GetNextTrackId(CurrentlyPlayingTrackId.value() + 1);
        if (trackId == MusicTrackCount) {
          if (PlaybackMode == MusicPlaybackMode::RepeatPlaylist) {
            trackId = GetNextTrackId(0);
          } else if (PlaybackMode == MusicPlaybackMode::Playlist) {
            trackId = std::nullopt;
          }
        }
      }
      SwitchToTrack(trackId);
    }
    PreviousPosition = Audio::Channels[Audio::AC_BGM0]->PositionInSeconds();
  }
}

void MusicMenu::UpdateInput(float dt) {
  auto* prevFocus = CurrentlyFocusedElement;
  if (!MainScrollbar.IsScrollHeld()) {
    Menu::UpdateInput(dt);
  }
  if (State == Shown) {
    const float prevScrollPos = ScrollY;
    auto currentItemOutOfBounds = [&]() {
      const auto itemY = std::round(CurrentlyFocusedElement->Bounds.Y);
      return itemY < TrackListBounds.Y ||
             (TrackListBounds.Y + TrackListBounds.Height <= itemY);
    };

    const bool focusChanged = CurrentlyFocusedElement != prevFocus;
    const bool currentItemOOB = currentItemOutOfBounds();
    const bool changedToOOB = focusChanged && currentItemOOB;
    const bool navByButtons =
        focusChanged && !currentItemOOB &&
        Input::CurrentInputDevice != Input::Device::Mouse &&
        (PADinputButtonIsDown & (FDIR_DOWN | FDIR_UP | FDIR_LEFT | FDIR_RIGHT));

    if (changedToOOB) {
      auto* firstFocusable = MainItems->GetFirstFocusableChild();

      if (CurrentlyFocusedElement == firstFocusable) {
        ScrollY = 0;
      } else if (CurrentlyFocusedElement == MainItems->Children.back()) {
        ScrollY = MainScrollbar.EndValue;
      } else {
        // if focused item is out of bounds, then scroll to it
        float targetScroll =
            CurrentlyFocusedElement->Bounds.Y - firstFocusable->Bounds.Y;
        ScrollY = (targetScroll <= ScrollY)
                      ? targetScroll
                      : targetScroll - SelectableItemsPerPage * TrackOffset.y;
        MainScrollbar.ClampValue();
      }
    } else if (navByButtons) {
      // imitate d-pad/keyboard behavior when scrolling out of bounds
      int lowerBound = (int)(ScrollY / TrackOffset.y);
      int upperBound = lowerBound + SelectableItemsPerPage;
      int btnId = static_cast<Widgets::CHLCC::TrackSelectButton*>(
                      CurrentlyFocusedElement)
                      ->Id;
      if (btnId == lowerBound && btnId != 0) {
        ScrollY -= TrackOffset.y;
      }

      if (btnId == upperBound && btnId != MusicTrackCount - 1) {
        ScrollY += TrackOffset.y;
      }
      MainScrollbar.ClampValue();
    }

    MainScrollbar.UpdateInput(dt);
    PlayModeRepeatClickArea.UpdateInput(dt);
    PlayModeAllClickArea.UpdateInput(dt);

    if (prevScrollPos != ScrollY) {
      float delta = prevScrollPos - ScrollY;
      if (std::fmod(std::abs(delta), TrackOffset.y) >
          std::numeric_limits<float>::epsilon()) {
        const float newDelta =
            std::round(delta / TrackOffset.y) * TrackOffset.y;
        ScrollY = prevScrollPos - newDelta;
        delta = newDelta;
      }
      glm::vec2 itemsPos = {0, -ScrollY};
      MainItems->MoveTo(itemsPos);

      if (MainScrollbar.IsScrollHeld() && CurrentlyFocusedElement) {
        // advance focus during drag
        FocusDirection dir = (delta < 0) ? FDIR_DOWN : FDIR_UP;
        int steps = static_cast<int>(std::abs(delta) / TrackOffset.y);
        for (int i = 0; i < steps; i++) {
          AdvanceFocus(dir);
        }
      }
    }

    if (!MainScrollbar.IsScrollHeld()) MainItems->UpdateInput(dt);

    if (PADinputButtonWentDown & PAD1Y) {
      ++PlaybackMode;
      PlayModeAllSprite =
          isPlaylist(PlaybackMode) ? PlaymodeAllHighlight : PlaymodeAll;
      PlayModeRepeatSprite =
          isRepeat(PlaybackMode) ? PlaymodeRepeatHighlight : PlaymodeRepeat;
      UpdateLooping();
    }

    if (PADinputButtonWentDown & PAD1X) {
      SwitchToTrack(std::nullopt);
    }
  }
}

void MusicMenu::UpdateEntries() {
  auto onClick = [this](auto* btn) { return MusicButtonOnClick(btn); };
  for (size_t idx = 0; idx < MainItems->Children.size(); idx++) {
    auto button = static_cast<Widgets::CHLCC::TrackSelectButton*>(
        MainItems->Children[idx]);

    if (!SaveSystem::GetBgmFlag(Playlist[button->Id])) {
      button->SetTrackText(Vm::ScriptGetTextTableStrAddress(0, 15));
      continue;
    }

    button->OnClickHandler = onClick;
    button->SetTrackText(Vm::ScriptGetTextTableStrAddress(4, (int)idx * 3));
    button->SetArtistText(
        Vm::ScriptGetTextTableStrAddress(4, (int)idx * 3 + 1));
  }
}

void MusicMenu::SwitchToTrack(std::optional<int> id) {
  if (CurrentlyPlayingTrackId == id) {
    return;
  }

  CurrentlyPlayingTrackId = id;
  if (!id.has_value()) {
    NowPlayingAnimation.StartOut();
    Audio::Channels[Audio::AC_BGM0]->Stop(0.5f);
    return;
  }
  if (!NowPlayingAnimation.IsIn()) NowPlayingAnimation.StartIn();
  CurrentlyPlayingTrackName = Label(
      Vm::ScriptGetTextTableStrAddress(4, CurrentlyPlayingTrackId.value() * 3),
      NowPlayingPos + PlayingTrackOffset, 32, RendererOutlineMode::None, 0);
  CurrentlyPlayingTrackArtist =
      Label(Vm::ScriptGetTextTableStrAddress(
                4, CurrentlyPlayingTrackId.value() * 3 + 2),
            NowPlayingPos + PlayingTrackArtistOffset, 20,
            RendererOutlineMode::None, 0);
  PreviousPosition = 0.0f;
  Audio::Channels[Audio::AC_BGM0]->Play(
      "bgm", Playlist[id.value()],
      id >= 40 ? (PlaybackMode == MusicPlaybackMode::RepeatOne) : true, 0.5f);
}

inline int MusicMenu::GetNextTrackId(int id) {
  while (!SaveSystem::GetBgmFlag(Playlist[id])) {
    id += 1;
    if (id == MusicTrackCount) {
      if (PlaybackMode == MusicPlaybackMode::RepeatPlaylist) {
        id = 0;
      } else if (PlaybackMode == MusicPlaybackMode::Playlist) {
        id = -1;
        break;
      }
    }
  }
  return id;
}

}  // namespace CHLCC
}  // namespace UI
}  // namespace Impacto