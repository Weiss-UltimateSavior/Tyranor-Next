#include "optionsmenu.h"

#include "../../profile/configsystem.h"
#include "../../profile/game.h"
#include "../../profile/ui/optionsmenu.h"
#include "../../profile/games/cclcc/optionsmenu.h"
#include "../../profile/games/cclcc/systemmenu.h"
#include "../../profile/scriptinput.h"
#include "../../vm/interface/input.h"
#include "../../ui/widgets/cclcc/optionsbinarybutton.h"
#include "../../ui/widgets/cclcc/optionsslider.h"
#include "../../ui/widgets/cclcc/optionsvoiceslider.h"
#include "../../audio/audiosystem.h"

namespace Impacto {
namespace UI {
namespace CCLCC {

using namespace Impacto::Profile::OptionsMenu;
using namespace Impacto::Profile::CCLCC::OptionsMenu;
using namespace Impacto::Profile::ScriptVars;
using namespace Impacto::Profile::ConfigSystem;
using namespace Impacto::UI::Widgets;
using namespace Impacto::UI::Widgets::CCLCC;
using namespace Impacto::Vm::Interface;

std::unique_ptr<Group> OptionsMenu::CreateBasicPage(
    const std::function<void(OptionsEntry*)>& select,
    const std::function<void(Widget*)>& highlight) {
  const glm::vec4 highlightTint(HighlightColor, 1.0f);
  std::unique_ptr<Group> basicPage = std::make_unique<Group>(this);

  basicPage->Add(
      new OptionsBinaryButton(ShowTipsNotification, BinaryBoxSprite, OnSprite,
                              OffSprite, LabelSprites[0], EntriesStartPosition,
                              highlightTint, select, highlight),
      FDIR_DOWN);
  basicPage->Add(
      new OptionsBinaryButton(
          AdvanceTextOnDirectionalInput, BinaryBoxSprite, OnSprite, OffSprite,
          LabelSprites[1],
          EntriesStartPosition + glm::vec2(0.0f, EntriesVerticalOffset),
          highlightTint, select, highlight),
      FDIR_DOWN);
  basicPage->Add(
      new OptionsBinaryButton(
          DirectionalInputForTrigger, BinaryBoxSprite, OnSprite, OffSprite,
          LabelSprites[2],
          EntriesStartPosition + glm::vec2(0.0f, EntriesVerticalOffset * 2),
          highlightTint, select, highlight),
      FDIR_DOWN);
  basicPage->Add(
      new OptionsBinaryButton(
          TriggerStopSkip, BinaryBoxSprite, OnSprite, OffSprite,
          LabelSprites[3],
          EntriesStartPosition + glm::vec2(0.0f, EntriesVerticalOffset * 3),
          highlightTint, select, highlight),
      FDIR_DOWN);

  return basicPage;
}

std::unique_ptr<Group> OptionsMenu::CreateTextPage(
    const std::function<void(OptionsEntry*)>& select,
    const std::function<void(Widget*)>& highlight) {
  const glm::vec4 highlightTint(HighlightColor, 1.0f);
  std::unique_ptr<Group> textPage = std::make_unique<Group>(this);

  textPage->Add(new OptionsSlider(
                    TextSpeed, TextSpeedBounds[0], TextSpeedBounds[1],
                    SliderTrackSprite, LabelSprites[4], EntriesStartPosition,
                    highlightTint, SliderSpeed, select, highlight),
                FDIR_DOWN);
  textPage->Add(
      new OptionsSlider(
          AutoSpeed, AutoSpeedBounds[0], AutoSpeedBounds[1], SliderTrackSprite,
          LabelSprites[5],
          EntriesStartPosition + glm::vec2(0.0f, EntriesVerticalOffset),
          highlightTint, SliderSpeed, select, highlight),
      FDIR_DOWN);
  textPage->Add(
      new OptionsBinaryButton(
          SkipRead, BinaryBoxSprite, SkipReadSprite, SkipAllSprite,
          LabelSprites[6],
          EntriesStartPosition + glm::vec2(0.0f, EntriesVerticalOffset * 2),
          highlightTint, select, highlight),
      FDIR_DOWN);

  return textPage;
}

std::unique_ptr<Group> OptionsMenu::CreateSoundPage(
    const std::function<void(OptionsEntry*)>& select,
    const std::function<void(Widget*)>& highlight) {
  const glm::vec4 highlightTint(HighlightColor, 1.0f);
  std::unique_ptr<Group> soundPage = std::make_unique<Group>(this);

  soundPage->Add(new OptionsSlider(Audio::GroupVolumes[Audio::ACG_Voice], 0.0f,
                                   1.0f, SliderTrackSprite, LabelSprites[7],
                                   SoundEntriesStartPosition, highlightTint,
                                   SliderSpeed, select, highlight),
                 FDIR_DOWN);
  soundPage->Add(
      new OptionsSlider(Audio::GroupVolumes[Audio::ACG_BGM], 0.0f, 0.5f,
                        SliderTrackSprite, LabelSprites[8],
                        SoundEntriesStartPosition +
                            glm::vec2(0.0f, SoundEntriesVerticalOffset),
                        highlightTint, SliderSpeed, select, highlight),
      FDIR_DOWN);
  soundPage->Add(
      new OptionsSlider(Audio::GroupVolumes[Audio::ACG_SE], 0.0f, 1.0f,
                        SliderTrackSprite, LabelSprites[9],
                        SoundEntriesStartPosition +
                            glm::vec2(0.0f, SoundEntriesVerticalOffset * 2),
                        highlightTint, SliderSpeed, select, highlight),
      FDIR_DOWN);
  soundPage->Add(
      new OptionsSlider(Audio::GroupVolumes[Audio::ACG_Movie], 0.0f, 1.0f,
                        SliderTrackSprite, LabelSprites[10],
                        SoundEntriesStartPosition +
                            glm::vec2(0.0f, SoundEntriesVerticalOffset * 3),
                        highlightTint, SliderSpeed, select, highlight),
      FDIR_DOWN);
  soundPage->Add(
      new OptionsBinaryButton(
          SyncVoice, BinaryBoxSprite, YesSprite, NoSprite, LabelSprites[11],
          SoundEntriesStartPosition +
              glm::vec2(0.0f, SoundEntriesVerticalOffset * 4),
          highlightTint, select, highlight),
      FDIR_DOWN);
  soundPage->Add(
      new OptionsBinaryButton(
          SkipVoice, BinaryBoxSprite, YesSprite, NoSprite, LabelSprites[12],
          SoundEntriesStartPosition +
              glm::vec2(0.0f, SoundEntriesVerticalOffset * 5),
          highlightTint, select, highlight),
      FDIR_DOWN);

  return soundPage;
}

std::unique_ptr<Group> OptionsMenu::CreateVoicePage(
    const std::function<void(OptionsEntry*)>& select,
    const std::function<void(Widget*)>& highlight) {
  const glm::vec4 highlightTint(HighlightColor, 1.0f);
  std::unique_ptr<Group> voicePage = std::make_unique<Group>(this);

  constexpr int columns = 3;
  constexpr int entries = 12;
  for (int i = 0; i < entries; i++) {
    const glm::vec2 pos =
        VoicePosition +
        VoiceEntriesOffset * glm::vec2(i % columns, i / columns);

    Widget* widget = new OptionsVoiceSlider(
        VoiceVolume[i], 0.0f, 1.0f, VoiceMuted[i], VoiceSliderTrackSprite,
        NametagSprites[i], PortraitSprites[2 * i], PortraitSprites[2 * i + 1],
        pos, highlightTint, SliderSpeed, select, highlight);
    voicePage->Add(widget, FDIR_RIGHT);
  }

  // Loop separately to overwrite the direction set at initial adding
  // First entry won't set anything; skip
  for (int i = 1; i < entries; i++) {
    Widget* const widget = voicePage->Children[i];

    if (i % columns != 0) {  // Not on first column
      Widget* const leftWidget = voicePage->Children[i - 1];
      widget->SetFocus(leftWidget, FDIR_LEFT);
      leftWidget->SetFocus(widget, FDIR_RIGHT);

      if (i % columns == columns - 1) {  // On last column
        Widget* const rowStart = voicePage->Children[i - columns + 1];
        widget->SetFocus(rowStart, FDIR_RIGHT);
        rowStart->SetFocus(widget, FDIR_LEFT);
      }
    }
    if (i >= columns) {  // Not on first row
      Widget* const upWidget = voicePage->Children[i - columns];
      widget->SetFocus(upWidget, FDIR_UP);
      upWidget->SetFocus(widget, FDIR_DOWN);

      if (i >= entries - columns) {  // On last layer
        Widget* const columnStart = voicePage->Children[i % columns];
        widget->SetFocus(columnStart, FDIR_DOWN);
        columnStart->SetFocus(widget, FDIR_UP);
      }
    }
  }

  return voicePage;
}

OptionsMenu::OptionsMenu()
    : UI::OptionsMenu(),
      CommonMenu(FadeAnimation),
      PoleAnimation(Profile::CCLCC::OptionsMenu::PoleAnimation.Instantiate()) {
  PageButtons.reserve(PageCount);
  for (int i = 0; i < PageCount; i++) {
    PageButtons.emplace_back(i, PagePanelHoverBounds[i]);
  }

  std::function<void(OptionsEntry*)> select = [this](auto* btn) {
    return Select(btn);
  };
  std::function<void(Widget*)> highlight = [this](auto* btn) {
    return Highlight(btn);
  };

  Pages.reserve(PageCount);
  Pages.emplace_back(CreateBasicPage(select, highlight));
  Pages.emplace_back(CreateTextPage(select, highlight));
  Pages.emplace_back(CreateSoundPage(select, highlight));
  Pages.emplace_back(CreateVoicePage(select, highlight));

  Highlight(Pages[CurrentPage]->GetFirstFocusableChild());
}

void OptionsMenu::Show() {
  if (State != Shown) {
    CommonMenu::OnShow(FadeInDuration, FadeOutDuration, FadeAnimation);
  }

  UI::OptionsMenu::Show();

  if (State != Shown) {
    if (OpenedAsDirect) {
      PoleAnimation.Finish(AnimationDirection::In);
    } else {
      PoleAnimation.StartIn();
    }
  }
}

void OptionsMenu::Hide() {
  if (State != Hidden) {
    if (!OpenedAsDirect) {
      PoleAnimation.StartOut();
    }

    if (CurrentlyFocusedElement)
      static_cast<OptionsEntry*>(CurrentlyFocusedElement)->Selected = false;
  }

  UI::OptionsMenu::Hide();
}

void OptionsMenu::UpdateVisibility() {
  if (LastSubMenuCt > ScrWork[SW_SYSSUBMENUCT] &&
      ScrWork[SW_SYSSUBMENUCT] < 32 && State != Hidden && State != Hiding) {
    Hide();
  } else if (LastSubMenuCt < ScrWork[SW_SYSSUBMENUCT] &&
             ScrWork[SW_SYSSUBMENUCT] > 0 && ScrWork[SW_SYSSUBMENUNO] == 5 &&
             State != Shown && State != Showing) {
    Show();
  }

  if (FadeAnimation.IsIn() && ScrWork[SW_SYSSUBMENUCT] == 32) {
    State = Shown;
  } else if (State == Hiding && FadeAnimation.IsOut() &&
             ScrWork[SW_SYSSUBMENUCT] == 0) {
    State = Hidden;
    Pages[CurrentPage]->Hide();
    if (OpenedAsDirect) PoleAnimation.Finish(AnimationDirection::Out);
  }
  LastSubMenuCt = ScrWork[SW_SYSSUBMENUCT];
}

void OptionsMenu::Update(float dt) {
  UI::OptionsMenu::Update(dt);
  PoleAnimation.Update(dt);

  if (!FadeAnimation.IsIn() && !FadeAnimation.IsOut()) {
    const float bgPosY =
        OpenedAsDirect ? BackgroundPosition.y
                       : glm::mix(BackgroundFadeStartPosition.y,
                                  BackgroundPosition.y, FadeAnimation.Progress);

    const glm::vec2 backgroundPosition = glm::vec2(0.0f, bgPosY);
    for (std::unique_ptr<Group>& page : Pages) {
      page->MoveTo(backgroundPosition);
    }
  }

  AllowsScriptInput = !AnyEntrySelected();
}

void OptionsMenu::PageButtonOnHover(size_t pageNumber) {
  if (pageNumber != CurrentPage || !CurrentlyFocusedElement)
    Audio::PlayInGroup(Audio::ACG_SE, "sysse", 1, false, 0.0f);

  if (pageNumber == CurrentPage && CurrentlyFocusedElement) return;

  GoToPage(pageNumber);
  Highlight(Pages[CurrentPage]->GetFirstFocusableChild());
}

void OptionsMenu::UpdatePageInput(float dt) {
  // Mouse input
  for (ClickArea& button : PageButtons) {
    const bool wasHovered = button.Hovered;
    button.UpdateInput(dt);
    if (!wasHovered && button.Hovered) PageButtonOnHover(button.Id);
  }

  const size_t lastPage = CurrentPage;
  UI::OptionsMenu::UpdatePageInput(dt);

  if (CurrentPage != lastPage)
    Audio::PlayInGroup(Audio::ACG_SE, "sysse", 1, false, 0.0f);
}

void OptionsMenu::UpdateEntryMovementInput(float dt) {
  const Widget* const lastHighlight = CurrentlyFocusedElement;
  UI::OptionsMenu::UpdateEntryMovementInput(dt);

  if (CurrentlyFocusedElement != lastHighlight)
    Audio::PlayInGroup(Audio::ACG_SE, "sysse", 1, false, 0.0f);
}

void OptionsMenu::UpdateInput(float dt) {
  bool backBtnPressed =
      (PADinputMouseWentDown & PAD1B) ||
      (AllowsScriptInput && GetControlState(ControlType::Back));
  if (State == Shown && backBtnPressed) {
    if (!GetFlag(SF_SUBMENUEXIT))
      Audio::PlayInGroup(Audio::ACG_SE, "sysse", 3, false, 0.0f);
    SetFlag(SF_SUBMENUEXIT, 1);
    return;
  }

  UpdatePageInput(dt);

  // If something is selected, the option entry takes full control
  if (!AllowsScriptInput) return;

  UpdateEntryMovementInput(dt);
}

void OptionsMenu::Render() {
  if (State == Hidden) return;

  const float transitionProgress =
      OpenedAsDirect ? 1.0f : FadeAnimation.Progress;

  const glm::vec4 col(1.0f, 1.0f, 1.0f,
                      glm::smoothstep(0.0f, 1.0f, FadeAnimation.Progress));

  const glm::vec2 backgroundAnimationOffset = glm::vec2(
      0.0f, transitionProgress * BackgroundPosition.y +
                (1.0f - transitionProgress) * BackgroundFadeStartPosition.y);
  const glm::vec2 pagePanelPosition =
      PagePanelPosition * transitionProgress +
      (1.0f - transitionProgress) * PagePanelFadeStartPosition;
  const glm::vec2 guidePosition =
      GuidePosition * transitionProgress +
      (1.0f - transitionProgress) * GuideFadeStartPosition;

  if (OpenedAsDirect) CommonMenu::DrawBgSprite<false>(State, FadeAnimation);

  Renderer->DrawSprite(BackgroundSprite,
                       BackgroundPosition + backgroundAnimationOffset, col);
  Renderer->DrawSprite(HeaderSprite, HeaderPosition + backgroundAnimationOffset,
                       col);

  Renderer->DrawSprite(PageHeaderSprites[CurrentPage],
                       PageHeaderPosition + backgroundAnimationOffset, col);
  Pages[CurrentPage]->Tint = col;
  Pages[CurrentPage]->Render();

  Renderer->DrawSprite(PoleAnimation.CurrentSprite(), pagePanelPosition, col);
  if (PoleAnimation.IsIn()) {
    Renderer->DrawSprite(PagePanelSprites[2 * CurrentPage],
                         PagePanelPosition + PagePanelIconOffsets[CurrentPage],
                         col);
  }

  if (ScrWork[SW_SYSSUBMENUNO] == 5) {
    CommonMenu::DrawOverlay();
    if (GetFlag(SF_TITLEMODE)) {
      CommonMenu::DrawSmoke(Profile::CCLCC::SystemMenu::SmokeOpacityNormal *
                            (1.0f - FadeAnimation.Progress));
    }
  }

  const ButtonPrompt& guidePrompt =
      CurrentPage == +PageType::Voice ? VoiceGuideSprite : GuideSprite;
  UI::DrawButtonPrompt(guidePrompt, guidePosition, col);
}

void OptionsMenu::Select(OptionsEntry* toSelect) {
  for (Widget* entry : Pages[CurrentPage]->Children) {
    static_cast<OptionsEntry*>(entry)->Selected = false;
    entry->HasFocus = false;
  }

  toSelect->Selected = true;
  toSelect->HasFocus = true;
  CurrentlyFocusedElement = toSelect;
}

void OptionsMenu::Highlight(Widget* toHighlight) {
  UI::OptionsMenu::Highlight(toHighlight);

  for (Widget* entry : Pages[CurrentPage]->Children) {
    static_cast<OptionsEntry*>(entry)->Selected = false;
  }
}

void OptionsMenu::ResetToDefault() {
  switch (CurrentPage) {
    case +PageType::Basic: {
      ShowTipsNotification = Default::ShowTipsNotification;
      AdvanceTextOnDirectionalInput = Default::AdvanceTextOnDirectionalInput;
      DirectionalInputForTrigger = Default::DirectionalInputForTrigger;
      TriggerStopSkip = Default::TriggerStopSkip;
      break;
    }
    case +PageType::Text: {
      TextSpeed = Default::TextSpeed;
      AutoSpeed = Default::AutoSpeed;
      SkipRead = Default::SkipRead;
      break;
    }
    case +PageType::Sound: {
      std::ranges::copy(Default::GroupVolumes, Audio::GroupVolumes.begin());
      SyncVoice = Default::SyncVoice;
      SkipVoice = Default::SkipVoice;
      break;
    }
    case +PageType::Voice: {
      std::ranges::copy(Default::VoiceMuted, VoiceMuted.begin());
      std::ranges::copy(Default::VoiceVolume, VoiceVolume.begin());
      break;
    }
    default:
      break;
  }

  UpdateValues();
}

}  // namespace CCLCC
}  // namespace UI
}  // namespace Impacto