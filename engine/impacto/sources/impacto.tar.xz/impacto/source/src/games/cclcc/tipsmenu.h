#pragma once

#include "../../text/dialoguepage.h"

#include "commonmenu.h"
#include "../../ui/tipsmenu.h"
#include "../../ui/widgets/group.h"
#include "../../ui/widgets/button.h"
#include "../../ui/widgets/carousel.h"
#include "../../ui/widgets/label.h"
#include "../../data/tipssystem.h"
#include "../../ui/widgets/cclcc/tipsentrybutton.h"
#include "../../ui/widgets/scrollbar.h"
#include <vector>
#include <memory>

namespace Impacto::UI::Widgets::CCLCC {
class TipsTabGroup;
}
namespace Impacto {
namespace UI {
namespace CCLCC {

enum TipsTabType {
  AllTips,
  UnlockedTips,
  UnreadTips,
  NewTips,
};

class TipsMenu : public UI::TipsMenu, public CommonMenu {
 public:
  TipsMenu();

  void Init();

  void Show();
  void Hide();
  void UpdateInput(float dt);
  void Update(float dt);
  void Render();

  void TipOnClick(Widgets::Button* target);

 protected:
  void SwitchToTipId(int id);

 private:
  constexpr int static TabCount = 4;
  int CurrentTabIdx = 0;
  float TipPageY = 0;
  glm::vec2 TipsScrollStartPos;
  glm::vec2 TipsScrollTrackBounds;

  TipsTabType CurrentTabType;
  std::vector<int> SortedTipIds;
  std::array<Widgets::CCLCC::TipsTabGroup*, TabCount> TipsTabs;

  std::unique_ptr<Widgets::Scrollbar> TipsScrollbar;
  Widgets::Group TipViewItems;

  int ScrollWheelYDelta = 0;
  bool MouseInTextBounds = false;

  float ScrollPercentage = 0.0f;
  bool HasInitialized = false;
  void SetActiveTab(TipsTabType type);

  float LastYPos = 0.0f;

  Animation TransitionAnimation;
  int LastSubMenuCt = 0;
};

}  // namespace CCLCC
}  // namespace UI
}  // namespace Impacto