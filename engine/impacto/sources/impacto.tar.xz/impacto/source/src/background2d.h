#pragma once

#include <ankerl/unordered_dense.h>
#include <map>
#include "texture/texture.h"
#include "spritesheet.h"
#include "loadable.h"
#include "renderer/renderer.h"
#include "profile/game.h"

namespace Impacto {

enum class LinkDirection { Off, Up, Down, Left, Right, Up3, Down3 };

class Background2D;

struct LinkState {
  Background2D* LinkedBuffer;
  LinkDirection Direction;
  glm::vec2 DisplayCoords;
};

struct BgEff {
  bool Loaded = false;
  Texture BgEffTexture;
  Sprite BgEffSprite;
  ShaderProgramType Shader = ShaderProgramType::Sprite;
};

class Background2D : public Loadable<Background2D, bool, uint32_t> {
  friend class Loadable<Background2D, bool, uint32_t>;

 public:
  static void Init();
  static void InitFrameBuffers();

  Sprite BgSprite;
  Sprite RenderSprite = BgSprite;

  std::array<int, 2> BgEffsLayers = {0, 0};
  std::array<BgEff, 3> FrameBgEffs;
  BgEff ChaBgEff;

  glm::vec4 Tint = glm::vec4(1.0f);
  int MaskNumber = 0;

  int FadeCount = 0;
  int FadeRange = 0;

  bool Show = false;
  int RenderType = 0;
  std::array<int, 2> Layers;
  std::array<LinkState, 2> Links;

  inline static Background2D* LastRenderedBackground = nullptr;

  inline static ankerl::unordered_dense::map<int,
                                             std::array<ShaderProgramType, 4>>
      BgEffShaderMap;
  static ShaderProgramType GetBgEffShader(int bgId, size_t bgEffId) {
    const auto found = BgEffShaderMap.find(bgId);
    assert(found == BgEffShaderMap.end() || bgEffId < found->second.size());

    // Unmapped means sprite
    return found != BgEffShaderMap.end() ? found->second[bgEffId]
                                         : ShaderProgramType::Sprite;
  }

  inline static ankerl::unordered_dense::map<int, std::array<int, 4>>
      BgEffTextureIdMap;

  virtual void Render(int layer);
  void RenderBgEff(int layer);
  virtual void UpdateState(int bgId);

  void LoadSolidColor(uint32_t color, int width, int height);

  struct BgTransformState {
   public:
    glm::vec2 Position{};
    glm::vec2 Scale = glm::vec2(1.0f);
    glm::quat Rotation{};
    glm::vec2 Origin{};

    RectF Subsection = RectF(0.0f, 0.0f, Profile::Game::DesignWidth,
                             Profile::Game::DesignHeight);

    static BgTransformState GetBgTransformState(int bgId);
    static BgTransformState GetCapTransformState(int capId);
    static BgTransformState GetBgEffTransformState(int bgEffId);

    glm::mat4 ToMatrix() const {
      return TransformationMatrix(Origin, Scale, {Origin, 0.0f}, Rotation,
                                  Position);
    }
  };
  BgTransformState TransformState;

 protected:
  Texture BgTexture;

  bool LoadSync(uint32_t bgId);
  void UnloadSync();
  void MainThreadOnLoad(bool result);

  void LinkBuffers(int linkCode, int currentBufferId);

  virtual void SetTransformState(int dispMode, BgTransformState state);

  bool OnLayer(int layer) {
    return std::find(Layers.begin(), Layers.end(), layer) != Layers.end();
  }

  using BackgroundRenderProc = auto (Background2D::*)() -> void;

  void RenderRegular();
  void RenderMasked();
  void RenderCaptureMasked();
  void RenderMaskedInverted();
  void RenderFade();
  void RenderExplode();
  template <bool PhaseZero>
  void RenderBgWave();

  // RenderRegular at positions 2-27 are used as stubs, engine has separate
  // calls for those
  std::array<BackgroundRenderProc, 40> constexpr static BackgroundRenderTable =
      {
          &Background2D::RenderRegular,         // 0
          &Background2D::RenderFade,            // 1
          &Background2D::RenderExplode,         // 2
          &Background2D::RenderRegular,         // 3
          &Background2D::RenderRegular,         // 4
          &Background2D::RenderRegular,         // 5
          &Background2D::RenderRegular,         // 6
          &Background2D::RenderRegular,         // 7
          &Background2D::RenderRegular,         // 8
          &Background2D::RenderRegular,         // 9
          &Background2D::RenderRegular,         // 10
          &Background2D::RenderRegular,         // 11
          &Background2D::RenderRegular,         // 12
          &Background2D::RenderRegular,         // 13
          &Background2D::RenderBgWave<true>,    // 14
          &Background2D::RenderMasked,          // 15
          &Background2D::RenderMaskedInverted,  // 16
          &Background2D::RenderRegular,         // 17
          &Background2D::RenderRegular,         // 18
          &Background2D::RenderRegular,         // 19
          &Background2D::RenderRegular,         // 20
          &Background2D::RenderRegular,         // 21
          &Background2D::RenderRegular,         // 22
          &Background2D::RenderCaptureMasked,   // 23
          &Background2D::RenderRegular,         // 24
          &Background2D::RenderRegular,         // 25
          &Background2D::RenderRegular,         // 26
          &Background2D::RenderRegular,         // 27
          &Background2D::RenderBgWave<false>,   // 28
          &Background2D::RenderRegular,         // 29
          &Background2D::RenderRegular,         // 30
          &Background2D::RenderRegular,         // 31
          &Background2D::RenderRegular,         // 32
          &Background2D::RenderRegular,         // 33
          &Background2D::RenderRegular,         // 34
          &Background2D::RenderRegular,         // 35
          &Background2D::RenderRegular,         // 36
          &Background2D::RenderRegular,         // 37
          &Background2D::RenderRegular,         // 38
          &Background2D::RenderRegular,         // 39
  };
};

class Capture2D : public Background2D {
 public:
  void Render(int layer) override;
  void UpdateState(int capId) override;
};

class BackgroundEffect2D : public Background2D {
 public:
  void Render(int layer) override;
  void UpdateState(int bgId) override;

 private:
  void SetTransformState(int dispMode, BgTransformState state) override;

  size_t VertexCount = 4;
  std::array<glm::vec2, 4> Vertices;

  glm::mat4 StencilTransformation = glm::mat4(1.0f);
};

inline std::array<Background2D, 8> Backgrounds;
inline std::array<Capture2D, 2> Screencaptures;
inline Capture2D MaskCapture;
inline std::array<BackgroundEffect2D, MaxFramebuffers> Framebuffers;
inline Background2D ShaderScreencapture;

inline ankerl::unordered_dense::map<int, Background2D*> Backgrounds2D;

bool IsBgWaveEffectActive();
void ResetExplodeTris(const Sprite& renderSprite);

}  // namespace Impacto