#pragma once

#include <ctime>
#include <magic_enum/magic_enum.hpp>
#include "../spritesheet.h"
#include "../loadable.h"

namespace Impacto {
namespace AchievementSystem {

enum class AchievementDataType : int {
  None,
  Common,
};
enum class AchievementError {
  OK = 0,
  InProgress = 1,
  OutOfDiskSpace = 4,
  Failed = 100,
};

class Achievement {
 public:
  Achievement(std::string name, std::string description, bool hidden,
              const Sprite& icon, const Sprite& lockedIcon)
      : name(std::move(name)),
        description(std::move(description)),
        hidden(hidden),
        icon(icon),
        lockedIcon(lockedIcon) {}

  std::string const& Name() const { return name; }
  std::string const& Description() const { return description; }
  bool Hidden() const { return hidden; }
  Sprite const& Icon() const { return icon; }
  Sprite const& LockedIcon() const { return lockedIcon; }

 protected:
  std::string name;
  std::string description;
  bool hidden;
  Sprite icon;
  Sprite lockedIcon;
};

class AchievementSystemBase {
 public:
  virtual AchievementError MountAchievementFile(
      std::function<void()>& mainThreadCallback) = 0;
  virtual const Achievement* GetAchievement(int id) = 0;
  virtual size_t GetAchievementCount() const = 0;
};

inline AchievementSystemBase* Implementation = nullptr;

void Init();

LoadStatus GetLoadStatus();
void MountAchievementFile();
const Achievement* GetAchievement(int id);
size_t GetAchievementCount();

bool IsAchievementUnlocked(int id);
bool UnlockAchievement(int id);
tm GetAchievementUnlockDate(int id);

}  // namespace AchievementSystem
}  // namespace Impacto