#pragma once
#include "../impacto.h"
#include "../vm/vm.h"

#include <string>
#include <magic_enum/magic_enum.hpp>
#include <ctime>
#include <numeric>
#include "../log.h"
#include "../spritesheet.h"
#include "../texture/texture.h"
#include "../loadable.h"

namespace Impacto {
namespace SaveSystem {

enum class SaveDataType : int {
  None,
  CHLCC,
  CCLCC_PS4,
  CCLCC_SWITCH,
  MO6TW,
};
enum SaveFlagsMode { WriteProtect = 1 };

enum class SaveError {
  OK = 0,
  InProgress = 1,
  NotFound = 2,
  WrongUser = 3,
  Restart = 4,
  OutOfDiskSpace = 4,
  CorruptedFixing = 5,
  Restart10 = 10,
  Failed = 100,
  Corrupted = 255
};

enum class SaveType { Full = 0, Quick = 1 };

enum class LoadProcess { Vars = 0, Thread = 1 };

int constexpr MaxSaveEntries = 48;

constexpr std::array<uint8_t, 8> Flbit = {1, 2, 4, 8, 0x10, 0x20, 0x40, 0x80};

struct ScriptMessageDataPair {
  uint32_t LineCount;
  uint32_t SaveDataOffset;
};

// A delayed Texture::Submit() operation to be executed on the main thread
struct QueuedTexture {
  std::reference_wrapper<uint32_t> Id;
  Texture Tex{};
};

class SaveFileEntryBase {
 public:
  uint8_t Status = 0;
  uint32_t Checksum = 0;
  std::tm SaveDate{};
  uint32_t PlayTime = 0;
  uint32_t SwTitle = 0;
  uint8_t Flags = 0;
  uint32_t SaveType = 0;
  uint32_t MainThreadExecPriority = 0;
  uint32_t MainThreadGroupId = 0;
  uint32_t MainThreadWaitCounter = 0;
  uint32_t MainThreadScriptParam = 0;
  uint32_t MainThreadIp = 0;
  uint32_t MainThreadLoopCounter = 0;
  uint32_t MainThreadLoopAdr = 0;
  uint32_t MainThreadCallStackDepth = 0;
  union {
    std::array<uint32_t, 8> MainThreadReturnAddresses{};
    std::array<uint32_t, 8> MainThreadReturnIds;
  };
  std::array<uint32_t, 8> MainThreadReturnBufIds{};
  uint32_t MainThreadScriptBufferId = 0;
  std::array<int, 16> MainThreadVariables{};
  uint32_t MainThreadDialoguePageId = 0;
  Sprite SaveThumbnail{};
};

struct SaveRecencyComparator {
  bool operator()(SaveFileEntryBase const& entryA,
                  SaveFileEntryBase const& entryB) const {
    const int statusA = entryA.Status;
    const int statusB = entryB.Status;
    if (statusA == statusB) {
      std::tm const& ta = entryA.SaveDate;
      std::tm const& tb = entryB.SaveDate;
      return timegm(ta) > timegm(tb);
    }
    return statusA > statusB;
  }
};

class SaveSystemBase {
 public:
  virtual SaveError CheckSaveFile() const = 0;
  virtual SaveError MountSaveFile(std::vector<QueuedTexture>& textures) = 0;

  virtual void SaveMemory() = 0;
  virtual void LoadEntry(SaveType type, int id) = 0;
  virtual void LoadMemoryNew(LoadProcess){};
  virtual void FlushWorkingSaveEntry(SaveType type, int id,
                                     int autoSaveType) = 0;

  // Reads and writes to system data are only safe if no other VM threads are
  // executing. This data should be copied to a buffer so that
  // flushing can happen without blocking other VM threads.
  virtual void SaveSystemData() = 0;
  virtual SaveError LoadSystemData() = 0;
  virtual void InitializeSystemData() = 0;

  virtual void SaveThumbnailData() = 0;
  virtual SaveError WriteSaveFile() = 0;
  virtual SaveError WriteQuickSaveFile() { return SaveError::OK; };
  virtual uint32_t GetSavePlayTime(SaveType type, int id) const = 0;
  virtual uint8_t GetSaveFlags(SaveType type, int id) const = 0;
  virtual void SetSaveFlags(SaveType type, int id, uint8_t flags) = 0;
  virtual tm const& GetSaveDate(SaveType type, int id) const = 0;
  virtual uint8_t GetSaveStatus(SaveType type, int id) const = 0;
  virtual int GetSaveTitle(SaveType type, int id) const = 0;
  virtual uint32_t GetTipStatus(size_t tipId) const = 0;
  virtual void SetTipStatus(size_t tipId, bool isLocked, bool isUnread,
                            bool isNew) = 0;
  virtual void SetLineRead(size_t scriptId, size_t lineId) = 0;
  virtual bool IsLineRead(size_t scriptId, size_t lineId) const = 0;
  virtual void GetReadMessagesCount(int* totalMessageCount,
                                    int* readMessageCount) const = 0;
  virtual void GetViewedEVsCount(int* totalEVCount,
                                 int* viewedEVCount) const = 0;
  virtual void GetEVStatus(int evId, int* totalVariations,
                           int* viewedVariations) const = 0;
  virtual void SetEVStatus(int id) = 0;
  virtual bool GetEVVariationIsUnlocked(size_t evId,
                                        size_t variationIdx) const = 0;
  virtual bool GetBgmFlag(int id) const = 0;
  virtual void SetBgmFlag(int id, bool flag) = 0;
  virtual void SetCheckpointId(int id) = 0;
  virtual Sprite& GetSaveThumbnail(SaveType type, int id) = 0;
  std::optional<uint8_t> GetQuickSaveOpenSlot() const;
  int GetNewestSaveId(SaveType type) const;
  void UpdateQuickSaveRecentSortedId(int replacedSlot);
  Sprite& GetWorkingSaveThumbnail() { return WorkingSaveThumbnail; }
  int GetLockedQuickSaveCount() const;
  void SetLockedQuickSaveCount(int value);
  bool HasQSavedOnCurrentLine() const;
  void SetQSavedOnCurrentLine(bool value);

  template <typename T>
  T* GetSaveEntry(SaveType type, int position) const
    requires(std::derived_from<T, SaveFileEntryBase>)
  {
    switch (type) {
      case SaveType::Full:
        return static_cast<T*>(FullSaveEntries[position]);
      case SaveType::Quick:
        return static_cast<T*>(
            QuickSaveEntries[QuickSaveRecentSortedId[position]]);
    }
    throw std::invalid_argument(fmt::format(
        "Invalid save type provided to GetSaveEntry: {}", (int)type));
  }

 protected:
  SaveFileEntryBase* FullSaveEntries[MaxSaveEntries];
  SaveFileEntryBase* QuickSaveEntries[MaxSaveEntries];
  std::array<uint8_t, MaxSaveEntries> QuickSaveRecentSortedId = [] {
    std::array<uint8_t, MaxSaveEntries> tmp;
    std::iota(tmp.begin(), tmp.end(), 0);
    return tmp;
  }();
  Sprite WorkingSaveThumbnail;
  int LockedQuickSaveCount;
  bool QuickSavedOnCurrentLine;
};

inline SaveSystemBase* Implementation = nullptr;

void Init();

LoadStatus GetLoadStatus();
void CheckSaveFile();
void MountSaveFile();
void SaveMemory();
void SaveThumbnailData();
void SaveSystemData();
SaveError LoadSystemData();
void InitializeSystemData();
void LoadEntry(SaveType type, int id);
void LoadMemoryNew(LoadProcess process);
void FlushWorkingSaveEntry(SaveType type, int id, int autoSaveType = 0);
void WriteSaveFile();
void WriteQuickSaveFile();
uint32_t GetSavePlayTime(SaveType type, int id);
uint8_t GetSaveFlags(SaveType type, int id);
void SetSaveFlags(SaveType type, int id, uint8_t flags);
tm const& GetSaveDate(SaveType type, int id);
uint8_t GetSaveStatus(SaveType type, int id);
int GetSaveTitle(SaveType type, int id);
uint32_t GetTipStatus(size_t tipId);
void SetTipStatus(size_t tipId, bool isLocked, bool isUnread, bool isNew);
std::optional<size_t> GetLineBitOffset(size_t scriptId, size_t lineId);
void SetLineRead(size_t scriptId, size_t lineId);
bool IsLineRead(size_t scriptId, size_t lineId);
void GetReadMessagesCount(int* totalMessageCount, int* readMessageCount);
void GetViewedEVsCount(int* totalEVCount, int* viewedEVCount);
void GetEVStatus(int evId, int* totalVariations, int* viewedVariations);
void SetEVStatus(int id);
bool GetEVVariationIsUnlocked(size_t evId, size_t variationIdx);
bool GetBgmFlag(int id);
void SetBgmFlag(int id, bool setFlag);
void SetCheckpointId(int id);
std::optional<uint8_t> GetQuickSaveOpenSlot();
int GetNewestSaveId(SaveType type);
void UpdateQuickSaveRecentSortedId(int replacedSlot);
Sprite& GetSaveThumbnail(SaveType type, int id);
Sprite& GetWorkingSaveThumbnail();
bool HasQSavedOnCurrentLine();
void SetQSavedOnCurrentLine(bool value);

}  // namespace SaveSystem
}  // namespace Impacto

template <>
struct magic_enum::customize::enum_range<Impacto::SaveSystem::SaveError> {
  static constexpr int min = 0;
  static constexpr int max = 255;
};