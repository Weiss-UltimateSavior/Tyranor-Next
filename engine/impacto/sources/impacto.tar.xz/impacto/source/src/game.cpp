#include "game.h"

#include "text/dialoguepage.h"
#include "workqueue.h"
#include "modelviewer.h"
#include "characterviewer.h"
#include "log.h"
#include "inputsystem.h"
#include "debugmenu.h"
#include "renderer/opengl/glc.h"

#ifndef IMPACTO_DISABLE_IMGUI
#include "overlay/overlay.h"
#endif

#include "ui/ui.h"
#include "ui/gamespecific.h"

#include "data/savesystem.h"
#include "data/achievementsystem.h"
#include "data/tipssystem.h"
#include "audio/audiosystem.h"
#include "video/videosystem.h"
#include "subtitle/subtitlesystem.h"
#include "background2d.h"
#include "mask2d.h"
#include "character2d.h"
#include "renderer/3d/scene.h"
#include "mem.h"
#include "vm/interface/input.h"
#include "vm/inst_dialogue.h"
#include "renderer/window.h"
#include "hud/datedisplay.h"
#include "hud/saveicondisplay.h"
#include "hud/loadingdisplay.h"
#include "hud/tipsnotification.h"
#include "hud/achievementnotification.h"
#include "games/cclcc/systemmenu.h"
#include "effects/wave.h"
#include "effects/blur.h"
#include "effects/mosaic.h"

#include "profile/profile.h"
#include "profile/game.h"

#include "games/chlcc/delusiontrigger.h"
#include "games/cclcc/delusiontrigger.h"
#include "profile/patch.h"
#include "profile/sprites.h"
#include "profile/charset.h"
#include "profile/fonts.h"
#include "profile/animations.h"
#include "profile/vm.h"
#include "profile/scriptvars.h"
#include "profile/configsystem.h"
#include "profile/hud/saveicon.h"
#include "profile/ui/commonmenu.h"
#include "profile/ui/selectionmenu.h"
#include "profile/ui/sysmesbox.h"
#include "profile/ui/systemmenu.h"
#include "profile/ui/titlemenu.h"
#include "profile/ui/savemenu.h"
#include "profile/ui/backlogmenu.h"
#include "profile/ui/optionsmenu.h"
#include "profile/ui/tipsmenu.h"
#include "profile/ui/extramenus.h"
#include "profile/ui/trophymenu.h"
#include "profile/ui/helpmenu.h"
#include "profile/data/bgeff.h"
#include "profile/ui/gamespecific.h"
#include "profile/ui/buttonprompticons.h"
#include "profile/subtitle.h"

namespace Impacto {

using namespace Profile::ScriptVars;

namespace Game {

static bool UsesCCRenderingRules() {
  return (Profile::GameSpecific::GameSpecificType ==
          UI::GameSpecificType::CC) ||
         (Profile::GameSpecific::GameSpecificType ==
          UI::GameSpecificType::CCLCC);
}

void Init() {
  SDL_SetHint(SDL_HINT_MOUSE_TOUCH_EVENTS, "0");

  WorkQueue::Init();

#ifndef IMPACTO_DISABLE_IMGUI
  IMGUI_CHECKVERSION();
  ImGui::CreateContext();
  ImGuiIO& io = ImGui::GetIO();
  io.IniFilename = NULL;
  io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
  io.ConfigFlags |= ImGuiConfigFlags_NavEnableGamepad;
  if ((+Profile::Game::GameFeatures & +GameFeature::DebugMenu &&
       +Profile::Game::GameFeatures & +GameFeature::DebugMenuMultiViewport) ||
      +Profile::Game::GameFeatures & +GameFeature::Overlay) {
    io.ConfigFlags |= ImGuiConfigFlags_ViewportsEnable;
    io.ConfigFlags |= ImGuiConfigFlags_DockingEnable;
  }
#endif
  InitWindow();
  CreateRenderer();
  InitCursors();

#ifndef IMPACTO_DISABLE_IMGUI
  Overlay::Init();
#endif
}

void InitGameProfile() {
  Profile::ConfigureGameProfile();
  Profile::Game::Configure();
  Profile::Patch::Configure();

  Window->ApplyWindowSettings();
  Renderer->Init();
  Io::VfsInit();

  InitCursors();
  std::fill(std::begin(DrawComponents), std::end(DrawComponents),
            DrawComponentType::None);

  Profile::ConfigSystem::Configure();

  if (+Profile::Game::GameFeatures & +GameFeature::Audio) {
    Audio::AudioInit();
  }

  if (+Profile::Game::GameFeatures & +GameFeature::Video) {
    Video::VideoInit();
  }

  if (+Profile::Game::GameFeatures & +GameFeature::Subtitles) {
    Profile::Subtitle::Configure();
    Subtitle::SubtitleInit();
  }

  ScrWork = {};
  FlagWork = {};

  if (+Profile::Game::GameFeatures & +GameFeature::Renderer2D) {
    Profile::LoadSpritesheets();
    Profile::ButtonPromptIcons::Configure();
    Profile::Charset::Load();
    Profile::LoadFonts();
    Profile::LoadAnimations();
    DialoguePage::Init();

    Background2D::Init();
    Mask2D::Init();

    Profile::BgEff::Load();

    if (Profile::Game::UseWaveEffects) {
      Profile::WaveEffects::Load();
      Effects::Init();
    }

    Effects::Blur.Init();
  }

  SetWindowIcon(Window->SDLWindow);

  if (+Profile::Game::GameFeatures & +GameFeature::ModelViewer) {
    ModelViewer::Init();
  }

  if (+Profile::Game::GameFeatures & +GameFeature::CharacterViewer) {
    CharacterViewer::Init();
  }

  if (+Profile::Game::GameFeatures & +GameFeature::Sc3VirtualMachine) {
    Vm::Init();

    Profile::CommonMenu::Configure();
    Profile::SelectionMenu::Configure();

    SaveSystem::Init();
    AchievementSystem::Init();
    TipsSystem::Init();
    SaveIconDisplay::Init();
    LoadingDisplay::Init();
    Profile::GameSpecific::Configure();
    Profile::SysMesBox::Configure();
    Profile::TitleMenu::Configure();
    Profile::SystemMenu::Configure();
    Profile::SaveMenu::Configure();
    Profile::BacklogMenu::Configure();
    Profile::OptionsMenu::Configure();
    Profile::TrophyMenu::Configure();
    Profile::HelpMenu::Configure();
    Profile::TipsMenu::Configure();
    Profile::ExtraMenus::Configure();
    DateDisplay::Init();
    TipsNotification::Init();
    if (+Profile::Game::GameFeatures & +GameFeature::Achievements) {
      AchievementNotification::Init();
    }
    // Default controls
    Vm::Interface::UpdatePADcustomType(0);

    SaveSystem::InitializeSystemData();

    Effects::Mosaic.Init();
  }

  Profile::ClearProfile();
}

void Shutdown() {
  if (+Profile::Game::GameFeatures & +GameFeature::Audio) {
    Audio::AudioShutdown();
  }

  if (+Profile::Game::GameFeatures & +GameFeature::Video) {
    Video::VideoShutdown();
  }

  if (+Profile::Game::GameFeatures & +GameFeature::Renderer2D) {
    Renderer->Shutdown();
  }
  WorkQueue::StopWorkQueue();
  Window->Shutdown();
}

void LauncherUpdate(float dt) {
  SDL_Event e;

  RequestCursor(CursorType::Default);

  while (SDL_PollEvent(&e)) {
    if (e.type == SDL_EVENT_QUIT) {
      ShouldQuit = true;
    }

#ifndef IMPACTO_DISABLE_IMGUI
    ImGui_ImplSDL3_ProcessEvent(&e);
#endif
  }
}

void LauncherRender() {
  Window->Update();

#ifndef IMPACTO_DISABLE_IMGUI
  Renderer->ImGuiBeginFrame();
  Overlay::Show();
#endif

  ApplyCursorForFrame();

  Window->Draw();
}

void UpdateGameState(float dt) {
  static float UpdateSecondCounter = 0.0f;
  UpdateSecondCounter += dt;
  if (UpdateSecondCounter >= 1) {
    constexpr int maxPlayTime = (999 * 60 + 59) * 60 + 59;
    constexpr int maxTotalPlayTime = (99999 * 60 + 59) * 60 + 59;
    ScrWork[SW_PLAYTIME] = std::min(ScrWork[SW_PLAYTIME] + 1, maxPlayTime);
    ScrWork[SW_TOTALPLAYTIME] =
        std::min(ScrWork[SW_TOTALPLAYTIME] + 1, maxTotalPlayTime);

    UpdateSecondCounter -= 1.0f;
  }

  if ((ScrWork[SW_GAMESTATE] & 5) == 1 && !GetFlag(SF_SYSTEMMENUDISABLE) &&
      !GetFlag(SF_GAMEPAUSE) && !GetFlag(SF_SYSMENUDISABLE) &&
      Vm::Interface::GetControlState(Vm::Interface::ControlType::Hide)) {
    // Some more stuff here?
    if ((GetFlag(SF_MESWINDOW0OPENFL) &&
         DialoguePages[0].TextIsFullyOpaque()) ||
        (GetFlag(SF_SHOWWAITICON) || GetFlag(SF_SHOWWAITICON + 1) ||
         GetFlag(SF_SHOWWAITICON + 2))) {
      SetFlag(SF_UIHIDDEN, !GetFlag(SF_UIHIDDEN));
    }
  }
  if (Profile::GameSpecific::GameSpecificType == UI::GameSpecificType::CHLCC) {
    UI::CHLCC::DelusionTrigger::GetInstance().UpdateHeartButtons();
  }
  if (Profile::GameSpecific::GameSpecificType == UI::GameSpecificType::CCLCC) {
    UI::CCLCC::DelusionTrigger::GetInstance().UpdateDragging(dt);
  }
  Vm::ChkMesSkip(dt);
  if (UsesCCRenderingRules()) {
    UI::GameSpecific::UpdateCCButtonGuide(dt);
  }
}

void UpdateSystem(float dt) {
  constexpr float updateInterval = 1.0f / 60.0f;

  static float UpdateSecondCounter = 0.0f;
  UpdateSecondCounter += dt;
  if (UpdateSecondCounter < updateInterval) {
    return;
  }

  SDL_Event e;
  if (+Profile::Game::GameFeatures & +GameFeature::Input) {
    Input::BeginFrame();
    RequestCursor(CursorType::Default);
  }

  while (SDL_PollEvent(&e)) {
    if (e.type == SDL_EVENT_QUIT) {
      if (Profile::Patch::HasScriptedExitLogic) {
        Input::KeyboardButtonWentDown[SDL_SCANCODE_ESCAPE] = true;
      } else {
        ShouldQuit = true;
      }
    }

    if (HandleWindowEvents(&e)) continue;
#ifndef IMPACTO_DISABLE_IMGUI
    ImGuiIO& io = ImGui::GetIO();
    const bool isImguiEvent = [&e] {
      switch (e.type) {
        case SDL_EVENT_GAMEPAD_BUTTON_DOWN:
        case SDL_EVENT_GAMEPAD_BUTTON_UP:
        case SDL_EVENT_GAMEPAD_AXIS_MOTION:
        case SDL_EVENT_FINGER_MOTION:
        case SDL_EVENT_FINGER_DOWN:
        case SDL_EVENT_FINGER_UP:
          return true;
        default:
          return ImGui_ImplSDL3_ProcessEvent(&e);
      }
    }();
    // pass key button up to the app so Alt + D won't cause sticky D key
    const bool isReleaseEvent =
        e.type == SDL_EVENT_KEY_UP || e.type == SDL_EVENT_GAMEPAD_BUTTON_UP;

    if (isImguiEvent && !isReleaseEvent &&
        (io.WantCaptureKeyboard || io.WantCaptureMouse || io.NavActive))
      continue;
#endif

    if (+Profile::Game::GameFeatures & +GameFeature::Input) {
      if (Input::HandleEvent(&e)) continue;
    }

    WorkQueue::HandleEvent(&e);
  }
  if (+Profile::Game::GameFeatures & +GameFeature::Sc3VirtualMachine) {
    Vm::Interface::UpdatePADInput();
    Vm::Interface::UpdatePADHoldInput(updateInterval);
    Vm::Interface::UpdateKBHoldInput(updateInterval);
    UpdateGameState(updateInterval);

    for (DrawComponentType value :
         magic_enum::enum_values<DrawComponentType>()) {
      for (auto const& menu : UI::Menus[value]) {
        menu->Update(updateInterval);
      }
    }
    for (auto const& [id, box] : UI::SysMesBox::MsgBoxes) {
      box->Update(updateInterval);
    }

    UI::GameSpecific::NonGameplayUpdate(updateInterval);
    SaveIconDisplay::Update(updateInterval);
    LoadingDisplay::Update(updateInterval);
    DateDisplay::Update(updateInterval);
    if (+Profile::Game::GameFeatures & +GameFeature::Achievements) {
      AchievementNotification::Update(updateInterval);
    }
    if (ScrWork[SW_GAMESTATE] & 5 && !GetFlag(SF_GAMEPAUSE)) {
      UI::GameSpecific::Update(updateInterval);

      if (Profile::Game::UseWaveEffects) {
        if (IsBgWaveEffectActive()) {
          Effects::WaveBG.Update(updateInterval);
        }
        if (GetFlag(SF_BGEFF1DISP) &&
            (!UsesCCRenderingRules() || ScrWork[SW_EFF_WAVE_ALPHA])) {
          Effects::WaveEFF.Update(updateInterval);
        }
      }

      if (!GetFlag(SF_MOVIEPLAY)) {
        TipsNotification::Update(updateInterval);
      }
    }

    Vm::Update(updateInterval);
  }
  UpdateSecondCounter -= updateInterval;
}

void Update(float dt) {
  bool AudioDeviceChanged = false;
  bool AudioReopenSupported = false;
  if (Audio::Backend) {
    AudioDeviceChanged = Audio::Backend->DidDeviceChanged();
    AudioReopenSupported = Audio::Backend->ReopenSupported();
  }
  UpdateSystem(dt);

#ifndef IMPACTO_DISABLE_IMGUI
  Renderer->ImGuiBeginFrame();
#endif

  if (+Profile::Game::GameFeatures & +GameFeature::ModelViewer) {
    ModelViewer::Update(dt);
  }

  if (+Profile::Game::GameFeatures & +GameFeature::CharacterViewer) {
    CharacterViewer::Update(dt);
  }

  if (+Profile::Game::GameFeatures & +GameFeature::Audio) {
    if (AudioDeviceChanged) Audio::AudioReinit();
    Audio::AudioUpdate(dt);
  }

  if (+Profile::Game::GameFeatures & +GameFeature::Video) {
    if (AudioDeviceChanged && !AudioReopenSupported) Video::ReinitAudio();
    Video::VideoUpdate(dt);
  }

  if (+Profile::Game::GameFeatures & +GameFeature::Audio &&
      +Profile::Game::GameFeatures & +GameFeature::Subtitles) {
    Audio::AudioSubtitlesUpdate();
  }

  if (+Profile::Game::GameFeatures & +GameFeature::Scene3D) {
    Renderer->Scene->Update(dt);
  }

  if (+Profile::Game::GameFeatures & +GameFeature::Renderer2D) {
    for (DialoguePage& page : DialoguePages) page.Update(dt);
    KeyWaitIcon->Update(dt);
    AutoIconDisplay::Update(dt);
    SkipIconDisplay::Update(dt);
  }
}

static void RenderMain() {
  Background2D::LastRenderedBackground = nullptr;
  UI::GameSpecific::RenderEarlyMain();
  std::array<bool, MaxFramebuffers + 1> cleared{};

  for (uint32_t layer = 0; layer <= Profile::Game::LayerCount; layer++) {
    if (UsesCCRenderingRules()) {
      const int renderTarget = ScrWork[SW_RENDERTARGET + layer];
      if (0 <= renderTarget && renderTarget <= MaxFramebuffers) {
        Renderer->SetFramebuffer(renderTarget);

        if (!cleared[renderTarget]) {
          Renderer->ClearFramebuffer(renderTarget);
          cleared[renderTarget] = true;
        }
      }
    }

    for (int bgId = 0; bgId < std::ssize(Backgrounds); bgId++) {
      int bufId = ScrWork[SW_BG1SURF + bgId];
      Backgrounds2D[bufId]->UpdateState(bgId);
      Backgrounds2D[bufId]->Render(layer);
    }

    // Games with <= 2 don't render their captures separately
    if (Profile::Vm::ScrWorkCaptureStructSize > 0) {
      for (int capId = 0;
           capId < static_cast<int>(Profile::Game::ScreenCaptureCount);
           capId++) {
        Screencaptures[capId].UpdateState(capId);
        Screencaptures[capId].Render(layer);
      }
    }

    if (Background2D::LastRenderedBackground != nullptr) {
      Background2D::LastRenderedBackground->RenderBgEff(layer);
    }

    if ((+Profile::Game::GameFeatures & +GameFeature::Renderer2D) &&
        !(+Profile::Game::GameFeatures & +GameFeature::Scene3D)) {
      for (int chaId = 0; chaId < std::ssize(Characters2D); chaId++) {
        int bufId = ScrWork[SW_CHA1SURF + chaId];
        Characters2D[bufId].UpdateState(chaId);
        Characters2D[bufId].Render(layer);
      }
    }

    if (Profile::Vm::ScrWorkBgEffStructSize > 0) {
      for (int bgId = 0; bgId < std::ssize(Backgrounds); bgId++) {
        Framebuffers[0].UpdateState(bgId);
        Framebuffers[0].Render(layer);
      }
    }

    for (int i = 0; i < 2; ++i) {
      constexpr static int maskOffset = 7;
      if (ScrWork[SW_MASK1PRI + maskOffset * i] == static_cast<int>(layer)) {
        const int maskAlpha = ScrWork[SW_MASK1ALPHA_OFS + i] +
                              ScrWork[SW_MASK1ALPHA + maskOffset * i];

        if (maskAlpha > 0) {
          RectF maskRect = {(float)ScrWork[SW_MASK1POSX + maskOffset * i],
                            (float)ScrWork[SW_MASK1POSY + maskOffset * i],
                            (float)ScrWork[SW_MASK1SIZEX + maskOffset * i],
                            (float)ScrWork[SW_MASK1SIZEY + maskOffset * i]};
          if (maskRect.Width == 0.0f || maskRect.Height == 0.0f) {
            maskRect = {0.0f, 0.0f, Profile::Game::DesignWidth,
                        Profile::Game::DesignHeight};
          }

          glm::vec4 col = ScrWorkGetColor(SW_MASK1COLOR + maskOffset * i);
          col.a = glm::min(maskAlpha / 256.0f, 1.0f);

          Renderer->DrawQuad(maskRect, col);
        }
      }
    }

    if (Profile::Game::UseMoviePriority &&
        (+Profile::Game::GameFeatures & +GameFeature::Video)) {
      int videoAlpha = 0;
      if (Profile::Vm::GameInstructionSet == Vm::InstructionSet::CHLCC) {
        if (ScrWork[SW_MOVIEALPHA] > 0 &&
            ScrWork[SW_MOVIEPRI] == static_cast<int>(layer)) {
          videoAlpha = ScrWork[SW_MOVIEALPHA];
        } else if (ScrWork[SW_MOVIEALPHA] == 0 &&
                   ScrWork[SW_MOVIEPRI2] == static_cast<int>(layer)) {
          videoAlpha = ScrWork[SW_MOVIEALPHA2];
        }
      } else {
        if (ScrWork[SW_MOVIEPRI] == static_cast<int>(layer)) {
          videoAlpha = ScrWork[SW_MOVIEALPHA];
        } else if (ScrWork[SW_MOVIEPRI2] == static_cast<int>(layer)) {
          videoAlpha = ScrWork[SW_MOVIEALPHA2];
        } else if (ScrWork[SW_MOVIEPRI3] == static_cast<int>(layer)) {
          videoAlpha = ScrWork[SW_MOVIEALPHA3];
        } else if (ScrWork[SW_MOVIEPRI4] == static_cast<int>(layer)) {
          videoAlpha = ScrWork[SW_MOVIEALPHA4];
        }
      }
      if (videoAlpha > 0) {
        Video::VideoRender(videoAlpha / 256.0f);
      }
    }

    if (ScrWork[SW_FEATHERING_PRI] == static_cast<int>(layer) &&
        ScrWork[SW_FEATHERING] > 0) {
      Effects::Blur.Render(ScrWork[SW_FEATHERING]);
    }

    if (ScrWork[SW_FEATHERING2_PRI] == static_cast<int>(layer) &&
        ScrWork[SW_FEATHERING2] > 0) {
      Effects::Blur.Render(ScrWork[SW_FEATHERING2]);
    }

    if (Profile::Game::UseWaveEffects) {
      if (GetFlag(SF_BGEFF1DISP) &&
          (!UsesCCRenderingRules() || ScrWork[SW_EFF_WAVE_ALPHA])) {
        if (ScrWork[SW_EFF_WAVE_PRI] == static_cast<int>(layer)) {
          std::optional<float> alpha = std::nullopt;
          if (UsesCCRenderingRules()) {
            alpha = static_cast<uint32_t>(ScrWork[SW_EFF_WAVE_ALPHA]) / 256.0f;
          }
          Renderer->CaptureScreencap(Screencaptures[0].BgSprite);
          Screencaptures[0].Status = LoadStatus::Loaded;
          Effects::WaveEFF.CalcPos(0, alpha);
          Effects::WaveEFF.Render(Screencaptures[0].BgSprite);
        }
      }
    }

    if (ScrWork[SW_MOSAIC_PRI] == static_cast<int>(layer)) {
      // There is no normalizing around the usual 720p ScrWork vars *by design*!
      // Lower-resolution games actually show larger tile sizes than
      // the higher-resolution ones.
      Effects::Mosaic.Render(static_cast<float>(ScrWork[SW_MOSAIC]));
    }

    UI::GameSpecific::RenderLayer(layer);

    for (size_t capId = 0; capId < Profile::Game::ScreenCaptureCount; capId++) {
      const size_t capOffset =
          capId * Profile::Vm::ScrWorkCaptureEffectInfoStructSize;
      if (ScrWork[SW_EFF_CAP_BUF + capOffset] == 0 ||
          static_cast<uint32_t>(ScrWork[SW_EFF_CAP_PRI + capOffset]) != layer) {
        continue;
      }

      Renderer->CaptureScreencap(Screencaptures[capId].BgSprite);
      Screencaptures[capId].Status = LoadStatus::Loaded;
    }

    if (GetFlag(SF_MASK_CAPTURE) &&
        ScrWork[SW_MASK_CAPTURE_PRI] == static_cast<int>(layer)) {
      Renderer->CaptureScreencap(MaskCapture.BgSprite);
      MaskCapture.Status = LoadStatus::Loaded;
    }
  }
  UI::GameSpecific::RenderMain();

  Renderer->SetFramebuffer(0);

  if (SaveSystem::Implementation) {
    Renderer->CaptureScreencap(SaveSystem::GetWorkingSaveThumbnail());
  }

  DateDisplay::Render();

  // MO8 uses those huge layer indexes for movie menu, it doesn't
  // actually have 4000 layers
  if ((+Profile::Game::GameFeatures & +GameFeature::Video) &&
      (!Profile::Game::UseMoviePriority ||
       (Profile::Vm::GameInstructionSet == Vm::InstructionSet::MO8 &&
        (ScrWork[SW_MOVIEPRI] == 3000 || ScrWork[SW_MOVIEPRI] == 4000)))) {
    Video::VideoRender(ScrWork[SW_MOVIEALPHA] / 256.0f);
  }

  if (+Profile::Game::GameFeatures & +GameFeature::Audio &&
      +Profile::Game::GameFeatures & +GameFeature::Subtitles) {
    Audio::AudioSubtitlesRender();
  }
}

void Render() {
  Window->Update();

  Renderer->BeginFrame();

  if (+Profile::Game::GameFeatures & +GameFeature::Scene3D) {
    Renderer->Scene->Render();
  }

  Renderer->BeginFrame2D();

#ifndef IMPACTO_DISABLE_IMGUI
  if (+Profile::Game::GameFeatures & +GameFeature::DebugMenu) {
    DebugMenu::Show();
  }
#endif

  if (+Profile::Game::GameFeatures & +GameFeature::Renderer2D) {
    if (Window->WindowDimensionsChanged) {
      Background2D::InitFrameBuffers();
    }
    for (int i = 0; i < Vm::MaxThreads; i++) {
      if (DrawComponents[i] == DrawComponentType::None) break;

      switch (DrawComponents[i]) {
        case DrawComponentType::Text: {
          if (!GetFlag(SF_UIHIDDEN) &&
              (!GetFlag(SF_SELECTMODE) || GetFlag(SF_SYSTEMMENUCAPTURE))) {
            // Dialogue pages drawn in reverse order, at least for cclcc
            for (auto pageIt = DialoguePages.rbegin();
                 pageIt != DialoguePages.rend(); pageIt++) {
              pageIt->Render(1.0f);
            }
          }

          // System menu capture
          if (UsesCCRenderingRules() && GetFlag(SF_SYSTEMMENUCAPTURE)) {
            Renderer->CaptureScreencap(
                static_cast<UI::CCLCC::SystemMenu*>(UI::SystemMenuPtr)
                    ->ScreenCap);
            SetFlag(SF_SYSTEMMENUCAPTURE, false);
          }

          KeyWaitIcon->Render({0.0f, 0.0f}, glm::vec4(1.0f));

          if (!GetFlag(SF_UIHIDDEN) && !GetFlag(SF_MOVIEPLAY)) {
            TipsNotification::Render();
          }
          break;
        }
        case DrawComponentType::Main: {
          if (UsesCCRenderingRules() && !(!GetFlag(SF_SELECTMODE) ||
                                          (GetFlag(SF_SYSTEMMENUCAPTURE) &&
                                           ScrWork[SW_RESTARTMASK] != 0x100))) {
            break;
          }
          RenderMain();
          break;
        }
        case DrawComponentType::ExtrasScenes: {
          break;
        }
        case DrawComponentType::Mask: {
          Renderer->DrawQuad(
              RectF(0.0f, 0.0f, Profile::Game::DesignWidth,
                    Profile::Game::DesignHeight),
              glm::vec4(0.0f, 0.0f, 0.0f, (ScrWork[SW_RESTARTMASK] / 256.0f)));
          break;
        }
        case DrawComponentType::SaveMenu: {
          break;
        }
        case DrawComponentType::SystemIcons: {
          if (UsesCCRenderingRules()) {
            UI::GameSpecific::RenderCCButtonGuide();
          }

          LoadingDisplay::Render();
          SaveIconDisplay::Render();
          break;
        }
        case DrawComponentType::TitleMenu: {
          break;
        }
        case DrawComponentType::SystemMenu: {
          break;
        }
        case DrawComponentType::PlayData: {
          break;
        }
        case DrawComponentType::SystemMessage: {
          for (auto const& [id, box] : UI::SysMesBox::MsgBoxes) {
            box->Render();
          }
          break;
        }
        case DrawComponentType::SaveIcon: {
          if (Profile::SaveIcon::SaveIconMenuOverlay) {
            SaveIconDisplay::Render();
          }
          break;
        }
        default: {
          ImpLogSlow(LogLevel::Warning, LogChannel::General,
                     "Encountered unknown draw component type {}\n",
                     DrawComponents[i]);
          break;
        }
      }

      for (auto const& menu : UI::Menus[DrawComponents[i]]) {
        menu->Render();
      }
    }
    if (+Profile::Game::GameFeatures & +GameFeature::Achievements) {
      AchievementNotification::Render();
    }
  }

  if (+Profile::Game::GameFeatures & +GameFeature::CharacterViewer) {
    if (Backgrounds2D[0]->Status == LoadStatus::Loaded) {
      Renderer->DrawSprite(
          Backgrounds2D[0]->BgSprite,
          RectF(0.0f, 0.0f, Backgrounds2D[0]->BgSprite.ScaledWidth(),
                Backgrounds2D[0]->BgSprite.ScaledHeight()));
    }
    if (Characters2D[0].Status == LoadStatus::Loaded) {
      Characters2D[0].Layers[0] = 0;
      ScrWork[SW_CHA1ALPHA] = 256;

      Characters2D[0].UpdateState(0);
      Characters2D[0].Render(0);
    }
  }
#ifndef IMPACTO_DISABLE_IMGUI
  if (+Profile::Game::GameFeatures & +GameFeature::Overlay) {
    Overlay::Show();
  }
#endif

  ApplyCursorForFrame();

  Renderer->EndFrame();

  Window->Draw();
}

}  // namespace Game

}  // namespace Impacto
