root.GameDefinitions = {
  chlcc = {
    Name = "CHAOS;HEAD Love Chu☆Chu!",
    LauncherOrderId = 0,
    LauncherTheme = 0xF4C7CC,
    GameProfile = root.BasePaths.RootProfilesDir .. "/chlcc/game.lua",
    Patch = {
      English = root.BasePaths.RootPatchesDir .. "/english/profiles/chlcc/patch.lua",
    }
  },
  ["chlcc-switch"] = {
    Hidden = true,
    Name = "CHAOS;HEAD Love Chu☆Chu! (Switch)",
    GameProfile = root.BasePaths.RootProfilesDir .. "/chlcc-switch/game.lua",
  },
  cclcc = {
    Name = "CHAOS;CHILD Love Chu☆Chu!! (PS4)",
    LauncherOrderId = 3,
    LauncherTheme = 0xFF7698,
    GameProfile = root.BasePaths.RootProfilesDir .. "/cclcc/game.lua",
    Patch = {
      English = root.BasePaths.RootPatchesDir .. "/english/profiles/cclcc/patch.lua",
    }
  },
  ["cclcc-switch"] = {
    Name = "CHAOS;CHILD Love Chu☆Chu!! (Switch)",
    LauncherOrderId = 4,
    LauncherTheme = 0xFF7698,
    GameProfile = root.BasePaths.RootProfilesDir .. "/cclcc-switch/game.lua",
    Patch = {
      English = root.BasePaths.RootPatchesDir .. "/english/profiles/cclcc-switch/patch.lua",
    }
  },
  mo6tw = {
    Hidden = true,
    Name = "Memories Off 6 ~T-Wave~",
    LauncherOrderId = 6,
    GameProfile = root.BasePaths.RootProfilesDir .. "/mo6tw/game.lua",
  },
  darling = {
    Hidden = true,
    Name = "STEINS;GATE: My Darling's Embrace",
    LauncherOrderId = 1,
    GameProfile = root.BasePaths.RootProfilesDir .. "/darling/game.lua",
  },
  dash = {
    Hidden = true,
    Name = "ROBOTICS;NOTES DaSH",
    LauncherOrderId = 5,
    GameProfile = root.BasePaths.RootProfilesDir .. "/dash/game.lua",
  },
  rne = {
    Hidden = true,
    Name = "ROBOTICS;NOTES ELITE",
    LauncherOrderId = 2,
    GameProfile = root.BasePaths.RootProfilesDir .. "/rne/game.lua",
  },
  characterviewer = {
    Hidden = true,
    Name = "Character Viewer",
    LauncherOrderId = 7,
    GameProfile = root.BasePaths.RootProfilesDir .. "/characterviewer/game.lua",
  },
  modelviewer = {
    Hidden = true,
    Name = "Model Viewer",
    LauncherOrderId = 8,
    GameProfile = root.BasePaths.RootProfilesDir .. "/modelviewer/game.lua",
  },
  ["modelviewer-dash"] = {
    Hidden = true,
    Name = "Model Viewer DaSH",
    LauncherOrderId = 9,
    GameProfile = root.BasePaths.RootProfilesDir .. "/modelviewer-dash/game.lua",
  },
};
