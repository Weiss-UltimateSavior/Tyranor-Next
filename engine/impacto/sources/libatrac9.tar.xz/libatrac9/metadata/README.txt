The source directory contains the actual patched build input, not a pristine checkout. Do not reapply local-modifications.patch. See the release SOURCE-DISTRIBUTION.md for rebuilding.
