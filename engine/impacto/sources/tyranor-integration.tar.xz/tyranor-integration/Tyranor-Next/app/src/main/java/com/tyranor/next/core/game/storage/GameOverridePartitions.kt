package com.tyranor.next.core.game.storage

import org.json.JSONObject

/**
 * 单游戏覆盖记录在「prefs 整条 JSON blob」与「DB 分区列」之间的双向映射（迁移方案 4.4）。
 *
 * 引擎契约：引擎子进程只读 prefs blob 镜像（TyranoActivity / RpgMakerActivity 启动时
 * 解析生效设置，含输入重映射开关与方案 id）；写路径已全部收敛到 app 侧，不再有引擎回写。
 * 键名在此以字面量锚定（与 PerGameSettingsStore 的 F_* 常量、引擎侧常量三处对应，
 * GameOverridePartitionsTest 约束一致），避免 storage 反向依赖 settings 形成包环。
 * 未识别的顶层键兜底归入 tyrano 分区，保证组装不丢字段。
 */
internal object GameOverridePartitions {

    /** 旧触屏手柄布局键（迁移来源，只在 touchpad 分区持久化）。 */
    const val TOUCH_PAD_CONFIG_KEY = "touch_pad_config"
    const val TOUCH_PAD_PRESETS_KEY = "touch_pad_presets"

    const val KEY_ENGINE_VERSION = "engine_version"
    const val KEY_ENGINE_KERNEL = "engine_kernel"
    const val KEY_SCOPED_SAVE_DIR = "scoped_save_dir"
    const val KEY_DEFAULT_FONT = "default_font"
    const val KEY_FORCE_DEFAULT_FONT = "force_default_font"
    const val KEY_PATCH_OVERLAY_MODE = "patch_overlay_mode"
    const val KEY_SKIP_STARTUP_DIALOGS = "skip_startup_dialogs"
    const val KEY_RENDERER = "renderer"
    const val KEY_SOFTWARE_DRAW_THREAD = "software_draw_thread"
    const val KEY_SOFTWARE_COMPRESS_TEX = "software_compress_tex"
    const val KEY_OGL_COMPRESS_TEX = "ogl_compress_tex"
    const val KEY_MEM_USAGE = "mem_usage"
    const val KEY_OGL_MAX_TEXSIZE = "ogl_max_texsize"
    const val KEY_OGL_ACCURATE_RENDER = "ogl_accurate_render"
    const val KEY_FPS_LIMIT = "fps_limit"
    const val KEY_VCURSOR_SCALE = "vcursor_scale"
    const val KEY_MENU_HANDLER_OPA = "menu_handler_opa"
    const val KEY_ART_VERSION = "art_engine_version"
    const val KEY_ART_KERNEL = "artemis_kernel"
    const val KEY_ART_ROTATE = "art_rotate_screen"
    const val KEY_ART_PATCH = "art_auto_patch"
    const val KEY_ART_ANIME4K_ENABLED = "art_anime4k_enabled"
    const val KEY_ART_ANIME4K_MODE = "art_anime4k_mode"
    const val KEY_RPG_MAKER_MOD_ENABLED = "rpg_maker_mod_enabled"
    const val KEY_RPG_LEGACY_RENDERER = "rpg_legacy_renderer"
    const val KEY_RPG_SAVE_INTEROP = "rpg_save_interop"
    const val KEY_RPG_MV_VERSION = "rpg_mv_engine_version"
    const val KEY_RPG_MZ_VERSION = "rpg_mz_engine_version"
    // 输入重映射（虚拟按键 + 手柄映射）单游戏覆盖键；与 engine 侧 InputConfigStore 字面量锚定
    const val KEY_INPUT_PAD_ENABLED = "input_pad_enabled"
    const val KEY_INPUT_GAMEPAD_ENABLED = "input_gamepad_enabled"
    const val KEY_INPUT_PROFILE_ID = "input_profile_id"
    // 旧触屏手柄的一次性迁移标记（与 PerGameSettingsStore.F_LEGACY_MIGRATED 字面量锚定）
    const val KEY_INPUT_LEGACY_MIGRATED = "input_legacy_migrated"
    // RPG Maker RGSS 外置模块覆盖键（与 PerGameSettingsStore.F_RPG_* 字面量锚定）
    const val KEY_RPG_USE_RUBY18 = "rpg_use_ruby18"
    const val KEY_RPG_DEBUG = "rpg_debug"
    const val KEY_RPG_SMOOTH_SCALING = "rpg_smooth_scaling"
    const val KEY_RPG_VSYNC = "rpg_vsync"
    const val KEY_RPG_FRAME_SKIP = "rpg_frame_skip"
    const val KEY_RPG_SOLID_FONTS = "rpg_solid_fonts"
    const val KEY_RPG_PATH_CACHE = "rpg_path_cache"
    const val KEY_RPG_PREBUILT_PATH_CACHE = "rpg_prebuilt_path_cache"
    const val KEY_RPG_FAST_PATH_ENUM = "rpg_fast_path_enum"
    const val KEY_RPG_COPY_TEXT = "rpg_copy_text"
    const val KEY_RPG_CHEATS = "rpg_cheats"
    const val KEY_RPG_USE_CJK_FONT = "rpg_use_cjk_font"
    const val KEY_RPG_ENABLE_POSTLOAD_SCRIPTS = "rpg_enable_postload_scripts"
    const val KEY_RPG_CUSTOM_FONT = "rpg_custom_font"
    const val KEY_RPG_VERTICAL_SCREEN_ALIGN = "rpg_vertical_screen_align"
    const val KEY_RPG_WINDOW_SIZE = "rpg_window_size"
    const val KEY_RPG_SPEED_UP = "rpg_speed_up"
    const val KEY_RPG_FONT_SCALE = "rpg_font_scale"
    const val KEY_TY_SCOPED = "ty_scoped"
    // Winlator 无独立分区：单游戏运行模式与覆盖参数随 tyrano 分区持久化，
    // 全部显式建模，避免未来收紧分区时靠「未识别键兜底」静默丢键。
    const val KEY_WINLATOR_MODE = "winlator_mode"
    const val KEY_WINLATOR_CONTAINER_ID = "winlator_container_id"
    const val KEY_WINLATOR_CONTAINER_NAME = "winlator_container_name"
    const val KEY_WINLATOR_GRAPHICS_DRIVER = "winlator_graphics_driver"
    const val KEY_WINLATOR_DXWRAPPER = "winlator_dxwrapper"
    const val KEY_WINLATOR_SCREEN_SIZE = "winlator_screen_size"
    const val KEY_WINLATOR_LC_ALL = "winlator_lc_all"
    const val KEY_WINLATOR_TZ = "winlator_tz"
    const val KEY_WINLATOR_BOX64_PRESET = "winlator_box64_preset"
    const val KEY_WINLATOR_SAVE = "winlator_save"
    const val KEY_RENPY_VERSION = "renpy_engine_version"
    // Siglus 无独立分区：语言覆盖随 tyrano 分区持久化（与 RPG Maker 会话键同策略）
    const val KEY_SIGLUS_LANGUAGE = "siglus_language"
    // framebuffer 引擎（RealLive / AVG32 / UK2）无独立分区：文本编码覆盖随 tyrano 分区持久化
    const val KEY_FB_NLS = "fb_nls"
    // FVP 无独立分区：编码/字体开关覆盖同样随 tyrano 分区持久化
    const val KEY_FVP_NLS = "fvp_nls"
    const val KEY_ETHORNELL_NLS = "ethornell_nls"
    const val KEY_ETHORNELL_FONT = "ethornell_font"
    const val KEY_CMVS_FONT = "cmvs_font"
    const val KEY_FVP_SYSTEM_FONT = "fvp_system_font"
    const val KEY_FVP_TEXT_HIDPI = "fvp_text_hidpi"
    const val KEY_FVP_FONT = "fvp_font"
    // System35 无独立分区：四项覆盖随 tyrano 分区持久化（与 PerGameSettingsStore.F_XSYS35_* 字面量锚定）
    const val KEY_XSYS35_SCOPED_SAVE_DIR = "xsys35_scoped_save_dir"
    const val KEY_XSYS35_RENDERER = "xsys35_renderer"
    const val KEY_XSYS35_INTEGER_SCALE = "xsys35_integer_scale"
    const val KEY_XSYS35_MUTE_UNFOCUS = "xsys35_mute_unfocus"
    // System4 无独立分区：六项覆盖随 tyrano 分区持久化（与 PerGameSettingsStore.F_XSYS4_* 字面量锚定）
    const val KEY_XSYS4_SCOPED_SAVE_DIR = "xsys4_scoped_save_dir"
    const val KEY_XSYS4_ENCODING = "xsys4_encoding"
    const val KEY_XSYS4_FONT_GOTHIC_PATH = "xsys4_font_gothic_path"
    const val KEY_XSYS4_FONT_MINCHO_PATH = "xsys4_font_mincho_path"
    const val KEY_XSYS4_JOYPAD = "xsys4_joypad"
    const val KEY_XSYS4_MSGSKIP_DELAY = "xsys4_msgskip_delay"
    // Ren'Py 外置模块配置覆盖键（与 PerGameSettingsStore.F_RENPY_* 字面量锚定）
    const val KEY_RENPY_CHEATS = "renpy_cheats"
    const val KEY_RENPY_HW_VIDEO = "renpy_hw_video"
    const val KEY_RENPY_AUTOSAVE = "renpy_autosave"
    const val KEY_RENPY_PHONE_SMALL_VARIANT = "renpy_phonesmallvariant"
    const val KEY_RENPY_VSYNC = "renpy_vsync"
    const val KEY_RENPY_LESS_MEMORY = "renpy_less_memory"
    const val KEY_RENPY_LESS_UPDATES = "renpy_less_updates"
    const val KEY_RENPY_DONT_USE_GL2 = "renpy_dont_use_gl2"
    const val KEY_RENPY_RECOMPILE = "renpy_recompile"
    // Ruffle 外置模块配置覆盖键（与 PerGameSettingsStore.F_RUFFLE_*、EngineSettingsStore.KEY_RUFFLE_* 字面量锚定）
    const val KEY_RUFFLE_SCREEN_TIMEOUT = "ruffle_screen_timeout"
    const val KEY_RUFFLE_BACKEND = "ruffle_backend"
    const val KEY_RUFFLE_QUALITY = "ruffle_quality"
    const val KEY_RUFFLE_SCALE_MODE = "ruffle_scale_mode"
    const val KEY_RUFFLE_LETTERBOX = "ruffle_letterbox"
    const val KEY_RUFFLE_LOAD_BEHAVIOR = "ruffle_load_behavior"
    const val ONS_OBJECT_KEY = "ons"

    /** Read-only legacy migration key; keep old KR values in their own partition until frozen. */
    const val KEY_KR_LEGACY_ANIME4K_MODE = "anime4k_mode"

    const val KEY_KR_GRAPHICS = "kr_graphics_v1"
    const val KEY_ART_GRAPHICS = "artemis_graphics_v1"
    const val KEY_SIGLUS_GRAPHICS = "siglus_graphics_v1"

    val KR_KEYS: Set<String> = setOf(
        KEY_KR_GRAPHICS, KEY_KR_LEGACY_ANIME4K_MODE,
        KEY_ENGINE_VERSION, KEY_ENGINE_KERNEL, KEY_SCOPED_SAVE_DIR, KEY_DEFAULT_FONT,
        KEY_FORCE_DEFAULT_FONT, KEY_PATCH_OVERLAY_MODE, KEY_RENDERER, KEY_SOFTWARE_DRAW_THREAD,
        KEY_SOFTWARE_COMPRESS_TEX, KEY_OGL_COMPRESS_TEX, KEY_MEM_USAGE, KEY_OGL_MAX_TEXSIZE,
        KEY_OGL_ACCURATE_RENDER, KEY_FPS_LIMIT, KEY_VCURSOR_SCALE, KEY_MENU_HANDLER_OPA,
        KEY_SKIP_STARTUP_DIALOGS,
    )
    val ARTEMIS_KEYS: Set<String> = setOf(
        KEY_ART_GRAPHICS,
        KEY_ART_VERSION, KEY_ART_KERNEL, KEY_ART_ROTATE, KEY_ART_PATCH,
        KEY_ART_ANIME4K_ENABLED, KEY_ART_ANIME4K_MODE,
    )
    // RPG Maker 会话键（legacy 渲染、MV/MZ 运行时版本、RGSS 外置模块配置）与 tyrano 共用分区：
    // v0 宿主与 v1/v2 宿主的逐游戏覆盖都在这一条 blob 里，显式建模，
    // 不依赖“未识别键兜底归入 tyrano”的 else 路径，防止未来收紧分区时丢键
    val TYRANO_KEYS: Set<String> = setOf(
        KEY_TY_SCOPED, KEY_WINLATOR_MODE,
        KEY_WINLATOR_CONTAINER_ID, KEY_WINLATOR_CONTAINER_NAME,
        KEY_WINLATOR_GRAPHICS_DRIVER, KEY_WINLATOR_DXWRAPPER, KEY_WINLATOR_SCREEN_SIZE,
        KEY_WINLATOR_LC_ALL, KEY_WINLATOR_TZ, KEY_WINLATOR_BOX64_PRESET, KEY_WINLATOR_SAVE,
        KEY_RPG_MAKER_MOD_ENABLED, KEY_RPG_SAVE_INTEROP,
        KEY_RPG_LEGACY_RENDERER, KEY_RPG_MV_VERSION, KEY_RPG_MZ_VERSION,
        KEY_INPUT_PAD_ENABLED, KEY_INPUT_GAMEPAD_ENABLED, KEY_INPUT_PROFILE_ID,
        KEY_INPUT_LEGACY_MIGRATED,
        KEY_RPG_USE_RUBY18, KEY_RPG_DEBUG, KEY_RPG_SMOOTH_SCALING, KEY_RPG_VSYNC,
        KEY_RPG_FRAME_SKIP, KEY_RPG_SOLID_FONTS, KEY_RPG_PATH_CACHE,
        KEY_RPG_PREBUILT_PATH_CACHE, KEY_RPG_FAST_PATH_ENUM, KEY_RPG_COPY_TEXT,
        KEY_RPG_CHEATS, KEY_RPG_USE_CJK_FONT, KEY_RPG_ENABLE_POSTLOAD_SCRIPTS,
        KEY_RPG_CUSTOM_FONT, KEY_RPG_VERTICAL_SCREEN_ALIGN, KEY_RPG_WINDOW_SIZE,
        KEY_RPG_SPEED_UP, KEY_RPG_FONT_SCALE,
        KEY_SIGLUS_LANGUAGE, KEY_SIGLUS_GRAPHICS,
        KEY_FB_NLS,
        KEY_ETHORNELL_NLS, KEY_ETHORNELL_FONT, KEY_CMVS_FONT,
        KEY_FVP_NLS, KEY_FVP_SYSTEM_FONT, KEY_FVP_TEXT_HIDPI, KEY_FVP_FONT,
        KEY_XSYS35_SCOPED_SAVE_DIR, KEY_XSYS35_RENDERER,
        KEY_XSYS35_INTEGER_SCALE, KEY_XSYS35_MUTE_UNFOCUS,
        KEY_XSYS4_SCOPED_SAVE_DIR, KEY_XSYS4_ENCODING,
        KEY_XSYS4_FONT_GOTHIC_PATH, KEY_XSYS4_FONT_MINCHO_PATH,
        KEY_XSYS4_JOYPAD, KEY_XSYS4_MSGSKIP_DELAY,
        KEY_RUFFLE_SCREEN_TIMEOUT, KEY_RUFFLE_BACKEND, KEY_RUFFLE_QUALITY,
        KEY_RUFFLE_SCALE_MODE, KEY_RUFFLE_LETTERBOX, KEY_RUFFLE_LOAD_BEHAVIOR,
    )
    // Ren'Py 分区：版本选择 + 外置模块配置，显式建模防止未来收紧分区时丢键
    val RENPY_KEYS: Set<String> = setOf(
        KEY_RENPY_VERSION,
        KEY_RENPY_CHEATS, KEY_RENPY_HW_VIDEO, KEY_RENPY_AUTOSAVE,
        KEY_RENPY_PHONE_SMALL_VARIANT, KEY_RENPY_VSYNC, KEY_RENPY_LESS_MEMORY,
        KEY_RENPY_LESS_UPDATES, KEY_RENPY_DONT_USE_GL2, KEY_RENPY_RECOMPILE,
    )
    val TOUCHPAD_KEYS: Set<String> = setOf(TOUCH_PAD_CONFIG_KEY, TOUCH_PAD_PRESETS_KEY)

    /** 整条 blob → 分区行；updatedAt 由调用方给出。 */
    fun split(gameUri: String, blob: JSONObject, updatedAt: Long): GameOverrideEntity {
        val kr = JSONObject()
        val artemis = JSONObject()
        val ons = JSONObject()
        val tyrano = JSONObject()
        val renpy = JSONObject()
        val touchpad = JSONObject()
        for (key in blob.keys()) {
            val value = blob.opt(key) ?: continue
            when {
                key == ONS_OBJECT_KEY -> ons.put(key, value)
                key in TOUCHPAD_KEYS -> touchpad.put(key, value)
                key in KR_KEYS -> kr.put(key, value)
                key in ARTEMIS_KEYS -> artemis.put(key, value)
                key in RENPY_KEYS -> renpy.put(key, value)
                // 未识别键（含未来引擎新增字段）兜底归入 tyrano 分区，保证整条组装不丢字段
                else -> tyrano.put(key, value)
            }
        }
        return GameOverrideEntity(
            gameUri = gameUri,
            krJson = kr.takeIfNotEmpty(),
            artemisJson = artemis.takeIfNotEmpty(),
            onsJson = ons.takeIfNotEmpty(),
            tyranoJson = tyrano.takeIfNotEmpty(),
            renpyJson = renpy.takeIfNotEmpty(),
            touchpadJson = touchpad.takeIfNotEmpty(),
            updatedAt = updatedAt,
        )
    }

    /** 分区行 → 整条 blob（引擎 prefs 镜像的组装来源）；各分区按键扁平并回。 */
    fun assemble(row: GameOverrideEntity): JSONObject {
        val blob = JSONObject()
        for (partition in listOf(row.krJson, row.artemisJson, row.tyranoJson, row.renpyJson, row.onsJson, row.touchpadJson)) {
            mergeFlat(blob, partition)
        }
        return blob
    }

    private fun mergeFlat(blob: JSONObject, json: String?) {
        if (json.isNullOrBlank()) return
        runCatching {
            val partition = JSONObject(json)
            for (key in partition.keys()) blob.put(key, partition.opt(key))
        }
    }

    private fun JSONObject.takeIfNotEmpty(): String? = if (length() == 0) null else toString()
}
