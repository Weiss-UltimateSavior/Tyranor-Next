package com.tyranor.next.core.settings

import android.content.Context
import com.core.engine.EnginePrefs
import com.core.engine.LaunchContract
import com.tyranor.next.core.engine.external.WinlatorContract
import org.json.JSONObject

/**
 * 引擎设置存储层。键名与 RinneMobile 保持一致：
 * - KRKR / Artemis / Tyrano 的全局设置存 tyranor_prefs（原 yukihub_prefs，引擎进程读取同一 prefs）
 * - ONS 设置存 onsyuri 的 gameargs JSON（OnsSettings.load 读取同文件）
 *
 * 设置值经 launcher 在启动时以 Intent extra 注入引擎（KR 走 krkr_engine_prefs 等，
 * 见 EngineLauncher），ONS 则由引擎进程直接读 prefs。
 */
object EngineSettingsStore {

    // 与 CorePreferences 一致的键名（Kr 引擎）
    const val KEY_KR_ENGINE_VERSION = "kr_engine_version"
    const val KEY_KR_ENGINE_KERNEL = "kr_engine_kernel"
    const val KEY_KR_DEFAULT_FONT = "kr_default_font"
    const val KEY_KR_FORCE_DEFAULT_FONT = "kr_force_default_font"
    const val KEY_KR_RENDERER = "kr_renderer"
    const val KEY_KR_SOFTWARE_DRAW_THREAD = "kr_software_draw_thread"
    const val KEY_KR_SOFTWARE_COMPRESS_TEX = "kr_software_compress_tex"
    const val KEY_KR_OGL_COMPRESS_TEX = "kr_ogl_compress_tex"
    const val KEY_KR_MEM_USAGE = "kr_mem_usage"
    const val KEY_KR_OGL_MAX_TEXSIZE = "kr_ogl_max_texsize"
    const val KEY_KR_OGL_ACCURATE_RENDER = "kr_ogl_accurate_render"
    const val KEY_KR_FPS_LIMIT = "kr_fps_limit"
    const val KEY_KR_VCURSOR_SCALE = "kr_vcursor_scale"
    const val KEY_KR_MENU_HANDLER_OPA = "kr_menu_handler_opa"
    const val KEY_KR_SCOPED_SAVE_DIR = "kr_scoped_save_dir"
    const val KEY_KR_PATCH_OVERLAY_MODE = "kr_patch_overlay_mode"
    const val KEY_KR_SKIP_STARTUP_DIALOGS = "kr_skip_startup_dialogs"
    const val KEY_KR_ANIME4K_MODE = "kr_anime4k_mode"

    // Artemis 应用级默认
    const val KEY_ARTEMIS_ENGINE_VERSION = "artemis_engine_version"
    const val KEY_ARTEMIS_KERNEL = "artemis_kernel"
    const val KEY_ARTEMIS_ROTATE_SCREEN = "artemis_rotate_screen"
    const val KEY_ARTEMIS_AUTO_PATCH = "artemis_auto_patch"
    const val KEY_ARTEMIS_RESOLUTION = "artemis_resolution"
    const val KEY_ARTEMIS_SIDE_CUT = "artemis_side_cut"
    const val KEY_ARTEMIS_SURFACE_CACHE_SIZE = "artemis_surface_cache_size"
    const val KEY_ARTEMIS_FONT_CACHE_SIZE = "artemis_font_cache_size"
    const val KEY_ARTEMIS_POWER_SAVING = "artemis_power_saving"
    const val KEY_ARTEMIS_ANIME4K_ENABLED = "artemis_anime4k_enabled"
    const val KEY_ARTEMIS_ANIME4K_MODE = "artemis_anime4k_mode"

    // Ren'Py 应用级默认（外置模块版本选择）
    const val KEY_RENPY_ENGINE_VERSION = "renpy_engine_version"

    // Siglus 应用级默认（游戏语言；引擎启动时经 SIGLUS_LANGUAGE → GET_LANGUAGE 生效）
    const val KEY_SIGLUS_LANGUAGE = "siglus_language"

    // Web 壳本地端口（Tyrano / WebOther / VN；固定端口保证 localStorage/IndexedDB 存档跨启动可见）
    const val KEY_WEB_SHELL_PORT = "web_shell_port"

    // PPSSPP 外置模拟器版本（标准版 / 黄金版；跳转 PSP 游戏时按此选择包名）
    const val KEY_PPSSPP_VERSION = "ppsspp_version"

    // framebuffer 引擎（RealLive / AVG32 / UK2）应用级默认（文本编码）
    const val KEY_FB_NLS = "fb_nls"

    // FVP（rfvp）应用级默认（文本编码 / 系统字体回退 / 文本高分辨率渲染 / 自定义字体）
    const val KEY_FVP_NLS = "fvp_nls"
    const val KEY_ETHORNELL_NLS = "ethornell_nls"
    const val KEY_ETHORNELL_FONT = "ethornell_font"
    const val KEY_FVP_SYSTEM_FONT = "fvp_system_font"
    const val KEY_FVP_TEXT_HIDPI = "fvp_text_hidpi"
    const val KEY_FVP_FONT = "fvp_font"

    // CMVS（cmvs-rs）应用级字体；路径必须位于 App 私有 files/fonts/，face 为字体集合索引
    const val KEY_CMVS_FONT = "cmvs_font"
    const val KEY_CMVS_FACE = "cmvs_font_face"

    // System35（xsystem35）应用级默认（独立存档 / 渲染后端 / 整数倍缩放 / 失焦静音）
    const val KEY_XSYS35_SCOPED_SAVE_DIR = "xsys35_scoped_save_dir"
    const val KEY_XSYS35_RENDERER = "xsys35_renderer"
    const val KEY_XSYS35_INTEGER_SCALE = "xsys35_integer_scale"
    const val KEY_XSYS35_MUTE_UNFOCUS = "xsys35_mute_unfocus"

    // System4（xsystem4）应用级默认（独立存档 / 文本编码 / 自定义字体 / 手柄 / 跳字延迟）
    const val KEY_XSYS4_SCOPED_SAVE_DIR = "xsys4_scoped_save_dir"
    const val KEY_XSYS4_ENCODING = "xsys4_encoding"
    const val KEY_XSYS4_FONT_GOTHIC_PATH = "xsys4_font_gothic_path"
    const val KEY_XSYS4_FONT_MINCHO_PATH = "xsys4_font_mincho_path"
    const val KEY_XSYS4_JOYPAD = "xsys4_joypad"
    const val KEY_XSYS4_MSGSKIP_DELAY = "xsys4_msgskip_delay"

    // Winlator 外置启动（YU-RIS / CatSystem2 / PC 经 Winlator 跳转时的下发参数）
    const val KEY_WINLATOR_CONTAINER_ID = "winlator_container_id"
    const val KEY_WINLATOR_CONTAINER_NAME = "winlator_container_name"
    const val KEY_WINLATOR_GRAPHICS_DRIVER = "winlator_graphics_driver"
    const val KEY_WINLATOR_DXWRAPPER = "winlator_dxwrapper"
    const val KEY_WINLATOR_SCREEN_SIZE = "winlator_screen_size"
    const val KEY_WINLATOR_LC_ALL = "winlator_lc_all"
    const val KEY_WINLATOR_TZ = "winlator_tz"
    const val KEY_WINLATOR_BOX64_PRESET = "winlator_box64_preset"
    const val KEY_WINLATOR_SAVE = "winlator_save"

    // Ren'Py 外置模块（settings extra 的 renpy 节；cheats 发 app 节，键名与 RenPyConfigurationParser 一致）
    const val KEY_RENPY_CHEATS = "renpy_cheats"
    const val KEY_RENPY_HW_VIDEO = "renpy_hw_video"
    const val KEY_RENPY_AUTOSAVE = "renpy_autosave"
    const val KEY_RENPY_PHONE_SMALL_VARIANT = "renpy_phonesmallvariant"
    const val KEY_RENPY_VSYNC = "renpy_vsync"
    const val KEY_RENPY_LESS_MEMORY = "renpy_less_memory"
    const val KEY_RENPY_LESS_UPDATES = "renpy_less_updates"
    const val KEY_RENPY_DONT_USE_GL2 = "renpy_dont_use_gl2"
    const val KEY_RENPY_RECOMPILE = "renpy_recompile"

    // Ruffle 外置模块的 App prefs 键（独立于插件 wire 键：插件 settings 节的键名是 backend/quality/
    // scaleMode/letterbox/loadBehavior 与 app.screenTimeout，由 RuffleExternalEngineModule 组装）
    const val KEY_RUFFLE_SCREEN_TIMEOUT = "ruffle_screen_timeout"
    const val KEY_RUFFLE_BACKEND = "ruffle_backend"
    const val KEY_RUFFLE_QUALITY = "ruffle_quality"
    const val KEY_RUFFLE_SCALE_MODE = "ruffle_scale_mode"
    const val KEY_RUFFLE_LETTERBOX = "ruffle_letterbox"
    const val KEY_RUFFLE_LOAD_BEHAVIOR = "ruffle_load_behavior"

    // Tyrano 与 RPG Maker Web 共用同一套 WebView 宿主设置；启动链路按同一键读取。
    const val KEY_TYRANO_EXTERNAL_NETWORK = "tyrano_external_network"
    const val KEY_TYRANO_SCOPED_SAVE_DIR = "tyrano_scoped_save_dir"
    // 输入重映射全局键（与 engine InputConfigStore 字面量锚定）
    const val KEY_INPUT_PAD_ENABLED = "input_pad_enabled"
    const val KEY_INPUT_GAMEPAD_ENABLED = "input_gamepad_enabled"
    const val KEY_INPUT_PROFILE_ID = "input_profile_id"
    const val KEY_RPG_MAKER_MOD_ENABLED = "rpg_maker_mod_enabled"
    const val KEY_RPG_LEGACY_RENDERER = "rpg_legacy_renderer"
    const val KEY_RPG_SAVE_INTEROP = "rpg_save_interop"
    const val KEY_RPG_MV_ENGINE_VERSION = "rpg_mv_engine_version"
    const val KEY_RPG_MZ_ENGINE_VERSION = "rpg_mz_engine_version"

    // RPG Maker RGSS 外置模块（settings extra 的 rpg 节，键名与 RPGM 插件 MKXPConfigurationParser 一致）
    const val KEY_RPG_USE_RUBY18 = "rpg_use_ruby18"
    const val KEY_RPG_DEBUG = "rpg_debug"
    const val KEY_RPG_SMOOTH_SCALING = "rpg_smooth_scaling"
    const val KEY_RPG_VSYNC = "rpg_vsync"
    const val KEY_RPG_FRAME_SKIP = "rpg_frame_skip"
    const val KEY_RPG_SOLID_FONTS = "rpg_solid_fonts"
    const val KEY_RPG_PATH_CACHE = "rpg_path_cache"
    const val KEY_RPG_PREBUILT_PATH_CACHE = "rpg_prebuilt_path_cache"
    const val KEY_RPG_FAST_PATH_ENUM = "rpg_fast_path_enum"
    const val KEY_RPG_COPY_TEXT = "rpg_copy_text"
    const val KEY_RPG_CHEATS = "rpg_cheats"
    const val KEY_RPG_USE_CJK_FONT = "rpg_use_cjk_font"
    const val KEY_RPG_ENABLE_POSTLOAD_SCRIPTS = "rpg_enable_postload_scripts"
    const val KEY_RPG_CUSTOM_FONT = "rpg_custom_font"
    const val KEY_RPG_VERTICAL_SCREEN_ALIGN = "rpg_vertical_screen_align"
    const val KEY_RPG_WINDOW_SIZE = "rpg_window_size"
    const val KEY_RPG_SPEED_UP = "rpg_speed_up"
    const val KEY_RPG_FONT_SCALE = "rpg_font_scale"

    // 取值常量
    const val KR_AUTO = "auto"
    const val KR_139 = "1.3.9"
    const val KR_134 = "1.3.4"
    const val KERNEL_KIRIKIRI2 = "kirikiri2"
    const val KERNEL_KRKRSDL3 = "krkrsdl3"
    val KR_VERSIONS = setOf(KR_AUTO, KR_139, KR_134)
    val KR_KERNELS = setOf(KR_AUTO, KERNEL_KIRIKIRI2, KERNEL_KRKRSDL3)
    const val KR_PATCH_OVERLAY_AUTO = "auto"
    const val KR_PATCH_OVERLAY_FORCE = "force"
    const val KR_PATCH_OVERLAY_OFF = "off"

    // 历史单模式设置的迁移取值；当前滤镜链的执行能力由原始帧接入门禁决定。
    const val ANIME4K_OFF = "off"
    const val ANIME4K_S = "s"
    const val ANIME4K_M = "m"
    const val ANIME4K_L = "l"
    const val ANIME4K_SOFT_S = "soft_s"
    const val ANIME4K_SOFT_M = "soft_m"
    const val ANIME4K_SOFT_L = "soft_l"
    const val ANIME4K_DEBLUR = "deblur"
    /** Anime4K 模式全量白名单，供单游戏覆盖值校验（非法持久化值回退全局）。 */
    val ANIME4K_MODES = setOf(
        ANIME4K_OFF, ANIME4K_S, ANIME4K_M, ANIME4K_L,
        ANIME4K_SOFT_S, ANIME4K_SOFT_M, ANIME4K_SOFT_L, ANIME4K_DEBLUR,
    )

    /** Artemis 的启用开关独立于模式，模式不接受 off。 */
    const val ART_ANIME4K_DEFAULT = ANIME4K_S
    val ART_ANIME4K_MODES = ANIME4K_MODES - ANIME4K_OFF

    const val RENDERER_SOFTWARE = "software"
    const val RENDERER_OPENGL = "opengl"

    // 写入引擎 XML（GlobalPreference.xml/Kirikiroid2Preference.xml）的 Item 键名。
    // 内核（libgame.so）按 Kirikiroid2 源码 PreferenceConfig.h 中各 tTVPPreferenceInfo*
    // 构造参数的第二项（存储键）读取，并非 locale ID（preference_* 仅为界面文案 id）；
    // 键名不可改。App 侧 prefs 键（kr_*）只是宿主自己的存储键，内核不认识。
    const val ENGINE_RENDERER = "renderer"
    const val ENGINE_SOFTWARE_DRAW_THREAD = "software_draw_thread"
    const val ENGINE_SOFTWARE_COMPRESS_TEX = "software_compress_tex"
    const val ENGINE_OGL_COMPRESS_TEX = "ogl_compress_tex"
    const val ENGINE_MEM_USAGE = "memusage"
    const val ENGINE_OGL_MAX_TEXSIZE = "ogl_max_texsize"
    const val ENGINE_OGL_ACCURATE_RENDER = "ogl_accurate_render"
    const val ENGINE_FPS_LIMIT = "fps_limit"
    const val ENGINE_VCURSOR_SCALE = "vcursor_scale"
    const val ENGINE_MENU_HANDLER_OPA = "menu_handler_opa"
    // 虚拟鼠标缩放比（0.01..1.50，引擎默认 1.00；0.50 与原版 Ty 一致，两位小数）
    val KR_VCURSOR_SCALE_MIN = 0.01f
    val KR_VCURSOR_SCALE_MAX = 1.50f
    val KR_VCURSOR_SCALES: Set<String> = (1..150).map { String.format(java.util.Locale.US, "%.2f", it / 100.0) }.toSet()
    // 菜单按钮不透明度（1..100，引擎默认 100；滚动条 1..100 全可选）
    val KR_MENU_HANDLER_OPA_RANGE = 1..100
    val KR_MENU_HANDLER_OPAS: Set<String> = KR_MENU_HANDLER_OPA_RANGE.map { it.toString() }.toSet()
    const val MEM_USAGE_UNLIMITED = "unlimited"
    const val MEM_USAGE_HIGH = "high"
    const val MEM_USAGE_MEDIUM = "medium"
    const val MEM_USAGE_LOW = "low"

    const val ART_ENGINE_AUTO = "auto"
    const val ART_ENGINE_V1 = "1"
    const val ART_ENGINE_V2 = "2"
    const val ART_ENGINE_V6 = "6"
    /** Artemis 内核：官方多 revision 运行库 / 自研 clean-room 兼容内核。 */
    const val ART_KERNEL_OFFICIAL = "official"
    const val ART_KERNEL_CLEAN = "clean"
    val ART_KERNELS = setOf(ART_KERNEL_OFFICIAL, ART_KERNEL_CLEAN)
    const val AUTO_PATCH_ASK = "ask"
    const val AUTO_PATCH_AUTO = "auto"
    const val AUTO_PATCH_OFF = "off"
    /** 补丁策略默认值：关闭（不询问、不自动补丁；用户可在引擎设置/单游戏覆盖中改为询问或自动）。 */
    const val ART_PATCH_DEFAULT = AUTO_PATCH_OFF
    /** Artemis 引擎版本全量白名单，供单游戏覆盖值校验（非法持久化值回退全局）。 */
    val ART_VERSIONS = setOf(ART_ENGINE_AUTO, ART_ENGINE_V1, ART_ENGINE_V2, ART_ENGINE_V6)
    /** Artemis 补丁策略全量白名单，供单游戏覆盖值校验（非法持久化值回退全局）。 */
    val ART_PATCHES = setOf(AUTO_PATCH_ASK, AUTO_PATCH_AUTO, AUTO_PATCH_OFF)
    const val ART_RESOLUTION_DEFAULT = ""
    const val ART_RESOLUTION_1920_1080 = "1920x1080"
    const val ART_RESOLUTION_1280_720 = "1280x720"
    const val ART_RESOLUTION_960_540 = "960x540"
    const val ART_TOGGLE_DEFAULT = ""
    const val ART_TOGGLE_OFF = "0"
    const val ART_TOGGLE_ON = "1"
    const val ART_CACHE_DEFAULT = ""
    const val ART_SURFACE_CACHE_64MB = "67108864"
    const val ART_SURFACE_CACHE_128MB = "134217728"
    const val ART_SURFACE_CACHE_256MB = "268435456"
    const val ART_FONT_CACHE_8MB = "8388608"
    const val ART_FONT_CACHE_16MB = "16777216"
    const val ART_FONT_CACHE_32MB = "33554432"
    const val ART_FONT_CACHE_64MB = "67108864"
    val ART_RESOLUTIONS = setOf(
        ART_RESOLUTION_DEFAULT,
        ART_RESOLUTION_1920_1080,
        ART_RESOLUTION_1280_720,
        ART_RESOLUTION_960_540,
    )
    val ART_TOGGLES = setOf(ART_TOGGLE_DEFAULT, ART_TOGGLE_OFF, ART_TOGGLE_ON)
    val ART_SURFACE_CACHES = setOf(
        ART_CACHE_DEFAULT,
        ART_SURFACE_CACHE_64MB,
        ART_SURFACE_CACHE_128MB,
        ART_SURFACE_CACHE_256MB,
    )
    val ART_FONT_CACHES = setOf(
        ART_CACHE_DEFAULT,
        ART_FONT_CACHE_8MB,
        ART_FONT_CACHE_16MB,
        ART_FONT_CACHE_32MB,
        ART_FONT_CACHE_64MB,
    )

    const val RPG_MV_V0 = "v0"
    const val RPG_MZ_V0 = "v0"
    const val RPG_MV_V1 = "v1"
    const val RPG_MZ_V1 = "v1"
    const val RPG_MV_V2 = "v2"
    const val RPG_MZ_V2 = "v2"
    // 与 PerGameSettingsStore.F_RPG_* 同名，分属不同 prefs 文件（yukihub_prefs vs tyranor_game_overrides）
    // Ren'Py 版本取值常量
    const val RENPY_AUTO = "auto"
    const val RENPY_85 = "8.5"
    const val RENPY_77 = "7.7.1"

    // Ruffle 外置模块取值域（对齐插件 RuffleConfiguration 的默认值）
    const val RUFFLE_SCREEN_TIMEOUT_DEFAULT = 0
    const val RUFFLE_BACKEND_OPENGL = "opengl"
    const val RUFFLE_QUALITY_HIGH = "high"
    const val RUFFLE_SCALE_MODE_SHOW_ALL = "showall"
    const val RUFFLE_LETTERBOX_ON = "on"
    const val RUFFLE_LOAD_BEHAVIOR_STREAMING = "streaming"
    val RUFFLE_SCREEN_TIMEOUTS: Set<Int> = linkedSetOf(0, 5, 10, 15, 30, 45, 60)
    val RUFFLE_BACKENDS: Set<String> = linkedSetOf("auto", RUFFLE_BACKEND_OPENGL, "vulkan")
    val RUFFLE_QUALITIES: Set<String> = linkedSetOf("low", "medium", RUFFLE_QUALITY_HIGH, "best")
    val RUFFLE_SCALE_MODES: Set<String> = linkedSetOf("exactfit", "noborder", "noscale", RUFFLE_SCALE_MODE_SHOW_ALL)
    val RUFFLE_LETTERBOXES: Set<String> = linkedSetOf(RUFFLE_LETTERBOX_ON, "off")
    val RUFFLE_LOAD_BEHAVIORS: Set<String> = linkedSetOf(RUFFLE_LOAD_BEHAVIOR_STREAMING, "delayed", "blocking")

    // Siglus 语言取值常量（auto 不设置 SIGLUS_LANGUAGE，保持引擎默认 JP）
    const val SIGLUS_LANGUAGE_AUTO = "auto"
    const val SIGLUS_LANGUAGE_JP = "JP"
    const val SIGLUS_LANGUAGE_EN = "EN"
    const val SIGLUS_LANGUAGE_ZH = "ZH"
    const val SIGLUS_LANGUAGE_ZHTW = "ZHTW"
    const val SIGLUS_LANGUAGE_DE = "DE"
    const val SIGLUS_LANGUAGE_ES = "ES"
    const val SIGLUS_LANGUAGE_FR = "FR"
    const val SIGLUS_LANGUAGE_ID = "ID"
    val SIGLUS_LANGUAGES: Set<String> = linkedSetOf(
        SIGLUS_LANGUAGE_AUTO,
        SIGLUS_LANGUAGE_JP,
        SIGLUS_LANGUAGE_EN,
        SIGLUS_LANGUAGE_ZH,
        SIGLUS_LANGUAGE_ZHTW,
        SIGLUS_LANGUAGE_DE,
        SIGLUS_LANGUAGE_ES,
        SIGLUS_LANGUAGE_FR,
        SIGLUS_LANGUAGE_ID,
    )

    // PPSSPP 外置模拟器版本取值（standard=org.ppsspp.ppsspp，gold=org.ppsspp.ppssppgold）
    const val PPSSPP_VERSION_STANDARD = "standard"
    const val PPSSPP_VERSION_GOLD = "gold"
    val PPSSPP_VERSIONS: Set<String> = linkedSetOf(PPSSPP_VERSION_STANDARD, PPSSPP_VERSION_GOLD)

    // framebuffer 引擎文本编码取值（创建引擎时固定，改动后需重启本局）
    const val FB_NLS_AUTO = "auto"
    const val FB_NLS_SJIS = "sjis"
    const val FB_NLS_GBK = "gbk"
    const val FB_NLS_BIG5 = "big5"
    const val FB_NLS_UTF8 = "utf8"
    const val FB_NLS_KOREAN = "korean"
    val FB_NLS_VALUES: Set<String> = linkedSetOf(
        FB_NLS_AUTO,
        FB_NLS_SJIS,
        FB_NLS_GBK,
        FB_NLS_BIG5,
        FB_NLS_UTF8,
        FB_NLS_KOREAN,
    )

    // FVP 文本编码取值（创建引擎时固定，改动后需重启本局）
    const val FVP_NLS_SJIS = "sjis"
    const val ETHORNELL_NLS_SJIS = "sjis"
    const val ETHORNELL_NLS_GBK = "gbk"
    val ETHORNELL_NLS_VALUES: Set<String> = linkedSetOf(ETHORNELL_NLS_SJIS, ETHORNELL_NLS_GBK)
    const val FVP_NLS_GBK = "gbk"
    const val FVP_NLS_UTF8 = "utf8"
    val FVP_NLS_VALUES: Set<String> = linkedSetOf(
        FVP_NLS_SJIS,
        FVP_NLS_GBK,
        FVP_NLS_UTF8,
    )

    // System35 渲染后端取值（auto 不传 -renderer，交由 SDL 自动探测；opengl = GLES2，software 兜底）
    const val XSYS35_RENDERER_AUTO = "auto"
    const val XSYS35_RENDERER_OPENGL = "opengl"
    const val XSYS35_RENDERER_SOFTWARE = "software"
    val XSYS35_RENDERER_VALUES: Set<String> = linkedSetOf(
        XSYS35_RENDERER_AUTO,
        XSYS35_RENDERER_OPENGL,
        XSYS35_RENDERER_SOFTWARE,
    )

    // System4 文本编码（sjis = 日文版默认，gbk = 中文版）
    const val XSYS4_ENCODING_SJIS = "sjis"
    const val XSYS4_ENCODING_GBK = "gbk"
    val XSYS4_ENCODING_VALUES: Set<String> = linkedSetOf(XSYS4_ENCODING_SJIS, XSYS4_ENCODING_GBK)

    // System4 手柄取值（auto 不传 --joypad，交由引擎默认）
    const val XSYS4_JOYPAD_AUTO = "auto"
    const val XSYS4_JOYPAD_ON = "on"
    const val XSYS4_JOYPAD_OFF = "off"
    val XSYS4_JOYPAD_VALUES: Set<String> = linkedSetOf(XSYS4_JOYPAD_AUTO, XSYS4_JOYPAD_ON, XSYS4_JOYPAD_OFF)

    // System4 跳字延迟预设（毫秒；0 = 引擎默认，不传 --msgskip-delay）
    const val XSYS4_MSGSKIP_DELAY_DEFAULT = 0
    val XSYS4_MSGSKIP_DELAY_VALUES: Set<Int> = linkedSetOf(0, 100, 200, 400)

    // Winlator 外置启动取值域（空串 = 不下发该参数，跟随容器/快捷方式配置）
    /**
     * 图形驱动固定组合：Vulkan 驱动（Turnip/Vortek）× OpenGL 驱动（Zink/VirGL/Gladio），
     * 对齐 Winlator 容器设置里的两项下拉，组合为 `vulkan,opengl` 下发。
     */
    val WINLATOR_GRAPHICS_DRIVERS: List<String> = listOf(
        "turnip,zink",
        "turnip,virgl",
        "turnip,gladio",
        "vortek,zink",
        "vortek,virgl",
        "vortek,gladio",
    )

    val WINLATOR_DXWRAPPERS: Set<String> = linkedSetOf(
        "", "dxvk", "wined3d",
        WinlatorContract.DXWRAPPER_WINED3D_GL,
        WinlatorContract.DXWRAPPER_WINED3D_GDI,
    )

    val WINLATOR_BOX64_PRESETS: Set<String> = linkedSetOf(
        "",
        "STABILITY",
        "CONSERVATIVE",
        "INTERMEDIATE",
        "PERFORMANCE",
    )

    /** 分辨率固定档位（无自定义输入；空串 = 跟随容器配置，其余须命中此白名单）。 */
    val WINLATOR_SCREEN_SIZES: List<String> = listOf(
        "640x360",
        "640x480",
        "800x600",
        "854x480",
        "960x544",
        "1024x768",
        "1280x720",
        "1280x800",
        "1280x1024",
        "1366x768",
        "1440x900",
        "1600x900",
        "1920x1080",
    )

    /** 语言环境（LC_ALL）固定档位（winlator-cn 校验正则内的常用取值）。 */
    val WINLATOR_LOCALES: List<String> = listOf(
        "ja_JP.UTF-8",
        "zh_CN.utf8",
        "zh_TW.utf8",
        "en_US.UTF-8",
        "ko_KR.UTF-8",
    )

    /** 时区（TZ）固定档位（winlator-cn 校验正则内的常用取值）。 */
    val WINLATOR_TIMEZONES: List<String> = listOf(
        "Asia/Tokyo",
        "Asia/Shanghai",
        "Asia/Taipei",
        "Asia/Seoul",
        "UTC",
        "Europe/London",
        "America/New_York",
    )

    /** winlator-cn `Box64Preset.CUSTOM` 形态（用户自定义预设，仅回读校验用）。 */
    private val WINLATOR_BOX64_CUSTOM_PATTERN = Regex("^CUSTOM-\\d+$")

    /** 被删实现遗留的 Winlator prefs 键（一次性清理；不含当前实现使用的键）。 */
    private val WINLATOR_LEGACY_KEYS = listOf(
        "winlator_locale",
        "winlator_dx_accel",
        "winlator_hud_mode",
        "winlator_debug_logs",
        "winlator_controls_profile",
        "winlator_box",
        "winlator_turnip_version",
        "winlator_turnip_memory",
        "winlator_turnip_present_mode",
        "winlator_turnip_direct_rendering",
        "winlator_vortek_memory",
        "winlator_vortek_image_cache",
        "winlator_vortek_resource_memory",
        "winlator_virgl_gl_version",
        "winlator_virgl_vertex_bgra",
        // 与当前实现同名的三个键：被删实现写入过非默认值（如 graphics=vortek,zink、
        // box64=PERFORMANCE、screen=auto），一并清回默认「跟随容器配置」。
        KEY_WINLATOR_GRAPHICS_DRIVER,
        KEY_WINLATOR_SCREEN_SIZE,
        KEY_WINLATOR_BOX64_PRESET,
        // 已下线的「追加启动参数」遗留键（当前实现不再读写）。
        "winlator_exec_args",
    )
    private const val KEY_WINLATOR_LEGACY_CLEANED = "winlator_legacy_clean_version"
    private const val WINLATOR_LEGACY_CLEAN_VERSION = 3

    // RPG Maker RGSS 外置模块取值域（对齐 JoiPlay utilities/f.java；verticalAlign 对齐插件默认）
    const val RPG_WINDOW_SIZE_DEFAULT = "640x480"
    const val RPG_SPEED_UP_DEFAULT = "1"
    const val RPG_FONT_SCALE_DEFAULT = "0.75"
    const val RPG_VERTICAL_ALIGN_DEFAULT = "top-center"
    val RPG_WINDOW_SIZES: Set<String> = linkedSetOf(
        "512x384", "512x768", "544x416", "640x480", "800x600",
        "1024x768", "1280x720", "1280x960", "1920x1080",
    )
    val RPG_SPEED_UPS: Set<String> = (1..9).map { it.toString() }.toSet()
    val RPG_FONT_SCALES: Set<String> =
        setOf("0.25", "0.50", "0.75", "1.00", "1.25", "1.50", "1.75", "2.00")
    val RPG_VERTICAL_ALIGNS: Set<String> = setOf("top", "top-center", "center")

    /** KR 渲染/内存偏好字段清单（由 [KrRenderPrefs] 派生，保证与单游戏覆盖字段一一对应）。 */
    val KR_RENDER_PREF_KEYS: List<String> = KrRenderPrefs.ALL.map { it.globalKey }

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(EnginePrefs.APP_PREFS, Context.MODE_PRIVATE)

    private fun onsPrefs(context: Context) =
        context.applicationContext.getSharedPreferences("onsyuri", Context.MODE_PRIVATE)

    // ---------- KRKR ----------
    fun getKrEngineVersion(c: Context): String =
        normalizeKr(prefs(c).getString(KEY_KR_ENGINE_VERSION, KR_AUTO))
    fun setKrEngineVersion(c: Context, v: String) =
        prefs(c).edit().putString(KEY_KR_ENGINE_VERSION, normalizeKr(v)).apply()

    fun getKrKernel(c: Context): String {
        val v = prefs(c).getString(KEY_KR_ENGINE_KERNEL, KR_AUTO)
        return when (v) { KERNEL_KIRIKIRI2, KERNEL_KRKRSDL3 -> v; else -> KR_AUTO }
    }
    fun setKrKernel(c: Context, v: String) = prefs(c).edit().putString(KEY_KR_ENGINE_KERNEL, v).apply()

    fun isKrScopedSaveDir(c: Context): Boolean =
        prefs(c).getBoolean(KEY_KR_SCOPED_SAVE_DIR, true)
    fun setKrScopedSaveDir(c: Context, b: Boolean) =
        prefs(c).edit().putBoolean(KEY_KR_SCOPED_SAVE_DIR, b).apply()

    fun getKrPatchOverlayMode(c: Context): String =
        normalizeKrPatchOverlayMode(prefs(c).getString(KEY_KR_PATCH_OVERLAY_MODE, KR_PATCH_OVERLAY_AUTO))
    fun setKrPatchOverlayMode(c: Context, v: String) =
        prefs(c).edit().putString(KEY_KR_PATCH_OVERLAY_MODE, normalizeKrPatchOverlayMode(v)).apply()

    /** Automatically confirm one-button KRKR information dialogs during the first 30 seconds. */
    fun isKrSkipStartupDialogs(c: Context): Boolean =
        prefs(c).getBoolean(KEY_KR_SKIP_STARTUP_DIALOGS, false)

    fun setKrSkipStartupDialogs(c: Context, enabled: Boolean) =
        prefs(c).edit().putBoolean(KEY_KR_SKIP_STARTUP_DIALOGS, enabled).apply()

    fun getKrDefaultFont(c: Context): String = prefs(c).getString(KEY_KR_DEFAULT_FONT, "").orEmpty()
    fun setKrDefaultFont(c: Context, p: String) = prefs(c).edit().putString(KEY_KR_DEFAULT_FONT, p.trim()).apply()

    fun isKrForceDefaultFont(c: Context): Boolean = prefs(c).getBoolean(KEY_KR_FORCE_DEFAULT_FONT, false)
    fun setKrForceDefaultFont(c: Context, b: Boolean) = prefs(c).edit().putBoolean(KEY_KR_FORCE_DEFAULT_FONT, b).apply()

    private fun krPref(c: Context, key: String): String = prefs(c).getString(key, null).orEmpty()
    private fun setKrPref(c: Context, key: String, v: String?) = prefs(c).edit().putString(key, v?.trim().orEmpty()).apply()

    fun getKrRenderer(c: Context): String = if (krPref(c, KEY_KR_RENDERER) in setOf(RENDERER_SOFTWARE, RENDERER_OPENGL)) krPref(c, KEY_KR_RENDERER) else ""
    fun setKrRenderer(c: Context, v: String) = setKrPref(c, KEY_KR_RENDERER, v)
    fun getKrSoftwareDrawThread(c: Context): String { val n = krPref(c, KEY_KR_SOFTWARE_DRAW_THREAD).toIntOrNull() ?: return ""; return if (n in 0..8) n.toString() else "" }
    fun setKrSoftwareDrawThread(c: Context, v: String) = setKrPref(c, KEY_KR_SOFTWARE_DRAW_THREAD, v)
    fun getKrSoftwareCompressTex(c: Context): String { val v = krPref(c, KEY_KR_SOFTWARE_COMPRESS_TEX); return if (v in setOf("none", "halfline", "lz4", "lz4+tlg5")) v else "" }
    fun setKrSoftwareCompressTex(c: Context, v: String) = setKrPref(c, KEY_KR_SOFTWARE_COMPRESS_TEX, v)
    fun getKrOglCompressTex(c: Context): String { val v = krPref(c, KEY_KR_OGL_COMPRESS_TEX); return if (v in setOf("none", "half", "etc2", "pvrtc")) v else "" }
    fun setKrOglCompressTex(c: Context, v: String) = setKrPref(c, KEY_KR_OGL_COMPRESS_TEX, v)
    fun getKrMemUsage(c: Context): String { val v = krPref(c, KEY_KR_MEM_USAGE); return if (v in setOf(MEM_USAGE_UNLIMITED, MEM_USAGE_HIGH, MEM_USAGE_MEDIUM, MEM_USAGE_LOW)) v else "" }
    fun setKrMemUsage(c: Context, v: String) = setKrPref(c, KEY_KR_MEM_USAGE, v)
    fun getKrOglMaxTexsize(c: Context): String { val n = krPref(c, KEY_KR_OGL_MAX_TEXSIZE).toIntOrNull() ?: return ""; return if (n == 0 || n in 1024..16384) n.toString() else "" }
    fun setKrOglMaxTexsize(c: Context, v: String) = setKrPref(c, KEY_KR_OGL_MAX_TEXSIZE, v)
    fun getKrOglAccurateRender(c: Context): String = when (krPref(c, KEY_KR_OGL_ACCURATE_RENDER)) { "1", "true" -> "1"; "0", "false" -> "0"; else -> "" }
    fun setKrOglAccurateRender(c: Context, v: String) = setKrPref(c, KEY_KR_OGL_ACCURATE_RENDER, v)
    fun getKrFpsLimit(c: Context): String { val v = krPref(c, KEY_KR_FPS_LIMIT); return if (v in setOf("60", "45", "30", "15")) v else "" }
    fun setKrFpsLimit(c: Context, v: String) = setKrPref(c, KEY_KR_FPS_LIMIT, v)
    fun getKrVCursorScale(c: Context): String {
        val v = krPref(c, KEY_KR_VCURSOR_SCALE).trim()
        if (v.isEmpty()) return ""
        // 兼容旧版整型百分比 1..150（如 "50" → "0.50"）
        normalizeVcursorScale(v)?.let { return it }
        return ""
    }
    fun setKrVCursorScale(c: Context, v: String) {
        val t = v.trim()
        if (t.isEmpty()) { setKrPref(c, KEY_KR_VCURSOR_SCALE, ""); return }
        normalizeVcursorScale(t)?.let { setKrPref(c, KEY_KR_VCURSOR_SCALE, it) }
    }

    fun normalizeVcursorScale(raw: String): String? {
        val t = raw.trim()
        if (t.isEmpty()) return null
        if (t in KR_VCURSOR_SCALES) return t
        // 旧整型百分比兼容： "50" → "0.50"
        t.toIntOrNull()?.let { iv ->
            if (iv in 1..150) return String.format(java.util.Locale.US, "%.2f", iv / 100.0)
        }
        // 单小数位等宽容： "0.5" → "0.50"，"1" → "1.00"
        val f = t.toFloatOrNull() ?: return null
        if (f < KR_VCURSOR_SCALE_MIN - 1e-6 || f > KR_VCURSOR_SCALE_MAX + 1e-6) return null
        // 四舍五入到两位小数
        val rounded = Math.round(f * 100) / 100.0
        val formatted = String.format(java.util.Locale.US, "%.2f", rounded)
        return if (formatted in KR_VCURSOR_SCALES) formatted else null
    }

    /** 供 PerGameSettingsScreen 等对旧整型/单小数位做展示归一，空串保持空 */
    fun normalizeVcursorScaleForDisplay(raw: String?): String? {
        if (raw == null) return null
        val t = raw.trim()
        if (t.isEmpty()) return null
        return normalizeVcursorScale(t) ?: t
    }
    fun getKrMenuHandlerOpa(c: Context): String { val v = krPref(c, KEY_KR_MENU_HANDLER_OPA).trim(); return if (v in KR_MENU_HANDLER_OPAS) v else "" }
    fun setKrMenuHandlerOpa(c: Context, v: String) { val t = v.trim(); if (t.isEmpty() || t in KR_MENU_HANDLER_OPAS) setKrPref(c, KEY_KR_MENU_HANDLER_OPA, t) }

    /** 组装 krkr_engine_prefs JSON：{<引擎键>:{v, s}}。overrideGetter 返回某偏好的单游戏覆盖（null=跟随全局）。 */
    fun buildKrEnginePrefsJson(c: Context, overrideGetter: (KrRenderPref) -> String? = { null }): String {
        val json = JSONObject()
        KrRenderPrefs.ALL.forEach { pref ->
            val key = pref.globalKey
            val rawOverride = overrideGetter(pref)
            val override = rawOverride?.trim()?.takeIf { it.isNotEmpty() || rawOverride == "" }
            // 仅保留合法值或显式空串（引擎默认），非法值按跟随全局处理；vcursor 支持旧整型兼容
            val sanitizedOverride = when (key) {
                KEY_KR_VCURSOR_SCALE -> override?.let {
                    if (it.isEmpty()) it else normalizeVcursorScale(it)
                }
                KEY_KR_MENU_HANDLER_OPA -> override?.let { if (it.isEmpty() || it in KR_MENU_HANDLER_OPAS) it else null }
                // 布尔开关没有「引擎默认」语义：存量 "" 是旧版「跟随全局」的写法，按 null
                // （跟随全局）处理，避免游戏级空值删项压过全局 XML 的当前值（PR #155 审查）
                KEY_KR_OGL_ACCURATE_RENDER -> override?.takeIf { it.isNotEmpty() }
                else -> override
            }
            val globalRaw = prefs(c).getString(key, null).orEmpty().trim()
            val normalizedGlobal = normalizeVcursorScale(globalRaw)
            val sanitizedGlobal = when (key) {
                KEY_KR_VCURSOR_SCALE -> when {
                    globalRaw.isEmpty() -> ""
                    normalizedGlobal != null -> normalizedGlobal
                    else -> ""
                }
                KEY_KR_MENU_HANDLER_OPA -> if (globalRaw in KR_MENU_HANDLER_OPAS) globalRaw else ""
                else -> prefs(c).getString(key, null).orEmpty()
            }
            val rawValue = sanitizedOverride ?: sanitizedGlobal
            // 虚拟鼠标：prefs 存 "0.01".."1.50"（两位小数），引擎需浮点字符串，去尾零与 Ty 一致
            val value = when (key) {
                KEY_KR_VCURSOR_SCALE -> if (rawValue.isEmpty()) "" else {
                    // 已是两位小数格式，去尾零后与原版 Ty 的 "0.5" 等价
                    rawValue.trimEnd('0').trimEnd('.').ifEmpty { rawValue }
                }
                else -> rawValue
            }
            json.put(pref.engineKey, JSONObject().put("v", value).put("s", if (sanitizedOverride != null) "game" else "global"))
        }
        return json.toString()
    }

    private fun normalizeKr(v: String?): String = when (v?.trim()?.lowercase()) {
        KR_139 -> KR_139
        KR_134 -> KR_134
        else -> KR_AUTO
    }

    fun normalizeKrPatchOverlayMode(v: String?): String = when (v?.trim()?.lowercase()) {
        KR_PATCH_OVERLAY_FORCE -> KR_PATCH_OVERLAY_FORCE
        KR_PATCH_OVERLAY_OFF -> KR_PATCH_OVERLAY_OFF
        else -> KR_PATCH_OVERLAY_AUTO
    }

    // ---------- ONS（存 onsyuri/gameargs JSON，引擎进程 OnsSettings.load 直接读） ----------
    data class Ons(
        var scopedSaveDir: Boolean = true,
        var stretchFull: Boolean = false,
        var ignoreCutout: Boolean = true,
        var disableVideo: Boolean = false,
        var sharpness: Boolean = false,
        var sharpnessValue: String = "2",
        var encoding: String = "gbk",
    ) {
        fun toJson(): String =
            JSONObject()
                .put("scopedsavedir", scopedSaveDir)
                .put("strechfull", stretchFull)
                .put("ignorecutout", ignoreCutout)
                .put("disablevideo", disableVideo)
                .put("sharpness", sharpness)
                .put("sharpness_value", sharpnessValue)
                .put("encoding", normalizeEncoding(encoding))
                .toString()
    }

    fun loadOns(c: Context): Ons {
        val o = Ons()
        try {
            val json = onsPrefs(c).getString("gameargs", null) ?: return o
            val j = JSONObject(json)
            o.scopedSaveDir = j.optBoolean("scopedsavedir", o.scopedSaveDir)
            o.stretchFull = j.optBoolean("strechfull", o.stretchFull)
            o.ignoreCutout = j.optBoolean("ignorecutout", o.ignoreCutout)
            o.disableVideo = j.optBoolean("disablevideo", o.disableVideo)
            o.sharpness = j.optBoolean("sharpness", o.sharpness)
            o.sharpnessValue = j.optString("sharpness_value", o.sharpnessValue)
            o.encoding = normalizeEncoding(j.optString("encoding", o.encoding))
        } catch (t: Throwable) {
            // 解析失败用默认值
        }
        return o
    }

    fun saveOns(c: Context, o: Ons) = onsPrefs(c).edit().putString("gameargs", o.toJson()).apply()

    fun normalizeEncoding(v: String): String = when (v.trim().lowercase()) {
        "utf8", "utf-8" -> "utf8"
        "sjis", "shift-jis", "shift_jis" -> "sjis"
        else -> "gbk"
    }

    // ---------- Artemis ----------
    fun getArtEngineVersion(c: Context): String {
        val v = prefs(c).getString(KEY_ARTEMIS_ENGINE_VERSION, ART_ENGINE_AUTO)
        return if (
            v == ART_ENGINE_V1 ||
            v == ART_ENGINE_V2 ||
            v == ART_ENGINE_V6
        ) v else ART_ENGINE_AUTO
    }
    fun setArtEngineVersion(c: Context, v: String) = prefs(c).edit().putString(KEY_ARTEMIS_ENGINE_VERSION, v).apply()
    fun getArtKernel(c: Context): String = normalizeArtKernel(prefs(c).getString(KEY_ARTEMIS_KERNEL, ART_KERNEL_OFFICIAL))
    fun setArtKernel(c: Context, v: String) = prefs(c).edit().putString(KEY_ARTEMIS_KERNEL, normalizeArtKernel(v)).apply()
    fun normalizeArtKernel(v: String?): String =
        if (v?.trim() == ART_KERNEL_CLEAN) ART_KERNEL_CLEAN else ART_KERNEL_OFFICIAL
    fun isArtRotateScreen(c: Context): Boolean = prefs(c).getBoolean(KEY_ARTEMIS_ROTATE_SCREEN, false)
    fun setArtRotateScreen(c: Context, b: Boolean) = prefs(c).edit().putBoolean(KEY_ARTEMIS_ROTATE_SCREEN, b).apply()
    fun getArtAutoPatch(c: Context): String {
        val v = prefs(c).getString(KEY_ARTEMIS_AUTO_PATCH, ART_PATCH_DEFAULT)?.trim()
        return if (v != null && v in ART_PATCHES) v else ART_PATCH_DEFAULT
    }
    fun setArtAutoPatch(c: Context, v: String) = prefs(c).edit().putString(KEY_ARTEMIS_AUTO_PATCH, v).apply()
    fun getArtResolution(c: Context): String = artStringPref(c, KEY_ARTEMIS_RESOLUTION, ART_RESOLUTIONS)
    fun setArtResolution(c: Context, v: String) = setArtStringPref(c, KEY_ARTEMIS_RESOLUTION, v, ART_RESOLUTIONS)
    fun getArtSideCut(c: Context): String = artStringPref(c, KEY_ARTEMIS_SIDE_CUT, ART_TOGGLES)
    fun setArtSideCut(c: Context, v: String) = setArtStringPref(c, KEY_ARTEMIS_SIDE_CUT, v, ART_TOGGLES)
    fun getArtSurfaceCacheSize(c: Context): String = artStringPref(c, KEY_ARTEMIS_SURFACE_CACHE_SIZE, ART_SURFACE_CACHES)
    fun setArtSurfaceCacheSize(c: Context, v: String) = setArtStringPref(c, KEY_ARTEMIS_SURFACE_CACHE_SIZE, v, ART_SURFACE_CACHES)
    fun getArtFontCacheSize(c: Context): String = artStringPref(c, KEY_ARTEMIS_FONT_CACHE_SIZE, ART_FONT_CACHES)
    fun setArtFontCacheSize(c: Context, v: String) = setArtStringPref(c, KEY_ARTEMIS_FONT_CACHE_SIZE, v, ART_FONT_CACHES)
    fun getArtPowerSaving(c: Context): String = artStringPref(c, KEY_ARTEMIS_POWER_SAVING, ART_TOGGLES)
    fun setArtPowerSaving(c: Context, v: String) = setArtStringPref(c, KEY_ARTEMIS_POWER_SAVING, v, ART_TOGGLES)


    fun normalizeArtAnime4kMode(mode: String?): String =
        mode?.trim()?.takeIf { it in ART_ANIME4K_MODES } ?: ART_ANIME4K_DEFAULT

    private fun artStringPref(c: Context, key: String, allowed: Set<String>): String {
        val value = prefs(c).getString(key, ART_CACHE_DEFAULT).orEmpty().trim()
        return if (value in allowed) value else ART_CACHE_DEFAULT
    }

    private fun setArtStringPref(c: Context, key: String, value: String, allowed: Set<String>) {
        val normalized = value.trim().takeIf { it in allowed } ?: ART_CACHE_DEFAULT
        prefs(c).edit().putString(key, normalized).apply()
    }

    // ---------- Ren'Py ----------
    fun getRenpyVersion(c: Context): String {
        val v = prefs(c).getString(KEY_RENPY_ENGINE_VERSION, RENPY_AUTO)
        return when (v) {
            RENPY_85, RENPY_77 -> v
            else -> RENPY_AUTO
        }
    }
    fun setRenpyVersion(c: Context, v: String) = prefs(c).edit().putString(KEY_RENPY_ENGINE_VERSION, v).apply()

    /** Capture new marker and legacy fields atomically from one SharedPreferences snapshot. */
    fun getGraphicsSettings(c: Context, family: GraphicsFamily): GraphicsSettings =
        GraphicsSettingsCodec.readGlobal(prefs(c).all, family)

    fun setGraphicsSettings(c: Context, family: GraphicsFamily, settings: GraphicsSettings) =
        prefs(c).edit().putString(family.preferenceKey, GraphicsSettingsCodec.encode(settings)).apply()

    // ---------- Siglus ----------
    fun getSiglusLanguage(c: Context): String =
        normalizeSiglusLanguage(prefs(c).getString(KEY_SIGLUS_LANGUAGE, SIGLUS_LANGUAGE_AUTO))
    fun setSiglusLanguage(c: Context, v: String) =
        prefs(c).edit().putString(KEY_SIGLUS_LANGUAGE, normalizeSiglusLanguage(v)).apply()
    fun normalizeSiglusLanguage(v: String?): String =
        v?.trim()?.takeIf { it in SIGLUS_LANGUAGES } ?: SIGLUS_LANGUAGE_AUTO

    // ---------- Web 壳（Tyrano / WebOther / VN） ----------
    fun getWebShellPort(c: Context): Int =
        normalizeWebShellPort(prefs(c).getString(KEY_WEB_SHELL_PORT, null))
    fun setWebShellPort(c: Context, v: Int) =
        prefs(c).edit().putString(KEY_WEB_SHELL_PORT, normalizeWebShellPort(v.toString()).toString()).apply()

    /** 归一：1..65535 合法，其余（含空/0/越界/非数字）回退 [LaunchContract.WEB_SHELL_PORT_DEFAULT]。 */
    fun normalizeWebShellPort(v: String?): Int {
        val parsed = v?.trim()?.toIntOrNull() ?: return LaunchContract.WEB_SHELL_PORT_DEFAULT
        return parsed.takeIf { it in 1..65535 } ?: LaunchContract.WEB_SHELL_PORT_DEFAULT
    }

    // ---------- PPSSPP 外置模拟器 ----------
    fun getPpssppVersion(c: Context): String =
        normalizePpssppVersion(prefs(c).getString(KEY_PPSSPP_VERSION, PPSSPP_VERSION_STANDARD))
    fun setPpssppVersion(c: Context, v: String) =
        prefs(c).edit().putString(KEY_PPSSPP_VERSION, normalizePpssppVersion(v)).apply()
    fun normalizePpssppVersion(v: String?): String =
        v?.trim()?.lowercase()?.takeIf { it in PPSSPP_VERSIONS } ?: PPSSPP_VERSION_STANDARD

    // ---------- framebuffer 引擎（RealLive / AVG32 / UK2） ----------
    fun getFbNls(c: Context): String =
        normalizeFbNls(prefs(c).getString(KEY_FB_NLS, FB_NLS_AUTO))
    fun setFbNls(c: Context, v: String) =
        prefs(c).edit().putString(KEY_FB_NLS, normalizeFbNls(v)).apply()
    fun normalizeFbNls(v: String?): String =
        v?.trim()?.lowercase()?.takeIf { it in FB_NLS_VALUES } ?: FB_NLS_AUTO

    // ---------- Ethornell / BGI ----------
    fun getEthornellNls(c: Context): String =
        normalizeEthornellNls(prefs(c).getString(KEY_ETHORNELL_NLS, ETHORNELL_NLS_SJIS))
    fun setEthornellNls(c: Context, value: String) =
        prefs(c).edit().putString(KEY_ETHORNELL_NLS, normalizeEthornellNls(value)).apply()
    fun normalizeEthornellNls(value: String?): String =
        value?.trim()?.lowercase(java.util.Locale.ROOT)?.takeIf { it in ETHORNELL_NLS_VALUES } ?: ETHORNELL_NLS_SJIS
    fun getEthornellFont(c: Context): String = prefs(c).getString(KEY_ETHORNELL_FONT, "").orEmpty()
    fun setEthornellFont(c: Context, value: String) = prefs(c).edit().putString(KEY_ETHORNELL_FONT, value.trim()).apply()

    // ---------- FVP ----------
    fun getFvpNls(c: Context): String =
        normalizeFvpNls(prefs(c).getString(KEY_FVP_NLS, FVP_NLS_SJIS))
    fun setFvpNls(c: Context, v: String) =
        prefs(c).edit().putString(KEY_FVP_NLS, normalizeFvpNls(v)).apply()
    fun normalizeFvpNls(v: String?): String =
        v?.trim()?.lowercase()?.takeIf { it in FVP_NLS_VALUES } ?: FVP_NLS_SJIS
    fun isFvpSystemFont(c: Context): Boolean = prefs(c).getBoolean(KEY_FVP_SYSTEM_FONT, true)
    fun setFvpSystemFont(c: Context, b: Boolean) = prefs(c).edit().putBoolean(KEY_FVP_SYSTEM_FONT, b).apply()
    fun isFvpTextHidpi(c: Context): Boolean = prefs(c).getBoolean(KEY_FVP_TEXT_HIDPI, true)
    fun setFvpTextHidpi(c: Context, b: Boolean) = prefs(c).edit().putBoolean(KEY_FVP_TEXT_HIDPI, b).apply()
    fun getFvpFont(c: Context): String = normalizeFvpFont(prefs(c).getString(KEY_FVP_FONT, ""))
    fun setFvpFont(c: Context, v: String?) =
        prefs(c).edit().putString(KEY_FVP_FONT, normalizeFvpFont(v)).apply()
    fun normalizeFvpFont(v: String?): String = v?.trim().orEmpty()

    // ---------- CMVS ----------
    fun getCmvsFont(c: Context): String = prefs(c).getString(KEY_CMVS_FONT, "").orEmpty()
    fun setCmvsFont(c: Context, v: String?) =
        prefs(c).edit().putString(KEY_CMVS_FONT, v?.trim().orEmpty()).apply()
    fun getCmvsFontFace(c: Context): Int = prefs(c).getInt(KEY_CMVS_FACE, 0).coerceIn(0, 1024)

    // ---------- System35（xsystem35） ----------
    fun isXs35ScopedSaveDir(c: Context): Boolean =
        prefs(c).getBoolean(KEY_XSYS35_SCOPED_SAVE_DIR, true)
    fun setXs35ScopedSaveDir(c: Context, b: Boolean) =
        prefs(c).edit().putBoolean(KEY_XSYS35_SCOPED_SAVE_DIR, b).apply()
    fun getXs35Renderer(c: Context): String =
        normalizeXs35Renderer(prefs(c).getString(KEY_XSYS35_RENDERER, XSYS35_RENDERER_AUTO))
    fun setXs35Renderer(c: Context, v: String) =
        prefs(c).edit().putString(KEY_XSYS35_RENDERER, normalizeXs35Renderer(v)).apply()
    fun normalizeXs35Renderer(v: String?): String =
        v?.trim()?.lowercase()?.takeIf { it in XSYS35_RENDERER_VALUES } ?: XSYS35_RENDERER_AUTO
    fun isXs35IntegerScale(c: Context): Boolean = prefs(c).getBoolean(KEY_XSYS35_INTEGER_SCALE, false)
    fun setXs35IntegerScale(c: Context, b: Boolean) =
        prefs(c).edit().putBoolean(KEY_XSYS35_INTEGER_SCALE, b).apply()
    fun isXs35MuteUnfocus(c: Context): Boolean = prefs(c).getBoolean(KEY_XSYS35_MUTE_UNFOCUS, false)
    fun setXs35MuteUnfocus(c: Context, b: Boolean) =
        prefs(c).edit().putBoolean(KEY_XSYS35_MUTE_UNFOCUS, b).apply()

    // ---------- System4（xsystem4） ----------
    fun isXs4ScopedSaveDir(c: Context): Boolean =
        prefs(c).getBoolean(KEY_XSYS4_SCOPED_SAVE_DIR, true)
    fun setXs4ScopedSaveDir(c: Context, b: Boolean) =
        prefs(c).edit().putBoolean(KEY_XSYS4_SCOPED_SAVE_DIR, b).apply()
    fun getXs4Encoding(c: Context): String =
        normalizeXs4Encoding(prefs(c).getString(KEY_XSYS4_ENCODING, XSYS4_ENCODING_SJIS))
    fun setXs4Encoding(c: Context, v: String) =
        prefs(c).edit().putString(KEY_XSYS4_ENCODING, normalizeXs4Encoding(v)).apply()
    fun normalizeXs4Encoding(v: String?): String =
        v?.trim()?.lowercase()?.takeIf { it in XSYS4_ENCODING_VALUES } ?: XSYS4_ENCODING_SJIS
    fun getXs4FontGothicPath(c: Context): String =
        normalizeXs4FontPath(prefs(c).getString(KEY_XSYS4_FONT_GOTHIC_PATH, ""))
    fun setXs4FontGothicPath(c: Context, v: String?) =
        prefs(c).edit().putString(KEY_XSYS4_FONT_GOTHIC_PATH, normalizeXs4FontPath(v)).apply()
    fun getXs4FontMinchoPath(c: Context): String =
        normalizeXs4FontPath(prefs(c).getString(KEY_XSYS4_FONT_MINCHO_PATH, ""))
    fun setXs4FontMinchoPath(c: Context, v: String?) =
        prefs(c).edit().putString(KEY_XSYS4_FONT_MINCHO_PATH, normalizeXs4FontPath(v)).apply()
    fun normalizeXs4FontPath(v: String?): String = v?.trim().orEmpty()
    fun getXs4Joypad(c: Context): String =
        normalizeXs4Joypad(prefs(c).getString(KEY_XSYS4_JOYPAD, XSYS4_JOYPAD_AUTO))
    fun setXs4Joypad(c: Context, v: String) =
        prefs(c).edit().putString(KEY_XSYS4_JOYPAD, normalizeXs4Joypad(v)).apply()
    fun normalizeXs4Joypad(v: String?): String =
        v?.trim()?.lowercase()?.takeIf { it in XSYS4_JOYPAD_VALUES } ?: XSYS4_JOYPAD_AUTO
    fun getXs4MsgskipDelay(c: Context): Int =
        normalizeXs4MsgskipDelay(prefs(c).getString(KEY_XSYS4_MSGSKIP_DELAY, null)?.trim()?.toIntOrNull())
    fun setXs4MsgskipDelay(c: Context, v: Int) =
        prefs(c).edit().putString(KEY_XSYS4_MSGSKIP_DELAY, normalizeXs4MsgskipDelay(v).toString()).apply()
    fun normalizeXs4MsgskipDelay(v: Int?): Int =
        v?.takeIf { it in XSYS4_MSGSKIP_DELAY_VALUES } ?: XSYS4_MSGSKIP_DELAY_DEFAULT

    // ---------- Winlator 外置启动 ----------

    /**
     * Winlator 外置启动下发参数（YU-RIS / CatSystem2 / PC 共用）。
     * 空串/0/false 表示不下发对应 extra，交由 Winlator 按容器配置与回退链处理。
     */
    data class Winlator(
        var containerId: Int = 0,
        var containerName: String = "",
        var graphicsDriver: String = "",
        var dxwrapper: String = "",
        var screenSize: String = "",
        var lcAll: String = "",
        var tz: String = "",
        var box64Preset: String = "",
        var save: Boolean = false,
    )

    fun loadWinlator(c: Context): Winlator {
        val p = prefs(c)
        val d = Winlator()
        return Winlator(
            containerId = p.getInt(KEY_WINLATOR_CONTAINER_ID, d.containerId).coerceAtLeast(0),
            containerName = p.getString(KEY_WINLATOR_CONTAINER_NAME, d.containerName).orEmpty().trim(),
            graphicsDriver = normalizeWinlatorGraphicsDriver(p.getString(KEY_WINLATOR_GRAPHICS_DRIVER, d.graphicsDriver)),
            dxwrapper = normalizeWinlatorDxWrapper(p.getString(KEY_WINLATOR_DXWRAPPER, d.dxwrapper)),
            screenSize = normalizeWinlatorScreenSize(p.getString(KEY_WINLATOR_SCREEN_SIZE, d.screenSize)),
            lcAll = normalizeWinlatorLcAll(p.getString(KEY_WINLATOR_LC_ALL, d.lcAll)),
            tz = normalizeWinlatorTz(p.getString(KEY_WINLATOR_TZ, d.tz)),
            box64Preset = normalizeWinlatorBox64Preset(p.getString(KEY_WINLATOR_BOX64_PRESET, d.box64Preset)),
            save = p.getBoolean(KEY_WINLATOR_SAVE, d.save),
        )
    }

    /**
     * 一次性清理被删实现遗留的 Winlator prefs 键（应用启动时调用，版本号保证每轮只跑一次）。
     * 含与当前实现同名的图形驱动/分辨率/Box64 预设（被删实现写入的值清回默认「跟随容器配置」）
     * 与已下线的「追加启动参数」键；其余当前实现的键不在清理范围内。
     */
    fun cleanupLegacyWinlatorKeys(c: Context) {
        val p = prefs(c)
        if (p.getInt(KEY_WINLATOR_LEGACY_CLEANED, 0) >= WINLATOR_LEGACY_CLEAN_VERSION) return
        val editor = p.edit()
        WINLATOR_LEGACY_KEYS.forEach(editor::remove)
        // 旧轮次的布尔标记一并移除（v1/v2）
        editor.remove("winlator_legacy_keys_cleaned")
        editor.remove("winlator_legacy_keys_cleaned_v2")
        editor.putInt(KEY_WINLATOR_LEGACY_CLEANED, WINLATOR_LEGACY_CLEAN_VERSION)
        editor.apply()
    }

    fun saveWinlator(c: Context, w: Winlator) {
        prefs(c).edit().apply {
            putInt(KEY_WINLATOR_CONTAINER_ID, w.containerId.coerceAtLeast(0))
            putString(KEY_WINLATOR_CONTAINER_NAME, w.containerName.trim())
            putString(KEY_WINLATOR_GRAPHICS_DRIVER, normalizeWinlatorGraphicsDriver(w.graphicsDriver))
            putString(KEY_WINLATOR_DXWRAPPER, normalizeWinlatorDxWrapper(w.dxwrapper))
            putString(KEY_WINLATOR_SCREEN_SIZE, normalizeWinlatorScreenSize(w.screenSize))
            putString(KEY_WINLATOR_LC_ALL, normalizeWinlatorLcAll(w.lcAll))
            putString(KEY_WINLATOR_TZ, normalizeWinlatorTz(w.tz))
            putString(KEY_WINLATOR_BOX64_PRESET, normalizeWinlatorBox64Preset(w.box64Preset))
            putBoolean(KEY_WINLATOR_SAVE, w.save)
        }.apply()
    }

    /** 图形驱动：仅接受 [WINLATOR_GRAPHICS_DRIVERS] 固定组合；其余（含单驱动残留）归一回空串。 */
    fun normalizeWinlatorGraphicsDriver(v: String?): String {
        val t = v?.trim()?.lowercase()?.replace(" ", "").orEmpty()
        return t.takeIf { it in WINLATOR_GRAPHICS_DRIVERS } ?: ""
    }

    /** 接受既有 wrapper 和 App 内部 GL/GDI 预设；未知值回退为空串，不下发覆盖。 */
    fun normalizeWinlatorDxWrapper(v: String?): String =
        v?.trim()?.lowercase()?.takeIf { it in WINLATOR_DXWRAPPERS } ?: ""

    fun normalizeWinlatorBox64Preset(v: String?): String {
        val t = v?.trim()?.uppercase().orEmpty()
        return if (t in WINLATOR_BOX64_PRESETS || WINLATOR_BOX64_CUSTOM_PATTERN.matches(t)) t else ""
    }

    /** 分辨率：仅接受固定档位白名单；其余（含旧实现残留的 auto 等）归一回空串。 */
    fun normalizeWinlatorScreenSize(v: String?): String {
        val t = v?.trim().orEmpty()
        return t.takeIf { it in WINLATOR_SCREEN_SIZES } ?: ""
    }

    /** 语言环境（LC_ALL）：仅接受 [WINLATOR_LOCALES] 固定档位；其余归一回空串。 */
    fun normalizeWinlatorLcAll(v: String?): String {
        val t = v?.trim().orEmpty()
        return t.takeIf { it in WINLATOR_LOCALES } ?: ""
    }

    /** 时区（TZ）：仅接受 [WINLATOR_TIMEZONES] 固定档位；其余归一回空串。 */
    fun normalizeWinlatorTz(v: String?): String {
        val t = v?.trim().orEmpty()
        return t.takeIf { it in WINLATOR_TIMEZONES } ?: ""
    }

    // ---------- Tyrano ----------
    fun isTyranoExternalNetwork(c: Context): Boolean = prefs(c).getBoolean(KEY_TYRANO_EXTERNAL_NETWORK, false)
    fun setTyranoExternalNetwork(c: Context, b: Boolean) = prefs(c).edit().putBoolean(KEY_TYRANO_EXTERNAL_NETWORK, b).apply()
    fun isTyranoScopedSaveDir(c: Context): Boolean = prefs(c).getBoolean(KEY_TYRANO_SCOPED_SAVE_DIR, true)
    fun setTyranoScopedSaveDir(c: Context, b: Boolean) = prefs(c).edit().putBoolean(KEY_TYRANO_SCOPED_SAVE_DIR, b).apply()
    fun isRpgMakerModEnabled(c: Context): Boolean = prefs(c).getBoolean(KEY_RPG_MAKER_MOD_ENABLED, true)
    fun setRpgMakerModEnabled(c: Context, b: Boolean) = prefs(c).edit().putBoolean(KEY_RPG_MAKER_MOD_ENABLED, b).apply()
    fun isRpgLegacyRenderer(c: Context): Boolean = prefs(c).getBoolean(KEY_RPG_LEGACY_RENDERER, false)
    fun setRpgLegacyRenderer(c: Context, b: Boolean) = prefs(c).edit().putBoolean(KEY_RPG_LEGACY_RENDERER, b).apply()
    fun isRpgSaveInterop(c: Context): Boolean = prefs(c).getBoolean(KEY_RPG_SAVE_INTEROP, false)
    fun setRpgSaveInterop(c: Context, b: Boolean) = prefs(c).edit().putBoolean(KEY_RPG_SAVE_INTEROP, b).apply()

    // ---------- 输入重映射（虚拟按键 + 手柄映射） ----------
    /**
     * 全局虚拟按键开关。
     *
     * [default] 必须由调用方显式给出（**故意不给默认值**）：「用户未设置」的生效值随引擎而异，
     * MV/MZ 改造前就有按键层故默认开、Tyrano/VN/WebOther 默认关；留一个隐式默认值意味着
     * 某个调用点可能悄悄用错策略（设置页「跟随全局」显示与游戏内实际按键层相悖）。
     * 唯一策略来源：[com.tyranor.next.core.input.InputRemapRepository.engineDefaultsPadEnabled]；
     * 引擎侧 `InputConfigStore.resolve` 用同一个 prefs 键 + `contains` 判定显式性，两处必须一致。
     */
    fun isInputPadEnabled(c: Context, default: Boolean): Boolean =
        prefs(c).getBoolean(KEY_INPUT_PAD_ENABLED, default)
    fun setInputPadEnabled(c: Context, b: Boolean) = prefs(c).edit().putBoolean(KEY_INPUT_PAD_ENABLED, b).apply()
    fun isInputGamepadEnabled(c: Context): Boolean = prefs(c).getBoolean(KEY_INPUT_GAMEPAD_ENABLED, true)
    fun setInputGamepadEnabled(c: Context, b: Boolean) = prefs(c).edit().putBoolean(KEY_INPUT_GAMEPAD_ENABLED, b).apply()
    fun getInputProfileId(c: Context): String =
        prefs(c).getString(KEY_INPUT_PROFILE_ID, null)?.takeIf { it.isNotBlank() }
            ?: com.core.input.InputConfigStore.DEFAULT_PROFILE_ID
    fun setInputProfileId(c: Context, v: String) =
        prefs(c).edit().putString(KEY_INPUT_PROFILE_ID, v).apply()

    // ---------- RPG Maker MV / MZ ----------
    fun getRpgMvEngineVersion(c: Context): String =
        normalizeRpgMv(prefs(c).getString(KEY_RPG_MV_ENGINE_VERSION, RPG_MV_V0))
    fun setRpgMvEngineVersion(c: Context, v: String) =
        prefs(c).edit().putString(KEY_RPG_MV_ENGINE_VERSION, normalizeRpgMv(v)).apply()
    fun getRpgMzEngineVersion(c: Context): String =
        normalizeRpgMz(prefs(c).getString(KEY_RPG_MZ_ENGINE_VERSION, RPG_MZ_V0))
    fun setRpgMzEngineVersion(c: Context, v: String) =
        prefs(c).edit().putString(KEY_RPG_MZ_ENGINE_VERSION, normalizeRpgMz(v)).apply()

    private fun normalizeRpgMv(v: String?): String = when (v?.trim()?.lowercase()) {
        RPG_MV_V1 -> RPG_MV_V1
        RPG_MV_V2 -> RPG_MV_V2
        RPG_MV_V0 -> RPG_MV_V0
        else -> RPG_MV_V0
    }

    private fun normalizeRpgMz(v: String?): String = when (v?.trim()?.lowercase()) {
        RPG_MZ_V1 -> RPG_MZ_V1
        RPG_MZ_V2 -> RPG_MZ_V2
        RPG_MZ_V0 -> RPG_MZ_V0
        else -> RPG_MZ_V0
    }

    // ---------- RPG Maker RGSS 外置模块 ----------

    /**
     * RGSS/mkxp 外置模块的 rpg 配置节。默认值对齐 JoiPlay `SettingsFactory.loadDefault`：
     * useRuby18/smoothScaling/prebuiltPathCache/cheats 默认开，其余默认关。
     * 仅保留 RPGM 插件 `MKXPConfigurationParser` 实际解析的键。
     */
    data class RpgMaker(
        var useRuby18: Boolean = true,
        var debug: Boolean = false,
        var smoothScaling: Boolean = true,
        var vsync: Boolean = false,
        var frameSkip: Boolean = false,
        var solidFonts: Boolean = false,
        var pathCache: Boolean = false,
        var prebuiltPathCache: Boolean = true,
        var fastPathEnum: Boolean = true,
        var copyText: Boolean = false,
        var cheats: Boolean = true,
        var useCJKFont: Boolean = false,
        var enablePostloadScripts: Boolean = false,
        var customFont: String = "",
        var verticalScreenAlign: String = RPG_VERTICAL_ALIGN_DEFAULT,
        var windowSize: String = RPG_WINDOW_SIZE_DEFAULT,
        var speedUp: String = RPG_SPEED_UP_DEFAULT,
        var fontScale: String = RPG_FONT_SCALE_DEFAULT,
    )

    private val RPG_MAKER_BOOL_KEYS = listOf(
        KEY_RPG_USE_RUBY18, KEY_RPG_DEBUG, KEY_RPG_SMOOTH_SCALING,
        KEY_RPG_VSYNC, KEY_RPG_FRAME_SKIP, KEY_RPG_SOLID_FONTS, KEY_RPG_PATH_CACHE,
        KEY_RPG_PREBUILT_PATH_CACHE, KEY_RPG_FAST_PATH_ENUM, KEY_RPG_COPY_TEXT,
        KEY_RPG_CHEATS, KEY_RPG_USE_CJK_FONT, KEY_RPG_ENABLE_POSTLOAD_SCRIPTS,
    )
    private val RPG_MAKER_STRING_KEYS = listOf(
        KEY_RPG_CUSTOM_FONT, KEY_RPG_VERTICAL_SCREEN_ALIGN,
        KEY_RPG_WINDOW_SIZE, KEY_RPG_SPEED_UP, KEY_RPG_FONT_SCALE,
    )

    fun loadRpgMaker(c: Context): RpgMaker {
        val p = prefs(c)
        val d = RpgMaker()
        return RpgMaker(
            useRuby18 = p.getBoolean(KEY_RPG_USE_RUBY18, d.useRuby18),
            debug = p.getBoolean(KEY_RPG_DEBUG, d.debug),
            smoothScaling = p.getBoolean(KEY_RPG_SMOOTH_SCALING, d.smoothScaling),
            vsync = p.getBoolean(KEY_RPG_VSYNC, d.vsync),
            frameSkip = p.getBoolean(KEY_RPG_FRAME_SKIP, d.frameSkip),
            solidFonts = p.getBoolean(KEY_RPG_SOLID_FONTS, d.solidFonts),
            pathCache = p.getBoolean(KEY_RPG_PATH_CACHE, d.pathCache),
            prebuiltPathCache = p.getBoolean(KEY_RPG_PREBUILT_PATH_CACHE, d.prebuiltPathCache),
            fastPathEnum = p.getBoolean(KEY_RPG_FAST_PATH_ENUM, d.fastPathEnum),
            copyText = p.getBoolean(KEY_RPG_COPY_TEXT, d.copyText),
            cheats = p.getBoolean(KEY_RPG_CHEATS, d.cheats),
            useCJKFont = p.getBoolean(KEY_RPG_USE_CJK_FONT, d.useCJKFont),
            enablePostloadScripts = p.getBoolean(KEY_RPG_ENABLE_POSTLOAD_SCRIPTS, d.enablePostloadScripts),
            customFont = p.getString(KEY_RPG_CUSTOM_FONT, d.customFont).orEmpty(),
            verticalScreenAlign = normalizeRpgVerticalAlign(p.getString(KEY_RPG_VERTICAL_SCREEN_ALIGN, d.verticalScreenAlign)),
            windowSize = normalizeRpgWindowSize(p.getString(KEY_RPG_WINDOW_SIZE, d.windowSize)),
            speedUp = normalizeRpgSpeedUp(p.getString(KEY_RPG_SPEED_UP, d.speedUp)),
            fontScale = normalizeRpgFontScale(p.getString(KEY_RPG_FONT_SCALE, d.fontScale)),
        )
    }

    fun saveRpgMaker(c: Context, r: RpgMaker) {
        prefs(c).edit().apply {
            putBoolean(KEY_RPG_USE_RUBY18, r.useRuby18)
            putBoolean(KEY_RPG_DEBUG, r.debug)
            putBoolean(KEY_RPG_SMOOTH_SCALING, r.smoothScaling)
            putBoolean(KEY_RPG_VSYNC, r.vsync)
            putBoolean(KEY_RPG_FRAME_SKIP, r.frameSkip)
            putBoolean(KEY_RPG_SOLID_FONTS, r.solidFonts)
            putBoolean(KEY_RPG_PATH_CACHE, r.pathCache)
            putBoolean(KEY_RPG_PREBUILT_PATH_CACHE, r.prebuiltPathCache)
            putBoolean(KEY_RPG_FAST_PATH_ENUM, r.fastPathEnum)
            putBoolean(KEY_RPG_COPY_TEXT, r.copyText)
            putBoolean(KEY_RPG_CHEATS, r.cheats)
            putBoolean(KEY_RPG_USE_CJK_FONT, r.useCJKFont)
            putBoolean(KEY_RPG_ENABLE_POSTLOAD_SCRIPTS, r.enablePostloadScripts)
            putString(KEY_RPG_CUSTOM_FONT, r.customFont.trim())
            putString(KEY_RPG_VERTICAL_SCREEN_ALIGN, normalizeRpgVerticalAlign(r.verticalScreenAlign))
            putString(KEY_RPG_WINDOW_SIZE, normalizeRpgWindowSize(r.windowSize))
            putString(KEY_RPG_SPEED_UP, normalizeRpgSpeedUp(r.speedUp))
            putString(KEY_RPG_FONT_SCALE, normalizeRpgFontScale(r.fontScale))
        }.apply()
    }

    /** 仅重置 rpg 节，其余引擎设置不动（对齐 JoiPlay resetSettingsButton 的作用域）。 */
    fun resetRpgMaker(c: Context) {
        val editor = prefs(c).edit()
        RPG_MAKER_BOOL_KEYS.forEach(editor::remove)
        RPG_MAKER_STRING_KEYS.forEach(editor::remove)
        editor.apply()
    }

    fun normalizeRpgWindowSize(v: String?): String {
        val t = v?.trim().orEmpty()
        return if (t in RPG_WINDOW_SIZES) t else RPG_WINDOW_SIZE_DEFAULT
    }

    fun normalizeRpgSpeedUp(v: String?): String {
        val t = v?.trim().orEmpty()
        return if (t in RPG_SPEED_UPS) t else RPG_SPEED_UP_DEFAULT
    }

    fun normalizeRpgFontScale(v: String?): String {
        val t = v?.trim().orEmpty()
        return if (t in RPG_FONT_SCALES) t else RPG_FONT_SCALE_DEFAULT
    }

    fun normalizeRpgVerticalAlign(v: String?): String {
        val t = v?.trim().orEmpty()
        return if (t in RPG_VERTICAL_ALIGNS) t else RPG_VERTICAL_ALIGN_DEFAULT
    }

    // ---------- Ren'Py 外置模块 ----------

    /**
     * Ren'Py 外置模块的配置节。默认值对齐 JoiPlay `SettingsFactory.loadDefault` 与插件
     * `RenPyConfiguration`：hw_video/cheats 默认开，其余默认关。
     */
    data class RenPy(
        var cheats: Boolean = true,
        var hwVideo: Boolean = true,
        var autosave: Boolean = false,
        var phoneSmallVariant: Boolean = false,
        var vsync: Boolean = false,
        var lessMemory: Boolean = false,
        var lessUpdates: Boolean = false,
        var dontUseGl2: Boolean = false,
        var recompile: Boolean = false,
    )

    private val RENPY_BOOL_KEYS = listOf(
        KEY_RENPY_CHEATS, KEY_RENPY_HW_VIDEO, KEY_RENPY_AUTOSAVE,
        KEY_RENPY_PHONE_SMALL_VARIANT, KEY_RENPY_VSYNC, KEY_RENPY_LESS_MEMORY,
        KEY_RENPY_LESS_UPDATES, KEY_RENPY_DONT_USE_GL2, KEY_RENPY_RECOMPILE,
    )

    fun loadRenPy(c: Context): RenPy {
        val p = prefs(c)
        val d = RenPy()
        return RenPy(
            cheats = p.getBoolean(KEY_RENPY_CHEATS, d.cheats),
            hwVideo = p.getBoolean(KEY_RENPY_HW_VIDEO, d.hwVideo),
            autosave = p.getBoolean(KEY_RENPY_AUTOSAVE, d.autosave),
            phoneSmallVariant = p.getBoolean(KEY_RENPY_PHONE_SMALL_VARIANT, d.phoneSmallVariant),
            vsync = p.getBoolean(KEY_RENPY_VSYNC, d.vsync),
            lessMemory = p.getBoolean(KEY_RENPY_LESS_MEMORY, d.lessMemory),
            lessUpdates = p.getBoolean(KEY_RENPY_LESS_UPDATES, d.lessUpdates),
            dontUseGl2 = p.getBoolean(KEY_RENPY_DONT_USE_GL2, d.dontUseGl2),
            recompile = p.getBoolean(KEY_RENPY_RECOMPILE, d.recompile),
        )
    }

    fun saveRenPy(c: Context, r: RenPy) {
        prefs(c).edit().apply {
            putBoolean(KEY_RENPY_CHEATS, r.cheats)
            putBoolean(KEY_RENPY_HW_VIDEO, r.hwVideo)
            putBoolean(KEY_RENPY_AUTOSAVE, r.autosave)
            putBoolean(KEY_RENPY_PHONE_SMALL_VARIANT, r.phoneSmallVariant)
            putBoolean(KEY_RENPY_VSYNC, r.vsync)
            putBoolean(KEY_RENPY_LESS_MEMORY, r.lessMemory)
            putBoolean(KEY_RENPY_LESS_UPDATES, r.lessUpdates)
            putBoolean(KEY_RENPY_DONT_USE_GL2, r.dontUseGl2)
            putBoolean(KEY_RENPY_RECOMPILE, r.recompile)
        }.apply()
    }

    /** 仅重置 renpy 节，版本键（renpy_engine_version）保留。 */
    fun resetRenPy(c: Context) {
        val editor = prefs(c).edit()
        RENPY_BOOL_KEYS.forEach(editor::remove)
        editor.apply()
    }

    // ---------- Ruffle 外置模块 ----------

    /**
     * Ruffle 外置模块的配置节。默认值对齐插件 `RuffleConfiguration`：
     * backend=opengl / quality=high / scaleMode=showall / letterbox=on /
     * loadBehavior=streaming / screenTimeout=0（禁用）。
     */
    data class Ruffle(
        var screenTimeout: Int = RUFFLE_SCREEN_TIMEOUT_DEFAULT,
        var backend: String = RUFFLE_BACKEND_OPENGL,
        var quality: String = RUFFLE_QUALITY_HIGH,
        var scaleMode: String = RUFFLE_SCALE_MODE_SHOW_ALL,
        var letterbox: String = RUFFLE_LETTERBOX_ON,
        var loadBehavior: String = RUFFLE_LOAD_BEHAVIOR_STREAMING,
    )

    private val RUFFLE_STRING_KEYS = listOf(
        KEY_RUFFLE_BACKEND, KEY_RUFFLE_QUALITY, KEY_RUFFLE_SCALE_MODE,
        KEY_RUFFLE_LETTERBOX, KEY_RUFFLE_LOAD_BEHAVIOR,
    )

    fun loadRuffle(c: Context): Ruffle {
        val p = prefs(c)
        val d = Ruffle()
        return Ruffle(
            screenTimeout = normalizeRuffleScreenTimeout(p.getInt(KEY_RUFFLE_SCREEN_TIMEOUT, d.screenTimeout)),
            backend = normalizeRuffleAllowed(p.getString(KEY_RUFFLE_BACKEND, null), RUFFLE_BACKENDS, d.backend),
            quality = normalizeRuffleAllowed(p.getString(KEY_RUFFLE_QUALITY, null), RUFFLE_QUALITIES, d.quality),
            scaleMode = normalizeRuffleAllowed(p.getString(KEY_RUFFLE_SCALE_MODE, null), RUFFLE_SCALE_MODES, d.scaleMode),
            letterbox = normalizeRuffleAllowed(p.getString(KEY_RUFFLE_LETTERBOX, null), RUFFLE_LETTERBOXES, d.letterbox),
            loadBehavior = normalizeRuffleAllowed(p.getString(KEY_RUFFLE_LOAD_BEHAVIOR, null), RUFFLE_LOAD_BEHAVIORS, d.loadBehavior),
        )
    }

    fun saveRuffle(c: Context, r: Ruffle) {
        prefs(c).edit().apply {
            putInt(KEY_RUFFLE_SCREEN_TIMEOUT, normalizeRuffleScreenTimeout(r.screenTimeout))
            putString(KEY_RUFFLE_BACKEND, normalizeRuffleBackend(r.backend))
            putString(KEY_RUFFLE_QUALITY, normalizeRuffleQuality(r.quality))
            putString(KEY_RUFFLE_SCALE_MODE, normalizeRuffleScaleMode(r.scaleMode))
            putString(KEY_RUFFLE_LETTERBOX, normalizeRuffleLetterbox(r.letterbox))
            putString(KEY_RUFFLE_LOAD_BEHAVIOR, normalizeRuffleLoadBehavior(r.loadBehavior))
        }.apply()
    }

    /** 仅重置 ruffle 节，其余引擎设置不动。 */
    fun resetRuffle(c: Context) {
        val editor = prefs(c).edit()
        editor.remove(KEY_RUFFLE_SCREEN_TIMEOUT)
        RUFFLE_STRING_KEYS.forEach(editor::remove)
        editor.apply()
    }

    fun normalizeRuffleScreenTimeout(v: Int?): Int =
        v?.takeIf { it in RUFFLE_SCREEN_TIMEOUTS } ?: RUFFLE_SCREEN_TIMEOUT_DEFAULT

    fun normalizeRuffleBackend(v: String?): String =
        normalizeRuffleAllowed(v, RUFFLE_BACKENDS, RUFFLE_BACKEND_OPENGL)

    fun normalizeRuffleQuality(v: String?): String =
        normalizeRuffleAllowed(v, RUFFLE_QUALITIES, RUFFLE_QUALITY_HIGH)

    fun normalizeRuffleScaleMode(v: String?): String =
        normalizeRuffleAllowed(v, RUFFLE_SCALE_MODES, RUFFLE_SCALE_MODE_SHOW_ALL)

    fun normalizeRuffleLetterbox(v: String?): String =
        normalizeRuffleAllowed(v, RUFFLE_LETTERBOXES, RUFFLE_LETTERBOX_ON)

    fun normalizeRuffleLoadBehavior(v: String?): String =
        normalizeRuffleAllowed(v, RUFFLE_LOAD_BEHAVIORS, RUFFLE_LOAD_BEHAVIOR_STREAMING)

    private fun normalizeRuffleAllowed(v: String?, allowed: Set<String>, fallback: String): String =
        v?.trim()?.lowercase(java.util.Locale.ROOT)?.takeIf { it in allowed } ?: fallback
}
