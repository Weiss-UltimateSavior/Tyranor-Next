package com.tyranor.next.core.game.save.sync

import org.json.JSONObject
import org.json.JSONException
import kotlinx.coroutines.CancellationException

/** Damaged known-host evidence remains unknown until a lifecycle record rewrites it. */
internal fun loadSaveHostRecords(
    store: SaveSyncStateStore,
    knownKeys: Set<String>,
): Map<String, JSONObject> = buildMap {
    for (key in store.keys()) {
        if (key !in knownKeys) continue
        val state = try {
            store.load(key) { record ->
                val pid = (record.opt("pid") as? Number)?.toString()?.toIntOrNull()
                val activities = (record.opt("activities") as? Number)?.toString()?.toIntOrNull()
                val uris = record.optJSONArray("uris")
                if (pid == null || pid <= 0 || activities == null || activities < 0 || uris == null ||
                    (0 until uris.length()).any { (uris.opt(it) as? String).isNullOrBlank() }) {
                    throw JSONException("Invalid save host record")
                }
            }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (failure: SaveSyncException) {
            if (failure.code != SaveSyncError.LOCAL_IO) throw failure
            JSONObject() // Strict loading preserves the original and its quarantine copy.
        }
        put(key, state)
    }
}

internal data class SaveHostProcess(val pid: Int, val name: String)
internal sealed interface SaveHostIdentity {
    data object Dead : SaveHostIdentity
    data object Unknown : SaveHostIdentity
    data class Live(val name: String) : SaveHostIdentity
}

/**
 * A persisted host record whose `/proc/<pid>/cmdline` cannot be read is probed with
 * `kill(pid, 0)`. `ESRCH` proves the process is gone; `EPERM`/`EACCES` mean this app cannot
 * signal a still-existing PID. Save host processes always share this app's UID and security
 * domain, so an unsignalable PID cannot be the recorded host either. Only an indeterminate
 * probe stays Unknown.
 */
internal fun classifyUnreadableHostProcess(processGone: Boolean, notSignalable: Boolean): SaveHostIdentity =
    if (processGone || notSignalable) SaveHostIdentity.Dead else SaveHostIdentity.Unknown

/** ActivityManager and /proc can independently be incomplete on OEM Android builds. */
internal interface SaveHostProbe {
    /** null means unavailable (including an empty ActivityManager process list). */
    fun visibleHosts(): List<SaveHostProcess>?
    fun records(): Map<String, JSONObject>
    fun identity(pid: Int): SaveHostIdentity
}

/**
 * Used by launch, manual selection and exit upload.
 * [hasSession] is true only for native work that still needs host-process evidence.
 */
internal fun hasRunningSaveHost(
    probe: SaveHostProbe,
    gameUri: String,
    hasSession: Boolean,
    inStartGrace: Boolean,
    elapsedMillis: Long,
    relatedUris: Set<String> = setOf(gameUri),
): Boolean {
    if (inStartGrace) return true
    val visible = probe.visibleHosts()
    if (visible == null && hasSession) return true
    val records = probe.records()
    fun relation(pid: Int, key: String): HostRecordRelation {
        val record = records[key] ?: return HostRecordRelation.UNKNOWN
        val array = record.optJSONArray("uris") ?: return HostRecordRelation.UNKNOWN
        val uris = (0 until array.length()).map { index ->
            (array.opt(index) as? String)?.takeIf(String::isNotBlank) ?: return HostRecordRelation.UNKNOWN
        }
        val idleSince = record.optLong("idleSince")
        val idleFor = if (idleSince > 0) elapsedMillis - idleSince else -1L
        val activities = record.optInt("activities", -1)
        val effectiveActivities = if (record.optBoolean("nativeOwnerPending") && activities >= 0) {
            maxOf(1, activities) // Retain owner URI correlation until native destruction ACK.
        } else activities
        return relatedUris.map { related ->
            classifyHostRecord(pid, record.optInt("pid", -1), effectiveActivities, uris, related,
                idleForMillis = idleFor)
        }.firstOrNull { it != HostRecordRelation.UNRELATED } ?: HostRecordRelation.UNRELATED
    }
    val visibleProcesses = visible.orEmpty()
    if (visibleProcesses.any { process ->
            process.name.isBlank() ||
                relation(process.pid, SaveContentHash.text(process.name)) != HostRecordRelation.UNRELATED
        }) {
        return true
    }
    var observed = visibleProcesses.isNotEmpty()
    // Never discard a malformed record: without a usable PID or identity, it cannot prove that
    // the host which owns the save tree has stopped.
    for ((key, record) in records) {
        val pid = record.optInt("pid", -1)
        if (pid <= 0) return true
        when (val identity = probe.identity(pid)) {
            SaveHostIdentity.Unknown -> return true
            SaveHostIdentity.Dead -> observed = true
            is SaveHostIdentity.Live -> {
                // A reused PID is evidence that the registered process ended, not that it runs.
                observed = true
                if (SaveContentHash.text(identity.name) == key &&
                    relation(pid, key) != HostRecordRelation.UNRELATED) return true
            }
        }
    }
    return hasSession && !observed
}
