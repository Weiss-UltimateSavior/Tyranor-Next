package com.tyranor.next.core.game.save

import com.tyranor.next.core.engine.EngineType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import com.core.rpgmaker.RpgSaveKeyMapping
import org.junit.Test
import org.junit.rules.TemporaryFolder

class RpgSaveFormatTest {
    @get:Rule
    val temporaryFolder = TemporaryFolder()

    /** 构造 MV 游戏目录：gameRoot/www/{index.html,js/rpg_core.js}。返回 gameRoot。 */
    private fun mvGameRoot(name: String = "Locked and Wagered"): java.io.File {
        val gameRoot = temporaryFolder.newFolder(name)
        val www = gameRoot.resolve("www")
        www.resolve("js").mkdirs()
        www.resolve("index.html").writeText("<html></html>")
        www.resolve("js/rpg_core.js").writeText("// MV")
        return gameRoot
    }

    // ===== 标准名判定 =====

    @Test
    fun detectsMvStandardNamesIncludingBackups() {
        listOf(
            "global.rpgsave", "config.rpgsave", "file1.rpgsave", "file12.rpgsave",
            "global.rpgsave.bak", "config.rpgsave.bak", "file3.rpgsave.bak",
        ).forEach { name ->
            assertTrue(name, RpgSaveFormat.isStandardName(name, EngineType.RPG_MV))
        }
    }

    @Test
    fun mvStandardNameIsCaseInsensitive() {
        assertTrue(RpgSaveFormat.isStandardName("Global.RPGSAVE", EngineType.RPG_MV))
        assertTrue(RpgSaveFormat.isStandardName("FILE2.RPGSave.BAK", EngineType.RPG_MV))
    }

    @Test
    fun rejectsNonStandardNames() {
        listOf(
            "RPG Global.bin", "RPG File1.bin", "global.bin",
            "file.rpgsave", "fileX.rpgsave", "global.rpgsave.tmp",
        ).forEach { name ->
            assertFalse(name, RpgSaveFormat.isStandardName(name, EngineType.RPG_MV))
        }
        // 哈希名不是标准名
        assertFalse(RpgSaveFormat.isStandardName("key_" + "a".repeat(64) + ".bin", EngineType.RPG_MV))
    }

    @Test
    fun mzStandardNamesUseRmmzsaveAndHaveNoBackup() {
        assertTrue(RpgSaveFormat.isStandardName("global.rmmzsave", EngineType.RPG_MZ))
        assertTrue(RpgSaveFormat.isStandardName("file4.rmmzsave", EngineType.RPG_MZ))
        assertFalse(RpgSaveFormat.isStandardName("global.rmmzsave.bak", EngineType.RPG_MZ))
        assertFalse(RpgSaveFormat.isStandardName("global.rpgsave", EngineType.RPG_MZ))
    }

    // ===== 双向映射 =====

    @Test
    fun mvStandardToTyranorMapping() {
        assertEquals("RPG Global.bin", RpgSaveFormat.standardToTyranor("global.rpgsave", EngineType.RPG_MV))
        assertEquals("RPG Config.bin", RpgSaveFormat.standardToTyranor("config.rpgsave", EngineType.RPG_MV))
        assertEquals("RPG File7.bin", RpgSaveFormat.standardToTyranor("file7.rpgsave", EngineType.RPG_MV))
        assertEquals("RPG Globalbak.bin", RpgSaveFormat.standardToTyranor("global.rpgsave.bak", EngineType.RPG_MV))
        assertEquals("RPG File7bak.bin", RpgSaveFormat.standardToTyranor("file7.rpgsave.bak", EngineType.RPG_MV))
    }

    @Test
    fun mvConversionAppliesHashedFileName() {
        // 转化后引擎实际落盘名 = key_<sha256(legacy 键)>.bin（引擎读到的正是该文件）
        assertEquals(
            "key_215007509301dd409efc2827bcef990f603bba0b5f3deceed8e025c3b67392eb.bin",
            RpgSaveFormat.tyranorFileNameForStandard("global.rpgsave", EngineType.RPG_MV),
        )
        // 真实观测值：Tyranor 内第 3 存档位落盘 key_938e37…，即 sha256("RPG File3")
        assertEquals(
            "key_938e37cbcee031a9bc044e6e784523ae2ee39d0cc30a060d16aedd0da815c8e5.bin",
            RpgSaveFormat.tyranorFileNameForStandard("file3.rpgsave", EngineType.RPG_MV),
        )
    }

    @Test
    fun mzConversionKeepsPlainName() {
        // MZ 键为纯 ASCII，引擎固定读写原名；改哈希名会永远读不到
        assertEquals("global.bin", RpgSaveFormat.tyranorFileNameForStandard("global.rmmzsave", EngineType.RPG_MZ))
        assertEquals("file9.bin", RpgSaveFormat.tyranorFileNameForStandard("file9.rmmzsave", EngineType.RPG_MZ))
    }

    @Test
    fun slotNameAppliesHashedNameForMvOnly() {
        assertEquals(
            "key_938e37cbcee031a9bc044e6e784523ae2ee39d0cc30a060d16aedd0da815c8e5.bin",
            RpgSaveFormat.tyranorNameForSlot("file3", EngineType.RPG_MV),
        )
        assertEquals("file3.bin", RpgSaveFormat.tyranorNameForSlot("file3", EngineType.RPG_MZ))
        // 哈希名仍可反解回槽位与标准名（导出/互通识别闭环）
        assertEquals(
            "file3",
            RpgSaveFormat.tyranorSlot(
                "key_938e37cbcee031a9bc044e6e784523ae2ee39d0cc30a060d16aedd0da815c8e5.bin",
                EngineType.RPG_MV,
            ),
        )
    }

    @Test
    fun mzStandardToTyranorMapping() {
        assertEquals("global.bin", RpgSaveFormat.standardToTyranor("global.rmmzsave", EngineType.RPG_MZ))
        assertEquals("config.bin", RpgSaveFormat.standardToTyranor("config.rmmzsave", EngineType.RPG_MZ))
        assertEquals("file9.bin", RpgSaveFormat.standardToTyranor("file9.rmmzsave", EngineType.RPG_MZ))
    }

    @Test
    fun tyranorToStandardMapping() {
        assertEquals("global.rpgsave", RpgSaveFormat.tyranorToStandard("RPG Global.bin", EngineType.RPG_MV))
        assertEquals("file3.rpgsave", RpgSaveFormat.tyranorToStandard("RPG File3.bin", EngineType.RPG_MV))
        assertEquals("file3.rpgsave.bak", RpgSaveFormat.tyranorToStandard("RPG File3bak.bin", EngineType.RPG_MV))
        assertEquals("global.rmmzsave", RpgSaveFormat.tyranorToStandard("global.bin", EngineType.RPG_MZ))
        assertEquals("file8.rmmzsave", RpgSaveFormat.tyranorToStandard("file8.bin", EngineType.RPG_MZ))
    }

    @Test
    fun mvAndMzTyranorNamesDoNotCrossMap() {
        assertNull(RpgSaveFormat.tyranorToStandard("RPG Global.bin", EngineType.RPG_MZ))
        assertNull(RpgSaveFormat.tyranorToStandard("global.bin", EngineType.RPG_MV))
    }

    @Test
    fun nonRpgEnginesAreNotConvertible() {
        assertNull(RpgSaveFormat.standardToTyranor("global.rpgsave", EngineType.TYRANO))
        assertNull(RpgSaveFormat.tyranorToStandard("RPG Global.bin", EngineType.TYRANO))
        assertFalse(RpgSaveFormat.isStandardName("global.rpgsave", EngineType.TYRANO))
        assertFalse(RpgSaveFormat.isRpgWebEngine(EngineType.TYRANO))
    }

    // ===== 哈希名反解（导出标准模式） =====

    @Test
    fun reversesHashedSaveNamesBackToStandard() {
        // 实测：Txranor 内创建第 3 存档位生成 key_938e37….bin，其原始键为 "RPG File3"
        val slot3 = "key_938e37cbcee031a9bc044e6e784523ae2ee39d0cc30a060d16aedd0da815c8e5.bin"
        assertEquals("file3.rpgsave", RpgSaveFormat.hashedToStandardName(slot3, EngineType.RPG_MV))
        assertEquals("file1.rpgsave", RpgSaveFormat.hashedToStandardName("key_a7fccfa2378924192142c2ab1c361c0a2c005a332478e0668c371f6107eb18d2.bin", EngineType.RPG_MV))
        assertEquals("global.rpgsave", RpgSaveFormat.hashedToStandardName("key_215007509301dd409efc2827bcef990f603bba0b5f3deceed8e025c3b67392eb.bin", EngineType.RPG_MV))
        assertEquals("global.rpgsave.bak", RpgSaveFormat.hashedToStandardName("key_4ae7448b065f23ae346c44c97189f5f9b7f0dbf0c2a0c892468d4dd20600cfbb.bin", EngineType.RPG_MV))
    }

    @Test
    fun hashedReversalRejectsUnknownKeysAndNonHashedNames() {
        // 插件自定义键无法枚举还原
        assertNull(RpgSaveFormat.hashedToStandardName("key_" + "0".repeat(64) + ".bin", EngineType.RPG_MV))
        assertNull(RpgSaveFormat.hashedToStandardName("RPG File3.bin", EngineType.RPG_MV))
        assertNull(RpgSaveFormat.hashedToStandardName("key_abc.bin", EngineType.RPG_MV))
        // 非 RPG 引擎无反解空间
        assertNull(RpgSaveFormat.hashedToStandardName("key_" + "a".repeat(64) + ".bin", EngineType.TYRANO))
    }

    @Test
    fun hashedNameIsRecognizedButNotStandard() {
        val hashed = "key_" + "a".repeat(64) + ".bin"
        assertTrue(RpgSaveFormat.isHashedTyranorName(hashed))
        assertFalse(RpgSaveFormat.isStandardName(hashed, EngineType.RPG_MV))
        assertNull(RpgSaveFormat.standardToTyranor(hashed, EngineType.RPG_MV))
    }

    // ===== 目录检测 =====

    @Test
    fun detectOnlyScansDirectChildrenAndReportsHashed() {
        val gameRoot = mvGameRoot()
        val savedata = gameRoot.resolve("savedata").apply { mkdirs() }
        savedata.resolve("global.rpgsave").writeText("a")
        savedata.resolve("file1.rpgsave").writeText("b")
        savedata.resolve("key_" + "b".repeat(64) + ".bin").writeText("h")
        savedata.resolve("RPG Global.bin").writeText("existing")
        // original/ 内的标准文件不应再次触发
        val original = savedata.resolve("original").apply { mkdirs() }
        original.resolve("file2.rpgsave").writeText("c")

        val detection = RpgSaveFormat.detect(gameRoot, EngineType.RPG_MV)
        assertEquals(2, detection.convertibleCount)
        assertEquals(1, detection.hashedCount)
    }

    @Test
    fun detectFindsStandardSavesInSaveDirectory() {
        val gameRoot = mvGameRoot()
        val savedata = gameRoot.resolve("savedata").apply { mkdirs() }
        savedata.resolve("global.rpgsave").writeText("a")

        val detection = RpgSaveFormat.detect(gameRoot, EngineType.RPG_MV)
        assertEquals(1, detection.convertibleCount)
    }

    // ===== 路径去重（大小写敏感文件系统） =====

    @Test
    fun saveAndSaveAreDistinctDirectoriesWhenBothExist() {
        // 大小写敏感的文件系统上 save 与 Save 是两个目录，去重不能按小写归一而丢弃其一
        val gameRoot = mvGameRoot()
        val lower = gameRoot.resolve("www/save").apply { mkdirs() }
        val upper = gameRoot.resolve("www/Save").apply { mkdirs() }
        lower.resolve("global.rpgsave").writeText("a")
        upper.resolve("file1.rpgsave").writeText("b")

        val dirs = RpgSaveFormat.standardSaveDirectories(gameRoot)
        // 只要文件系统把两者视作不同目录（Linux 测试环境），就必须都保留
        if (lower.canonicalPath != upper.canonicalPath) {
            assertEquals(2, dirs.size)
        }
    }

    @Test
    fun detectToleratesLegacyUppercaseSavedata() {
        val gameRoot = mvGameRoot()
        val upper = gameRoot.resolve("Savedata").apply { mkdirs() }
        upper.resolve("file1.rpgsave").writeText("a")

        val detection = RpgSaveFormat.detect(gameRoot, EngineType.RPG_MV)
        assertEquals(1, detection.convertibleCount)
    }

    @Test
    fun saveDirectoryIsGameRootSavedata() {
        val gameRoot = mvGameRoot()
        assertEquals(gameRoot.resolve("savedata").absolutePath, RpgSaveFormat.saveDirectory(gameRoot).absolutePath)
    }

    /**
     * 跨模块契约：应用侧转化按 RpgSaveKeyMapping 写入，引擎按同一实现读取。
     *
     * 该用例锁定「app == 共享实现」这一环（引擎侧另有 RpgSaveKeyMappingTest 锁定
     * 「引擎 == 共享实现」）。此前两侧各写一份实现、仅靠「MV 键必含空格」的巧合保持等价，
     * 一旦漂移会导致转化出的存档写进去却读不到，且没有任何报错。
     */
    @Test
    fun appNamingMatchesEngineMapping() {
        // MV：标准槽位 → legacy 键 → 引擎落盘名，必须与共享映射逐个一致
        listOf("global.rpgsave", "config.rpgsave", "file1.rpgsave", "file21.rpgsave")
            .forEach { standardName ->
                val applied = requireNotNull(RpgSaveFormat.tyranorFileNameForStandard(standardName, EngineType.RPG_MV))
                val legacyKey = requireNotNull(RpgSaveFormat.standardToTyranor(standardName, EngineType.RPG_MV))
                    .removeSuffix(".bin")
                assertEquals(
                    "MV '$standardName' 的落盘名必须等于引擎映射",
                    RpgSaveKeyMapping.canonicalFileName(legacyKey, ".bin"),
                    applied,
                )
            }

        // 槽位形式（同步路径使用）同样一致
        listOf("global", "config", "file3", "file3.bak").forEach { slot ->
            val applied = RpgSaveFormat.tyranorNameForSlot(slot, EngineType.RPG_MV)
                ?: return@forEach
            val legacyKey = applied.removeSuffix(".bin")
            // 已是哈希名：反解出的键必须能重新映射回同一文件名（往返一致）
            if (RpgSaveKeyMapping.isHashedFileName(applied)) {
                assertTrue("哈希名 '$applied' 必须是规范的 64 位小写十六进制", applied.startsWith("key_"))
            } else {
                assertEquals(
                    "非哈希名 '$slot' 应可由映射复现",
                    RpgSaveKeyMapping.canonicalFileName(legacyKey, ".bin"),
                    applied,
                )
            }
        }
    }

    /** MZ 保持原名（键为纯 ASCII，改名会让引擎读不到既有存档）。 */
    @Test
    fun mzKeepsRawNameInContract() {
        // 注意 MZ 用 .rmmzsave 扩展名（MV 为 .rpgsave）
        listOf("global.rmmzsave", "file1.rmmzsave").forEach { standardName ->
            val applied = requireNotNull(RpgSaveFormat.tyranorFileNameForStandard(standardName, EngineType.RPG_MZ))
            assertFalse("MZ '$standardName' 不应使用哈希名", RpgSaveKeyMapping.isHashedFileName(applied))
            val legacyKey = requireNotNull(RpgSaveFormat.standardToTyranor(standardName, EngineType.RPG_MZ))
                .removeSuffix(".bin")
            assertEquals(
                "MZ 落盘名必须等于引擎映射（纯 ASCII 键 → 原名）",
                RpgSaveKeyMapping.canonicalFileName(legacyKey, ".bin"),
                applied,
            )
        }
    }
}
