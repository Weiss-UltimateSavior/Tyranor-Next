package com.tyranor.next.core.engine.plugin

import android.content.Context
import android.content.SharedPreferences
import com.core.engine.EnginePrefs
import com.core.nativeplugin.NativePluginConstants
import com.core.nativeplugin.NativePluginInstallState
import com.core.nativeplugin.NativePluginManager
import com.tyranor.next.core.engine.EngineType
import org.json.JSONObject
import org.tukaani.xz.XZInputStream
import java.io.File
import java.util.zip.ZipInputStream

/**
 * 直接集成（非模块化）：把随 APK 打包在 assets 的引擎原生插件（`.zip.xz`），
 * 首次启动时自动安装到 app 私有插件目录，并标记为已安装+已启用。
 *
 * 引擎加载器（NativeLibraryLoader/OnsLibLoader/Artemis 相关）从
 * filesDir/engine_plugins/<engine>/current/arm64-v8a/ 读取 .so；
 * 此处解压 assets/nativeplugins/<engine>.zip.xz 到该目录，无需用户手动导入 zip。
 *
 * 外层是 LZMA2 流、内层是未压缩的 zip 容器：构建期 [CompressXzArchive] 让同一引擎家族的
 * 多个近重复 .so 共享一份字典，APK 内因此只需约一半空间；运行时先解 xz 再走原有 zip 逻辑。
 *
 * 更新策略：仅按「必备 so 是否齐全」校验无法发现同名 .so 内容变化
 * （如自研内核与宿主 Java 桥成对更新），因此额外比对已装 `pluginVersion`
 * 与 assets 内 manifest 的 `pluginVersion`，不一致即重新解压。
 */
object EnginePluginBootstrap {

    private const val TAG = "EnginePluginBootstrap"
    private const val ASSET_PLUGIN_DIR = "nativeplugins"
    private const val ASSET_PLUGIN_SUFFIX = ".zip.xz"

    private class EngineSpec(
        val engineId: String,
        val installedKey: String,
        val enabledKey: String,
        val versionKey: String,
    )

    private val engines = listOf(
        EngineSpec(
            NativePluginConstants.ENGINE_KIRIKIROID2,
            EnginePrefs.KEY_NATIVE_PLUGIN_KIRIKIROID2_INSTALLED,
            EnginePrefs.KEY_NATIVE_PLUGIN_KIRIKIROID2_ENABLED,
            EnginePrefs.KEY_NATIVE_PLUGIN_KIRIKIROID2_VERSION,
        ),
        EngineSpec(
            NativePluginConstants.ENGINE_ONS,
            EnginePrefs.KEY_NATIVE_PLUGIN_ONS_INSTALLED,
            EnginePrefs.KEY_NATIVE_PLUGIN_ONS_ENABLED,
            EnginePrefs.KEY_NATIVE_PLUGIN_ONS_VERSION,
        ),
        EngineSpec(
            NativePluginConstants.ENGINE_ARTEMIS,
            EnginePrefs.KEY_NATIVE_PLUGIN_ARTEMIS_INSTALLED,
            EnginePrefs.KEY_NATIVE_PLUGIN_ARTEMIS_ENABLED,
            EnginePrefs.KEY_NATIVE_PLUGIN_ARTEMIS_VERSION,
        ),
    )

    /** 启动前插件保障失败原因（P0-6）：核心层只给类型，UI 层映射本地化文案。 */
    sealed interface Failure {
        data class UnknownEngine(val engineId: String) : Failure

        data object InstallFailed : Failure
    }

    /** 幂等：仅对尚未安装的引擎执行一次复制。每次应用启动调用开销极低。 */
    @JvmStatic
    fun provisionIfNeeded(context: Context) {
        val app = context.applicationContext
        for (spec in engines) {
            provisionEngineIfNeeded(app, spec, requireEnabled = false)
        }
    }

    /** 启动前同步保障：对应引擎插件必须已安装、已启用且文件完整。 */
    @JvmStatic
    fun ensureForLaunch(context: Context, engine: EngineType): Failure? {
        val engineId = when (engine) {
            EngineType.KIRIKIRI -> NativePluginConstants.ENGINE_KIRIKIROID2
            EngineType.ONS -> NativePluginConstants.ENGINE_ONS
            EngineType.ARTEMIS -> NativePluginConstants.ENGINE_ARTEMIS
            EngineType.TYRANO,
            EngineType.RPG_MV,
            EngineType.RPG_MZ,
            EngineType.VN,
            EngineType.WEB_OTHER,
            EngineType.SIGLUS,
            EngineType.REALLIVE,
            EngineType.AVG32,
            EngineType.XSYS35,
            EngineType.XSYS4,
            EngineType.SYSTEMNNN,
            EngineType.UK2,
            EngineType.FVP,
            EngineType.ETHORNELL,
            EngineType.IMPACTO,
            EngineType.CMVS,
            EngineType.YURIS,
            EngineType.CATSYSTEM2,
            EngineType.PC,
            EngineType.ANDROID_APP,
            EngineType.RPGMAKER,
            EngineType.RENPY,
            EngineType.RUFFLE,
            EngineType.PSP,
            EngineType.NINTENDO_SWITCH,
            EngineType.RUNTIME_MODULE,
            EngineType.UNKNOWN -> return null
        }
        val app = context.applicationContext
        val spec = engines.firstOrNull { it.engineId == engineId }
            ?: return Failure.UnknownEngine(engineId)
        return if (provisionEngineIfNeeded(app, spec, requireEnabled = true)) {
            null
        } else {
            Failure.InstallFailed
        }
    }

    @Synchronized
    private fun provisionEngineIfNeeded(app: Context, spec: EngineSpec, requireEnabled: Boolean): Boolean {
        val prefs = app.getSharedPreferences(EnginePrefs.APP_PREFS, Context.MODE_PRIVATE)
        val state = installState(app, spec.engineId)
        val bundledVersion = bundledPluginVersion(app, spec.engineId)
        val installedVersion = prefs.getInt(spec.versionKey, 0)
        // 已装插件内容过期（同名 .so 已更新但校验看不出来）时也必须重新解压
        val outdated = state != NativePluginInstallState.NOT_INSTALLED &&
            bundledVersion != null && bundledVersion != installedVersion
        if (state == NativePluginInstallState.INSTALLED_ENABLED && !outdated) {
            markInstalled(prefs, spec, enabled = true, version = bundledVersion)
            return true
        }
        if (!requireEnabled && state == NativePluginInstallState.INSTALLED_DISABLED && !outdated) {
            markInstalled(prefs, spec, enabled = false, version = bundledVersion)
            return true
        }
        if (requireEnabled && state == NativePluginInstallState.INSTALLED_DISABLED && !outdated) {
            markInstalled(prefs, spec, enabled = true, version = bundledVersion)
            return isReady(app, spec.engineId)
        }
        if (outdated) {
            android.util.Log.i(TAG, "re-provision ${spec.engineId}: version $installedVersion -> $bundledVersion")
        }
        return try {
            val target = currentDirFor(app, spec.engineId)
            if (target.exists()) target.deleteRecursively()
            extractPluginZip(app, spec.engineId, target)
            markInstalled(prefs, spec, enabled = true, version = bundledVersion)
            val ready = isReady(app, spec.engineId)
            if (ready) {
                android.util.Log.i(TAG, "provisioned native plugin: ${spec.engineId}")
            } else {
                android.util.Log.w(TAG, "provision ${spec.engineId} finished but validation failed")
            }
            ready
        } catch (t: Throwable) {
            android.util.Log.w(TAG, "provision ${spec.engineId} failed", t)
            false
        }
    }

    /**
     * 打开随包插件：LZMA2 流包住的未压缩 zip。调用方负责 close，会连带关闭底层 asset。
     * 插件资产较大（Kirikiroid2 约 87 MiB 展开），全程流式解压，不整体读入内存。
     */
    private fun openBundledPluginZip(context: Context, engineId: String): ZipInputStream {
        val asset = context.assets.open("$ASSET_PLUGIN_DIR/$engineId$ASSET_PLUGIN_SUFFIX")
        return try {
            ZipInputStream(XZInputStream(asset.buffered()))
        } catch (t: Throwable) {
            // XZInputStream 构造失败时 asset 流尚未交给 ZipInputStream，需要自己关闭。
            runCatching { asset.close() }
            throw t
        }
    }

    /** assets 内插件 zip 的 manifest.pluginVersion；缺失/读取失败返回 null（按不判定过期处理）。 */
    private fun bundledPluginVersion(app: Context, engineId: String): Int? =
        runCatching {
            var version: Int? = null
            openBundledPluginZip(app, engineId).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    if (entry.name == "manifest.json") {
                        val text = zip.readBytes().toString(Charsets.UTF_8)
                        version = JSONObject(text).optInt("pluginVersion", 0)
                        break
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
            version
        }.getOrNull()

    private fun isReady(app: Context, engineId: String): Boolean {
        return installState(app, engineId) == NativePluginInstallState.INSTALLED_ENABLED
    }

    private fun installState(app: Context, engineId: String): NativePluginInstallState {
        val state = when (engineId) {
            NativePluginConstants.ENGINE_KIRIKIROID2 -> NativePluginManager.kirikiroid2InstallState(app)
            NativePluginConstants.ENGINE_ONS -> NativePluginManager.onsInstallState(app)
            NativePluginConstants.ENGINE_ARTEMIS -> NativePluginManager.artemisInstallState(app)
            else -> NativePluginInstallState.INVALID
        }
        return state
    }

    private fun markInstalled(prefs: SharedPreferences, spec: EngineSpec, enabled: Boolean, version: Int?) {
        prefs.edit()
            .putBoolean(spec.installedKey, true)
            .putBoolean(spec.enabledKey, enabled)
            .apply {
                if (version != null) putInt(spec.versionKey, version)
            }
            .apply()
    }

    private fun currentDirFor(app: Context, engineId: String): File = when (engineId) {
        NativePluginConstants.ENGINE_KIRIKIROID2 -> NativePluginManager.kirikiroid2CurrentDir(app)
        NativePluginConstants.ENGINE_ONS -> NativePluginManager.onsCurrentDir(app)
        NativePluginConstants.ENGINE_ARTEMIS -> NativePluginManager.artemisCurrentDir(app)
        else -> error("unknown engine: $engineId")
    }

    private fun extractPluginZip(context: Context, engineId: String, destDir: File) {
        val canonicalDest = destDir.canonicalFile
        val canonicalDestPath = canonicalDest.path + File.separator
        destDir.mkdirs()
        openBundledPluginZip(context, engineId).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                val out = File(destDir, entry.name)
                val canonicalOut = out.canonicalFile
                if (canonicalOut.path != canonicalDest.path &&
                    !canonicalOut.path.startsWith(canonicalDestPath)
                ) {
                    throw SecurityException("Invalid native plugin zip entry: ${entry.name}")
                }
                if (entry.isDirectory) {
                    canonicalOut.mkdirs()
                } else {
                    canonicalOut.parentFile?.mkdirs()
                    canonicalOut.outputStream().use { output -> zip.copyTo(output) }
                }
                zip.closeEntry()
            }
        }
        require(destDir.isDirectory) {
            "native plugin extraction produced no directory: $engineId"
        }
    }
}
