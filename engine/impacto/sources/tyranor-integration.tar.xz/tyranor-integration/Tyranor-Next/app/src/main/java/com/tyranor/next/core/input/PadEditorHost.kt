package com.tyranor.next.core.input

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import com.core.engine.EngineThemeColors
import com.core.input.InputSink
import com.core.input.PadProfile
import com.core.input.VirtualPadEditPanel
import com.core.input.VirtualPadView
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/**
 * 按键布局编辑器的应用层宿主（core 门面）。
 *
 * 为什么需要它：engine 侧的 [VirtualPadView] / [VirtualPadEditPanel] 必须活在游戏宿主
 * 进程内，而设置页希望复用同一套渲染与编辑逻辑（所见即所得）。按三层架构约定 `ui` 层
 * 不得直接 import `com.core.*`，因此由 core 承担这层适配：UI 只拿到一个普通 [rootView]
 * 与保存/取消回调，不接触任何 engine 类型。
 *
 * 生命周期：根视图由本类自建并持有 pad 与编辑面板；UI 在 `AndroidView` 工厂里取
 * [rootView] 挂载即可，Activity 销毁时随视图树回收（pad 的 Handler 在
 * `onDetachedFromWindow` 中清理，本类的协程作用域在根视图 detach 时取消）。
 *
 * 已知边界（取消竞态）：写盘是阻塞 IO，`cancelEdit()`（清会话）只发生在主线程，
 * 无法中断已在 `Dispatchers.IO` 上执行的写盘——用户按返回键「取消」时，若一次写盘
 * 已在途，文件仍可能落盘且 UI 不做任何提示。窗口为一次 fsync 写盘的耗时（毫秒级），
 * 属可接受边界；如需严格语义应在保存前先落「待提交」状态由页面统一裁决（成本较高）。
 */
class PadEditorHost private constructor(
    private val pad: VirtualPadView,
    val rootView: View,
    /**
     * 保存成功回调（**id / 展示名**，不带 engine 的 `PadProfile`）。
     *
     * 签名刻意不出现 engine 类型：本门面的对外承诺是「UI 不接触任何 engine 类型」，
     * 回调解出 `PadProfile` 会让任何需要用到保存结果（显示方案名、保存后跳转）的页面
     * 被迫 `import com.core.input.PadProfile`，直接违反三层架构。
     */
    private val onSavedCallback: (id: String, name: String) -> Unit,
    /**
     * 编辑会话结束（保存成功与取消共用）。
     *
     * 命名刻意不叫 `onCancelled`：保存成功路径也会走到这里（面板收起 + 页面退出）。
     * 若将来在此挂「丢弃草稿」之类的语义，保存路径会误执行。
     */
    private val onEditEndedCallback: () -> Unit,
    private val onSaveFailedCallback: () -> Unit,
) {

    /**
     * 落盘协程：挂在编辑器根视图的生命周期上（detach 即取消）。
     *
     * 可重建：视图被重新挂载时若作用域已取消，保存协程将永远不会执行（界面停在编辑态且
     * 无任何提示），因此 attach 时按需重建（见 `create` 里的挂载监听）。
     */
    private var scope = newScope()

    /**
     * 写入串行化：并发写同一文件时，先发起的旧快照可能后落盘、覆盖掉新会话写下的内容。
     * 会话号只能拦住「迟到结果改 UI」，拦不住落盘顺序，因此这里再加一层互斥。
     */
    private val saveMutex = Mutex()

    private fun newScope() = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    companion object {

        /** 预览用按键出口：设置页里编辑布局不向任何引擎发送输入。 */
        private object PreviewSink : InputSink {
            override fun send(key: Int, down: Boolean) = Unit
            override fun releaseAll() = Unit
        }

        /**
         * 构建编辑器宿主；方案文件缺失/不可读时返回 null（调用方提示并退出，
         * 不在组合期抛异常）。
         *
         * **读盘在 [Dispatchers.IO]**：方案 JSON 解析（最大 1MB）此前发生在调用方
         * （Compose 组合期）的主线程上，属 ANR 风险；视图构建本身仍在调用线程执行，
         * 因此调用方必须在主线程的协程里 await（`LaunchedEffect` 即满足）。
         */
        suspend fun create(
            context: Context,
            profileId: String,
            primaryColor: Int,
            onPrimaryColor: Int,
            onSaved: (id: String, name: String) -> Unit,
            onEditEnded: () -> Unit,
            onSaveFailed: () -> Unit = {},
        ): PadEditorHost? {
            val profile = withContext(Dispatchers.IO) {
                InputRemapRepository.readProfile(context, profileId)
            } ?: return null
            val palette = EngineThemeColors.Palette(
                primary = primaryColor,
                onPrimary = onPrimaryColor,
                card = 0,
                text = 0,
                textMuted = 0,
            )

            val pad = VirtualPadView(context, PreviewSink).apply {
                theme = VirtualPadView.PadTheme(primaryColor, onPrimaryColor)
                this.profile = profile
                setPadVisible(true)
            }
            val root = FrameLayout(context).apply {
                addView(
                    pad,
                    FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT,
                    ),
                )
            }
            val panel = VirtualPadEditPanel.attach(
                parent = root,
                context = context,
                pad = pad,
                theme = palette,
                onSave = { pad.commitEdit() },
                onCancel = { pad.cancelEdit() },
            )
            val host = PadEditorHost(pad, root, onSaved, onEditEnded, onSaveFailed)
            // 落盘协程随视图树销毁：detach 后不该再有人调 onSaved/onSaveFailed；
            // 重新挂载时按需重建（被取消的作用域会让后续保存永不执行）
            root.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
                override fun onViewAttachedToWindow(view: View) {
                    if (!host.scope.isActive) host.scope = host.newScope()
                }

                override fun onViewDetachedFromWindow(view: View) {
                    host.scope.cancel()
                }
            })
            pad.listener = object : VirtualPadView.Listener {
                override fun onEditStarted() = Unit

                override fun onEditEnded() {
                    // 保存与取消都走这里；面板先收起，再交给页面决定是否退出
                    panel.dismiss()
                    host.onEditEndedCallback()
                }

                override fun onSelectionChanged(info: VirtualPadView.SelectionInfo?) {
                    panel.refresh()
                }

                override fun onProfileCommitted(committed: PadProfile) {
                    // 写盘带 fsync，放主线程会在保存瞬间卡住界面：交给 IO 线程，
                    // 结果回主线程再收尾。提交协议据此走「会话号 → 结果校验」两段
                    // （见 VirtualPadView.beginDeferredSave / completeDeferredSave）
                    val session = pad.beginDeferredSave()
                    host.scope.launch {
                        val ok = host.saveMutex.withLock {
                            // 已在锁内再次确认会话：被接替的提交不再写盘，否则旧快照可能
                            // 后落盘把新会话的内容覆盖掉（会话号本身只保证 UI 不被过期结果改）
                            if (!pad.isDeferredSaveCurrent(session)) return@launch
                            runCatching {
                                withContext(Dispatchers.IO) {
                                    InputRemapRepository.writeProfile(context, committed)
                                }
                            }.getOrElse { error ->
                                // 取消（页面退出）必须原样传播，否则会被当成写盘失败误报提示
                                if (error is CancellationException) throw error
                                false
                            }
                        }
                        // 会话已被新的提交接替、或用户已取消/离开：结果不再提示、不再改状态
                        // （否则连点保存会「已保存成功又弹失败」，取消后还会弹过期提示）
                        if (!pad.isDeferredSaveCurrent(session)) return@launch
                        if (ok) {
                            // 先通知页面再收尾：与同步路径一致（页面在 onSaved 里会退出并
                            // 回收视图树），失败时才由页面提示并留在编辑态。
                            // 回调不设防会拖垮收尾：onSaved（Toast + finish）若抛出，异常会从
                            // launch 逃到未捕获处理器（SupervisorJob 只隔离兄弟协程）导致进程
                            // 崩溃，且会话停在 pending、编辑态不收尾。收尾放 finally、回调自身
                            // 的异常吞掉（finally 里的收尾同样包住，避免收尾自身抛出）。
                            try {
                                runCatching { host.onSavedCallback(committed.id, committed.name) }
                            } finally {
                                runCatching { pad.completeDeferredSave(session, true) }
                            }
                        } else {
                            runCatching { pad.completeDeferredSave(session, false) }
                            // 写盘失败：留在编辑态并提示，避免用户改完的布局被静默丢弃
                            runCatching { host.onSaveFailedCallback() }
                        }
                    }
                }

                override fun onPadVisibilityChanged(visible: Boolean) = Unit
            }
            // 进屏即编辑态：等首次布局完成（元素矩形在 onSizeChanged 里计算，
            // 提前进入会拿到空元素表而无法选中）
            pad.post { pad.enterEditMode() }
            return host
        }
    }
}
