package com.tyranor.next.core.settings

import android.content.Context
import com.core.engine.EnginePrefs
import com.tyranor.next.core.game.storage.GameOverridePartitions
import com.tyranor.next.core.game.storage.GameOverridesRepository
import org.json.JSONObject
import java.util.Locale

/**
 * 单游戏（应用级）引擎设置覆盖层。参考 Rinne 的 Per-game 实现：
 * 以每个游戏的稳定标识（本应用用游戏 uri）为键存一份 JSON 覆盖快照；
 * 某字段缺失 = 跟随全局默认。启动时由启动器 覆盖 ?: 全局 逐字段合并。
 *
 * 存储已迁移到 game_overrides 表（迁移方案阶段 4）：本类保留原同步 API，
 * 内部为 Repository 门面——DB 为 App 侧事实源；prefs 文件作为引擎子进程
 * （TyranoActivity / RpgMakerActivity 启动时读取生效设置）的同步镜像，每次写入即刷。
 * prefs 文件名契约锚点在 engine，改名只需改 EnginePrefs 一处。
 */
object PerGameSettingsStore {

    private val PREF_NAME = EnginePrefs.GAME_OVERRIDES_PREFS

    // KR 覆盖字段名
    /** Read-only migration anchor; the removed single-mode UI has no setter. */
    const val F_ANIME4K_MODE = GameOverridePartitions.KEY_KR_LEGACY_ANIME4K_MODE
    const val F_ENGINE_VERSION = "engine_version"
    const val F_ENGINE_KERNEL = "engine_kernel"
    const val F_SCOPED_SAVE_DIR = "scoped_save_dir"
    const val F_DEFAULT_FONT = "default_font"
    const val F_FORCE_DEFAULT_FONT = "force_default_font"
    const val F_PATCH_OVERLAY_MODE = "patch_overlay_mode"
    const val F_SKIP_STARTUP_DIALOGS = "skip_startup_dialogs"
    const val F_RENDERER = "renderer"
    const val F_SOFTWARE_DRAW_THREAD = "software_draw_thread"
    const val F_SOFTWARE_COMPRESS_TEX = "software_compress_tex"
    const val F_OGL_COMPRESS_TEX = "ogl_compress_tex"
    const val F_MEM_USAGE = "mem_usage"
    const val F_OGL_MAX_TEXSIZE = "ogl_max_texsize"
    const val F_OGL_ACCURATE_RENDER = "ogl_accurate_render"
    const val F_FPS_LIMIT = "fps_limit"
    const val F_VCURSOR_SCALE = "vcursor_scale"
    const val F_MENU_HANDLER_OPA = "menu_handler_opa"
    /** KR 渲染偏好覆盖字段清单（由 [KrRenderPrefs] 派生，与全局键一一对应）。 */
    val KR_FIELDS: List<String> = KrRenderPrefs.ALL.map { it.overrideField }

    // Artemis
    const val F_ART_VERSION = "art_engine_version"
    const val F_ART_KERNEL = "artemis_kernel"
    const val F_ART_ROTATE = "art_rotate_screen"
    const val F_ART_PATCH = "art_auto_patch"
    const val F_ART_RESOLUTION = "art_resolution"
    const val F_ART_SIDE_CUT = "art_side_cut"
    const val F_ART_SURFACE_CACHE_SIZE = "art_surface_cache_size"
    const val F_ART_FONT_CACHE_SIZE = "art_font_cache_size"
    const val F_ART_POWER_SAVING = "art_power_saving"
    const val F_ART_ANIME4K_ENABLED = "art_anime4k_enabled"
    const val F_ART_ANIME4K_MODE = "art_anime4k_mode"

    // RPG Maker MV/MZ
    const val F_RPG_MAKER_MOD_ENABLED = "rpg_maker_mod_enabled"
    const val F_RPG_LEGACY_RENDERER = "rpg_legacy_renderer"
    const val F_RPG_SAVE_INTEROP = "rpg_save_interop"
    const val F_RPG_MV_VERSION = "rpg_mv_engine_version"
    const val F_RPG_MZ_VERSION = "rpg_mz_engine_version"

    // 输入重映射（虚拟按键 + 手柄映射）单游戏覆盖键（与 engine InputConfigStore 字面量锚定）
    const val F_INPUT_PAD_ENABLED = "input_pad_enabled"
    const val F_INPUT_GAMEPAD_ENABLED = "input_gamepad_enabled"
    const val F_INPUT_PROFILE_ID = "input_profile_id"

    /** 旧触屏手柄数据迁移标记（本类内部使用：一次性迁移的幂等守卫）。 */
    const val F_LEGACY_MIGRATED = "input_legacy_migrated"

    // RPG Maker RGSS 外置模块（settings extra 的 rpg 节，null=跟随全局）
    const val F_RPG_USE_RUBY18 = "rpg_use_ruby18"
    const val F_RPG_DEBUG = "rpg_debug"
    const val F_RPG_SMOOTH_SCALING = "rpg_smooth_scaling"
    const val F_RPG_VSYNC = "rpg_vsync"
    const val F_RPG_FRAME_SKIP = "rpg_frame_skip"
    const val F_RPG_SOLID_FONTS = "rpg_solid_fonts"
    const val F_RPG_PATH_CACHE = "rpg_path_cache"
    const val F_RPG_PREBUILT_PATH_CACHE = "rpg_prebuilt_path_cache"
    const val F_RPG_FAST_PATH_ENUM = "rpg_fast_path_enum"
    const val F_RPG_COPY_TEXT = "rpg_copy_text"
    const val F_RPG_CHEATS = "rpg_cheats"
    const val F_RPG_USE_CJK_FONT = "rpg_use_cjk_font"
    const val F_RPG_ENABLE_POSTLOAD_SCRIPTS = "rpg_enable_postload_scripts"
    const val F_RPG_CUSTOM_FONT = "rpg_custom_font"
    const val F_RPG_VERTICAL_SCREEN_ALIGN = "rpg_vertical_screen_align"
    const val F_RPG_WINDOW_SIZE = "rpg_window_size"
    const val F_RPG_SPEED_UP = "rpg_speed_up"
    const val F_RPG_FONT_SCALE = "rpg_font_scale"

    // Tyrano 与 RPG Maker Web 共用的存档目录开关（GameSaveManager 按此键读取）
    const val F_TY_SCOPED = "ty_scoped"

    // Ren'Py（外置模块版本选择）
    const val F_RENPY_VERSION = "renpy_engine_version"

    // Web 壳本地端口覆盖（Tyrano / WebOther / VN；null=跟随全局）
    const val F_WEB_SHELL_PORT = "web_shell_port"

    // PPSSPP 外置模拟器版本覆盖（standard/gold；null=跟随全局）
    const val F_PPSSPP_VERSION = "ppsspp_version"

    // Siglus（游戏语言覆盖；null=跟随全局）
    const val F_SIGLUS_LANGUAGE = "siglus_language"

    // framebuffer 引擎（RealLive / AVG32 / UK2）（文本编码覆盖；null=跟随全局）
    const val F_FB_NLS = "fb_nls"

    // FVP（文本编码/系统字体回退/HiDPI/自定义字体覆盖；null=跟随全局）
    const val F_FVP_NLS = "fvp_nls"
    const val F_ETHORNELL_NLS = "ethornell_nls"
    const val F_ETHORNELL_FONT = "ethornell_font"
    const val F_CMVS_FONT = "cmvs_font"
    const val F_FVP_SYSTEM_FONT = "fvp_system_font"
    const val F_FVP_TEXT_HIDPI = "fvp_text_hidpi"
    const val F_FVP_FONT = "fvp_font"

    // System35（独立存档/渲染后端/整数倍缩放/失焦静音覆盖；null=跟随全局）
    const val F_XSYS35_SCOPED_SAVE_DIR = "xsys35_scoped_save_dir"
    const val F_XSYS35_RENDERER = "xsys35_renderer"
    const val F_XSYS35_INTEGER_SCALE = "xsys35_integer_scale"
    const val F_XSYS35_MUTE_UNFOCUS = "xsys35_mute_unfocus"

    // System4（独立存档/文本编码/自定义字体/手柄/跳字延迟覆盖；null=跟随全局）
    const val F_XSYS4_SCOPED_SAVE_DIR = "xsys4_scoped_save_dir"
    const val F_XSYS4_ENCODING = "xsys4_encoding"
    const val F_XSYS4_FONT_GOTHIC_PATH = "xsys4_font_gothic_path"
    const val F_XSYS4_FONT_MINCHO_PATH = "xsys4_font_mincho_path"
    const val F_XSYS4_JOYPAD = "xsys4_joypad"
    const val F_XSYS4_MSGSKIP_DELAY = "xsys4_msgskip_delay"

    // Winlator 外置启动（null=跟随全局；字符串 "" = 显式不下发该参数）
    const val F_WINLATOR_MODE = "winlator_mode"
    const val WINLATOR_MODE_GLOBAL = "global"
    const val WINLATOR_MODE_CONTAINER = "container"
    const val WINLATOR_MODE_CUSTOM = "custom"
    const val F_WINLATOR_CONTAINER_ID = "winlator_container_id"
    const val F_WINLATOR_CONTAINER_NAME = "winlator_container_name"
    const val F_WINLATOR_GRAPHICS_DRIVER = "winlator_graphics_driver"
    const val F_WINLATOR_DXWRAPPER = "winlator_dxwrapper"
    const val F_WINLATOR_SCREEN_SIZE = "winlator_screen_size"
    const val F_WINLATOR_LC_ALL = "winlator_lc_all"
    const val F_WINLATOR_TZ = "winlator_tz"
    const val F_WINLATOR_BOX64_PRESET = "winlator_box64_preset"
    const val F_WINLATOR_SAVE = "winlator_save"

    // Ren'Py 外置模块配置（settings extra 的 renpy 节 + app.cheats，null=跟随全局）
    const val F_RENPY_CHEATS = "renpy_cheats"
    const val F_RENPY_HW_VIDEO = "renpy_hw_video"
    const val F_RENPY_AUTOSAVE = "renpy_autosave"
    const val F_RENPY_PHONE_SMALL_VARIANT = "renpy_phonesmallvariant"
    const val F_RENPY_VSYNC = "renpy_vsync"
    const val F_RENPY_LESS_MEMORY = "renpy_less_memory"
    const val F_RENPY_LESS_UPDATES = "renpy_less_updates"
    const val F_RENPY_DONT_USE_GL2 = "renpy_dont_use_gl2"
    const val F_RENPY_RECOMPILE = "renpy_recompile"

    // Ruffle 外置模块配置覆盖（与全局键同名；null=跟随全局）
    const val F_RUFFLE_SCREEN_TIMEOUT = "ruffle_screen_timeout"
    const val F_RUFFLE_BACKEND = "ruffle_backend"
    const val F_RUFFLE_QUALITY = "ruffle_quality"
    const val F_RUFFLE_SCALE_MODE = "ruffle_scale_mode"
    const val F_RUFFLE_LETTERBOX = "ruffle_letterbox"
    const val F_RUFFLE_LOAD_BEHAVIOR = "ruffle_load_behavior"

    // ONS 子对象键
    const val ONS_KEY = "ons"

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    /** 该游戏是否存在覆盖。 */
    fun hasOverride(context: Context, gameId: String): Boolean {
        if (gameId.isBlank()) return false
        return GameOverridesRepository.loadRowBlocking(context, gameId) != null
    }

    /**
     * 存在单游戏覆盖的游戏 id 列表。
     *
     * 用于「删除方案后清理指向它的引用」这类需要反向扫描覆盖的场景。
     * prefs 镜像按 gameId 为键存储，键集即全部有覆盖的游戏。
     */
    fun overrideGameIds(context: Context): Set<String> =
        runCatching { prefs(context).all.keys.toSet() }.getOrDefault(emptySet())

    /** 读取该游戏覆盖 JSON；无则返回空对象。 */
    fun load(context: Context, gameId: String): JSONObject {
        if (gameId.isBlank()) return JSONObject()
        val row = GameOverridesRepository.loadRowBlocking(context, gameId) ?: return JSONObject()
        return runCatching { GameOverridePartitions.assemble(row) }.getOrDefault(JSONObject())
    }

    fun getGraphicsOverride(context: Context, gameId: String, family: GraphicsFamily): GraphicsOverride =
        GraphicsSettingsCodec.readOverride(load(context, gameId), family)

    /** Keeps the version marker even for full inheritance, and preserves every unrelated/legacy key. */
    fun setGraphicsOverride(context: Context, gameId: String, family: GraphicsFamily, value: GraphicsOverride) {
        if (gameId.isBlank()) return
        val json = load(context, gameId)
        json.put(family.overrideKey, GraphicsSettingsCodec.encode(value))
        persist(context, gameId, json)
    }

    /** 字符串字段覆盖值；null=未覆盖（跟随全局），""=覆盖为空串（如内置字体）。 */
    fun getStr(context: Context, gameId: String, key: String): String? {
        val j = load(context, gameId)
        return if (j.has(key)) j.optString(key) else null
    }

    /** 布尔字段覆盖值；null=未覆盖（跟随全局）。 */
    fun getBool(context: Context, gameId: String, key: String): Boolean? {
        val j = load(context, gameId)
        return if (j.has(key)) j.optBoolean(key) else null
    }

    /** 设置字符串覆盖；value=null 表示移除该覆盖（跟随全局）。 */
    fun setStr(context: Context, gameId: String, key: String, value: String?) {
        if (gameId.isBlank()) return
        val j = load(context, gameId)
        if (value == null) j.remove(key) else j.put(key, value.trim())
        persist(context, gameId, j)
    }

    /** 设置布尔覆盖；value=null 表示移除该覆盖（跟随全局）。 */
    fun setBool(context: Context, gameId: String, key: String, value: Boolean?) {
        if (gameId.isBlank()) return
        val j = load(context, gameId)
        if (value == null) j.remove(key) else j.put(key, value)
        persist(context, gameId, j)
    }

    /** 读取 ONS 覆盖子对象（缺失字段=跟随全局）。 */
    fun loadOnsOverride(context: Context, gameId: String): JSONObject? {
        val j = load(context, gameId)
        return if (j.has(ONS_KEY)) j.optJSONObject(ONS_KEY) else null
    }

    /** ONS 覆盖 JSON → 类型化模型（缺失字段=跟随全局，供 [EffectiveEngineSettings.mergeOns] 使用）。 */
    fun toOnsOverride(json: JSONObject?): OnsOverride? {
        if (json == null) return null
        return OnsOverride(
            scopedSaveDir = if (json.has("scopedsavedir")) json.optBoolean("scopedsavedir") else null,
            stretchFull = if (json.has("strechfull")) json.optBoolean("strechfull") else null,
            ignoreCutout = if (json.has("ignorecutout")) json.optBoolean("ignorecutout") else null,
            disableVideo = if (json.has("disablevideo")) json.optBoolean("disablevideo") else null,
            sharpness = if (json.has("sharpness")) json.optBoolean("sharpness") else null,
            sharpnessValue = if (json.has("sharpness_value")) json.optString("sharpness_value") else null,
            encoding = if (json.has("encoding")) json.optString("encoding") else null,
        )
    }

    /** 保存 ONS 覆盖子对象。 */
    fun setOnsOverride(context: Context, gameId: String, ons: JSONObject) {
        if (gameId.isBlank()) return
        val j = load(context, gameId)
        j.put(ONS_KEY, ons)
        persist(context, gameId, j)
    }

    /**
     * RPG Maker RGSS 外置模块覆盖快照 → 类型化模型（缺失字段=跟随全局，
     * 供 [EffectiveEngineSettings.mergeRpgMaker] 使用）。
     */
    fun toRpgMakerOverride(json: JSONObject?): RpgMakerOverride? {
        if (json == null) return null
        fun boolOrNull(key: String): Boolean? = if (json.has(key)) json.optBoolean(key) else null
        fun strOrNull(key: String): String? = if (json.has(key)) json.optString(key) else null
        val override = RpgMakerOverride(
            useRuby18 = boolOrNull(F_RPG_USE_RUBY18),
            debug = boolOrNull(F_RPG_DEBUG),
            smoothScaling = boolOrNull(F_RPG_SMOOTH_SCALING),
            vsync = boolOrNull(F_RPG_VSYNC),
            frameSkip = boolOrNull(F_RPG_FRAME_SKIP),
            solidFonts = boolOrNull(F_RPG_SOLID_FONTS),
            pathCache = boolOrNull(F_RPG_PATH_CACHE),
            prebuiltPathCache = boolOrNull(F_RPG_PREBUILT_PATH_CACHE),
            fastPathEnum = boolOrNull(F_RPG_FAST_PATH_ENUM),
            copyText = boolOrNull(F_RPG_COPY_TEXT),
            cheats = boolOrNull(F_RPG_CHEATS),
            useCJKFont = boolOrNull(F_RPG_USE_CJK_FONT),
            enablePostloadScripts = boolOrNull(F_RPG_ENABLE_POSTLOAD_SCRIPTS),
            customFont = strOrNull(F_RPG_CUSTOM_FONT),
            verticalScreenAlign = strOrNull(F_RPG_VERTICAL_SCREEN_ALIGN),
            windowSize = strOrNull(F_RPG_WINDOW_SIZE),
            speedUp = strOrNull(F_RPG_SPEED_UP),
            fontScale = strOrNull(F_RPG_FONT_SCALE),
        )
        return override.takeIf { it != RpgMakerOverride() }
    }

    /**
     * Ren'Py 外置模块覆盖快照 → 类型化模型（缺失字段=跟随全局，
     * 供 [EffectiveEngineSettings.mergeRenPy] 使用）。版本键不在此列。
     */
    fun toRenPyOverride(json: JSONObject?): RenPyOverride? {
        if (json == null) return null
        fun boolOrNull(key: String): Boolean? = if (json.has(key)) json.optBoolean(key) else null
        val override = RenPyOverride(
            cheats = boolOrNull(F_RENPY_CHEATS),
            hwVideo = boolOrNull(F_RENPY_HW_VIDEO),
            autosave = boolOrNull(F_RENPY_AUTOSAVE),
            phoneSmallVariant = boolOrNull(F_RENPY_PHONE_SMALL_VARIANT),
            vsync = boolOrNull(F_RENPY_VSYNC),
            lessMemory = boolOrNull(F_RENPY_LESS_MEMORY),
            lessUpdates = boolOrNull(F_RENPY_LESS_UPDATES),
            dontUseGl2 = boolOrNull(F_RENPY_DONT_USE_GL2),
            recompile = boolOrNull(F_RENPY_RECOMPILE),
        )
        return override.takeIf { it != RenPyOverride() }
    }

    /**
     * Ruffle 外置模块覆盖快照 → 类型化模型（缺失字段=跟随全局，
     * 供 [EffectiveEngineSettings.mergeRuffle] 使用）。screenTimeout 按字符串存储以保持覆盖层一致。
     */
    fun toRuffleOverride(json: JSONObject?): RuffleOverride? {
        if (json == null) return null
        // 五个枚举字段统一 trim/lowercase，保证 load → merge → save 使用同一比较口径；
        // screenTimeout 是数值字符串，交给 mergeRuffle 自行 trim + toIntOrNull。
        fun strOrNull(key: String): String? =
            if (json.has(key)) json.optString(key).trim().lowercase(Locale.ROOT) else null
        val override = RuffleOverride(
            screenTimeout = if (json.has(F_RUFFLE_SCREEN_TIMEOUT)) json.optString(F_RUFFLE_SCREEN_TIMEOUT) else null,
            backend = strOrNull(F_RUFFLE_BACKEND),
            quality = strOrNull(F_RUFFLE_QUALITY),
            scaleMode = strOrNull(F_RUFFLE_SCALE_MODE),
            letterbox = strOrNull(F_RUFFLE_LETTERBOX),
            loadBehavior = strOrNull(F_RUFFLE_LOAD_BEHAVIOR),
        )
        return override.takeIf { it != RuffleOverride() }
    }

    /**
     * 1.61 的六个旧参数键：只用于「六键都存在且全为空串 → 跟随容器」的迁移判定。
     * 新增覆盖字段时不要动这个列表，否则历史记录会被误判。
     */
    private val LEGACY_CONTAINER_FIELDS = listOf(
        F_WINLATOR_GRAPHICS_DRIVER,
        F_WINLATOR_DXWRAPPER,
        F_WINLATOR_SCREEN_SIZE,
        F_WINLATOR_LC_ALL,
        F_WINLATOR_TZ,
        F_WINLATOR_BOX64_PRESET,
    )

    /**
     * 当前全部逐游戏参数覆盖键（独立清单，不等于旧六键）：新增字段必须同时登记到这里，
     * 否则「只写了新字段」的记录会被判成全局。
     */
    internal val CURRENT_OVERRIDE_FIELDS = listOf(
        F_WINLATOR_GRAPHICS_DRIVER,
        F_WINLATOR_DXWRAPPER,
        F_WINLATOR_SCREEN_SIZE,
        F_WINLATOR_LC_ALL,
        F_WINLATOR_TZ,
        F_WINLATOR_BOX64_PRESET,
    )

    /**
     * 单游戏运行模式：global（默认）/ container / custom。
     * 旧数据严格按 1.61 的 null / "" / 值语义迁移。
     */
    fun getWinlatorMode(context: Context, gameId: String): String = inferWinlatorMode(load(context, gameId))

    /** [getWinlatorMode] 的纯函数部分：按 1.61 的 null / "" / 值语义推断模式，便于 JVM 回归。 */
    internal fun inferWinlatorMode(json: JSONObject): String {
        val mode = json.optString(F_WINLATOR_MODE, "")
        if (mode == WINLATOR_MODE_GLOBAL || mode == WINLATOR_MODE_CONTAINER || mode == WINLATOR_MODE_CUSTOM) {
            return mode
        }
        // 未知的非空 mode 不直接判全局：继续走下面的字段推断，尽量保留可解释的旧数据。

        val legacyPresent = LEGACY_CONTAINER_FIELDS.filter { json.has(it) }
        val legacyAllBlank =
            legacyPresent.size == LEGACY_CONTAINER_FIELDS.size &&
                LEGACY_CONTAINER_FIELDS.all { json.optString(it).isEmpty() }
        // 任一当前覆盖字段有值即自定义；用当前字段清单而不是「旧六键数量」，避免新增字段被漏判。
        val anyNonEmptyCurrent = CURRENT_OVERRIDE_FIELDS.any { json.has(it) && json.optString(it).isNotEmpty() }
        if (anyNonEmptyCurrent) return WINLATOR_MODE_CUSTOM
        // 六个旧参数全空是「跟随容器」的强信号，必须优先于单独出现的容器字段判断：
        // 这类记录在 1.61 里本来就走容器基线，若判成 custom 会把 save 继承成全局值。
        if (legacyAllBlank) return WINLATOR_MODE_CONTAINER
        if (legacyPresent.isNotEmpty()) return WINLATOR_MODE_CUSTOM
        if (json.has(F_WINLATOR_CONTAINER_ID) || json.has(F_WINLATOR_CONTAINER_NAME)) {
            return WINLATOR_MODE_CUSTOM
        }
        // save 是真实的逐游戏覆盖（仅「自定义」模式写入）：只有它一条的旧记录不能回落到全局，
        // 否则会丢掉玩家原有的「写回容器配置」。
        if (json.has(F_WINLATOR_SAVE)) return WINLATOR_MODE_CUSTOM
        return WINLATOR_MODE_GLOBAL
    }

    fun setWinlatorMode(context: Context, gameId: String, mode: String) {
        setStr(context, gameId, F_WINLATOR_MODE, mode)
    }

    /**
     * Winlator 外置启动覆盖快照 → 类型化模型（缺失字段=跟随全局；存在但为空串=显式不下发该参数，
     * 供 [EffectiveEngineSettings.mergeWinlator] 使用）。
     */
    fun toWinlatorOverride(json: JSONObject?): WinlatorOverride? {
        if (json == null) return null
        fun boolOrNull(key: String): Boolean? = if (json.has(key)) json.optBoolean(key) else null
        fun strOrNull(key: String): String? = if (json.has(key)) json.optString(key) else null
        val override = WinlatorOverride(
            // 旧数据的 "" 与 null 语义不同："" = 显式不下发该字段（1.61 的弹窗确认空值），
            // null = 未覆盖、继承全局。不能把空串归一成 null，否则升级后会改用全局容器。
            containerId = strOrNull(F_WINLATOR_CONTAINER_ID),
            containerName = strOrNull(F_WINLATOR_CONTAINER_NAME),
            graphicsDriver = strOrNull(F_WINLATOR_GRAPHICS_DRIVER),
            dxwrapper = strOrNull(F_WINLATOR_DXWRAPPER),
            screenSize = strOrNull(F_WINLATOR_SCREEN_SIZE),
            lcAll = strOrNull(F_WINLATOR_LC_ALL),
            tz = strOrNull(F_WINLATOR_TZ),
            box64Preset = strOrNull(F_WINLATOR_BOX64_PRESET),
            save = boolOrNull(F_WINLATOR_SAVE),
        )
        return override.takeIf { it != WinlatorOverride() }
    }

    /** 清除某游戏全部覆盖，回退到全局默认。 */
    fun clear(context: Context, gameId: String) {
        if (gameId.isBlank()) return
        GameOverridesRepository.clearRow(context, gameId)
        prefs(context).edit().remove(gameId).apply()
    }

    /**
     * 双写持久化：DB 异步落库（失败仅记日志），prefs 同步镜像立即刷盘——
     * 引擎子进程启动游戏时按契约整条读取镜像（方案阶段 4 过渡策略）。
     *
     * 写路径已全部收敛到 app 侧：引擎只读镜像，不再回写任何字段，因此不存在
     * 「app 进程的 prefs 缓存与引擎写入互相覆盖」的问题（跨进程 prefs 缓存不共享，
     * 但单向只读不受其影响）。镜像的权威来源仍是 DB，进程启动时由
     * `GameOverridesRepository.syncFromPrefs` 回灌保证历史数据不丢。
     */
    private fun persist(context: Context, gameId: String, record: JSONObject) {
        GameOverridesRepository.updateRecord(context, gameId, record)
        prefs(context).edit().putString(gameId, record.toString()).apply()
    }
}
