package com.tyranor.next.core.game.save

import com.tyranor.next.core.engine.EngineType
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertThrows
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

class RpgSaveSyncTest {
    @get:Rule
    val temporaryFolder = TemporaryFolder()

    private fun store(): RpgSaveSyncState = RpgSaveSyncState(temporaryFolder.newFolder("state"))

    /** MV 转化/导入后的实际落盘名（key_<sha256(键)>.bin），与实现同源，避免手抄哈希。 */
    private fun mvName(standardName: String): String =
        requireNotNull(RpgSaveFormat.tyranorFileNameForStandard(standardName, EngineType.RPG_MV))

    /** 建一个两侧目录并返回 (standard, tyranor)。 */
    private fun dirs(): Pair<File, File> {
        val standard = temporaryFolder.newFolder("save")
        val tyranor = temporaryFolder.newFolder("savedata")
        return standard to tyranor
    }

    private fun File.writeAt(name: String, content: String, mtime: Long): File {
        val f = resolve(name)
        f.writeText(content)
        f.setLastModified(mtime)
        return f
    }

    @Test
    fun importsNewStandardSaveIntoTyranor() {
        val (standard, tyranor) = dirs()
        standard.writeAt("file1.rpgsave", "PC-SAVE", 1_000)

        val result = RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store(), "g")

        assertEquals(1, result.imported)
        assertEquals("PC-SAVE", tyranor.resolve(mvName("file1.rpgsave")).readText())
        // 标准侧保留，供 PC 使用
        assertTrue(standard.resolve("file1.rpgsave").isFile)
    }

    @Test
    fun exportsNewTyranorSaveToStandard() {
        val (standard, tyranor) = dirs()
        tyranor.writeAt("RPG File2.bin", "PHONE-SAVE", 1_000)

        val result = RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store(), "g")

        assertEquals(1, result.exported)
        assertEquals("PHONE-SAVE", standard.resolve("file2.rpgsave").readText())
        assertTrue(tyranor.resolve("RPG File2.bin").isFile)
    }

    @Test
    fun newerStandardWinsAndPropagatesMtime() {
        val (standard, tyranor) = dirs()
        standard.writeAt("global.rpgsave", "NEW-PC", 5_000)
        tyranor.writeAt(mvName("global.rpgsave"), "OLD-PHONE", 1_000)
        val store = store()

        val result = RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store, "g")

        assertEquals(1, result.toTyranor)
        assertEquals("NEW-PC", tyranor.resolve(mvName("global.rpgsave")).readText())
        assertEquals(5_000, tyranor.resolve(mvName("global.rpgsave")).lastModified())
        // 幂等：再同步一次应为 skipped
        val second = RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store, "g")
        assertEquals(1, second.skipped)
        assertEquals(0, second.changed)
    }

    @Test
    fun newerTyranorWinsAndPropagatesMtime() {
        val (standard, tyranor) = dirs()
        standard.writeAt("global.rpgsave", "OLD-PC", 1_000)
        tyranor.writeAt(mvName("global.rpgsave"), "NEW-PHONE", 9_000)

        val result = RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store(), "g")

        assertEquals(1, result.toStandard)
        assertEquals("NEW-PHONE", standard.resolve("global.rpgsave").readText())
        assertEquals(9_000, standard.resolve("global.rpgsave").lastModified())
    }

    @Test
    fun tyranorDeletionMovesStandardFileToDeleted() {
        val (standard, tyranor) = dirs()
        val store = store()
        standard.writeAt("file3.rpgsave", "S", 1_000)
        tyranor.writeAt("RPG File3.bin", "S", 1_000)
        assertEquals(0, RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store, "g").changed)

        // Tyranor 侧删除该槽位
        tyranor.resolve("RPG File3.bin").delete()
        val result = RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store, "g")

        assertEquals(1, result.movedToDeleted)
        assertFalse(standard.resolve("file3.rpgsave").exists())
        assertTrue(standard.resolve("deleted/file3.rpgsave").isFile)
        // 不反向删除已删存档
        assertFalse(tyranor.resolve("RPG File3.bin").exists())
    }

    @Test
    fun standardDeletionKeepsTyranorAndReExports() {
        val (standard, tyranor) = dirs()
        val store = store()
        standard.writeAt("file4.rpgsave", "S", 1_000)
        tyranor.writeAt("RPG File4.bin", "S", 1_000)
        RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store, "g")

        // 外部（PC 清理）删了标准文件：不得删掉手机存档
        standard.resolve("file4.rpgsave").delete()
        val result = RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store, "g")

        assertEquals(1, result.exported)
        assertTrue(tyranor.resolve("RPG File4.bin").isFile)
        assertEquals("S", standard.resolve("file4.rpgsave").readText())
    }

    @Test
    fun hashNamedTyranorSaveIsExportedToStandard() {
        val (standard, tyranor) = dirs()
        // key_938e37... == sha256("RPG File3")
        val slot3 = "key_938e37cbcee031a9bc044e6e784523ae2ee39d0cc30a060d16aedd0da815c8e5.bin"
        tyranor.writeAt(slot3, "HASHED", 2_000)

        val result = RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store(), "g")

        assertEquals(1, result.exported)
        assertEquals("HASHED", standard.resolve("file3.rpgsave").readText())
    }

    @Test
    fun unmappedHashedSaveIsReportedAndUntouched() {
        val (standard, tyranor) = dirs()
        val unknown = "key_" + "0".repeat(64) + ".bin"
        tyranor.writeAt(unknown, "X", 1_000)

        val result = RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store(), "g")

        assertEquals(1, result.unmapped)
        assertEquals(0, result.exported)
        assertTrue(tyranor.resolve(unknown).isFile)
    }

    @Test
    fun originalAndDeletedSubdirsAreNotSynced() {
        val (standard, tyranor) = dirs()
        tyranor.resolve("original").mkdirs()
        tyranor.resolve("original/global.rpgsave").writeText("LEFTOVER")
        standard.resolve("deleted").mkdirs()
        standard.resolve("deleted/file9.rpgsave").writeText("LEFT")

        val result = RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store(), "g")

        assertEquals(0, result.changed)
        assertFalse(standard.resolve("global.rpgsave").exists())
    }

    @Test
    fun mvBackupSlotIsSynced() {
        val (standard, tyranor) = dirs()
        standard.writeAt("file1.rpgsave.bak", "BAK", 1_000)

        val result = RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store(), "g")

        assertEquals(1, result.imported)
        assertEquals("BAK", tyranor.resolve(mvName("file1.rpgsave.bak")).readText())
    }

    @Test
    fun mzMappingIsUsedForMzEngine() {
        val (standard, tyranor) = dirs()
        standard.writeAt("global.rmmzsave", "MZ", 1_000)
        tyranor.writeAt("file1.bin", "MZ-1", 2_000)

        val result = RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MZ, store(), "g")

        assertEquals(1, result.imported)
        assertEquals(1, result.exported)
        assertEquals("MZ", tyranor.resolve("global.bin").readText())
        assertEquals("MZ-1", standard.resolve("file1.rmmzsave").readText())
    }

    @Test
    fun firstRunOverwritePreservesLoserOnTyranorSide() {
        // 首次同步（无清单）：标准侧 mtime 被复制刷新成较新，覆盖前须把手机存档留底
        val (standard, tyranor) = dirs()
        standard.writeAt("global.rpgsave", "PC", 9_000)
        tyranor.writeAt("RPG Global.bin", "PHONE", 1_000)

        val result = RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store(), "g")

        assertEquals(1, result.toTyranor)
        assertEquals("PC", tyranor.resolve(mvName("global.rpgsave")).readText())
        // 同槽位旧 legacy 名必须让位（否则遮蔽新数据）：内容移入 original/，不丢
        assertTrue(tyranor.resolve("original/RPG Global.bin").isFile)
        assertEquals("PHONE", tyranor.resolve("original/RPG Global.bin").readText())
    }

    @Test
    fun firstRunOverwritePreservesLoserOnStandardSide() {
        val (standard, tyranor) = dirs()
        standard.writeAt("global.rpgsave", "PC", 1_000)
        tyranor.writeAt("RPG Global.bin", "PHONE", 9_000)

        val result = RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store(), "g")

        assertEquals(1, result.toStandard)
        assertEquals("PHONE", standard.resolve("global.rpgsave").readText())
        assertTrue(standard.resolve("deleted/global.rpgsave").isFile)
        assertEquals("PC", standard.resolve("deleted/global.rpgsave").readText())
    }

    @Test
    fun establishedSlotDoesNotKeepBackingUpOnEachOverwrite() {
        // 已有清单后再次覆盖不应再留底（避免无限膨胀）
        val (standard, tyranor) = dirs()
        val store = store()
        standard.writeAt("global.rpgsave", "A", 1_000)
        RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store, "g")

        standard.writeAt("global.rpgsave", "B", 5_000)
        val first = RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store, "g")
        assertEquals(1, first.toTyranor)

        standard.writeAt("global.rpgsave", "C", 9_000)
        val second = RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store, "g")
        assertEquals(1, second.toTyranor)
        assertEquals("C", tyranor.resolve(mvName("global.rpgsave")).readText())
        // original/ 里没有累积副本（清单已建立，无需再留底）
        assertFalse(tyranor.resolve("original").isDirectory)
    }

    @Test
    fun uppercaseSaveDirectoryIsSyncedAndWrittenInPlace() {
        // 兼容 Save/：槽位已在 Save/ 中存在时就地更新（大小写不敏感文件系统上 save==Save）
        val parent = temporaryFolder.newFolder("www")
        val lower = parent.resolve("save")
        val upper = parent.resolve("Save").apply { mkdirs() }
        val tyranor = temporaryFolder.newFolder("savedata")
        upper.writeAt("global.rpgsave", "FROM-UPPER", 1_000)
        val store = store()

        val result = RpgSaveSync.sync(
            standardDirs = listOf(lower, upper),
            tyranorDir = tyranor,
            engine = EngineType.RPG_MV,
            stateStore = store,
            gameKey = "g",
        )

        assertEquals(1, result.imported)
        assertEquals("FROM-UPPER", tyranor.resolve(mvName("global.rpgsave")).readText())
        // 回写应落在该已存在的标准目录内（不另造目录）
        tyranor.resolve(mvName("global.rpgsave")).apply { writeText("NEW"); setLastModified(9_000) }
        val second = RpgSaveSync.sync(listOf(lower, upper), tyranor, EngineType.RPG_MV, store, "g")
        assertEquals(1, second.toStandard)
        assertEquals("NEW", upper.resolve("global.rpgsave").readText())
        assertEquals(1, parent.listFiles().orEmpty().count { it.name.equals("save", ignoreCase = true) })
    }

    @Test
    fun uppercaseSaveIsWrittenWhenItIsTheOnlyExistingDir() {
        // 只有 Save/ 存在时，无槽位的新导出应写入该目录。
        // 注意：**候选目录的排序**由 RpgSaveFormat.standardSaveDirectories 负责（已存在的目录排首位），
        // RpgSaveSync 只写 standardDirs.first()（见其 KDoc）。因此这里必须走真实排序函数，
        // 不能手工构造 listOf(lower, upper) 来断言「sync 自己会挑存在的那个」——
        // 该断言在大小写不敏感的文件系统（Windows/macOS）上会因两个拼写折叠为同一目录而假通过，
        // 在区分大小写的文件系统（Linux CI / Android 真机 ext4）上必然失败。
        val root = temporaryFolder.newFolder("game")
        // www/index.html 是内容根标记（locateContentRoot 据此把 www 认作内容根）
        val www = File(root, "www").apply { mkdirs() }
        File(www, "index.html").writeText("<html></html>")
        val upper = File(www, "Save").apply { mkdirs() }
        val tyranor = temporaryFolder.newFolder("savedata")
        tyranor.writeAt("RPG File1.bin", "PHONE", 1_000)

        val standardDirs = RpgSaveFormat.standardSaveDirectories(root)
        val target = standardDirs.first()
        // 首位必须是**已存在**的目录：区分大小写的文件系统上，若实现把不存在的小写 save 排在前面，
        // 导出就会新建 save/ 而游戏读的是 Save/（存档「消失」）。大小写不敏感的文件系统上两个拼写
        // 本就是同一目录，用 isSameFile 判定才不会因路径大小写不同而误报。
        assertTrue("首位候选必须是已存在的标准目录", target.isDirectory)
        assertTrue(
            "写入目录必须就是那个已存在的 Save",
            java.nio.file.Files.isSameFile(upper.toPath(), target.toPath()),
        )

        val result = RpgSaveSync.sync(standardDirs, tyranor, EngineType.RPG_MV, store(), "g")

        assertEquals(1, result.exported)
        assertEquals("PHONE", upper.resolve("file1.rpgsave").readText())
        assertEquals(1, www.listFiles().orEmpty().count { it.name.equals("save", ignoreCase = true) })
    }

    @Test
    fun preserveFailureAbortsOverwriteAndKeepsBothCopies() {
        // 留底（original/）创建失败时不得继续覆盖：否则较旧的唯一手机存档会在没有留底的情况下被抹掉
        val (standard, tyranor) = dirs()
        standard.writeAt("global.rpgsave", "PC-NEW", 9_000)
        tyranor.writeAt("RPG Global.bin", "PHONE-OLD", 1_000)
        // 用同名文件占位 original/，迫使 preserveLoser 无法创建留底目录
        tyranor.resolve("original").writeText("block")

        val result = RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store(), "g")

        assertEquals(1, result.failed)
        assertEquals(0, result.toTyranor)
        assertEquals("PHONE-OLD", tyranor.resolve("RPG Global.bin").readText())
        assertEquals("PC-NEW", standard.resolve("global.rpgsave").readText())
    }

    @Test
    fun sameMtimeDifferentContentIsNotSkipped() {
        // mtime 相同、长度也相同（长度校验挡不住）但内容不同：必须靠内容哈希识别，不能跳过
        val (standard, tyranor) = dirs()
        standard.writeAt("global.rpgsave", "PC-CONTENT", 5_000)
        tyranor.writeAt("RPG Global.bin", "PHONE-DIFF", 5_000)

        val result = RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store(), "g")

        assertEquals(0, result.skipped)
        assertEquals(1, result.toTyranor + result.toStandard)
        // 平局以标准侧为准，且较旧一方须留底（平局下新旧未知）
        assertEquals("PC-CONTENT", tyranor.resolve(mvName("global.rpgsave")).readText())
        assertTrue(tyranor.resolve("original/RPG Global.bin").isFile)
    }

    /**
     * 平局 + Tyranor 侧**已是规范名**（本改动后的常态）：必须留底。
     *
     * 旧实现用 `!sameAsTarget` 判断是否留底，规范名时被跳过 → 直接原地覆盖、无 original/ 备份，
     * 而平局下较旧一方未知，与「留底才能保证不丢任何一份」的契约矛盾。
     */
    @Test
    fun tieWithCanonicalTyranorNameStillPreservesLoser() {
        val (standard, tyranor) = dirs()
        standard.writeAt("global.rpgsave", "PC-CONTENT", 5_000)
        // 关键：Tyranor 侧用**规范名**（而非 legacy 名），旧实现的测试盲区
        val canonical = mvName("global.rpgsave")
        tyranor.writeAt(canonical, "PHONE-OLD", 5_000)

        val result = RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store(), "g")

        assertEquals(0, result.skipped)
        assertEquals("PC-CONTENT", tyranor.resolve(canonical).readText())
        assertEquals(
            "规范名平局时必须留底（旧实现此处无备份）",
            "PHONE-OLD",
            tyranor.resolve("original/$canonical").readText(),
        )
    }

    /** 首同步（无历史记录）+ 规范名：同样必须留底。 */
    @Test
    fun firstSyncWithCanonicalNamePreservesTarget() {
        val (standard, tyranor) = dirs()
        standard.writeAt("file1.rpgsave", "PC-NEW", 9_000)
        val canonical = mvName("file1.rpgsave")
        tyranor.writeAt(canonical, "PHONE-OLD", 1_000)

        val result = RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store(), "g")

        assertEquals(1, result.toTyranor)
        assertEquals("PC-NEW", tyranor.resolve(canonical).readText())
        assertEquals(
            "首次同步覆盖规范名目标时必须留底",
            "PHONE-OLD",
            tyranor.resolve("original/$canonical").readText(),
        )
    }

    /**
     * 非首同步且**存在 legacy 同名槽位**时，规范名目标被覆盖前也必须留底。
     *
     * 旧实现只在 `mustPreserveTarget`（平局/首同步）为真时留底，非首同步下
     * 规范名目标的旧内容会被直接覆盖且无备份 —— 本用例两轮构造出该条件：
     * 第 1 轮建立槽位历史（hadPrevious=true），第 2 轮制造 legacy + 规范名并存且标准侧更新。
     */
    @Test
    fun canonicalTargetIsPreservedWhenLegacySiblingExists() {
        val (standard, tyranor) = dirs()
        val canonical = mvName("file2.rpgsave")
        // 两轮共用同一 state（状态需跨轮累积，才能构造出 hadPrevious=true）
        val state = store()
        // 第 1 轮：两侧同内容，建立槽位历史
        standard.writeAt("file2.rpgsave", "SAME", 5_000)
        tyranor.writeAt("RPG File2.bin", "SAME", 5_000)
        RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, state, "g")

        // 第 2 轮：标准侧更新；Tyranor 侧同时存在 legacy 名与规范名（规范名内容有价值）
        standard.writeAt("file2.rpgsave", "PC-NEW", 9_000)
        tyranor.writeAt("RPG File2.bin", "PHONE-LEGACY", 1_000)
        tyranor.writeAt(canonical, "PHONE-CANONICAL", 1_000)

        val result = RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, state, "g")

        assertEquals(1, result.toTyranor)
        assertEquals("PC-NEW", tyranor.resolve(canonical).readText())
        assertTrue(
            "legacy 同名槽位文件必须留底",
            tyranor.resolve("original/RPG File2.bin").isFile,
        )
        assertEquals(
            "规范名目标的旧内容也必须留底（旧实现此处直接覆盖、备份为空）",
            "PHONE-CANONICAL",
            tyranor.resolve("original/$canonical").readText(),
        )
    }

    @Test
    fun sameMtimeSameContentIsSkipped() {
        val (standard, tyranor) = dirs()
        standard.writeAt("global.rpgsave", "IDENTICAL", 5_000)
        tyranor.writeAt("RPG Global.bin", "IDENTICAL", 5_000)

        val result = RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store(), "g")

        assertEquals(1, result.skipped)
        assertEquals(0, result.changed)    }

    @Test
    fun zeroMtimeSlotIsStillTrackedAsPresent() {
        // mtime 为 0 是合法时间戳：不能被当成「该侧不存在」，否则删除语义错乱
        val (standard, tyranor) = dirs()
        val store = store()
        val std = standard.resolve("file7.rpgsave").apply { writeText("S") }
        std.setLastModified(0L)

        val first = RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store, "g")
        assertEquals(1, first.imported)
        assertTrue(tyranor.resolve(mvName("file7.rpgsave")).isFile)

        // Tyranor 侧删除后，第二轮应识别为「已删除」而非「新建」而复活
        tyranor.resolve(mvName("file7.rpgsave")).delete()
        val second = RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store, "g")
        assertEquals(1, second.movedToDeleted)
        assertFalse(standard.resolve("file7.rpgsave").exists())
    }

    @Test
    fun legacyNamedTyranorSaveYieldsToCanonicalHashedName() {
        // 引擎读档优先 legacy 名（RPG *.bin）：若同槽位保留 legacy，新写入的哈希文件会被遮蔽，
        // 且同槽位出现两份（同步不再幂等）。覆盖时必须让位——内容移入 original/，规范名成为唯一落点。
        val (standard, tyranor) = dirs()
        val store = store()
        tyranor.writeAt("RPG Global.bin", "LEGACY", 1_000)
        standard.writeAt("global.rpgsave", "FROM-PC", 5_000)

        val result = RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store, "g")

        assertEquals(1, result.toTyranor)
        assertEquals("FROM-PC", tyranor.resolve(mvName("global.rpgsave")).readText())
        assertFalse(tyranor.resolve("RPG Global.bin").exists())
        assertEquals("LEGACY", tyranor.resolve("original/RPG Global.bin").readText())
        // 该槽位在 Tyranor 侧只应剩一个文件
        assertEquals(
            1,
            tyranor.listFiles().orEmpty().count { it.isFile && RpgSaveFormat.tyranorSlot(it.name, EngineType.RPG_MV) == "global" },
        )
        // 幂等：再同步一次不应再产生变化
        val second = RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store, "g")
        assertEquals(0, second.changed)
    }

    @Test
    fun nonRpgEngineIsNoOp() {        val (standard, tyranor) = dirs()
        standard.writeAt("global.rpgsave", "X", 1_000)
        val result = RpgSaveSync.sync(standard, tyranor, EngineType.TYRANO, store(), "g")
        assertEquals(0, result.changed)
    }

    @Test
    fun conflictingDuplicateSlotAcrossDirsIsQuarantined() {
        // 同一槽位出现在两个标准侧目录且内容不一致：不得静默丢弃后者——
        // 未选中的副本须隔离进其所在目录的 deleted/，同步以首选目录为准
        val lower = temporaryFolder.newFolder("save")
        val alt = temporaryFolder.newFolder("save_alt")
        val tyranor = temporaryFolder.newFolder("savedata")
        lower.writeAt("global.rpgsave", "PREFERRED", 1_000)
        alt.writeAt("global.rpgsave", "DIVERGED", 2_000)

        val result = RpgSaveSync.sync(listOf(lower, alt), tyranor, EngineType.RPG_MV, store(), "g")

        assertEquals(1, result.movedToDeleted)
        assertTrue(alt.resolve("deleted/global.rpgsave").isFile)
        assertEquals("DIVERGED", alt.resolve("deleted/global.rpgsave").readText())
        assertFalse(alt.resolve("global.rpgsave").exists())
        assertEquals("PREFERRED", tyranor.resolve(mvName("global.rpgsave")).readText())
    }

    @Test
    fun duplicateSlotWithSameContentIsNotQuarantined() {
        // 内容一致的等价副本不算冲突：任取其一，未选中者原样保留
        val lower = temporaryFolder.newFolder("save")
        val alt = temporaryFolder.newFolder("save_alt")
        val tyranor = temporaryFolder.newFolder("savedata")
        lower.writeAt("global.rpgsave", "SAME", 1_000)
        alt.writeAt("global.rpgsave", "SAME", 2_000)

        val result = RpgSaveSync.sync(listOf(lower, alt), tyranor, EngineType.RPG_MV, store(), "g")

        assertEquals(0, result.movedToDeleted)
        assertEquals(1, result.imported)
        assertTrue(alt.resolve("global.rpgsave").isFile)
    }

    @Test
    fun corruptManifestAbortsSyncWithoutImporting() {
        // 清单损坏不能当成「首次同步」继续：已删除记录丢失后会把已删存档当新存档导入。
        // 读取失败必须中止本轮同步（不做任何文件改动、如实报失败）。
        val (standard, tyranor) = dirs()
        val stateDir = temporaryFolder.newFolder("state")
        val store = RpgSaveSyncState(stateDir)
        standard.writeAt("file1.rpgsave", "V1", 1_000)
        tyranor.writeAt(mvName("file1.rpgsave"), "V1", 1_000)
        RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store, "g")

        stateDir.listFiles().orEmpty().forEach { it.writeText("{corrupt") }
        // 清单损坏时，同槽位冲突副本也不得被隔离——隔离必须发生在清单验证成功之后
        val alt = temporaryFolder.newFolder("save_alt")
        standard.writeAt("global.rpgsave", "PREFERRED", 2_000)
        alt.writeAt("global.rpgsave", "DIVERGED", 3_000)
        standard.writeAt("file2.rpgsave", "V2", 2_000)

        val result = RpgSaveSync.sync(listOf(standard, alt), tyranor, EngineType.RPG_MV, store, "g")

        assertEquals(1, result.failed)
        assertEquals(0, result.imported)
        assertEquals(0, result.changed)
        assertFalse(tyranor.resolve(mvName("file2.rpgsave")).exists())
        // 冲突副本原位保留：清单验证失败前不做任何文件改动
        assertTrue(alt.resolve("global.rpgsave").isFile)
        assertFalse(alt.resolve("deleted").exists())
    }

    /** 在 [stateDir] 里写入一份指定内容的清单（覆盖首个 .json 文件；无则跳过）。 */
    private fun overwriteManifest(stateDir: File, json: String) {
        val files = stateDir.listFiles().orEmpty().filter { it.isFile }
        if (files.isEmpty()) error("manifest file not found in ${stateDir.absolutePath}")
        files.forEach { it.writeText(json) }
    }

    @Test
    fun manifestWithoutSlotsObjectAbortsSync() {
        // 缺 slots 键的清单是损坏形态：绝不能当成空清单（首次同步）继续
        val (standard, tyranor) = dirs()
        val stateDir = temporaryFolder.newFolder("state")
        val store = RpgSaveSyncState(stateDir)
        standard.writeAt("file1.rpgsave", "V1", 1_000)
        tyranor.writeAt(mvName("file1.rpgsave"), "V1", 1_000)
        RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store, "g")

        overwriteManifest(stateDir, """{"other":{}}""")

        val result = RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store, "g")

        assertEquals(1, result.failed)
        assertEquals(0, result.changed)
    }

    @Test
    fun manifestWithNonObjectSlotEntryAbortsSync() {
        // 槽位值不是对象（或缺 std/tyr 字段）同样是损坏清单：静默跳过会丢该槽位的删除历史
        val (standard, tyranor) = dirs()
        val stateDir = temporaryFolder.newFolder("state")
        val store = RpgSaveSyncState(stateDir)
        standard.writeAt("file1.rpgsave", "V1", 1_000)
        tyranor.writeAt(mvName("file1.rpgsave"), "V1", 1_000)
        RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store, "g")

        overwriteManifest(stateDir, """{"slots":{"file1":"bogus"}}""")

        val result = RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store, "g")

        assertEquals(1, result.failed)
        assertEquals(0, result.changed)
    }

    @Test
    fun manifestWithNonBooleanExistsFlagAbortsSync() {
        // 审查跟进 #1：std_x/tyr_x 字段存在但类型不是 Boolean 属于损坏清单——
        // 静默回退会让 tyr_x 误成 false，把「已删除」当「新建」而复活
        val (standard, tyranor) = dirs()
        val stateDir = temporaryFolder.newFolder("state")
        val store = RpgSaveSyncState(stateDir)
        standard.writeAt("file1.rpgsave", "V1", 1_000)
        tyranor.writeAt(mvName("file1.rpgsave"), "V1", 1_000)
        RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store, "g")

        overwriteManifest(stateDir, """{"slots":{"file1":{"std":1000,"tyr":1000,"tyr_x":"yes"}}}""")

        val result = RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store, "g")

        assertEquals(1, result.failed)
        assertEquals(0, result.changed)
    }

    @Test
    fun manifestWithMissingRequiredFieldAbortsSync() {
        // 槽位条目缺 std/tyr 必需字段：视为损坏，中止同步
        val (standard, tyranor) = dirs()
        val stateDir = temporaryFolder.newFolder("state")
        val store = RpgSaveSyncState(stateDir)
        standard.writeAt("file1.rpgsave", "V1", 1_000)
        tyranor.writeAt(mvName("file1.rpgsave"), "V1", 1_000)
        RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store, "g")

        overwriteManifest(stateDir, """{"slots":{"file1":{"std":1000}}}""")

        val result = RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store, "g")

        assertEquals(1, result.failed)
        assertEquals(0, result.changed)
    }

    @Test
    fun inlineFailureKeepsManifestHistoryForDeletionSemantics() {
        // H2 回归：moveToDeleted 失败的内联分支也必须回填清单历史——否则该槽位从清单消失，
        // 下一轮 existedOnTyranor==false 会把「Tyranor 侧已删除」误判为「新建」而复活
        val (standard, tyranor) = dirs()
        val store = store()
        standard.writeAt("file7.rpgsave", "S", 1_000)
        tyranor.writeAt(mvName("file7.rpgsave"), "S", 1_000)
        RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store, "g")

        // 用同名文件占位 deleted/，迫使 moveToDeleted 失败
        standard.resolve("deleted").writeText("block")
        tyranor.resolve(mvName("file7.rpgsave")).delete()
        val failedRound = RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store, "g")

        assertEquals(1, failedRound.failed)
        assertEquals(0, failedRound.movedToDeleted)
        // 关键断言：清单仍记录该槽位曾在 Tyranor 存在
        val state = when (val loaded = store.load("g")) {
            is RpgSaveSyncState.LoadResult.Loaded -> loaded.slots
            else -> error("manifest must still be readable")
        }
        assertEquals(true, state["file7"]?.tyranorExists)

        // 清除占位后重试：应走「已删除」分支，而不是把标准文件当新存档导入
        standard.resolve("deleted").delete()
        val retry = RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store, "g")

        assertEquals(1, retry.movedToDeleted)
        assertEquals(0, retry.imported)
        assertFalse(tyranor.resolve(mvName("file7.rpgsave")).exists())
    }

    @Test
    fun preferTyranorOverwritesNewerStandardAndAlignsEquivalentDuplicate() {
        // 用户显式选了 Tyranor 侧的旧版本：不看 mtime，标准侧一律服从 Tyranor 内容。
        // save/ 与次要目录里的**等价副本**也必须一起对齐——只刷新首选目录那份，
        // 剩下的旧副本会在标记清除后被选中，把用户已否定的内容带回（复活）。
        val lower = temporaryFolder.newFolder("save")
        val alt = temporaryFolder.newFolder("save_alt")
        val tyranor = temporaryFolder.newFolder("savedata")
        lower.writeAt("global.rpgsave", "NEW-PC", 9_000)
        alt.writeAt("global.rpgsave", "NEW-PC", 9_000)
        tyranor.writeAt(mvName("global.rpgsave"), "SELECTED-OLD", 1_000)

        val result = RpgSaveSync.sync(listOf(lower, alt), tyranor, EngineType.RPG_MV, store(), "g", preferTyranor = true)

        assertEquals(1, result.toStandard)
        assertEquals(0, result.imported)
        assertEquals(0, result.movedToDeleted)
        assertEquals("SELECTED-OLD", lower.resolve("global.rpgsave").readText())
        assertEquals("SELECTED-OLD", alt.resolve("global.rpgsave").readText())
        // 被替换的标准侧副本一律留底，不静默覆盖
        assertTrue(lower.resolve("deleted/global.rpgsave").isFile)
        assertEquals("NEW-PC", lower.resolve("deleted/global.rpgsave").readText())
        assertTrue(alt.resolve("deleted/global.rpgsave").isFile)
        // mtime 一并对齐：否则下一轮常规同步还会按标准侧较新时间戳反向覆盖
        assertEquals(1_000, lower.resolve("global.rpgsave").lastModified())
        assertEquals(1_000, alt.resolve("global.rpgsave").lastModified())
        assertEquals("SELECTED-OLD", tyranor.resolve(mvName("global.rpgsave")).readText())

        // 标记清除后的常规同步：两侧一致，不得再改动任何一份（含次要目录副本）
        val ordinaryStore = RpgSaveSyncState(temporaryFolder.newFolder("state_follow_up"))
        RpgSaveSync.sync(listOf(lower, alt), tyranor, EngineType.RPG_MV, ordinaryStore, "g", preferTyranor = true)
        val followUp = RpgSaveSync.sync(listOf(lower, alt), tyranor, EngineType.RPG_MV, ordinaryStore, "g")

        assertEquals(0, followUp.changed)
        assertEquals("SELECTED-OLD", lower.resolve("global.rpgsave").readText())
        assertEquals("SELECTED-OLD", alt.resolve("global.rpgsave").readText())
        assertEquals("SELECTED-OLD", tyranor.resolve(mvName("global.rpgsave")).readText())
    }

    @Test
    fun preferTyranorMovesStandardOnlySlotToDeletedAndStaysRemoved() {
        val standard = temporaryFolder.newFolder("save_prefer")
        val tyranor = temporaryFolder.newFolder("savedata_prefer")
        val store = store()
        standard.writeAt("file8.rpgsave", "PC-ONLY", 9_000)
        tyranor.writeAt(mvName("file1.rpgsave"), "SELECTED", 1_000)

        val result = RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store, "g", preferTyranor = true)

        // 仅标准侧有 ⇒ 用户没选它：归入 deleted/ 保留，绝不导入，也绝不直接删文件
        assertEquals(1, result.movedToDeleted)
        assertEquals(0, result.imported)
        assertEquals(1, result.exported)
        assertFalse(standard.resolve("file8.rpgsave").exists())
        assertTrue(standard.resolve("deleted/file8.rpgsave").isFile)
        assertFalse(tyranor.resolve(mvName("file8.rpgsave")).exists())

        // 下一轮常规同步不得把它当「新 PC 存档」导回
        val followUp = RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, store, "g")

        assertEquals(0, followUp.imported)
        assertEquals(0, followUp.changed)
        assertFalse(tyranor.resolve(mvName("file8.rpgsave")).exists())
        assertTrue(standard.resolve("deleted/file8.rpgsave").isFile)

        // 对照组：同样布局不开标记时仍是「新 PC 存档 → 导入」，默认行为不受影响
        val control = dirs()
        control.first.writeAt("file8.rpgsave", "PC-ONLY", 9_000)
        val controlResult = RpgSaveSync.sync(control.first, control.second, EngineType.RPG_MV,
            RpgSaveSyncState(temporaryFolder.newFolder("state_control")), "ctrl")

        assertEquals(1, controlResult.imported)
        assertEquals("PC-ONLY", control.second.resolve(mvName("file8.rpgsave")).readText())
    }

    @Test
    fun manualSelectionMarkerSurvivesUntilClearedAndFailsClosed() {
        val stateDir = temporaryFolder.newFolder("state_marker")
        val store = RpgSaveSyncState(stateDir)
        assertFalse(store.hasManualSelection("g"))

        assertTrue(store.markManualSelection("g", temporaryFolder.root))
        assertTrue(store.hasManualSelection("g"))
        // 跨实例（等价于进程重启）仍在：同步失败/进程被杀都不能丢用户的选择
        assertTrue(RpgSaveSyncState(stateDir).hasManualSelection("g"))
        // 标记与同步清单互不干扰：清单读写不受标记文件影响
        standardAndTyranorSync(stateDir)
        assertTrue(RpgSaveSyncState(stateDir).hasManualSelection("g"))

        assertTrue(store.clearManualSelection("g"))
        assertFalse(store.hasManualSelection("g"))
        // 重复清除幂等，不谎报失败
        assertTrue(store.clearManualSelection("g"))

        // 游戏被真正移除：清单一并清掉时标记也必须跟着清，避免同 uri 重新添加后凭空定向同步
        assertTrue(store.markManualSelection("g", temporaryFolder.root))
        store.clear("g")
        assertFalse(store.hasManualSelection("g"))

        // 标记内容损坏 ⇒ 失败关闭：既不退回常规 mtime 同步，也不当成已选择
        store.markManualSelection("g", temporaryFolder.root)
        markerFiles(stateDir).forEach { it.writeText("{corrupt") }
        val failed = runCatching { store.hasManualSelection("g") }
        assertTrue(failed.isFailure)
        assertTrue(failed.exceptionOrNull() is GameSaveException)
        // 重新显式选择可自愈：损坏标记被替换为完好标记
        assertTrue(store.markManualSelection("g", temporaryFolder.root))
        assertTrue(RpgSaveSyncState(stateDir).hasManualSelection("g"))
        val marker = markerFiles(stateDir).single()
        assertTrue(marker.delete())
        assertTrue(marker.mkdir())
        assertTrue(runCatching { store.hasManualSelection("g") }.exceptionOrNull() is GameSaveException)
    }

    @Test
    fun selectedDirectoryCannotRetireStandardSavesAfterScopedDirectoryChange() {
        val (standard, selected) = dirs()
        val other = temporaryFolder.newFolder("other_scoped_save")
        standard.writeAt("global.rpgsave", "NEW-PC", 9_000)
        standard.writeAt("file8.rpgsave", "PC-ONLY", 9_000)
        selected.writeAt(mvName("global.rpgsave"), "SELECTED-OLD", 1_000)
        val stateDir = temporaryFolder.newFolder("bound_state")
        val state = RpgSaveSyncState(stateDir)
        state.withManualSelection("g", selected) { committed -> committed() }
        val marker = markerFiles(stateDir).single()
        val selectedMarker = marker.readBytes()

        // Reopen the store to establish that the directory guard survives process death.
        val reopened = RpgSaveSyncState(stateDir)
        val failure = assertThrows(GameSaveException::class.java) {
            RpgSaveSync.syncWithManualSelection(listOf(standard), other, EngineType.RPG_MV, reopened, "g")
        }
        assertEquals(SaveErrorCode.SAVE_SELECTION_INCOMPLETE, failure.code)
        assertEquals("NEW-PC", standard.resolve("global.rpgsave").readText())
        assertEquals("PC-ONLY", standard.resolve("file8.rpgsave").readText())
        assertFalse(standard.resolve("deleted").exists())
        assertTrue(other.listFiles().orEmpty().isEmpty())
        assertArrayEquals(selectedMarker, marker.readBytes())
        assertTrue(reopened.needsManualSelectionRecovery("g", other))
        assertFalse(reopened.needsManualSelectionRecovery("g", selected))
        assertEquals(RpgSaveSyncState.LoadResult.Missing, reopened.load("g"))

        // Switching back resumes the original explicit choice, with the standard originals retained.
        val resumed = RpgSaveSync.syncWithManualSelection(
            listOf(standard), selected, EngineType.RPG_MV, reopened, "g")
        assertEquals(0, resumed.failed)
        assertEquals("SELECTED-OLD", standard.resolve("global.rpgsave").readText())
        assertFalse(standard.resolve("file8.rpgsave").exists())
        assertTrue(standard.resolve("deleted").walkTopDown().filter { it.isFile }
            .any { it.readText() == "PC-ONLY" })
        assertFalse(reopened.hasManualSelection("g"))
    }

    @Test
    fun legacyUnboundSelectionStopsBeforeAnyInteropWrite() {
        val (standard, tyranor) = dirs()
        standard.writeAt("file8.rpgsave", "PC-ONLY", 9_000)
        val stateDir = temporaryFolder.newFolder("legacy_state")
        val state = RpgSaveSyncState(stateDir)
        assertTrue(state.markManualSelection("g", tyranor))
        val marker = markerFiles(stateDir).single()
        marker.writeText("{\"manual\":true}")
        val legacy = marker.readBytes()

        val failure = assertThrows(GameSaveException::class.java) {
            RpgSaveSync.syncWithManualSelection(listOf(standard), tyranor, EngineType.RPG_MV, state, "g")
        }
        assertEquals(SaveErrorCode.SAVE_SELECTION_INCOMPLETE, failure.code)
        assertTrue(state.needsManualSelectionRecovery("g", tyranor))
        assertEquals("PC-ONLY", standard.resolve("file8.rpgsave").readText())
        assertFalse(standard.resolve("deleted").exists())
        assertTrue(tyranor.listFiles().orEmpty().isEmpty())
        assertArrayEquals(legacy, marker.readBytes())
    }

    @Test
    fun canonicalAliasOfSelectedDirectoryStillConsumesSelection() {
        val (standard, tyranor) = dirs()
        standard.writeAt("global.rpgsave", "NEW-PC", 9_000)
        tyranor.writeAt(mvName("global.rpgsave"), "SELECTED", 1_000)
        val state = store()
        val alias = File(tyranor.parentFile, tyranor.name + "/../" + tyranor.name)
        assertTrue(state.markManualSelection("g", alias))
        val result = RpgSaveSync.syncWithManualSelection(listOf(standard), tyranor, EngineType.RPG_MV, state, "g")
        assertEquals(0, result.failed)
        assertEquals("SELECTED", standard.resolve("global.rpgsave").readText())
        assertFalse(state.hasManualSelection("g"))
    }

    @Test
    fun manualSelectionSyncConsumesMarkerOnlyAfterSuccessfulSync() {
        val (standard, tyranor) = dirs()
        standard.writeAt("global.rpgsave", "NEW-PC", 9_000)
        tyranor.writeAt(mvName("global.rpgsave"), "SELECTED-OLD", 1_000)
        val state = store()
        assertTrue(state.markManualSelection("g", tyranor))

        val result = RpgSaveSync.syncWithManualSelection(
            standardDirs = listOf(standard),
            tyranorDir = tyranor,
            engine = EngineType.RPG_MV,
            stateStore = state,
            gameKey = "g",
        )

        assertEquals(0, result.failed)
        assertEquals(1, result.toStandard)
        assertEquals("SELECTED-OLD", standard.resolve("global.rpgsave").readText())
        assertFalse(state.hasManualSelection("g"))
        assertEquals(0, RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, state, "g").changed)
    }

    @Test
    fun manualSelectionSyncKeepsMarkerWhenSyncFails() {
        val (standard, tyranor) = dirs()
        standard.writeAt("global.rpgsave", "NEW-PC", 9_000)
        tyranor.writeAt(mvName("global.rpgsave"), "SELECTED-OLD", 1_000)
        standard.resolve("deleted").writeText("block")
        val state = store()
        assertTrue(state.markManualSelection("g", tyranor))

        val result = RpgSaveSync.syncWithManualSelection(
            standardDirs = listOf(standard),
            tyranorDir = tyranor,
            engine = EngineType.RPG_MV,
            stateStore = state,
            gameKey = "g",
        )

        assertEquals(1, result.failed)
        assertTrue(state.hasManualSelection("g"))
        assertEquals("NEW-PC", standard.resolve("global.rpgsave").readText())
    }

    @Test
    fun interopLockedAndDirectSyncConcurrentlyDoNotDeadlock() {
        val executor = Executors.newFixedThreadPool(2) { task ->
            Thread(task, "rpg-save-lock-regression").apply { isDaemon = true }
        }
        val (standard, tyranor) = dirs()
        standard.writeAt("global.rpgsave", "PC", 1_000)
        val state = store()
        val interopHeld = CountDownLatch(1)
        val continueOuterSync = CountDownLatch(1)
        val directThread = AtomicReference<Thread>()
        try {
            val interopLocked = executor.submit<RpgSaveSync.Result> {
                synchronized(RpgSaveSyncState.INTEROP_LOCK) {
                    interopHeld.countDown()
                    continueOuterSync.await()
                    RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, state, "g")
                }
            }
            assertTrue("interop lock holder did not start", interopHeld.await(10, TimeUnit.SECONDS))

            val direct = executor.submit<RpgSaveSync.Result> {
                directThread.set(Thread.currentThread())
                RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, state, "g")
            }
            val directReachedLock = waitUntilBlocked(directThread)
            continueOuterSync.countDown()

            assertTrue("direct sync did not reach the interop lock", directReachedLock)
            assertEquals(0, interopLocked.get(10, TimeUnit.SECONDS).failed)
            assertEquals(0, direct.get(10, TimeUnit.SECONDS).failed)
        } finally {
            continueOuterSync.countDown()
            executor.shutdownNow()
        }
    }

    private fun waitUntilBlocked(threadRef: AtomicReference<Thread>): Boolean {
        val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(10)
        while (System.nanoTime() < deadline) {
            if (threadRef.get()?.state == Thread.State.BLOCKED) return true
            Thread.sleep(5)
        }
        return false
    }

    private fun standardAndTyranorSync(stateDir: File) {
        val standard = temporaryFolder.newFolder("save_marker")
        val tyranor = temporaryFolder.newFolder("savedata_marker")
        standard.writeAt("file9.rpgsave", "S", 1_000)
        assertEquals(1, RpgSaveSync.sync(standard, tyranor, EngineType.RPG_MV, RpgSaveSyncState(stateDir), "g").imported)
    }

    private fun markerFiles(stateDir: File): List<File> =
        stateDir.listFiles().orEmpty().filter { it.name.endsWith(".manual.json") }
}
