package com.tyranor.next.ui.settings

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.DrawableRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.tyranor.next.R
import com.tyranor.next.core.game.launch.EngineLauncher
import com.tyranor.next.core.settings.AppSettingsStore
import com.tyranor.next.core.settings.GraphicsCapabilities
import com.tyranor.next.core.settings.GraphicsFamily
import com.tyranor.next.core.settings.GraphicsSettings
import com.tyranor.next.core.settings.EngineSettingsStore
import com.tyranor.next.core.game.storage.GameLibraryFacade
import com.tyranor.next.theme.AppSheetTopShape
import com.tyranor.next.theme.AppThemeColors
import com.tyranor.next.theme.GlassPanelSolid
import com.tyranor.next.theme.GlassSurfaceSolid
import com.tyranor.next.theme.MilkGlassPanelBackground
import com.tyranor.next.theme.NavWhite
import com.tyranor.next.theme.PageSecondaryTextColor
import com.tyranor.next.theme.PageTextColor
import com.tyranor.next.theme.DialogItemSurface
import com.tyranor.next.theme.MiuixSettingsTheme
import com.tyranor.next.theme.TextColor
import com.tyranor.next.theme.glassBorder
import com.tyranor.next.theme.AppComponentShape
import com.tyranor.next.theme.AppComponentCornerRadius
import com.tyranor.next.ui.common.AppNavItem
import com.tyranor.next.ui.common.AppAlertDialog
import com.tyranor.next.ui.common.AppDialogMaxWidth
import com.tyranor.next.ui.common.AppSheetDragHandle
import com.tyranor.next.ui.common.AppSearchField
import com.tyranor.next.ui.common.AppTopBar
import com.tyranor.next.ui.common.SettingsEntryCard
import com.tyranor.next.ui.common.coachAnchor
import com.tyranor.next.ui.common.BottomInsetSpacer
import com.tyranor.next.ui.common.ByteFormats
import com.tyranor.next.ui.common.DialogTextButton
import com.tyranor.next.ui.common.NoIndication
import com.tyranor.next.ui.common.NoRippleButton
import com.tyranor.next.ui.common.TopBarIcon
import com.tyranor.next.ui.common.formatUiDecimal
import com.tyranor.next.ui.common.glassNavBottomInset
import com.tyranor.next.core.updater.GitHubUpdateChecker
import com.tyranor.next.core.updater.UpdateApkDownloader
import com.tyranor.next.core.updater.UpdateCandidate
import com.tyranor.next.core.updater.UpdateCheckResult
import com.tyranor.next.core.updater.UpdateDownloadResult
import com.tyranor.next.ui.cover.CoverScraperSettingsActivity
import com.tyranor.next.ui.game.startActivityWithPageTransition
import java.io.File
import java.util.Locale
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import top.yukonga.miuix.kmp.basic.Card as MiuixCard
import top.yukonga.miuix.kmp.basic.LinearProgressIndicator
import top.yukonga.miuix.kmp.basic.Scaffold as MiuixScaffold
import top.yukonga.miuix.kmp.basic.Slider
import top.yukonga.miuix.kmp.basic.SliderDefaults
import com.tyranor.next.ui.common.ArrowPreference
import top.yukonga.miuix.kmp.preference.OverlayDropdownPreference
import top.yukonga.miuix.kmp.preference.SwitchPreference
import top.yukonga.miuix.kmp.theme.MiuixTheme

/** 更新弹窗的下载阶段；null 表示停留在“发现新版本”阶段，四个阶段复用同一个 AppAlertDialog。 */
private sealed interface UpdateDownloadPhase {
    data class Downloading(val downloadedBytes: Long, val totalBytes: Long) : UpdateDownloadPhase

    data class Completed(val apkFile: File) : UpdateDownloadPhase

    data class Failed(val message: String) : UpdateDownloadPhase
}

/** 更新下载进度文案的字节格式化（统一走 [ByteFormats]：二进制单位 + 有效量级精度）。 */
private fun formatUpdateBytes(bytes: Long): String = ByteFormats.formatBinarySize(bytes)

/** 设置页：只展示各引擎全局设置入口，具体设置内容由独立 Activity 承载。列表项采用 Miuix Card + Preference 体系。 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    modifier: Modifier = Modifier,
    onCoachAnchorChanged: (Rect) -> Unit = {},
    isActive: Boolean = true,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    // 已知行为：以下更新弹窗状态均为 remember 持有，Activity 重建（旋转/语言切换）会丢失并静默取消下载；
    // 更新检查是低频操作，接受该取舍，未上 ViewModel 持久化。
    var checkingUpdate by remember { mutableStateOf(false) }
    val hasUpdate by GitHubUpdateChecker.hasUpdate.collectAsState()
    var updateAvailable by remember { mutableStateOf<UpdateCheckResult.UpdateAvailable?>(null) }
    var activeCandidate by remember { mutableStateOf<UpdateCandidate?>(null) }
    var updateDownloadPhase by remember { mutableStateOf<UpdateDownloadPhase?>(null) }
    var updateDownloadJob by remember { mutableStateOf<Job?>(null) }
    var showGroupDialog by remember { mutableStateOf(false) }
    var showScanDirs by rememberSaveable { mutableStateOf(false) }
    var scanDirs by remember { mutableStateOf(emptyList<String>()) }
    val resourceCleanup: SystemNnnCleanupViewModel = viewModel()
    val cleanupState by resourceCleanup.state.collectAsStateWithLifecycle()
    var showPathDialog by remember { mutableStateOf(false) }
    var pathInput by remember { mutableStateOf("") }
    val settingsUpdateLatestMessage = stringResource(R.string.settings_update_latest)
    val settingsUpdateFailedFormat = stringResource(R.string.settings_update_failed)
    // 锚点生命周期跟随页面，而不是 LazyColumn 首项；拖动时保留上一帧目标，避免立即退化为全屏拦截。
    DisposableEffect(isActive) {
        onDispose { onCoachAnchorChanged(Rect.Zero) }
    }
    LaunchedEffect(Unit) {
        scanDirs = withContext(Dispatchers.IO) { GameLibraryFacade.loadRoots(ctx) }
        GameLibraryFacade.rootsRevision.collect {
            scanDirs = withContext(Dispatchers.IO) { GameLibraryFacade.loadRoots(ctx) }
        }
    }
    val dirPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        uri?.let { u ->
            runCatching {
                ctx.contentResolver.takePersistableUriPermission(
                    u,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or
                        android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
                )
            }
            GameLibraryFacade.saveRoot(ctx, u)
            scanDirs = GameLibraryFacade.loadRoots(ctx)
        }
    }

    fun checkUpdate() {
        if (checkingUpdate) return
        checkingUpdate = true
        scope.launch {
            when (val result = GitHubUpdateChecker.check(ctx)) {
                is UpdateCheckResult.UpdateAvailable -> updateAvailable = result
                is UpdateCheckResult.UpToDate -> {
                    Toast.makeText(ctx, settingsUpdateLatestMessage, Toast.LENGTH_SHORT).show()
                }
                is UpdateCheckResult.Failed -> {
                    Toast.makeText(ctx, settingsUpdateFailedFormat.format(result.message), Toast.LENGTH_SHORT).show()
                }
            }
            checkingUpdate = false
        }
    }

    fun closeUpdateDialog() {
        // 约定：关闭弹窗即取消下载，并清理临时文件
        updateDownloadJob?.cancel()
        updateDownloadJob = null
        updateDownloadPhase = null
        activeCandidate = null
        updateAvailable = null
    }

    fun startApkDownload(candidate: UpdateCandidate) {
        // 防重入：下载进行中时忽略重复点击，避免并发两个下载
        if (updateDownloadJob?.isActive == true) return
        val asset = candidate.apkAsset ?: return
        activeCandidate = candidate
        updateDownloadPhase = UpdateDownloadPhase.Downloading(0L, asset.size)
        var job: Job? = null
        job = scope.launch {
            try {
                val result = UpdateApkDownloader.download(ctx, asset) { downloaded, total ->
                    // 身份校验：仅当前任务可回写进度，防止取消/重试后旧协程污染状态
                    if (updateDownloadJob === job) {
                        updateDownloadPhase = UpdateDownloadPhase.Downloading(downloaded, total)
                    }
                }
                if (updateDownloadJob === job) {
                    when (result) {
                        is UpdateDownloadResult.Success -> {
                            updateDownloadPhase = UpdateDownloadPhase.Completed(result.apkFile)
                        }
                        is UpdateDownloadResult.Failed -> {
                            updateDownloadPhase = UpdateDownloadPhase.Failed(result.message)
                        }
                    }
                }
            } catch (cancelled: CancellationException) {
                // 用户关闭弹窗即取消下载：状态由 closeUpdateDialog 复位，这里无需处理
                throw cancelled
            }
        }
        updateDownloadJob = job
        // 兜底：无论正常结束、失败还是被取消，当前 job 完成后清引用，避免快速重试时孤儿下载
        job.invokeOnCompletion { if (updateDownloadJob === job) updateDownloadJob = null }
    }

    val settingsUpdateInstallFailedMessage = stringResource(R.string.update_install_failed)
    fun installUpdateApk(file: File) {
        if (!ctx.packageManager.canRequestPackageInstalls()) {
            // 未授权“安装未知应用”：先跳系统授权页，授权后用户再次点击安装即可
            runCatching {
                ctx.startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:${ctx.packageName}"),
                    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                )
            }
            return
        }
        // getUriForFile 可能因外置存储不可用且回退路径未在 file_paths 声明而抛异常，兜底提示
        val uri = runCatching { FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file) }.getOrElse {
            Toast.makeText(ctx, settingsUpdateInstallFailedMessage, Toast.LENGTH_SHORT).show()
            return
        }
        val installIntent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching { ctx.startActivity(installIntent) }
            .onFailure { Toast.makeText(ctx, settingsUpdateInstallFailedMessage, Toast.LENGTH_SHORT).show() }
    }

    MiuixSettingsTheme {
        MiuixScaffold(
            modifier = modifier,
            containerColor = Color.Transparent,
            contentWindowInsets = WindowInsets(0.dp),
            topBar = { SettingsTopBar(stringResource(R.string.nav_settings)) },
        ) { innerPadding ->
            LazyColumn(
                // 顶栏透明：列表整体垫在顶栏下方（持久 padding），避免滚动时内容穿过顶栏
                modifier = Modifier.fillMaxSize()
                    .padding(horizontal = 12.dp)
                    .padding(top = innerPadding.calculateTopPadding()),
                contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp + glassNavBottomInset()),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                item {
                    MiuixCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .coachAnchor(isActive, onCoachAnchorChanged)
                            .glassBorder(),
                        cornerRadius = AppComponentCornerRadius,
                    ) {
                        Column(Modifier.padding(vertical = 4.dp)) {
                            ArrowPreference(
                                title = stringResource(R.string.settings_add_game_dir),
                                summary = stringResource(R.string.settings_dir_count, scanDirs.size),
                                onClick = { showScanDirs = true },
                            )
                            var depth by remember { mutableIntStateOf(AppSettingsStore.getScanDepth(ctx)) }
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(
                                    stringResource(R.string.settings_scan_depth),
                                    style = MaterialTheme.typography.titleMedium,
                                    modifier = Modifier.weight(1f),
                                )
                                Text(
                                    stringResource(R.string.settings_scan_depth_level, depth),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            Slider(
                                value = depth.toFloat(),
                                onValueChange = { depth = it.roundToInt().coerceIn(1, 5) },
                                onValueChangeFinished = { AppSettingsStore.setScanDepth(ctx, depth) },
                                valueRange = 1f..5f,
                                showKeyPoints = true,
                                keyPoints = (1..5).map { it.toFloat() },
                                magnetThreshold = 0.25f,
                                hapticEffect = SliderDefaults.SliderHapticEffect.Step,
                                modifier = Modifier.padding(horizontal = 16.dp),
                            )
                            var gameSort by remember { mutableStateOf(AppSettingsStore.getGameSort(ctx)) }
                            val gameSortModes = listOf(
                                AppSettingsStore.GAME_SORT_ALPHA to stringResource(R.string.settings_sort_alpha),
                                AppSettingsStore.GAME_SORT_BRACKET_TAG to stringResource(R.string.settings_sort_bracket_tag),
                            )
                            val sortIndex = gameSortModes.indexOfFirst { it.first == gameSort }
                                .let { if (it < 0) 0 else it }
                            OverlayDropdownPreference(
                                title = stringResource(R.string.settings_game_sort),
                                items = gameSortModes.map { it.second },
                                selectedIndex = sortIndex,
                                onSelectedIndexChange = { index ->
                                    gameSortModes.getOrNull(index)?.first?.let { sort ->
                                        gameSort = sort
                                        AppSettingsStore.setGameSort(ctx, sort)
                                    }
                                },
                            )
                        }
                    }
                }
                item {
                    SettingsEntryCard(
                        title = stringResource(R.string.settings_app_title),
                        iconRes = R.drawable.ic_settings_app,
                        onClick = { startActivityWithPageTransition(ctx, AppSettingsActivity.createIntent(ctx)) },
                    )
                }
                item {
                    SettingsEntryCard(
                        title = stringResource(R.string.settings_cover_scraper),
                        iconRes = R.drawable.ic_game_cover,
                        onClick = { startActivityWithPageTransition(ctx, CoverScraperSettingsActivity.createIntent(ctx)) },
                    )
                }
                item {
                    SettingsEntryCard(
                        title = if (checkingUpdate) {
                            stringResource(R.string.settings_update_checking)
                        } else {
                            stringResource(R.string.settings_update_check)
                        },
                        iconRes = R.drawable.ic_settings_update,
                        showBadge = hasUpdate,
                        onClick = { checkUpdate() },
                    )
                }
                item {
                    SettingsEntryCard(
                        title = stringResource(R.string.settings_join_group),
                        iconRes = R.drawable.ic_settings_group,
                        onClick = { showGroupDialog = true },
                    )
                }
                item {
                    SettingsEntryCard(
                        title = stringResource(R.string.settings_about_app),
                        iconRes = R.drawable.ic_settings_about,
                        onClick = { startActivityWithPageTransition(ctx, AboutAppActivity.createIntent(ctx)) },
                    )
                }
                item { BottomInsetSpacer() }
            }
        }
    }

    if (showScanDirs) {
        // 抽屉内条目底色：与游戏操作抽屉一致（复古玻璃用不透明条目色，白雾玻璃用弹窗内条目色）
        val dirItemSurface = when {
            AppThemeColors.isGlass -> GlassSurfaceSolid
            AppThemeColors.isMilkGlass -> DialogItemSurface
            else -> NavWhite
        }
        ModalBottomSheet(
            onDismissRequest = { showScanDirs = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            sheetMaxWidth = AppDialogMaxWidth,
            // 关闭拖拽手势：只允许遮罩/返回键关闭（与游戏操作抽屉一致）
            sheetGesturesEnabled = false,
            containerColor = when {
                AppThemeColors.isGlass -> GlassPanelSolid
                AppThemeColors.isMilkGlass -> Color.Transparent
                else -> MaterialTheme.colorScheme.background
            },
            contentColor = TextColor,
            scrimColor = when {
                AppThemeColors.isGlass -> Color.Black.copy(alpha = 0.6f)
                AppThemeColors.isMilkGlass -> Color.Black.copy(alpha = 0.45f)
                else -> Color.Black.copy(alpha = 0.32f)
            },
            contentWindowInsets = { WindowInsets(0.dp) },
            shape = AppSheetTopShape,
            dragHandle = {
                if (!AppThemeColors.isMilkGlass) AppSheetDragHandle(showGlassTopBorder = true)
            },
        ) {
            // 列表最大高度为底部两个长按钮与标题预留空间，避免抽屉整体超出屏幕
            val sheetMaxHeight = with(LocalConfiguration.current) {
                (screenHeightDp - 280).dp.coerceIn(80.dp, 420.dp)
            }
            Box(Modifier.fillMaxWidth().clip(AppSheetTopShape)) {
                if (AppThemeColors.isMilkGlass) {
                    MilkGlassPanelBackground(Modifier.matchParentSize())
                }
                Column(Modifier.fillMaxWidth()) {
                    if (AppThemeColors.isMilkGlass) {
                        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                            AppSheetDragHandle()
                        }
                    }
                    LazyColumn(
                        modifier = Modifier.fillMaxWidth().heightIn(max = sheetMaxHeight),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        item {
                            Text(
                                stringResource(R.string.settings_game_dirs_title),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 8.dp),
                            )
                        }
                        if (scanDirs.isEmpty()) {
                            item {
                                Text(
                                    stringResource(R.string.settings_no_game_dirs),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = PageSecondaryTextColor,
                                )
                            }
                        }
                        items(scanDirs, key = { it }) { dir ->
                            // 目录被改名/删除或权限失效后标记为已失效，提示用户手动清理。
                            // DocumentFile.isDirectory 可能触发 binder 调用，放到 IO 线程执行。
                            val valid by produceState(initialValue = false, dir) {
                                value = withContext(Dispatchers.IO) { isScanDirValid(ctx, dir) }
                            }
                            // 与游戏操作抽屉的 AppNavItem 同规格：约 58dp 高、16dp 左右视觉留白、
                            // 24dp 左侧图标、标题 bodyMedium；删除动作以行尾图标按钮承载
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(AppComponentShape)
                                    .background(dirItemSurface)
                                    .glassBorder()
                                    .padding(start = 16.dp, end = 8.dp, top = 11.dp, bottom = 11.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Image(
                                    painter = painterResource(R.drawable.ic_settings_game_dir),
                                    contentDescription = null,
                                    colorFilter = ColorFilter.tint(MaterialTheme.colorScheme.primary),
                                    modifier = Modifier.size(24.dp),
                                )
                                Text(
                                    if (valid) scanDirName(ctx, dir) else "${scanDirName(ctx, dir)}（${stringResource(R.string.settings_invalid_suffix)}）",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (valid) TextColor else MaterialTheme.colorScheme.error,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f).padding(horizontal = 12.dp),
                                )
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(AppComponentShape)
                                        .clickable(
                                            enabled = !cleanupState.running,
                                            interactionSource = remember { MutableInteractionSource() },
                                            indication = null,
                                            onClick = { resourceCleanup.removeRoot(dir) },
                                        ),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    // 复用长按游戏卡片操作弹窗「删除游戏」的左侧图标
                                    Icon(
                                        painter = painterResource(R.drawable.ic_sheet_delete),
                                        contentDescription = stringResource(R.string.common_delete),
                                        tint = MaterialTheme.colorScheme.error,
                                        modifier = Modifier.size(24.dp),
                                    )
                                }
                            }
                        }
                        item {
                            val result = cleanupState.result
                            val message = when {
                                cleanupState.running -> stringResource(R.string.settings_systemnnn_copy_cleanup_running)
                                result != null && result.failed > 0 -> stringResource(
                                    R.string.settings_systemnnn_copy_cleanup_incomplete,
                                    result.cleared, result.failed,
                                )
                                cleanupState.canRetry -> stringResource(R.string.settings_systemnnn_copy_cleanup_pending)
                                cleanupState.failed -> stringResource(R.string.save_operation_failed)
                                result != null && result.cleared > 0 -> stringResource(
                                    R.string.settings_systemnnn_copy_cleanup_done,
                                    result.cleared,
                                )
                                result != null -> stringResource(R.string.settings_systemnnn_copy_cleanup_empty)
                                else -> null
                            }
                            if (message != null) {
                                Text(message, color = PageSecondaryTextColor, style = MaterialTheme.typography.bodyMedium)
                            }
                            if (cleanupState.canRetry && !cleanupState.running) {
                                NoRippleButton(
                                    text = stringResource(R.string.common_retry),
                                    modifier = Modifier.fillMaxWidth(),
                                    onClick = resourceCleanup::retry,
                                )
                            }
                        }
                    }
                    // 底部主操作：输入路径 / 添加目录 改为两个长按钮；
                    // 点击后抽屉保持展开，列表随 rootsRevision 自动刷新
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .navigationBarsPadding()
                            .padding(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        NoRippleButton(
                            text = stringResource(R.string.settings_input_path),
                            modifier = Modifier.fillMaxWidth(),
                            onClick = { showPathDialog = true },
                        )
                        NoRippleButton(
                            text = stringResource(R.string.settings_add_dir),
                            modifier = Modifier.fillMaxWidth(),
                            onClick = { dirPicker.launch(null) },
                        )
                    }
                }
            }
        }
    }

    if (showPathDialog) {
        val pathInvalidMsg = stringResource(R.string.settings_path_invalid)
        val allFilesAccessMsg = stringResource(R.string.settings_all_files_access_required)
        val savePath: () -> Unit = {
            scope.launch {
                val trimmed = pathInput.trim()
                val target = File(trimmed)
                // 仅绝对路径且为有效目录才允许保存；磁盘 IO 放到 Dispatchers.IO（同本文件 :265-269 约定）。
                val ok = target.isAbsolute &&
                    withContext(Dispatchers.IO) { runCatching { target.isDirectory }.getOrDefault(false) }
                if (!ok) {
                    Toast.makeText(ctx, pathInvalidMsg, Toast.LENGTH_SHORT).show()
                    return@launch
                }
                // /storage 等共享存储路径需“管理所有文件”权限，否则扫描会静默为空；先引导授权，不落盘。
                if (guideAllFilesAccessIfNeeded(ctx, target.absolutePath)) {
                    Toast.makeText(ctx, allFilesAccessMsg, Toast.LENGTH_SHORT).show()
                    return@launch
                }
                GameLibraryFacade.saveRoot(ctx, target.absolutePath)
                showPathDialog = false
                pathInput = ""
            }
        }
        AppAlertDialog(
            onDismissRequest = {
                showPathDialog = false
                pathInput = ""
            },
            title = { Text(stringResource(R.string.settings_input_dir_title), style = MaterialTheme.typography.titleMedium) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    AppSearchField(
                        query = pathInput,
                        onQueryChange = { pathInput = it },
                        onSearch = savePath,
                        leadingIcon = painterResource(R.drawable.ic_sheet_folder),
                        iconContentDescription = stringResource(R.string.settings_input_dir_title),
                        imeAction = ImeAction.Done,
                        textStyle = MaterialTheme.typography.bodyMedium,
                    )
                }
            },
            confirmButton = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    DialogTextButton(
                        text = stringResource(R.string.common_confirm),
                        modifier = Modifier.padding(end = 8.dp),
                        onClick = savePath,
                    )
                    DialogTextButton(
                        text = stringResource(R.string.common_cancel),
                        onClick = {
                            showPathDialog = false
                            pathInput = ""
                        },
                    )
                }
            },
        )
    }

    if (showGroupDialog) {
        AppAlertDialog(
            onDismissRequest = { showGroupDialog = false },
            title = { Text(stringResource(R.string.settings_join_group), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    AppNavItem(
                        stringResource(R.string.settings_qq_group),
                        leadingIcon = R.drawable.ic_group_qq,
                        containerColor = DialogItemSurface,
                        indication = null,
                    ) {
                        showGroupDialog = false
                        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://qm.qq.com/q/M9JH8A9Yys")))
                    }
                    AppNavItem(
                        stringResource(R.string.settings_telegram_channel),
                        leadingIcon = R.drawable.ic_group_telegram,
                        containerColor = DialogItemSurface,
                        indication = null,
                    ) {
                        showGroupDialog = false
                        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/tyranornext")))
                    }
                }
            },
            confirmButton = {
                DialogTextButton(
                    text = stringResource(R.string.common_cancel),
                    onClick = { showGroupDialog = false },
                )
            },
        )
    }

    updateAvailable?.let { update ->
        val downloadPhase = updateDownloadPhase
        AppAlertDialog(
            onDismissRequest = { closeUpdateDialog() },
            title = {
                Text(
                    stringResource(
                        when (downloadPhase) {
                            is UpdateDownloadPhase.Failed -> R.string.update_download_failed_title
                            is UpdateDownloadPhase.Completed -> R.string.update_download_completed_title
                            else -> R.string.update_found_title
                        },
                    ),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                )
            },
            text = {
                when (downloadPhase) {
                    null -> {
                        // 统一条目组件列出最新三个版本，点击进入下载弹窗
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            update.candidates.forEach { candidate ->
                                AppNavItem(
                                    title = stringResource(R.string.update_version_item, candidate.latestVersion),
                                    leadingIcon = R.drawable.ic_update_download,
                                    containerColor = DialogItemSurface,
                                    onClick = {
                                        if (candidate.apkAsset != null) {
                                            startApkDownload(candidate)
                                        } else {
                                            // 无 APK 资产时回退浏览器打开该版本发布页
                                            runCatching {
                                                ctx.startActivity(
                                                    Intent(Intent.ACTION_VIEW, Uri.parse(candidate.releaseUrl))
                                                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                                                )
                                            }
                                        }
                                    },
                                )
                            }
                            // 跳转浏览器查看全部 Releases（外部跳转属执行动作，不显示右箭头）
                            AppNavItem(
                                title = stringResource(R.string.update_open_releases),
                                leadingIcon = R.drawable.ic_update_github,
                                containerColor = DialogItemSurface,
                                showArrow = false,
                                onClick = {
                                    runCatching {
                                        ctx.startActivity(
                                            Intent(
                                                Intent.ACTION_VIEW,
                                                Uri.parse("https://github.com/Weiss-UltimateSavior/Tyranor-Next/releases"),
                                            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                                        )
                                    }
                                },
                            )
                        }
                    }
                    is UpdateDownloadPhase.Downloading -> {
                        val fraction = if (downloadPhase.totalBytes > 0) {
                            (downloadPhase.downloadedBytes.toFloat() / downloadPhase.totalBytes).coerceIn(0f, 1f)
                        } else {
                            null
                        }
                        val percent = if (downloadPhase.totalBytes > 0) {
                            ((downloadPhase.downloadedBytes * 100) / downloadPhase.totalBytes).toInt()
                        } else {
                            0
                        }
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            // miuix 风格进度条：progress 为 null 时展示不定态
                            LinearProgressIndicator(
                                progress = fraction,
                                modifier = Modifier.fillMaxWidth(),
                            )
                            Text(
                                stringResource(
                                    R.string.update_downloading_status,
                                    formatUpdateBytes(downloadPhase.downloadedBytes),
                                    formatUpdateBytes(downloadPhase.totalBytes),
                                    percent,
                                ),
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextColor,
                            )
                        }
                    }
                    is UpdateDownloadPhase.Completed -> {
                        Text(
                            stringResource(R.string.update_download_completed_message, downloadPhase.apkFile.name),
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextColor,
                        )
                    }
                    is UpdateDownloadPhase.Failed -> {
                        Text(
                            downloadPhase.message,
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextColor,
                        )
                    }
                }
            },
            dismissButton = {
                when (downloadPhase) {
                    // 版本列表阶段：无次要按钮，点击条目即进入下载
                    null -> Unit
                    is UpdateDownloadPhase.Downloading -> Unit
                    is UpdateDownloadPhase.Completed, is UpdateDownloadPhase.Failed -> {
                        DialogTextButton(
                            text = stringResource(R.string.common_cancel),
                            onClick = { closeUpdateDialog() },
                        )
                    }
                }
            },
            confirmButton = {
                when (downloadPhase) {
                    null -> {
                        DialogTextButton(
                            text = stringResource(R.string.common_cancel),
                            onClick = { closeUpdateDialog() },
                        )
                    }
                    is UpdateDownloadPhase.Downloading -> {
                        DialogTextButton(
                            text = stringResource(R.string.update_download_cancel),
                            onClick = { closeUpdateDialog() },
                        )
                    }
                    is UpdateDownloadPhase.Completed -> {
                        DialogTextButton(
                            text = stringResource(R.string.update_install),
                            onClick = { installUpdateApk(downloadPhase.apkFile) },
                        )
                    }
                    is UpdateDownloadPhase.Failed -> {
                        DialogTextButton(
                            text = stringResource(R.string.update_retry),
                            onClick = { activeCandidate?.let { startApkDownload(it) } },
                        )
                    }
                }
            },
        )
    }
}

@Composable
internal fun EngineSettingsDetailScreen(kind: EngineSettingsKind) {
    if (kind == EngineSettingsKind.ETHORNELL) {
        EthornellSettingsScreen()
        return
    }
    if (kind == EngineSettingsKind.RUFFLE) {
        RuffleSettingsScreen()
        return
    }
    if (kind == EngineSettingsKind.CMVS) {
        CmvsSettingsScreen()
        return
    }
    val ctx = LocalContext.current
    val graphicsFamily = kind.graphicsFamily()
    var graphics by remember(kind) {
        mutableStateOf(graphicsFamily?.let { EngineSettingsStore.getGraphicsSettings(ctx, it) }
            ?: GraphicsSettings.defaults(GraphicsFamily.KR))
    }
    val engineSettingsSavedMessage = stringResource(R.string.engine_settings_saved)

    var krVersion by remember { mutableStateOf(EngineSettingsStore.getKrEngineVersion(ctx)) }
    var krKernel by remember { mutableStateOf(EngineSettingsStore.getKrKernel(ctx)) }
    var krScoped by remember { mutableStateOf(EngineSettingsStore.isKrScopedSaveDir(ctx)) }
    var krSkipStartupDialogs by remember { mutableStateOf(EngineSettingsStore.isKrSkipStartupDialogs(ctx)) }
    var krPatchOverlayMode by remember { mutableStateOf(EngineSettingsStore.getKrPatchOverlayMode(ctx)) }
    var krFont by remember { mutableStateOf(EngineSettingsStore.getKrDefaultFont(ctx)) }
    var krForceFont by remember { mutableStateOf(EngineSettingsStore.isKrForceDefaultFont(ctx)) }
    var krRenderer by remember { mutableStateOf(EngineSettingsStore.getKrRenderer(ctx)) }
    var krDrawThread by remember { mutableStateOf(EngineSettingsStore.getKrSoftwareDrawThread(ctx)) }
    var krSwCompress by remember { mutableStateOf(EngineSettingsStore.getKrSoftwareCompressTex(ctx)) }
    var krOglCompress by remember { mutableStateOf(EngineSettingsStore.getKrOglCompressTex(ctx)) }
    var krMem by remember { mutableStateOf(EngineSettingsStore.getKrMemUsage(ctx)) }
    var krTexsize by remember { mutableStateOf(EngineSettingsStore.getKrOglMaxTexsize(ctx)) }
    var krAccurate by remember { mutableStateOf(EngineSettingsStore.getKrOglAccurateRender(ctx)) }
    var krFps by remember { mutableStateOf(EngineSettingsStore.getKrFpsLimit(ctx)) }
    var krVCursorScale by remember { mutableStateOf(EngineSettingsStore.getKrVCursorScale(ctx)) }
    var krMenuOpa by remember { mutableStateOf(EngineSettingsStore.getKrMenuHandlerOpa(ctx)) }

    var ons by remember { mutableStateOf(EngineSettingsStore.loadOns(ctx)) }

    var artKernel by remember { mutableStateOf(EngineSettingsStore.getArtKernel(ctx)) }
    var artVersion by remember { mutableStateOf(EngineSettingsStore.getArtEngineVersion(ctx)) }
    var artRotate by remember { mutableStateOf(EngineSettingsStore.isArtRotateScreen(ctx)) }
    var artPatch by remember { mutableStateOf(EngineSettingsStore.getArtAutoPatch(ctx)) }
    var artResolution by remember { mutableStateOf(EngineSettingsStore.getArtResolution(ctx)) }
    var artSideCut by remember { mutableStateOf(EngineSettingsStore.getArtSideCut(ctx)) }
    var artSurfaceCache by remember { mutableStateOf(EngineSettingsStore.getArtSurfaceCacheSize(ctx)) }
    var artFontCache by remember { mutableStateOf(EngineSettingsStore.getArtFontCacheSize(ctx)) }
    var artPowerSaving by remember { mutableStateOf(EngineSettingsStore.getArtPowerSaving(ctx)) }

    var tyExternal by remember { mutableStateOf(EngineSettingsStore.isTyranoExternalNetwork(ctx)) }
    var tyScoped by remember { mutableStateOf(EngineSettingsStore.isTyranoScopedSaveDir(ctx)) }
    var rpgMakerMod by remember { mutableStateOf(EngineSettingsStore.isRpgMakerModEnabled(ctx)) }
    var rpgLegacyRenderer by remember { mutableStateOf(EngineSettingsStore.isRpgLegacyRenderer(ctx)) }
    var rpgSaveInterop by remember { mutableStateOf(EngineSettingsStore.isRpgSaveInterop(ctx)) }
    var rpgMvVersion by remember { mutableStateOf(EngineSettingsStore.getRpgMvEngineVersion(ctx)) }
    var rpgMzVersion by remember { mutableStateOf(EngineSettingsStore.getRpgMzEngineVersion(ctx)) }
    var rpg by remember { mutableStateOf(EngineSettingsStore.loadRpgMaker(ctx)) }
    var renpyVersion by remember { mutableStateOf(EngineSettingsStore.getRenpyVersion(ctx)) }
    var renpy by remember { mutableStateOf(EngineSettingsStore.loadRenPy(ctx)) }
    var siglusLanguage by remember { mutableStateOf(EngineSettingsStore.getSiglusLanguage(ctx)) }
    var fbNls by remember { mutableStateOf(EngineSettingsStore.getFbNls(ctx)) }
    var fvpNls by remember { mutableStateOf(EngineSettingsStore.getFvpNls(ctx)) }
    var fvpSystemFont by remember { mutableStateOf(EngineSettingsStore.isFvpSystemFont(ctx)) }
    var fvpTextHidpi by remember { mutableStateOf(EngineSettingsStore.isFvpTextHidpi(ctx)) }
    var fvpFont by remember { mutableStateOf(EngineSettingsStore.getFvpFont(ctx)) }
    var xs35Scoped by remember { mutableStateOf(EngineSettingsStore.isXs35ScopedSaveDir(ctx)) }
    var xs35Renderer by remember { mutableStateOf(EngineSettingsStore.getXs35Renderer(ctx)) }
    var xs35IntegerScale by remember { mutableStateOf(EngineSettingsStore.isXs35IntegerScale(ctx)) }
    var xs35MuteUnfocus by remember { mutableStateOf(EngineSettingsStore.isXs35MuteUnfocus(ctx)) }
    var xs4Scoped by remember { mutableStateOf(EngineSettingsStore.isXs4ScopedSaveDir(ctx)) }
    var xs4Encoding by remember { mutableStateOf(EngineSettingsStore.getXs4Encoding(ctx)) }
    var xs4FontGothic by remember { mutableStateOf(EngineSettingsStore.getXs4FontGothicPath(ctx)) }
    var xs4FontMincho by remember { mutableStateOf(EngineSettingsStore.getXs4FontMinchoPath(ctx)) }
    var xs4Joypad by remember { mutableStateOf(EngineSettingsStore.getXs4Joypad(ctx)) }
    var xs4MsgskipDelay by remember { mutableStateOf(EngineSettingsStore.getXs4MsgskipDelay(ctx)) }
    var winlator by remember { mutableStateOf(EngineSettingsStore.loadWinlator(ctx)) }
    var ppssppVersion by remember { mutableStateOf(EngineSettingsStore.getPpssppVersion(ctx)) }
    var webShellPort by remember { mutableStateOf(EngineSettingsStore.getWebShellPort(ctx)) }

    val fontImportScope = rememberCoroutineScope()
    var importingFont by remember { mutableStateOf(false) }
    val fontLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null && !importingFont) {
            importingFont = true
            fontImportScope.launch {
                try {
                    val path = FontImport.importToPrivate(ctx, uri)
                    if (path != null) krFont = path
                } finally { importingFont = false }
            }
        }
    }
    val fvpFontLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null && !importingFont) {
            importingFont = true
            fontImportScope.launch {
                try {
                    val path = FontImport.importToPrivate(ctx, uri)
                    if (path != null) fvpFont = path else {
                        android.widget.Toast.makeText(
                            ctx,
                            ctx.getString(R.string.engine_settings_fvp_font_import_failed),
                            android.widget.Toast.LENGTH_SHORT,
                        ).show()
                    }
                } finally { importingFont = false }
            }
        }
    }
    val xs4GothicFontLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null && !importingFont) {
            importingFont = true
            fontImportScope.launch {
                try {
                    val path = FontImport.importToPrivate(ctx, uri)
                    if (path != null) xs4FontGothic = path else {
                        android.widget.Toast.makeText(
                            ctx,
                            ctx.getString(R.string.engine_settings_fvp_font_import_failed),
                            android.widget.Toast.LENGTH_SHORT,
                        ).show()
                    }
                } finally { importingFont = false }
            }
        }
    }
    val xs4MinchoFontLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null && !importingFont) {
            importingFont = true
            fontImportScope.launch {
                try {
                    val path = FontImport.importToPrivate(ctx, uri)
                    if (path != null) xs4FontMincho = path else {
                        android.widget.Toast.makeText(
                            ctx,
                            ctx.getString(R.string.engine_settings_fvp_font_import_failed),
                            android.widget.Toast.LENGTH_SHORT,
                        ).show()
                    }
                } finally { importingFont = false }
            }
        }
    }

    val isSdl3 = krKernel == EngineSettingsStore.KERNEL_KRKRSDL3
    val krIs134 = krVersion == EngineSettingsStore.KR_134

    // 编辑→保存模型：控件仅更新本地状态，点顶部保存按钮才统一写盘
    fun saveAll() {
        graphicsFamily?.let { EngineSettingsStore.setGraphicsSettings(ctx, it, graphics) }
        EngineSettingsStore.setKrEngineVersion(ctx, krVersion)
        EngineSettingsStore.setKrKernel(ctx, krKernel)
        EngineSettingsStore.setKrScopedSaveDir(ctx, krScoped)
        EngineSettingsStore.setKrSkipStartupDialogs(ctx, krSkipStartupDialogs)
        EngineSettingsStore.setKrPatchOverlayMode(ctx, krPatchOverlayMode)
        EngineSettingsStore.setKrDefaultFont(ctx, krFont)
        EngineSettingsStore.setKrForceDefaultFont(ctx, krForceFont)
        EngineSettingsStore.setKrRenderer(ctx, krRenderer)
        EngineSettingsStore.setKrSoftwareDrawThread(ctx, krDrawThread)
        EngineSettingsStore.setKrSoftwareCompressTex(ctx, krSwCompress)
        EngineSettingsStore.setKrOglCompressTex(ctx, krOglCompress)
        EngineSettingsStore.setKrMemUsage(ctx, krMem)
        EngineSettingsStore.setKrOglMaxTexsize(ctx, krTexsize)
        EngineSettingsStore.setKrOglAccurateRender(ctx, krAccurate)
        EngineSettingsStore.setKrFpsLimit(ctx, krFps)
        EngineSettingsStore.setKrVCursorScale(ctx, krVCursorScale)
        EngineSettingsStore.setKrMenuHandlerOpa(ctx, krMenuOpa)
        EngineSettingsStore.saveOns(ctx, ons)
        EngineSettingsStore.setArtKernel(ctx, artKernel)
        EngineSettingsStore.setArtEngineVersion(ctx, artVersion)
        EngineSettingsStore.setArtRotateScreen(ctx, artRotate)
        EngineSettingsStore.setArtAutoPatch(ctx, artPatch)
        EngineSettingsStore.setArtResolution(ctx, artResolution)
        EngineSettingsStore.setArtSideCut(ctx, artSideCut)
        EngineSettingsStore.setArtSurfaceCacheSize(ctx, artSurfaceCache)
        EngineSettingsStore.setArtFontCacheSize(ctx, artFontCache)
        EngineSettingsStore.setArtPowerSaving(ctx, artPowerSaving)
        EngineSettingsStore.setTyranoExternalNetwork(ctx, tyExternal)
        EngineSettingsStore.setTyranoScopedSaveDir(ctx, tyScoped)
        EngineSettingsStore.setRpgMakerModEnabled(ctx, rpgMakerMod)
        EngineSettingsStore.setRpgLegacyRenderer(ctx, rpgLegacyRenderer)
        EngineSettingsStore.setRpgSaveInterop(ctx, rpgSaveInterop)
        EngineSettingsStore.setRpgMvEngineVersion(ctx, rpgMvVersion)
        EngineSettingsStore.setRpgMzEngineVersion(ctx, rpgMzVersion)
        EngineSettingsStore.saveRpgMaker(ctx, rpg)
        EngineSettingsStore.setRenpyVersion(ctx, renpyVersion)
        EngineSettingsStore.saveRenPy(ctx, renpy)
        EngineSettingsStore.setSiglusLanguage(ctx, siglusLanguage)
        EngineSettingsStore.setFbNls(ctx, fbNls)
        EngineSettingsStore.setFvpNls(ctx, fvpNls)
        EngineSettingsStore.setFvpSystemFont(ctx, fvpSystemFont)
        EngineSettingsStore.setFvpTextHidpi(ctx, fvpTextHidpi)
        EngineSettingsStore.setFvpFont(ctx, fvpFont)
        EngineSettingsStore.setXs35ScopedSaveDir(ctx, xs35Scoped)
        EngineSettingsStore.setXs35Renderer(ctx, xs35Renderer)
        EngineSettingsStore.setXs35IntegerScale(ctx, xs35IntegerScale)
        EngineSettingsStore.setXs35MuteUnfocus(ctx, xs35MuteUnfocus)
        EngineSettingsStore.setXs4ScopedSaveDir(ctx, xs4Scoped)
        EngineSettingsStore.setXs4Encoding(ctx, xs4Encoding)
        EngineSettingsStore.setXs4FontGothicPath(ctx, xs4FontGothic)
        EngineSettingsStore.setXs4FontMinchoPath(ctx, xs4FontMincho)
        EngineSettingsStore.setXs4Joypad(ctx, xs4Joypad)
        EngineSettingsStore.setXs4MsgskipDelay(ctx, xs4MsgskipDelay)
        EngineSettingsStore.saveWinlator(ctx, winlator)
        EngineSettingsStore.setPpssppVersion(ctx, ppssppVersion)
        EngineSettingsStore.setWebShellPort(ctx, webShellPort)
    }

    MiuixSettingsTheme {
        MiuixScaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = Color.Transparent,
            contentWindowInsets = WindowInsets(0.dp),
            topBar = {
                AppTopBar(
                    title = engineSettingsKindTitle(kind),
                    background = Color.Transparent,
                    contentColor = PageTextColor,
                    trailing = {
                        TopBarIcon(painterResource(R.drawable.ic_save), stringResource(R.string.engine_settings_save_content_description), MiuixTheme.colorScheme.primary) {
                            saveAll()
                            android.widget.Toast.makeText(ctx, engineSettingsSavedMessage, android.widget.Toast.LENGTH_SHORT).show()
                        }
                    },
                )
            },
        ) { innerPadding ->
            LazyListPlaceholder(
                kind,
                krVersion, krKernel, krScoped, krSkipStartupDialogs, krFont, krForceFont, krRenderer, krDrawThread,
                krSwCompress, krOglCompress, krMem, krTexsize, krAccurate, krFps, isSdl3, krIs134,
                krVCursorScale, krMenuOpa, krPatchOverlayMode,
                ons, artKernel, artVersion, artRotate, artPatch, artResolution, artSideCut, artSurfaceCache,
                artFontCache, artPowerSaving, tyExternal, tyScoped, rpgMakerMod, rpgLegacyRenderer, rpgSaveInterop, rpgMvVersion, rpgMzVersion, rpg, renpyVersion, renpy, siglusLanguage, fbNls,
                fvpNls, fvpSystemFont, fvpTextHidpi, fvpFont,
                xs35Scoped, xs35Renderer, xs35IntegerScale, xs35MuteUnfocus,
                xs4Scoped, xs4Encoding, xs4FontGothic, xs4FontMincho, xs4Joypad, xs4MsgskipDelay,
                fontLauncher, fvpFontLauncher, xs4GothicFontLauncher, xs4MinchoFontLauncher,
                winlator, ppssppVersion, webShellPort,
                topInset = innerPadding.calculateTopPadding(),
                graphicsContent = {
                    graphicsFamily?.let { family ->
                        GlobalGraphicsSettings(
                            settings = graphics,
                            capability = GraphicsCapabilities.forSettings(family, if (family == GraphicsFamily.KR) krKernel else artKernel, if (family == GraphicsFamily.KR) krVersion else artVersion, krRenderer),
                        ) { graphics = it }
                    }
                },
                onKrVersion = { krVersion = it },
                onKrKernel = { krKernel = it },
                onKrScoped = { krScoped = it },
                onKrSkipStartupDialogs = { krSkipStartupDialogs = it },
                onKrPatchOverlayMode = { krPatchOverlayMode = it },
                onKrForceFont = { krForceFont = it },
                onKrRenderer = { krRenderer = it },
                onKrDrawThread = { krDrawThread = it },
                onKrSwCompress = { krSwCompress = it },
                onKrOglCompress = { krOglCompress = it },
                onKrMem = { krMem = it },
                onKrTexsize = { krTexsize = it },
                onKrAccurate = { krAccurate = it },
                onKrFps = { krFps = it },
                onKrVCursorScale = { krVCursorScale = it },
                onKrMenuOpa = { krMenuOpa = it },
                onResetKrFont = { krFont = "" },
                onOns = { ons = it },
                onArtKernel = { artKernel = it },
                onArtVersion = { artVersion = it },
                onArtRotate = { artRotate = it },
                onArtPatch = { artPatch = it },
                onArtResolution = { artResolution = it },
                onArtSideCut = { artSideCut = it },
                onArtSurfaceCache = { artSurfaceCache = it },
                onArtFontCache = { artFontCache = it },
                onArtPowerSaving = { artPowerSaving = it },
                onTyExternal = { tyExternal = it },
                onTyScoped = { tyScoped = it },
                onRpgMakerMod = { rpgMakerMod = it },
                onRpgLegacyRenderer = { rpgLegacyRenderer = it },
                onRpgSaveInterop = { rpgSaveInterop = it },
                onRpgMvVersion = { rpgMvVersion = it },
                onRpgMzVersion = { rpgMzVersion = it },
                onRpg = { rpg = it },
                onRenpyVersion = { renpyVersion = it },
                onRenpy = { renpy = it },
                onSiglusLanguage = { siglusLanguage = it },
                onFbNls = { fbNls = it },
                onFvpNls = { fvpNls = it },
                onFvpSystemFont = { fvpSystemFont = it },
                onFvpTextHidpi = { fvpTextHidpi = it },
                onFvpFontFollow = { fvpFont = "" },
                onFvpFontPick = { fvpFontLauncher.launch("*/*") },
                onXs35Scoped = { xs35Scoped = it },
                onXs35Renderer = { xs35Renderer = it },
                onXs35IntegerScale = { xs35IntegerScale = it },
                onXs35MuteUnfocus = { xs35MuteUnfocus = it },
                onXs4Scoped = { xs4Scoped = it },
                onXs4Encoding = { xs4Encoding = it },
                onXs4FontGothicFollow = { xs4FontGothic = "" },
                onXs4FontGothicPick = { xs4GothicFontLauncher.launch("*/*") },
                onXs4FontMinchoFollow = { xs4FontMincho = "" },
                onXs4FontMinchoPick = { xs4MinchoFontLauncher.launch("*/*") },
                onXs4Joypad = { xs4Joypad = it },
                onXs4MsgskipDelay = { xs4MsgskipDelay = it },
                onWinlator = { winlator = it },
                onPpssppVersion = { ppssppVersion = it },
                onWebShellPort = { webShellPort = it },
            )
        }
    }
}

/** 顶部栏：统一复用 AppTopBar（Miuix 页面背景取色）。 */
@Composable
private fun SettingsTopBar(title: String) {
    AppTopBar(
        title = title,
        background = Color.Transparent,
        contentColor = PageTextColor,
    )
}

private typealias FontPickerLauncher = androidx.activity.compose.ManagedActivityResultLauncher<String, Uri?>

/** 引擎设置详情页的滚动列表内容：按 [kind] 渲染对应引擎的设置卡片。
 *  全部控件仅更新本地状态，统一由顶部保存按钮落盘（编辑→保存模型）。
 *  KRKR 专属卡片按内核/版本条件显隐：渲染项随 [isSdl3] 切换数据源，
 *  字体与「操作」卡片仅 kirikiri2 内核显示（krkrsdl3 走命令行参数不生效）。 */
@Composable
private fun LazyListPlaceholder(
    kind: EngineSettingsKind,
    krVersion: String, krKernel: String, krScoped: Boolean, krSkipStartupDialogs: Boolean,
    krFont: String, krForceFont: Boolean,
    krRenderer: String, krDrawThread: String, krSwCompress: String, krOglCompress: String,
    krMem: String, krTexsize: String, krAccurate: String, krFps: String, isSdl3: Boolean, krIs134: Boolean,
    krVCursorScale: String, krMenuOpa: String, krPatchOverlayMode: String,
    ons: EngineSettingsStore.Ons, artKernel: String, artVersion: String, artRotate: Boolean, artPatch: String,
    artResolution: String, artSideCut: String, artSurfaceCache: String, artFontCache: String,
    artPowerSaving: String,
    tyExternal: Boolean, tyScoped: Boolean, rpgMakerMod: Boolean,
    rpgLegacyRenderer: Boolean, rpgSaveInterop: Boolean, rpgMvVersion: String, rpgMzVersion: String,
    rpg: EngineSettingsStore.RpgMaker,
    renpyVersion: String, renpy: EngineSettingsStore.RenPy, siglusLanguage: String,
    fbNls: String,
    fvpNls: String, fvpSystemFont: Boolean, fvpTextHidpi: Boolean, fvpFont: String,
    xs35Scoped: Boolean, xs35Renderer: String, xs35IntegerScale: Boolean, xs35MuteUnfocus: Boolean,
    xs4Scoped: Boolean, xs4Encoding: String, xs4FontGothic: String, xs4FontMincho: String,
    xs4Joypad: String, xs4MsgskipDelay: Int,
    fontLauncher: FontPickerLauncher, fvpFontLauncher: FontPickerLauncher,
    xs4GothicFontLauncher: FontPickerLauncher, xs4MinchoFontLauncher: FontPickerLauncher,
    winlator: EngineSettingsStore.Winlator,
    ppssppVersion: String,
    webShellPort: Int,
    topInset: Dp,
    graphicsContent: @Composable () -> Unit,
    onKrVersion: (String) -> Unit, onKrKernel: (String) -> Unit, onKrScoped: (Boolean) -> Unit,
    onKrSkipStartupDialogs: (Boolean) -> Unit,
    onKrPatchOverlayMode: (String) -> Unit,
    onKrForceFont: (Boolean) -> Unit, onKrRenderer: (String) -> Unit, onKrDrawThread: (String) -> Unit,
    onKrSwCompress: (String) -> Unit, onKrOglCompress: (String) -> Unit, onKrMem: (String) -> Unit,
    onKrTexsize: (String) -> Unit, onKrAccurate: (String) -> Unit, onKrFps: (String) -> Unit,
    onKrVCursorScale: (String) -> Unit, onKrMenuOpa: (String) -> Unit,
    onResetKrFont: () -> Unit, onOns: (EngineSettingsStore.Ons) -> Unit,
    onArtKernel: (String) -> Unit,
    onArtVersion: (String) -> Unit, onArtRotate: (Boolean) -> Unit, onArtPatch: (String) -> Unit,
    onArtResolution: (String) -> Unit, onArtSideCut: (String) -> Unit,
    onArtSurfaceCache: (String) -> Unit, onArtFontCache: (String) -> Unit,
    onArtPowerSaving: (String) -> Unit,
    onTyExternal: (Boolean) -> Unit, onTyScoped: (Boolean) -> Unit, onRpgMakerMod: (Boolean) -> Unit,
    onRpgLegacyRenderer: (Boolean) -> Unit, onRpgSaveInterop: (Boolean) -> Unit, onRpgMvVersion: (String) -> Unit, onRpgMzVersion: (String) -> Unit,
    onRpg: (EngineSettingsStore.RpgMaker) -> Unit,
    onRenpyVersion: (String) -> Unit,
    onRenpy: (EngineSettingsStore.RenPy) -> Unit,
    onSiglusLanguage: (String) -> Unit,
    onFbNls: (String) -> Unit,
    onFvpNls: (String) -> Unit,
    onFvpSystemFont: (Boolean) -> Unit,
    onFvpTextHidpi: (Boolean) -> Unit,
    onFvpFontFollow: () -> Unit,
    onFvpFontPick: () -> Unit,
    onXs35Scoped: (Boolean) -> Unit,
    onXs35Renderer: (String) -> Unit,
    onXs35IntegerScale: (Boolean) -> Unit,
    onXs35MuteUnfocus: (Boolean) -> Unit,
    onXs4Scoped: (Boolean) -> Unit,
    onXs4Encoding: (String) -> Unit,
    onXs4FontGothicFollow: () -> Unit,
    onXs4FontGothicPick: () -> Unit,
    onXs4FontMinchoFollow: () -> Unit,
    onXs4FontMinchoPick: () -> Unit,
    onXs4Joypad: (String) -> Unit,
    onXs4MsgskipDelay: (Int) -> Unit,
    onWinlator: (EngineSettingsStore.Winlator) -> Unit,
    onPpssppVersion: (String) -> Unit,
    onWebShellPort: (Int) -> Unit,
) {
    val krSelectMap = krSelectOptions()
    val krKernelMap = krKernelOptions()
    val krPatchOverlayMap = krPatchOverlayOptions()
    val krRendererMap = krRendererOptions()
    val krSdl3RendererMap = krSdl3RendererOptions()
    val krThreadMap = krThreadOptions()
    val krSwCompressMap = krSoftwareCompressOptions()
    val krOglCompressMap = krOglCompressOptions()
    val krMemMap = krMemOptions()
    val krTexsizeMap = krTexSizeOptions()
    val krFpsMap = krFpsOptions()
    val onsSharpnessMap = onsSharpnessOptions()
    val onsEncodingMap = onsEncodingOptions()
    val artKernelSelect = artKernelOptions()
    val artVersionMap = artVersionOptions()
    val renpyVersionMap = renpyVersionOptions()
    val artPatchMap = artPatchOptions()
    val artResolutionMap = artResolutionOptions()
    val artToggleMap = artToggleOptions()
    val artSurfaceCacheMap = artSurfaceCacheOptions()
    val artFontCacheMap = artFontCacheOptions()

    LazyColumn(
        // 顶栏透明：列表整体垫在顶栏下方（持久 padding），避免滚动时内容穿过顶栏
        modifier = Modifier.fillMaxSize()
            .padding(horizontal = 12.dp)
            .padding(top = topInset),
        contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        if (kind == EngineSettingsKind.KRKR) item {
            EngineCard("KRKR") {
                SwitchPreference(title = stringResource(R.string.engine_settings_scoped_save_dir), checked = krScoped, onCheckedChange = onKrScoped)
                SwitchPreference(
                    title = stringResource(R.string.engine_settings_skip_startup_dialogs),
                    summary = stringResource(R.string.engine_settings_skip_startup_dialogs_summary),
                    checked = krSkipStartupDialogs,
                    onCheckedChange = onKrSkipStartupDialogs,
                )
                DropdownRow(stringResource(R.string.engine_settings_engine_version), krSelectMap, krVersion, onKrVersion)
                DropdownRow(stringResource(R.string.engine_settings_engine_kernel), krKernelMap, krKernel, onKrKernel)
                if (!isSdl3) {
                    DropdownRow(stringResource(R.string.engine_settings_krkr_patch_overlay), krPatchOverlayMap, krPatchOverlayMode, onKrPatchOverlayMode)
                }
            }
        }

        if (kind == EngineSettingsKind.KRKR) item {
            EngineCard(stringResource(R.string.engine_settings_render)) {
                if (!isSdl3) {
                    SwitchPreference(title = stringResource(R.string.engine_settings_opengl_accurate_render), checked = krAccurate == "1", onCheckedChange = { b -> onKrAccurate(if (b) "1" else "0") })
                    SliderRow(stringResource(R.string.engine_settings_memory_usage), krMemMap, krMem, onSelect = onKrMem)
                }
                val rendererOptions = if (isSdl3) krSdl3RendererMap else krRendererMap
                val selectedRenderer = if (isSdl3) {
                    krRenderer.ifEmpty { EngineSettingsStore.RENDERER_OPENGL }
                } else {
                    krRenderer.ifEmpty { "default" }
                }
                DropdownRow(stringResource(R.string.engine_settings_renderer), rendererOptions, selectedRenderer) {
                    onKrRenderer(if (!isSdl3 && it == "default") "" else it)
                }
                if (!isSdl3 && (krRenderer == "" || krRenderer == EngineSettingsStore.RENDERER_SOFTWARE)) {
                    SliderRow(stringResource(R.string.engine_settings_software_draw_threads), krThreadMap, krDrawThread, onSelect = onKrDrawThread)
                    DropdownRow(stringResource(R.string.engine_settings_software_texture_compression), krSwCompressMap, krSwCompress, onKrSwCompress)
                }
                if (!isSdl3 && !krIs134) {
                    SliderRow(stringResource(R.string.engine_settings_fps_limit), krFpsMap, krFps, onSelect = onKrFps)
                }
                if (!isSdl3 && (krRenderer == "" || krRenderer == EngineSettingsStore.RENDERER_OPENGL)) {
                    DropdownRow(stringResource(R.string.engine_settings_opengl_texture_compression), krOglCompressMap, krOglCompress, onKrOglCompress)
                    SliderRow(stringResource(R.string.engine_settings_max_texture_size), krTexsizeMap, krTexsize, onSelect = onKrTexsize)
                }
            }
        }

        if (kind == EngineSettingsKind.KRKR && !isSdl3) item {
            EngineCard(stringResource(R.string.engine_settings_font)) {
                FontPreference(
                    label = stringResource(R.string.engine_settings_default_font),
                    value = krFont.ifEmpty { stringResource(R.string.engine_settings_builtin_font) },
                    followLabel = stringResource(R.string.engine_settings_use_builtin_font),
                    onFollow = onResetKrFont,
                    onPick = { fontLauncher.launch("*/*") },
                )
                SwitchPreference(title = stringResource(R.string.engine_settings_force_default_font), checked = krForceFont, onCheckedChange = onKrForceFont)
                Text(
                    stringResource(R.string.engine_settings_force_font_hint),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MiuixTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                )
            }
        }

        if (kind == EngineSettingsKind.KRKR && !isSdl3) item {
            EngineCard(stringResource(R.string.engine_settings_operation)) {
                // 仅 kirikiri2 内核（libgame.so）读取这两项偏好，krkrsdl3 走命令行参数不生效
                // 虚拟鼠标 1..150%（50% 即原版 Ty 的 0.5），菜单不透明度 1..100%
                SliderRow(stringResource(R.string.engine_settings_vcursor_scale), krkrVcursorOptions(), krVCursorScale, discrete = false, onSelect = onKrVCursorScale)
                SliderRow(stringResource(R.string.engine_settings_menu_handler_opa), krkrPercentOptions(), krMenuOpa, discrete = false, onSelect = onKrMenuOpa)
            }
        }

        if (kind == EngineSettingsKind.ONS) item {
            EngineCard("ONS") {
                SwitchPreference(title = stringResource(R.string.engine_settings_scoped_save_dir), checked = ons.scopedSaveDir, onCheckedChange = { b -> onOns(ons.copy(scopedSaveDir = b)) })
                SwitchPreference(title = stringResource(R.string.engine_settings_fullscreen_stretch), checked = ons.stretchFull, onCheckedChange = { b -> onOns(ons.copy(stretchFull = b)) })
                SwitchPreference(title = stringResource(R.string.engine_settings_ignore_cutout), checked = ons.ignoreCutout, onCheckedChange = { b -> onOns(ons.copy(ignoreCutout = b)) })
                SwitchPreference(title = stringResource(R.string.engine_settings_disable_video), checked = ons.disableVideo, onCheckedChange = { b -> onOns(ons.copy(disableVideo = b)) })
                SwitchPreference(title = stringResource(R.string.engine_settings_sharpness), checked = ons.sharpness, onCheckedChange = { b -> onOns(ons.copy(sharpness = b)) })
                if (ons.sharpness) {
                    SliderRow(stringResource(R.string.engine_settings_sharpness_strength), onsSharpnessMap, ons.sharpnessValue) {
                        onOns(ons.copy(sharpnessValue = it))
                    }
                }
                DropdownRow(stringResource(R.string.engine_settings_text_encoding), onsEncodingMap, EngineSettingsStore.normalizeEncoding(ons.encoding)) {
                    onOns(ons.copy(encoding = it))
                }
            }
        }

        if (kind == EngineSettingsKind.ARTEMIS) item {
            EngineCard("Artemis") {
                DropdownRow(stringResource(R.string.engine_settings_engine_kernel), artKernelSelect, artKernel, onArtKernel)
                SwitchPreference(title = stringResource(R.string.engine_settings_rotate_screen), checked = artRotate, onCheckedChange = onArtRotate)
                if (artKernel == EngineSettingsStore.ART_KERNEL_OFFICIAL) {
                    DropdownRow(stringResource(R.string.engine_settings_engine_version), artVersionMap, artVersion, onArtVersion)
                    DropdownRow(stringResource(R.string.engine_settings_auto_patch), artPatchMap, artPatch, onArtPatch)
                    DropdownRow(stringResource(R.string.engine_settings_artemis_resolution), artResolutionMap, artResolution, onArtResolution)
                    DropdownRow(stringResource(R.string.engine_settings_artemis_side_cut), artToggleMap, artSideCut, onArtSideCut)
                    DropdownRow(stringResource(R.string.engine_settings_artemis_surface_cache), artSurfaceCacheMap, artSurfaceCache, onArtSurfaceCache)
                    DropdownRow(stringResource(R.string.engine_settings_artemis_font_cache), artFontCacheMap, artFontCache, onArtFontCache)
                    DropdownRow(stringResource(R.string.engine_settings_artemis_power_saving), artToggleMap, artPowerSaving, onArtPowerSaving)
                } else {
                    // 自研内核直接读游戏包内配置，官方专属项（版本/补丁/显示注入）不适用
                    Text(
                        stringResource(R.string.engine_settings_artemis_clean_hint),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    )
                }
            }
        }

        if (kind == EngineSettingsKind.TYRANO) item {
            EngineCard("Tyrano") {
                // RPG Maker Web 与 Tyrano 共用同一套 WebView 宿主开关，避免同类引擎重复配置。
                SwitchPreference(title = stringResource(R.string.engine_settings_external_network_resources), checked = tyExternal, onCheckedChange = onTyExternal)
                SwitchPreference(title = stringResource(R.string.engine_settings_scoped_save_dir), checked = tyScoped, onCheckedChange = onTyScoped)
                // Tyrano / WebOther / VN：固定端口保证 WebView 存档域（origin）跨启动稳定
                WinlatorValueRow(
                    label = stringResource(R.string.engine_settings_web_shell_port_title),
                    summaryHint = stringResource(R.string.engine_settings_web_shell_port_summary),
                    value = webShellPort.toString(),
                    sanitize = { it.filter { ch -> ch.isDigit() }.take(5) },
                    validate = { it.isNotEmpty() && (it.toIntOrNull()?.let { port -> port in 1..65535 } == true) },
                    keyboardType = KeyboardType.Number,
                    onValueChange = { onWebShellPort(it.toInt()) },
                )
            }
        }

        if (kind == EngineSettingsKind.RPG_MAKER) item {
            EngineCard("RPG Maker MV/MZ") {
                SwitchPreference(title = stringResource(R.string.engine_settings_external_network_resources), checked = tyExternal, onCheckedChange = onTyExternal)
                SwitchPreference(title = stringResource(R.string.engine_settings_scoped_save_dir), checked = tyScoped, onCheckedChange = onTyScoped)
                SwitchPreference(title = stringResource(R.string.engine_settings_game_modifier), checked = rpgMakerMod, onCheckedChange = onRpgMakerMod)
                SwitchPreference(title = stringResource(R.string.engine_settings_legacy_renderer), checked = rpgLegacyRenderer, onCheckedChange = onRpgLegacyRenderer)
                SwitchPreference(title = stringResource(R.string.engine_settings_save_interop), checked = rpgSaveInterop, onCheckedChange = onRpgSaveInterop)
                DropdownRow(stringResource(R.string.engine_settings_engine_version_mv), rpgMvVersionOptions(), rpgMvVersion, onRpgMvVersion)
                DropdownRow(stringResource(R.string.engine_settings_engine_version_mz), rpgMzVersionOptions(), rpgMzVersion, onRpgMzVersion)
            }
        }

        if (kind == EngineSettingsKind.RPG_MAKER) item {
            RpgMakerRgssSettingsCard(settings = rpg, onSettings = onRpg)
        }

        if (kind == EngineSettingsKind.RENPY) item {
            EngineCard("Ren'Py") {
                DropdownRow(stringResource(R.string.engine_settings_engine_version), renpyVersionMap, renpyVersion, onRenpyVersion)
                Text(
                    stringResource(R.string.engine_settings_renpy_module_description_global),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MiuixTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                )
            }
        }

        if (kind == EngineSettingsKind.RENPY) item {
            RenPySettingsCard(settings = renpy, onSettings = onRenpy)
        }

        if (kind == EngineSettingsKind.SIGLUS) item {
            EngineCard("Siglus") {
                DropdownRow(
                    stringResource(R.string.engine_settings_siglus_language_title),
                    siglusLanguageOptions(),
                    siglusLanguage,
                    onSiglusLanguage,
                )
                Text(
                    stringResource(R.string.engine_settings_siglus_note),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MiuixTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                )
            }
        }

        if (kind == EngineSettingsKind.FRAMEBUFFER) item {
            EngineCard("RealLive / AVG32 / UK2") {
                DropdownRow(
                    stringResource(R.string.engine_settings_fb_nls_title),
                    fbNlsOptions(),
                    fbNls,
                    onFbNls,
                )
                Text(
                    stringResource(R.string.engine_settings_fb_note),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MiuixTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                )
            }
        }

        if (kind == EngineSettingsKind.FVP) item {
            EngineCard("FVP") {
                DropdownRow(
                    stringResource(R.string.engine_settings_fvp_nls_title),
                    fvpNlsOptions(),
                    fvpNls,
                    onFvpNls,
                )
                SwitchPreference(
                    title = stringResource(R.string.engine_settings_fvp_system_font_title),
                    summary = stringResource(R.string.engine_settings_fvp_system_font_summary),
                    checked = fvpSystemFont,
                    onCheckedChange = onFvpSystemFont,
                )
                SwitchPreference(
                    title = stringResource(R.string.engine_settings_fvp_text_hidpi_title),
                    summary = stringResource(R.string.engine_settings_fvp_text_hidpi_summary),
                    checked = fvpTextHidpi,
                    onCheckedChange = onFvpTextHidpi,
                )
                FontPreference(
                    label = stringResource(R.string.engine_settings_fvp_font_title),
                    value = fvpFont.ifBlank { stringResource(R.string.engine_settings_fvp_font_follow) },
                    followLabel = stringResource(R.string.engine_settings_fvp_font_follow),
                    onFollow = onFvpFontFollow,
                    onPick = onFvpFontPick,
                )
                Text(
                    stringResource(R.string.engine_settings_fvp_font_hint),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MiuixTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                )
                Text(
                    stringResource(R.string.engine_settings_fvp_note),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MiuixTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                )
            }
        }

        if (kind == EngineSettingsKind.XSYS35) item {
            EngineCard(stringResource(R.string.engine_settings_xsys35_title)) {
                DropdownRow(
                    stringResource(R.string.engine_settings_xsys35_renderer_title),
                    xsys35RendererOptions(),
                    xs35Renderer,
                    onXs35Renderer,
                )
                SwitchPreference(
                    title = stringResource(R.string.engine_settings_scoped_save_dir),
                    checked = xs35Scoped,
                    onCheckedChange = onXs35Scoped,
                )
                SwitchPreference(
                    title = stringResource(R.string.engine_settings_xsys35_integer_scale_title),
                    checked = xs35IntegerScale,
                    onCheckedChange = onXs35IntegerScale,
                )
                SwitchPreference(
                    title = stringResource(R.string.engine_settings_xsys35_mute_unfocus_title),
                    checked = xs35MuteUnfocus,
                    onCheckedChange = onXs35MuteUnfocus,
                )
                Text(
                    stringResource(R.string.engine_settings_xsys35_note),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MiuixTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                )
            }
        }

        if (kind == EngineSettingsKind.XSYS4) item {
            EngineCard(stringResource(R.string.engine_settings_xsys4_title)) {
                SwitchPreference(
                    title = stringResource(R.string.engine_settings_scoped_save_dir),
                    checked = xs4Scoped,
                    onCheckedChange = onXs4Scoped,
                )
                DropdownRow(
                    stringResource(R.string.engine_settings_xsys4_encoding_title),
                    xsys4EncodingOptions(),
                    xs4Encoding,
                    onXs4Encoding,
                )
                FontPreference(
                    label = stringResource(R.string.engine_settings_xsys4_font_gothic_title),
                    value = xs4FontGothic.ifBlank { stringResource(R.string.engine_settings_builtin_font) },
                    followLabel = stringResource(R.string.engine_settings_use_builtin_font),
                    onFollow = onXs4FontGothicFollow,
                    onPick = onXs4FontGothicPick,
                )
                FontPreference(
                    label = stringResource(R.string.engine_settings_xsys4_font_mincho_title),
                    value = xs4FontMincho.ifBlank { stringResource(R.string.engine_settings_builtin_font) },
                    followLabel = stringResource(R.string.engine_settings_use_builtin_font),
                    onFollow = onXs4FontMinchoFollow,
                    onPick = onXs4FontMinchoPick,
                )
                Text(
                    stringResource(R.string.engine_settings_xsys4_font_hint),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MiuixTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                )
                DropdownRow(
                    stringResource(R.string.engine_settings_xsys4_joypad_title),
                    xsys4JoypadOptions(),
                    xs4Joypad,
                    onXs4Joypad,
                )
                DropdownRow(
                    stringResource(R.string.engine_settings_xsys4_msgskip_title),
                    xsys4MsgskipOptions(),
                    xs4MsgskipDelay.toString(),
                    { onXs4MsgskipDelay(it.toIntOrNull() ?: EngineSettingsStore.XSYS4_MSGSKIP_DELAY_DEFAULT) },
                )
                Text(
                    stringResource(R.string.engine_settings_xsys4_note),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MiuixTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                )
                Text(
                    stringResource(R.string.engine_settings_xsys4_compat_hint),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MiuixTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                )
            }
        }

        if (kind == EngineSettingsKind.PPSSPP) item {
            EngineCard("PPSSPP") {
                DropdownRow(
                    stringResource(R.string.engine_settings_ppsspp_version_title),
                    ppssppVersionOptions(),
                    ppssppVersion,
                    onPpssppVersion,
                )
                Text(
                    stringResource(R.string.engine_settings_ppsspp_note),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MiuixTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                )
            }
        }

        if (kind == EngineSettingsKind.WINLATOR) item {
            EngineCard("Winlator") {
                WinlatorValueRow(
                    label = stringResource(R.string.engine_settings_winlator_container_id_title),
                    summaryHint = stringResource(R.string.engine_settings_winlator_container_id_summary),
                    value = if (winlator.containerId > 0) winlator.containerId.toString() else "",
                    sanitize = { it.filter { ch -> ch.isDigit() }.take(6) },
                    keyboardType = KeyboardType.Number,
                    onValueChange = { text ->
                        onWinlator(winlator.copy(containerId = text.toIntOrNull()?.coerceAtLeast(0) ?: 0))
                    },
                )
                WinlatorValueRow(
                    label = stringResource(R.string.engine_settings_winlator_container_name_title),
                    summaryHint = stringResource(R.string.engine_settings_winlator_container_name_summary),
                    value = winlator.containerName,
                    onValueChange = { onWinlator(winlator.copy(containerName = it)) },
                )
                DropdownRow(
                    stringResource(R.string.engine_settings_winlator_graphics_driver_title),
                    winlatorGraphicsDriverOptions(),
                    winlator.graphicsDriver,
                ) { onWinlator(winlator.copy(graphicsDriver = it)) }
                DropdownRow(
                    stringResource(R.string.engine_settings_winlator_dxwrapper_title),
                    winlatorDxWrapperOptions(),
                    winlator.dxwrapper,
                ) { onWinlator(winlator.copy(dxwrapper = it)) }
                DropdownRow(
                    stringResource(R.string.engine_settings_winlator_screen_size_title),
                    winlatorScreenSizeOptions(),
                    winlator.screenSize,
                ) { onWinlator(winlator.copy(screenSize = it)) }
                DropdownRow(
                    stringResource(R.string.engine_settings_winlator_lc_all_title),
                    winlatorLcAllOptions(),
                    winlator.lcAll,
                ) { onWinlator(winlator.copy(lcAll = it)) }
                DropdownRow(
                    stringResource(R.string.engine_settings_winlator_tz_title),
                    winlatorTimezoneOptions(),
                    winlator.tz,
                ) { onWinlator(winlator.copy(tz = it)) }
                DropdownRow(
                    stringResource(R.string.engine_settings_winlator_box64_preset_title),
                    winlatorBox64PresetOptions(),
                    winlator.box64Preset,
                ) { onWinlator(winlator.copy(box64Preset = it)) }
                SwitchPreference(
                    title = stringResource(R.string.engine_settings_winlator_save_title),
                    summary = stringResource(R.string.engine_settings_winlator_save_summary),
                    checked = winlator.save,
                    onCheckedChange = { onWinlator(winlator.copy(save = it)) },
                )
                Text(
                    stringResource(R.string.engine_settings_winlator_note),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MiuixTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                )
            }
        }

        if (kind.graphicsFamily() != null) item { graphicsContent() }
        item { BottomInsetSpacer() }
    }

}

/**
 * 值编辑行：ArrowPreference 展示当前值（空值显示「跟随容器配置」），点击弹统一输入框；
 * 仅更新本地状态，落盘由页面顶部保存按钮统一处理。[sanitize] 用于输入即时过滤（如容器 ID 仅数字）。
 */
@Composable
private fun WinlatorValueRow(
    label: String,
    summaryHint: String,
    value: String,
    onValueChange: (String) -> Unit,
    sanitize: ((String) -> String)? = null,
    validate: (String) -> Boolean = { true },
    keyboardType: KeyboardType = KeyboardType.Text,
) {
    var showDialog by remember { mutableStateOf(false) }
    ArrowPreference(
        title = label,
        summary = value.ifBlank { stringResource(R.string.engine_settings_winlator_follow_container) },
        onClick = { showDialog = true },
    )
    if (showDialog) {
        WinlatorValueDialog(
            title = label,
            hint = summaryHint,
            initial = value,
            sanitize = sanitize,
            validate = validate,
            keyboardType = keyboardType,
            onDismiss = { showDialog = false },
            onConfirm = {
                onValueChange(it)
                showDialog = false
            },
        )
    }
}

@Composable
private fun WinlatorValueDialog(
    title: String,
    hint: String,
    initial: String,
    sanitize: ((String) -> String)?,
    validate: (String) -> Boolean,
    keyboardType: KeyboardType,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit,
) {
    var text by remember(initial) { mutableStateOf(initial) }
    val normalized = text.trim()
    val canConfirm = normalized.isEmpty() || validate(normalized)
    AppAlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, style = MaterialTheme.typography.titleMedium) },
        text = {
            // 输入区内禁用全部点击/按压反馈（无涟漪）
            CompositionLocalProvider(LocalIndication provides NoIndication) {
                Column {
                    AppSearchField(
                        query = text,
                        onQueryChange = { text = sanitize?.invoke(it) ?: it },
                        onSearch = { if (canConfirm) onConfirm(normalized) },
                        leadingIcon = painterResource(R.drawable.ic_sheet_rename),
                        iconContentDescription = title,
                        imeAction = ImeAction.Done,
                        keyboardType = keyboardType,
                        textStyle = MaterialTheme.typography.bodyMedium,
                    )
                    Text(
                        hint,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 8.dp),
                    )
                }
            }
        },
        confirmButton = {
            DialogTextButton(
                text = stringResource(R.string.common_save),
                enabled = canConfirm,
                onClick = { onConfirm(normalized) },
            )
        },
        dismissButton = {
            DialogTextButton(
                text = stringResource(R.string.common_cancel),
                onClick = onDismiss,
            )
        },
    )
}


@Composable
internal fun EngineCard(header: String, content: @Composable () -> Unit) {
    MiuixCard(modifier = Modifier.fillMaxWidth().glassBorder(), cornerRadius = AppComponentCornerRadius) {
        Column(Modifier.padding(vertical = 6.dp)) {
            Text(
                header,
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
            )
            content()
        }
    }
}

/** 单选下拉行：Miuix OverlayDropdownPreference，点击展开覆盖式选项浮层，选中即回填。 */
@Composable
internal fun DropdownRow(
    label: String,
    options: List<Pair<String, String>>,
    current: String,
    onSelect: (String) -> Unit,
) {
    val keys = options.map { it.first }
    val labels = options.map { it.second }
    val index = keys.indexOf(current).takeIf { it >= 0 } ?: 0
    OverlayDropdownPreference(
        title = label,
        items = labels,
        selectedIndex = index,
        onSelectedIndexChange = { onSelect(keys[it]) },
    )
}

/**
 * 档次/数字滑杆行：ArrowPreference 底部内嵌 Slider，档位映射为整数索引；
 * [discrete] 控制是否开启 keyPoints 磁吸 + Step 震动反馈（枚举档位 true，连续档位 false）。
 * 右侧实时显示当前档位文本；拖拽只更新本地状态，松手（onValueChangeFinished）才回调写盘。
 */
@Composable
private fun SliderRow(
    label: String,
    options: List<Pair<String, String>>,
    current: String,
    discrete: Boolean = true,
    onSelect: (String) -> Unit,
) {
    val initIndex = options.indexOfFirst { it.first == current }.takeIf { it >= 0 } ?: 0
    var sliderIndex by remember(current) { mutableIntStateOf(initIndex) }
    ArrowPreference(
        title = label,
        endActions = {
            Text(
                options[sliderIndex].second,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        },
        onClick = { },
        bottomAction = {
            if (discrete) {
                Slider(
                    value = sliderIndex.toFloat(),
                    onValueChange = { sliderIndex = it.roundToInt().coerceIn(0, options.size - 1) },
                    onValueChangeFinished = { onSelect(options[sliderIndex].first) },
                    valueRange = 0f..(options.size - 1).toFloat(),
                    showKeyPoints = true,
                    keyPoints = (0 until options.size).map { it.toFloat() },
                    magnetThreshold = 0.25f,
                    hapticEffect = SliderDefaults.SliderHapticEffect.Step,
                )
            } else {
                Slider(
                    value = sliderIndex.toFloat(),
                    onValueChange = { sliderIndex = it.roundToInt().coerceIn(0, options.size - 1) },
                    onValueChangeFinished = { onSelect(options[sliderIndex].first) },
                    valueRange = 0f..(options.size - 1).toFloat(),
                )
            }
        },
    )
}

/** KRKR 百分比选项：""（引擎默认）+ 1..100%，供全局滑杆与单游戏下拉共用；顶层 val 取不到 stringResource，故封装为函数。 */
@Composable
internal fun krkrPercentOptions(): List<Pair<String, String>> =
    listOf("" to stringResource(R.string.engine_option_engine_default)) + (1..100).map { it.toString() to "$it%" }

/** KRKR 虚拟鼠标专用：0.01..1.50 两位小数（0.50 与 Tyranor 2.3.4 的 0.5 等价，下限 0.01） */
@Composable
internal fun krkrVcursorOptions(): List<Pair<String, String>> =
    listOf("" to stringResource(R.string.engine_option_engine_default)) +
        (1..150).map {
            val v = formatUiDecimal(it / 100.0, fractionDigits = 2)
            v to v
        }
/** 游戏目录 URI → 可读目录名（取 SAF documentId 的最后一段，失败回退原 uri）。 */
private fun scanDirName(context: android.content.Context, uri: String): String =
    if (uri.startsWith('/')) {
        runCatching { File(uri).name.takeIf { it.isNotBlank() } ?: uri }.getOrDefault(uri)
    } else {
        runCatching {
            val docId = DocumentsContract.getTreeDocumentId(android.net.Uri.parse(uri))
            docId.substringAfterLast(':').substringAfterLast('/').ifBlank { uri }
        }.getOrDefault(uri)
    }

/** 游戏根目录是否仍可访问（被改名/删除/权限失效时返回 false；TF 卡暂时拔出也会显示失效，重插后恢复）。 */
private fun isScanDirValid(context: android.content.Context, uri: String): Boolean =
    if (uri.startsWith('/')) {
        runCatching { File(uri).isDirectory }.getOrDefault(false)
    } else {
        runCatching {
            val doc = DocumentFile.fromTreeUri(context, android.net.Uri.parse(uri))
            doc != null && doc.isDirectory
        }.getOrDefault(false)
    }

/**
 * 手动添加共享存储路径前检查“管理所有文件”权限。
 * Android 11+ 上原生引擎无法仅凭 SAF 授权读取 /storage 真实路径；缺少权限时
 * 尝试打开系统授权页并返回 true（调用方应提示用户并暂不保存），与 EngineLauncher 启动前校验保持一致。
 */
private fun guideAllFilesAccessIfNeeded(context: android.content.Context, path: String): Boolean {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return false
    if (Environment.isExternalStorageManager()) return false
    if (!EngineLauncher.needsAllFilesAccess(path)) return false
    val app = context.applicationContext
    val packageUri = Uri.parse("package:${app.packageName}")
    runCatching {
        app.startActivity(
            Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, packageUri)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
    }.recoverCatching {
        app.startActivity(
            Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
    }
    return true
}
