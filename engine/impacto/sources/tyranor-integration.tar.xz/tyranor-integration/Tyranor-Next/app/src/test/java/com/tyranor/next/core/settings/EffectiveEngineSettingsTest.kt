package com.tyranor.next.core.settings

import com.tyranor.next.core.engine.EngineType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class EffectiveEngineSettingsTest {

    @Test
    fun resolvePrefersOverrideAndFallsBackToGlobal() {
        assertEquals("game", EffectiveEngineSettings.resolve("game", "global"))
        assertEquals("global", EffectiveEngineSettings.resolve(null, "global"))
    }

    @Test
    fun resolveBoolPrefersOverrideAndFallsBackToGlobal() {
        assertTrue(EffectiveEngineSettings.resolveBool(true, false))
        assertFalse(EffectiveEngineSettings.resolveBool(false, true))
        assertTrue(EffectiveEngineSettings.resolveBool(null, true))
    }

    @Test
    fun resolveAllowedRejectsIllegalOverrideAndGlobal() {
        val allowed = setOf("auto", "force", "off")
        assertEquals("force", EffectiveEngineSettings.resolveAllowed("force", "auto", allowed, "auto"))
        // 非法覆盖回退全局
        assertEquals("off", EffectiveEngineSettings.resolveAllowed("bogus", "off", allowed, "auto"))
        // 全局也非法时回退 fallback
        assertEquals("auto", EffectiveEngineSettings.resolveAllowed(null, "bogus", allowed, "auto"))
        // 覆盖值去空白
        assertEquals("force", EffectiveEngineSettings.resolveAllowed(" force ", "auto", allowed, "auto"))
    }

    @Test
    fun krKernelFallsBackOnRemovableStorage() {
        assertEquals(
            EngineSettingsStore.KERNEL_KIRIKIRI2,
            EffectiveEngineSettings.resolveKrKernel(
                EngineSettingsStore.KERNEL_KRKRSDL3,
                EngineSettingsStore.KERNEL_KRKRSDL3,
                removableStorage = true,
            ),
        )
        assertEquals(
            EngineSettingsStore.KERNEL_KRKRSDL3,
            EffectiveEngineSettings.resolveKrKernel(
                EngineSettingsStore.KERNEL_KRKRSDL3,
                EngineSettingsStore.KERNEL_KRKRSDL3,
                removableStorage = false,
            ),
        )
        assertEquals(
            EngineSettingsStore.KERNEL_KIRIKIRI2,
            EffectiveEngineSettings.resolveKrKernel(
                EngineSettingsStore.KERNEL_KIRIKIRI2,
                EngineSettingsStore.KERNEL_KRKRSDL3,
                removableStorage = false,
            ),
        )
    }

    @Test
    fun rpgMakerModEnabledOnlyForMvMz() {
        assertTrue(EffectiveEngineSettings.resolveRpgMakerModEnabled(EngineType.RPG_MV, null, true))
        assertFalse(EffectiveEngineSettings.resolveRpgMakerModEnabled(EngineType.RPG_MV, false, true))
        assertFalse(EffectiveEngineSettings.resolveRpgMakerModEnabled(EngineType.TYRANO, true, true))
        assertFalse(EffectiveEngineSettings.resolveRpgMakerModEnabled(EngineType.WEB_OTHER, true, true))
    }

    @Test
    fun rpgVersionValidatesOverrideAgainstWhitelist() {
        val allowed = setOf(
            EngineSettingsStore.RPG_MV_V0,
            EngineSettingsStore.RPG_MV_V1,
            EngineSettingsStore.RPG_MV_V2,
        )
        assertEquals(
            EngineSettingsStore.RPG_MV_V2,
            EffectiveEngineSettings.resolveRpgVersion("V2", "v0", allowed, "v0"),
        )
        assertEquals(
            EngineSettingsStore.RPG_MV_V0,
            EffectiveEngineSettings.resolveRpgVersion("v9", "v0", allowed, "v0"),
        )
        assertEquals(
            EngineSettingsStore.RPG_MV_V1,
            EffectiveEngineSettings.resolveRpgVersion(null, "v1", allowed, "v0"),
        )
    }

    @Test
    fun mergeOnsFollowsGlobalWhenNoOverride() {
        val global = EngineSettingsStore.Ons(scopedSaveDir = false, sharpness = true)
        assertEquals(global, EffectiveEngineSettings.mergeOns(global, null))
    }

    @Test
    fun mergeOnsAppliesFieldOverridesOnly() {
        val global = EngineSettingsStore.Ons(
            scopedSaveDir = true,
            stretchFull = false,
            ignoreCutout = true,
            disableVideo = false,
            sharpness = false,
            sharpnessValue = "2",
            encoding = "gbk",
        )
        val merged = EffectiveEngineSettings.mergeOns(
            global,
            OnsOverride(
                scopedSaveDir = false,
                sharpness = true,
                sharpnessValue = "4.5",
                encoding = "utf-8",
            ),
        )
        assertFalse(merged.scopedSaveDir)
        assertTrue(merged.sharpness)
        assertEquals("4.5", merged.sharpnessValue)
        // 编码统一归一
        assertEquals("utf8", merged.encoding)
        // 未覆盖字段保持全局
        assertFalse(merged.stretchFull)
        assertTrue(merged.ignoreCutout)
    }

    @Test
    fun mergeRpgMakerFollowsGlobalWhenNoOverride() {
        val global = EngineSettingsStore.RpgMaker(vsync = true, windowSize = "1280x720")
        assertEquals(global, EffectiveEngineSettings.mergeRpgMaker(global, null))
        assertEquals(global, EffectiveEngineSettings.mergeRpgMaker(global, RpgMakerOverride()))
    }

    @Test
    fun mergeRpgMakerAppliesFieldOverridesOnly() {
        val global = EngineSettingsStore.RpgMaker(
            useRuby18 = true,
            vsync = false,
            smoothScaling = true,
            windowSize = "640x480",
            speedUp = "1",
            fontScale = "0.75",
            customFont = "/global/font.ttf",
        )
        val merged = EffectiveEngineSettings.mergeRpgMaker(
            global,
            RpgMakerOverride(
                useRuby18 = false,
                vsync = true,
                windowSize = "1920x1080",
                speedUp = "5",
                customFont = "/game/font.ttf",
            ),
        )

        assertFalse(merged.useRuby18)
        assertTrue(merged.vsync)
        assertEquals("1920x1080", merged.windowSize)
        assertEquals("5", merged.speedUp)
        assertEquals("/game/font.ttf", merged.customFont)
        // 未覆盖字段保持全局
        assertTrue(merged.smoothScaling)
        assertEquals("0.75", merged.fontScale)
    }

    @Test
    fun mergeRpgMakerRejectsIllegalWhitelistValues() {
        val global = EngineSettingsStore.RpgMaker(
            windowSize = "800x600",
            speedUp = "2",
            fontScale = "1.00",
        )
        val merged = EffectiveEngineSettings.mergeRpgMaker(
            global,
            RpgMakerOverride(
                windowSize = "bogus",
                speedUp = "42",
                fontScale = "",
            ),
        )

        assertEquals("800x600", merged.windowSize)
        assertEquals("2", merged.speedUp)
        assertEquals("1.00", merged.fontScale)
    }

    @Test
    fun mergeRpgMakerAllowsExplicitEmptyCustomFont() {
        val global = EngineSettingsStore.RpgMaker(customFont = "/global/font.ttf")
        val merged = EffectiveEngineSettings.mergeRpgMaker(global, RpgMakerOverride(customFont = ""))
        assertEquals("", merged.customFont)
    }

    @Test
    fun fvpNlsUsesWhitelistFallback() {
        val allowed = EngineSettingsStore.FVP_NLS_VALUES
        // 覆盖值合法：优先覆盖
        assertEquals("gbk", EffectiveEngineSettings.resolveAllowed("gbk", "sjis", allowed, "sjis"))
        // 覆盖值非法：回退全局
        assertEquals("sjis", EffectiveEngineSettings.resolveAllowed("bogus", "sjis", allowed, "sjis"))
        // 无覆盖：使用全局
        assertEquals("utf8", EffectiveEngineSettings.resolveAllowed(null, "utf8", allowed, "sjis"))
        // 全局非法：回退默认 sjis
        assertEquals("sjis", EffectiveEngineSettings.resolveAllowed(null, "bogus", allowed, "sjis"))
    }

    @Test
    fun fvpBoolOverridesFollowGlobal() {
        assertTrue(EffectiveEngineSettings.resolveBool(null, true))
        assertFalse(EffectiveEngineSettings.resolveBool(false, true))
        assertTrue(EffectiveEngineSettings.resolveBool(true, false))
    }

    @Test
    fun fvpFontOverrideSupportsExplicitGameDefault() {
        // 覆盖路径优先
        assertEquals(
            "/data/fonts/a.ttf",
            EffectiveEngineSettings.resolve("/data/fonts/a.ttf", "/data/fonts/global.ttf"),
        )
        // 显式空串 = 跟随游戏默认（合法覆盖值，不回落全局）
        assertEquals("", EffectiveEngineSettings.resolve("", "/data/fonts/global.ttf"))
        // 无覆盖回落全局
        assertEquals(
            "/data/fonts/global.ttf",
            EffectiveEngineSettings.resolve(null, "/data/fonts/global.ttf"),
        )
    }

    @Test
    fun xsys35RendererUsesWhitelistFallback() {
        val allowed = EngineSettingsStore.XSYS35_RENDERER_VALUES
        // 覆盖值合法：优先覆盖
        assertEquals("opengl", EffectiveEngineSettings.resolveAllowed("opengl", "software", allowed, "auto"))
        // 覆盖值非法：回退全局
        assertEquals("software", EffectiveEngineSettings.resolveAllowed("vulkan", "software", allowed, "auto"))
        // 无覆盖：使用全局
        assertEquals("opengl", EffectiveEngineSettings.resolveAllowed(null, "opengl", allowed, "auto"))
        // 全局也非法：回退默认 auto
        assertEquals("auto", EffectiveEngineSettings.resolveAllowed(null, "bogus", allowed, "auto"))
    }

    @Test
    fun xsys35BoolOverridesFollowGlobal() {
        assertTrue(EffectiveEngineSettings.resolveBool(null, true))
        assertFalse(EffectiveEngineSettings.resolveBool(false, true))
        assertTrue(EffectiveEngineSettings.resolveBool(true, false))
    }

    @Test
    fun xs4EncodingFallsBackToSjisWhenInvalid() {
        val allowed = EngineSettingsStore.XSYS4_ENCODING_VALUES
        assertEquals("gbk", EffectiveEngineSettings.resolveAllowed("gbk", "sjis", allowed, "sjis"))
        // 覆盖值非法（大小写不匹配白名单也视为非法）：回退全局
        assertEquals("sjis", EffectiveEngineSettings.resolveAllowed("GBK", "sjis", allowed, "sjis"))
        assertEquals("gbk", EffectiveEngineSettings.resolveAllowed("big5", "gbk", allowed, "sjis"))
        // 全局也非法：回退 sjis
        assertEquals("sjis", EffectiveEngineSettings.resolveAllowed(null, "utf8", allowed, "sjis"))
    }

    @Test
    fun xs4JoypadUsesWhitelistFallback() {
        val allowed = EngineSettingsStore.XSYS4_JOYPAD_VALUES
        assertEquals("on", EffectiveEngineSettings.resolveAllowed("on", "auto", allowed, "auto"))
        assertEquals("off", EffectiveEngineSettings.resolveAllowed("bogus", "off", allowed, "auto"))
        assertEquals("auto", EffectiveEngineSettings.resolveAllowed(null, "bogus", allowed, "auto"))
    }

    @Test
    fun xs4MsgskipDelayOverrideAndFallback() {
        // 覆盖命中预设：优先覆盖
        assertEquals(200, EffectiveEngineSettings.resolveXs4MsgskipDelay("200", 400))
        // 覆盖非预设值 / 非数字：回退全局
        assertEquals(400, EffectiveEngineSettings.resolveXs4MsgskipDelay("150", 400))
        assertEquals(400, EffectiveEngineSettings.resolveXs4MsgskipDelay("abc", 400))
        // 无覆盖：跟随全局
        assertEquals(100, EffectiveEngineSettings.resolveXs4MsgskipDelay(null, 100))
        // 全局非预设：归一为引擎默认 0
        assertEquals(0, EffectiveEngineSettings.resolveXs4MsgskipDelay(null, 37))
        // 覆盖为显式 0：仍是有效预设，不回退全局
        assertEquals(0, EffectiveEngineSettings.resolveXs4MsgskipDelay("0", 400))
    }

    @Test
    fun mergeRenPyFollowsGlobalWhenNoOverride() {
        val global = EngineSettingsStore.RenPy(lessMemory = true, autosave = true)
        assertEquals(global, EffectiveEngineSettings.mergeRenPy(global, null))
        assertEquals(global, EffectiveEngineSettings.mergeRenPy(global, RenPyOverride()))
    }

    @Test
    fun mergeRenPyAppliesFieldOverridesOnly() {
        val global = EngineSettingsStore.RenPy(
            cheats = true,
            hwVideo = true,
            autosave = false,
            lessMemory = false,
            dontUseGl2 = false,
        )
        val merged = EffectiveEngineSettings.mergeRenPy(
            global,
            RenPyOverride(cheats = false, autosave = true, dontUseGl2 = true),
        )

        assertFalse(merged.cheats)
        assertTrue(merged.autosave)
        assertTrue(merged.dontUseGl2)
        // 未覆盖字段保持全局
        assertTrue(merged.hwVideo)
        assertFalse(merged.lessMemory)
    }

    @Test
    fun mergeRuffleFollowsGlobalWhenNoOverride() {
        val global = EngineSettingsStore.Ruffle(
            screenTimeout = 30,
            backend = "vulkan",
            quality = "best",
            scaleMode = "noborder",
            letterbox = "off",
            loadBehavior = "blocking",
        )
        assertEquals(global, EffectiveEngineSettings.mergeRuffle(global, null))
        assertEquals(global, EffectiveEngineSettings.mergeRuffle(global, RuffleOverride()))
    }

    @Test
    fun mergeRuffleAppliesFieldOverridesOnly() {
        val global = EngineSettingsStore.Ruffle(
            screenTimeout = 15,
            backend = "opengl",
            quality = "high",
            scaleMode = "showall",
            letterbox = "on",
            loadBehavior = "streaming",
        )
        val merged = EffectiveEngineSettings.mergeRuffle(
            global,
            RuffleOverride(
                screenTimeout = "45",
                backend = "vulkan",
                quality = "best",
                scaleMode = "exactfit",
                letterbox = "off",
                loadBehavior = "blocking",
            ),
        )

        assertEquals(45, merged.screenTimeout)
        assertEquals("vulkan", merged.backend)
        assertEquals("best", merged.quality)
        assertEquals("exactfit", merged.scaleMode)
        assertEquals("off", merged.letterbox)
        assertEquals("blocking", merged.loadBehavior)
        // 0 是有效的「不自动关闭」，不能被当作未覆盖而回落全局
        assertEquals(
            0,
            EffectiveEngineSettings.mergeRuffle(global, RuffleOverride(screenTimeout = "0")).screenTimeout,
        )
    }

    @Test
    fun mergeRuffleRejectsInvalidOverrideAndNormalizesGlobal() {
        val global = EngineSettingsStore.Ruffle(
            screenTimeout = 30,
            backend = " OpenGL ",
            quality = "best",
            scaleMode = "noborder",
            letterbox = "off",
            loadBehavior = "delayed",
        )
        val merged = EffectiveEngineSettings.mergeRuffle(
            global,
            RuffleOverride(
                screenTimeout = "7",
                backend = "bogus",
                quality = "BEST",
                scaleMode = "",
                letterbox = "nope",
                loadBehavior = "STREAMING",
            ),
        )

        // 非法覆盖回退全局；大小写差异经归一后命中白名单
        assertEquals(30, merged.screenTimeout)
        assertEquals("opengl", merged.backend)
        assertEquals("best", merged.quality)
        assertEquals("noborder", merged.scaleMode)
        assertEquals("off", merged.letterbox)
        assertEquals("streaming", merged.loadBehavior)

        val invalidGlobal = EffectiveEngineSettings.mergeRuffle(
            EngineSettingsStore.Ruffle(
                screenTimeout = 99,
                backend = "bogus",
                quality = "",
                scaleMode = "bogus",
                letterbox = "bogus",
                loadBehavior = "bogus",
            ),
            RuffleOverride(),
        )
        assertEquals(0, invalidGlobal.screenTimeout)
        assertEquals("opengl", invalidGlobal.backend)
        assertEquals("high", invalidGlobal.quality)
        assertEquals("showall", invalidGlobal.scaleMode)
        assertEquals("on", invalidGlobal.letterbox)
        assertEquals("streaming", invalidGlobal.loadBehavior)
    }

    @Test
    fun artemisUiAndLaunchShareValidatedVersionFallback() {
        assertEquals(EngineSettingsStore.ART_ENGINE_V6,
            EffectiveEngineSettings.resolveArtVersion("broken", EngineSettingsStore.ART_ENGINE_V6))
        assertEquals(EngineSettingsStore.ART_ENGINE_AUTO,
            EffectiveEngineSettings.resolveArtVersion("broken", "broken"))
        assertEquals(EngineSettingsStore.ART_ENGINE_V2,
            EffectiveEngineSettings.resolveArtVersion(" 2 ", EngineSettingsStore.ART_ENGINE_V6))
        val version = EffectiveEngineSettings.resolveArtVersion("broken", EngineSettingsStore.ART_ENGINE_V6)
        assertTrue(GraphicsCapabilities.forRuntime(GraphicsFamily.ARTEMIS,
            EngineSettingsStore.ART_KERNEL_OFFICIAL, version).supported)
        assertEquals(EngineSettingsStore.ART_VERSIONS - EngineSettingsStore.ART_ENGINE_AUTO,
            com.core.engine.ArtemisVersion.values().map { it.id }.toSet())
        for (host in com.core.engine.ArtemisVersion.values()) {
            assertEquals(com.core.gl.ArtemisLibraryIdentity.supports(host.libraryFilename),
                GraphicsCapabilities.forRuntime(GraphicsFamily.ARTEMIS,
                    EngineSettingsStore.ART_KERNEL_OFFICIAL, host.id).supported)
        }
    }

    @Test fun staleKrVersionAndKernelOverridesFollowValidatedGlobalValues() {
        assertEquals(EngineSettingsStore.KR_134,
            EffectiveEngineSettings.resolveKrVersion("retired", EngineSettingsStore.KR_134))
        assertEquals(EngineSettingsStore.KR_AUTO,
            EffectiveEngineSettings.resolveKrVersion("retired", "invalid"))
        assertEquals(EngineSettingsStore.KR_139,
            EffectiveEngineSettings.resolveKrVersion(" 1.3.9 ", EngineSettingsStore.KR_134))
        assertEquals(EngineSettingsStore.KERNEL_KRKRSDL3,
            EffectiveEngineSettings.resolveKrKernel("retired", EngineSettingsStore.KERNEL_KRKRSDL3, false))
        assertEquals(EngineSettingsStore.KERNEL_KIRIKIRI2,
            EffectiveEngineSettings.resolveKrKernel("retired", EngineSettingsStore.KERNEL_KRKRSDL3, true))
        assertEquals(EngineSettingsStore.KR_AUTO,
            EffectiveEngineSettings.resolveKrKernel("retired", "invalid", false))
        val version = EffectiveEngineSettings.resolveKrVersion("retired", EngineSettingsStore.KR_134)
        val kernel = EffectiveEngineSettings.resolveKrKernel("retired", EngineSettingsStore.KERNEL_KIRIKIRI2, false)
        assertTrue(GraphicsCapabilities.forSettings(GraphicsFamily.KR, kernel, version).supported)
        assertEquals(GraphicsCapabilities.forRuntime(GraphicsFamily.KR, kernel, version),
            GraphicsCapabilities.forSettings(GraphicsFamily.KR, kernel, version))
    }

}
