package com.tyranor.next.ui.save

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color as ComposeColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.tyranor.next.R
import com.tyranor.next.core.engine.EngineType
import com.tyranor.next.core.game.save.GameSaveManager
import com.tyranor.next.core.game.save.RpgSaveFormat
import com.tyranor.next.core.game.save.RpgSaveSync
import com.tyranor.next.core.game.save.sync.SaveSyncException
import com.tyranor.next.core.game.save.sync.SaveSyncRuntime
import com.tyranor.next.core.game.launch.EngineLauncher
import com.tyranor.next.core.game.model.ScanGame
import com.tyranor.next.core.game.model.ScanGameIntents
import com.tyranor.next.theme.PageTextColor
import com.tyranor.next.theme.NavWhite
import com.tyranor.next.theme.TextColor
import com.tyranor.next.theme.DialogItemSurface
import com.tyranor.next.theme.AppComponentCornerRadius
import com.tyranor.next.theme.MiuixSettingsTheme
import com.tyranor.next.theme.glassBorder
import com.tyranor.next.theme.AppComponentShape
import com.tyranor.next.ui.common.AppAlertDialog
import com.tyranor.next.ui.common.AppNavItem
import com.tyranor.next.ui.common.AppScreenActivity
import com.tyranor.next.ui.common.AppTopBar
import com.tyranor.next.ui.common.BottomInsetSpacer
import com.tyranor.next.ui.common.DialogTextButton
import com.tyranor.next.ui.common.toSaveSyncMessage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import top.yukonga.miuix.kmp.basic.Card as MiuixCard
import top.yukonga.miuix.kmp.basic.Scaffold as MiuixScaffold
import top.yukonga.miuix.kmp.theme.MiuixTheme

class SaveManagementActivity : AppScreenActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val game = intent.readScanGame()
        if (game == null) {
            finish()
            return
        }

        setAppScreenContent {
            SaveManagementScreen(game = game)
        }
    }

    companion object {
        fun createIntent(context: Context, game: ScanGame): Intent =
            ScanGameIntents.putGame(Intent(context, SaveManagementActivity::class.java), game)

        private fun Intent.readScanGame(): ScanGame? = ScanGameIntents.getGame(this)
    }
}

@Composable
private fun SaveManagementScreen(game: ScanGame) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val saveOperationFailedMessage = stringResource(R.string.save_operation_failed)
    val saveExportedCountFormat = stringResource(R.string.save_exported_count)
    val saveImportedCountFormat = stringResource(R.string.save_imported_count)
    val saveDeletedCountFormat = stringResource(R.string.save_deleted_count)
    val saveSyncResultFormat = stringResource(R.string.save_sync_result)
    val saveSyncNoChangeMessage = stringResource(R.string.save_sync_result_no_change)
    val saveSyncFailedFormat = stringResource(R.string.save_sync_result_failed)
    val saveSyncUnmappedFormat = stringResource(R.string.save_sync_unmapped)
    // 独立存档目录不可用（scoped 目录返回 null）时的同步提示，与存档位置解析共用同一文案
    val saveDirUnavailableMessage = stringResource(R.string.save_error_tyrano_external_unavailable)
    // 会话运行中/启动中：手动同步被拒绝的提示
    val saveBusyEngineRunningMessage = stringResource(R.string.save_busy_engine_running)
    val externalExitDoneMessage = stringResource(R.string.save_external_exit_done)
    val clearImportedResourcesDone = stringResource(R.string.save_systemnnn_clear_resources_done)
    val manager = remember { GameSaveManager(context) }
    var location by remember { mutableStateOf<GameSaveManager.SaveLocation?>(null) }
    var fileCount by remember { mutableStateOf(0) }
    var refreshError by remember { mutableStateOf<String?>(null) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var hasImportedResources by remember { mutableStateOf(false) }
    var showClearImportedResources by remember { mutableStateOf(false) }
    var showExportFormatPicker by remember { mutableStateOf(false) }
    // CreateDocument 系统页期间进程重建后仍按用户所选格式导出。
    var exportFormat by rememberSaveable { mutableStateOf(GameSaveManager.ExportFormat.TYRANOR) }
    val rpgWebGame = RpgSaveFormat.isRpgWebEngine(game.engine)
    // 存档互通生效值（单游戏覆盖 > 全局）：L7——关闭时隐藏「立即同步」，
    // 避免用户在功能未开启时触发出人意料的删除归置语义
    var saveInteropEnabled by remember { mutableStateOf(false) }
    // 导入/导出/删除互斥：并发任务会互相清掉对方的暂存目录，破坏导入的原子性
    var taskRunning by remember { mutableStateOf(false) }
    var versionsRevision by remember { mutableIntStateOf(0) }
    var externalExitConfirmation by remember(game) {
        mutableStateOf<SaveSyncRuntime.ExternalExitConfirmation?>(null)
    }

    // 目录解析与文件递归遍历均为磁盘 IO：统一切到 IO 线程，避免组合期/主线程卡顿
    suspend fun refresh() {
        try {
            val snapshot = withContext(Dispatchers.IO) { manager.inspectSaves(game) }
            location = snapshot.location
            fileCount = snapshot.fileCount
            hasImportedResources = snapshot.hasImportedResources
            refreshError = null
            versionsRevision++
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (failure: Exception) {
            location = null
            fileCount = 0
            hasImportedResources = false
            refreshError = failure.toSaveErrorMessage(context, saveOperationFailedMessage)
        }
    }

    LaunchedEffect(game) {
        refresh()
        // 互通开关读取命中 DB：挂起在 IO 线程取生效值
        saveInteropEnabled = EngineLauncher.isRpgSaveInteropEnabled(context, game)
    }

    /** 把同步结果格式化成用户可读文案：无变化提示、有变化给明细、失败与无法识别的追加说明。 */
    fun formatSyncResult(result: RpgSaveSync.Result): String {
        // failed > 0 时不能只看 changed==0 就说「两侧一致」——可能是处理失败什么都没做成
        val base = when {
            result.failed > 0 -> saveSyncFailedFormat.format(result.failed)
            result.changed == 0 -> saveSyncNoChangeMessage
            else -> {
                val overwritten = result.toTyranor + result.toStandard
                saveSyncResultFormat.format(result.imported, result.exported, overwritten, result.movedToDeleted)
            }
        }
        return if (result.unmapped > 0) "$base\n${saveSyncUnmappedFormat.format(result.unmapped)}" else base
    }

    fun runSaveTask(shortFeedback: Boolean = false, block: suspend () -> String?) {
        if (taskRunning) return
        scope.launch {
            taskRunning = true
            try {
                val message = withContext(Dispatchers.IO) {
                    try {
                        block()
                    } catch (cancelled: CancellationException) {
                        throw cancelled
                    } catch (failure: Exception) {
                        if (failure is SaveSyncException) failure.code.toSaveSyncMessage(context)
                        else failure.toSaveErrorMessage(context, saveOperationFailedMessage)
                    }
                }
                refresh()
                if (message != null) {
                    val duration = if (shortFeedback) Toast.LENGTH_SHORT else Toast.LENGTH_LONG
                    Toast.makeText(context, message, duration).show()
                }
            } finally {
                taskRunning = false
            }
        }
    }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/zip"),
    ) { uri: Uri? ->
        if (uri != null) {
            runSaveTask {
                val count = manager.exportToZip(game, uri, exportFormat)
                saveExportedCountFormat.format(count)
            }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            runSaveTask {
                val count = manager.importFromZip(game, uri)
                saveImportedCountFormat.format(count)
            }
        }
    }

    MiuixSettingsTheme {
        MiuixScaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = ComposeColor.Transparent,
            contentWindowInsets = WindowInsets(0.dp),
            topBar = {
                AppTopBar(
                    title = stringResource(R.string.save_management_title),
                    background = ComposeColor.Transparent,
                    contentColor = PageTextColor,
                )
            },
        ) { innerPadding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize()
                    .padding(horizontal = 12.dp)
                    .padding(top = innerPadding.calculateTopPadding()),
                contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth().glassBorder(),
                        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
                        colors = CardDefaults.cardColors(containerColor = NavWhite, contentColor = TextColor),
                        shape = AppComponentShape,
                    ) {
                        Column(Modifier.fillMaxWidth().padding(16.dp)) {
                            Text(game.title, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            location?.let { loadedLocation ->
                                Text(
                                    loadedLocation.description(game.engine.displayName),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(top = 8.dp),
                                )
                                if (loadedLocation.mirrorForced) {
                                    Text(
                                        stringResource(R.string.krkr_mirror_save_import_hint),
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(top = 4.dp),
                                    )
                                }
                                Text(
                                    if (loadedLocation.available) stringResource(R.string.save_file_count, fileCount) else stringResource(R.string.save_unmanageable),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(top = 4.dp),
                                )
                            }
                            refreshError?.let { error ->
                                Text(
                                    error,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.padding(top = 8.dp),
                                )
                            }
                        }
                    }
                }

                item {
                    MiuixCard(
                        modifier = Modifier.fillMaxWidth().glassBorder(),
                        cornerRadius = AppComponentCornerRadius,
                    ) {
                        Column(Modifier.padding(vertical = 4.dp)) {
                            if (game.engine == EngineType.YURIS) {
                                AppNavItem(
                                    title = stringResource(R.string.save_external_exit_title),
                                    summary = stringResource(R.string.save_external_exit_summary),
                                    showLeadingIcon = false,
                                    showArrow = false,
                                    drawSurface = false,
                                    onClick = if (taskRunning) null else ({
                                        runSaveTask {
                                            externalExitConfirmation = SaveSyncRuntime.externalExitConfirmation(context, game)
                                            if (externalExitConfirmation == null) externalExitDoneMessage else null
                                        }
                                    }),
                                )
                            }
                            AppNavItem(
                                title = stringResource(R.string.save_export_zip),
                                showLeadingIcon = false,
                                showArrow = false,
                                drawSurface = false,
                                onClick = if (taskRunning) null else ({
                                    if (rpgWebGame) {
                                        showExportFormatPicker = true
                                    } else {
                                        exportFormat = GameSaveManager.ExportFormat.TYRANOR
                                        exportLauncher.launch(defaultArchiveName(game))
                                    }
                                }),
                            )
                            if (rpgWebGame && saveInteropEnabled) {
                                AppNavItem(
                                    title = stringResource(R.string.save_sync_now),
                                    showLeadingIcon = false,
                                    showArrow = false,
                                    drawSurface = false,
                                    onClick = if (taskRunning) null else ({
                                        runSaveTask {
                                            when (val op = EngineLauncher.syncRpgSaves(context, game)) {
                                                is EngineLauncher.RpgSaveOpResult.Done -> formatSyncResult(op.value)
                                                // 会话运行中/启动中：未触碰存档，提示先退出游戏
                                                EngineLauncher.RpgSaveOpResult.Busy -> saveBusyEngineRunningMessage
                                                // 独立存档目录不可用：如实报告，绝不能显示「同步完成」
                                                EngineLauncher.RpgSaveOpResult.SaveDirUnavailable -> saveDirUnavailableMessage
                                            }
                                        }
                                    }),
                                )
                            }
                            AppNavItem(
                                title = stringResource(R.string.save_import_zip),
                                showLeadingIcon = false,
                                showArrow = false,
                                drawSurface = false,
                                onClick = if (taskRunning) null else ({
                                    importLauncher.launch("application/zip")
                                }),
                            )
                            AppNavItem(
                                title = stringResource(R.string.save_delete_title),
                                showLeadingIcon = false,
                                showArrow = false,
                                drawSurface = false,
                                onClick = if (taskRunning) null else ({ showDeleteConfirm = true }),
                            )
                            if (hasImportedResources) {
                                AppNavItem(
                                    title = stringResource(R.string.save_systemnnn_clear_resources),
                                    showLeadingIcon = false,
                                    showArrow = false,
                                    drawSurface = false,
                                    onClick = if (taskRunning) null else ({ showClearImportedResources = true }),
                                )
                            }
                        }
                    }
                }
                if (location?.available == true) {
                    item {
                        SaveVersionsPanel(game, taskRunning, versionsRevision) { block ->
                            runSaveTask(block = block, shortFeedback = true)
                        }
                    }
                }
                item { BottomInsetSpacer() }
            }
        }
    }

    externalExitConfirmation?.let { confirmation ->
        AppAlertDialog(
            onDismissRequest = { externalExitConfirmation = null },
            title = { Text(stringResource(R.string.save_external_exit_title), style = MaterialTheme.typography.titleMedium) },
            text = { Text(stringResource(R.string.save_external_exit_message, game.title), style = MaterialTheme.typography.bodyMedium) },
            confirmButton = {
                DialogTextButton(
                    text = stringResource(R.string.common_confirm),
                    enabled = !taskRunning,
                    onClick = {
                        externalExitConfirmation = null
                        runSaveTask {
                            SaveSyncRuntime.confirmExternalExit(context, game, confirmation)
                            externalExitDoneMessage
                        }
                    },
                )
            },
            dismissButton = {
                DialogTextButton(
                    text = stringResource(R.string.common_cancel),
                    onClick = { externalExitConfirmation = null },
                )
            },
        )
    }

    // MV/MZ 导出格式选择：保留原有的格式确认与说明。
    if (showExportFormatPicker) {
        AppAlertDialog(
            onDismissRequest = { showExportFormatPicker = false },
            title = { Text(stringResource(R.string.save_export_format_title), style = MaterialTheme.typography.titleMedium) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    AppNavItem(
                        title = stringResource(R.string.save_export_format_standard),
                        summary = stringResource(R.string.save_export_format_standard_summary),
                        leadingIcon = R.drawable.ic_save_export_format,
                        containerColor = DialogItemSurface,
                        showArrow = false,
                        indication = null,
                        onClick = {
                            showExportFormatPicker = false
                            exportFormat = GameSaveManager.ExportFormat.STANDARD
                            exportLauncher.launch(defaultArchiveName(game))
                        },
                    )
                    AppNavItem(
                        title = stringResource(R.string.save_export_format_tyranor),
                        summary = stringResource(R.string.save_export_format_tyranor_summary),
                        leadingIcon = R.drawable.ic_save_export_format,
                        containerColor = DialogItemSurface,
                        showArrow = false,
                        indication = null,
                        onClick = {
                            showExportFormatPicker = false
                            exportFormat = GameSaveManager.ExportFormat.TYRANOR
                            exportLauncher.launch(defaultArchiveName(game))
                        },
                    )
                }
            },
            confirmButton = {},
        )
    }

    if (showClearImportedResources) {
        AppAlertDialog(
            onDismissRequest = { showClearImportedResources = false },
            title = { Text(stringResource(R.string.save_systemnnn_clear_resources), style = MaterialTheme.typography.titleMedium) },
            text = { Text(stringResource(R.string.save_systemnnn_clear_resources_message), style = MaterialTheme.typography.bodyMedium) },
            confirmButton = {
                DialogTextButton(
                    text = stringResource(R.string.common_confirm),
                    enabled = !taskRunning,
                    onClick = {
                        showClearImportedResources = false
                        runSaveTask {
                            if (manager.clearImportedSystemNnnResources(game)) clearImportedResourcesDone else null
                        }
                    },
                )
            },
            dismissButton = {
                DialogTextButton(text = stringResource(R.string.common_cancel), onClick = { showClearImportedResources = false })
            },
        )
    }

    if (showDeleteConfirm) {
        AppAlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text(stringResource(R.string.save_delete_title), style = MaterialTheme.typography.titleMedium) },
            text = { Text(stringResource(R.string.save_delete_message, game.title), style = MaterialTheme.typography.bodyMedium) },
            confirmButton = {
                DialogTextButton(
                    text = stringResource(R.string.common_delete),
                    enabled = !taskRunning,
                    contentColor = MaterialTheme.colorScheme.error,
                    onClick = {
                        showDeleteConfirm = false
                        runSaveTask {
                            val count = manager.deleteSaves(game)
                            saveDeletedCountFormat.format(count)
                        }
                    },
                )
            },
            dismissButton = {
                DialogTextButton(text = stringResource(R.string.common_cancel), onClick = { showDeleteConfirm = false })
            },
        )
    }
}

private fun defaultArchiveName(game: ScanGame): String {
    val safeTitle = game.title.replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "game" }
    return "${safeTitle}_saves.zip"
}
