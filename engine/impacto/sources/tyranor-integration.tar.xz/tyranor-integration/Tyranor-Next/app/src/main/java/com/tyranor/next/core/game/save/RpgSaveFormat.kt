package com.tyranor.next.core.game.save

import com.core.rpgmaker.RpgSaveKeyMapping
import com.tyranor.next.core.engine.EngineType
import java.io.File
import java.util.Locale

/**
 * RPG Maker MV/MZ 存档文件名在「Tyranor 格式」与「JoiPlay/PC 标准格式」之间的映射、检测与路径解析。
 *
 * 两种格式内容字节级一致，仅文件名不同；转化是纯改名（不重编码）。
 *
 * 引擎实际读写的存档目录由「独立存档」开关决定（GameSaveManager.resolveSaveLocation /
 * effectiveTyranoFamilySaveDirectory）：关闭时为 `<游戏根>/savedata`，开启时为应用外部目录
 * `<external>/save/tyrano/<safeName>`。检测/转化必须消费**生效目录**（与引擎一致），
 * [saveDirectory] 仅是非独立存档时的默认路径，不是唯一来源。
 *
 * MV（键形如 `RPG FileN`，含空格 → 引擎按确定性哈希命名）：
 * | 转化后落盘名（key_<sha256>） | 标准格式（JoiPlay/PC） |
 * | -------------------------- | --------------------- |
 * | key_<sha256("RPG Global")>.bin    | global.rpgsave     |
 * | key_<sha256("RPG Config")>.bin    | config.rpgsave     |
 * | key_<sha256("RPG FileN")>.bin     | fileN.rpgsave      |
 * | key_<sha256("RPG Globalbak")>.bin | global.rpgsave.bak |
 * | key_<sha256("RPG FileNbak")>.bin  | fileN.rpgsave.bak  |
 * 其中 `RPG *.bin`（不带 key_ 前缀）是原 Tyranor 的 legacy 名，引擎读取时优先 legacy、
 * 否则回退哈希名；两种名字引擎都能读，本模块的转化与互通统一写入哈希名（见 [tyranorAppliedName]）。
 *
 * MZ（键为 `global`/`config`/`fileN`，纯 ASCII 命中 directFileKey，核心不带备份）：
 * | global.bin / config.bin / fileN.bin | global.rmmzsave / config.rmmzsave / fileN.rmmzsave |
 * MZ 不能改哈希名——引擎固定读写原名，改了就永远读不到。
 *
 * 哈希名反解回标准名依赖键空间有限（见 [hashedToStandardName]），可枚举还原；插件自定义键
 * 无法还原，导出时保留原名并计入 unmapped。
 */
object RpgSaveFormat {

    /** 标准存档扫描结果。 */
    data class Detection(
        /** 可转化的标准存档文件（含 `.bak`），绝对路径。 */
        val standardFiles: List<File>,
        /** 检测到但不可转化的哈希存档数量（key_<sha256>.bin）。 */
        val hashedCount: Int,
    ) {
        val convertibleCount: Int get() = standardFiles.size
    }

    /** 转化结果计数。 */
    data class ConvertResult(
        /** 成功改名为 Tyranor 格式的文件数。 */
        val converted: Int,
        /** 目标已存在而跳过（不覆盖）的文件数。 */
        val skipped: Int,
        /** 处理失败的文件数（源文件原样保留）。 */
        val failed: Int,
        /** 检测到但未转化的哈希存档数量（仅报告）。 */
        val hashedCount: Int,
    )

    /** 转化时源文件留底的子目录名（位于源存档目录内，不参与列表/导出/删除）。 */
    const val ORIGINAL_DIR = "original"

    /** MV 的 Tyranor 文件名：`RPG Global.bin` / `RPG File1bak.bin` 等。 */
    private val MV_TYRANOR_NAME = Regex("^rpg (global|config|file(\\d+))(bak)?\\.bin$", RegexOption.IGNORE_CASE)

    /** MZ 的 Tyranor 文件名：`global.bin` / `file1.bin` 等。 */
    private val MZ_TYRANOR_NAME = Regex("^(global|config|file(\\d+))(bak)?\\.bin$", RegexOption.IGNORE_CASE)


    private const val MV_EXT = ".rpgsave"
    private const val MZ_EXT = ".rmmzsave"

    /** 枚举哈希反解时的最大存档位（覆盖常见 MV/MZ 存档位，超出则保留原名）。 */
    private const val MAX_SAVE_SLOT = 999

    fun isRpgWebEngine(engine: EngineType): Boolean =
        engine == EngineType.RPG_MV || engine == EngineType.RPG_MZ

    private fun standardExtension(engine: EngineType): String? = when (engine) {
        EngineType.RPG_MV -> MV_EXT
        EngineType.RPG_MZ -> MZ_EXT
        else -> null
    }

    private fun tyranorPattern(engine: EngineType): Regex? = when (engine) {
        EngineType.RPG_MV -> MV_TYRANOR_NAME
        EngineType.RPG_MZ -> MZ_TYRANOR_NAME
        else -> null
    }

    /** MV 才有存档备份（MZ 核心不含 backup）。 */
    private fun supportsBackup(engine: EngineType): Boolean = engine == EngineType.RPG_MV

    // ===== 路径解析 =====

    /**
     * Tyranor 侧存档目录（engine 宿主 resolveSaveDirectory 读写处）：`<游戏根>/savedata`。
     * 检测、转化、导出、列表以本函数为唯一来源，避免多套路径漂移。
     */
    fun saveDirectory(gameRoot: File): File = File(gameRoot, "savedata")

    /**
     * 标准侧（JoiPlay/PC）存档目录：`<内容根>/save`。内容根 = 含 `index.html` / `app.asar`
     * 的目录，与 engine 入口探测同序——MV 常见 `.../Game/www` ⇒ `.../Game/www/save`；
     * 根目录布局（含 MZ 无 www）⇒ `<游戏根>/save`。定位失败回退 `<游戏根>/save`。
     */
    fun standardSaveDirectory(gameRoot: File): File {
        val contentRoot = locateContentRoot(gameRoot) ?: return File(gameRoot, "save")
        return File(contentRoot, "save")
    }

    /**
     * 标准侧存档目录候选（兼容大小写 `save` / `Save`，按大小写不敏感去重）：
     * 第一个为默认写入目录（优先已存在的小写 `save`，否则已存在的大写 `Save`，都没有则小写）。
     * 供同步枚举与导入归位使用，避免只认一种拼写而漏掉另一侧。
     */
    fun standardSaveDirectories(gameRoot: File): List<File> {
        val lower = standardSaveDirectory(gameRoot)
        val upper = File(lower.parentFile, "Save")
        val lowerExists = lower.isDirectory
        val upperExists = upper.isDirectory
        val ordered = when {
            lowerExists -> listOf(lower, upper)
            upperExists -> listOf(upper, lower)
            else -> listOf(lower, upper)
        }
        val seen = mutableSetOf<String>()
        return ordered.filter { dir -> seen.add(pathKey(dir)) }
    }

    /**
     * 存档目录去重键（[standardSaveDirectories] 与检测/转化目录组共用同一份实现，
     * 避免两处规则各自漂移）。
     *
     * 规则：
     * - **存在的目录**用精确规范路径，不做大小写归一。区分大小写的文件系统（Linux/Android
     *   真机）上 `savedata` 与 `Savedata` 是两个不同目录，小写归一会把它们合并，
     *   导致只存在于其中一个的历史存档漏检/漏转化；大小写不敏感的文件系统上
     *   `canonicalPath` 本就返回磁盘上的真实大小写，两种拼写自然折叠为一条，无需小写。
     * - **不存在的目录**没有真实大小写身份，按小写折叠：此时目录为空、不会被扫描到，
     *   折叠只是避免同一目录的两种拼写重复入列，不会丢失任何存档。
     */
    internal fun saveDirDedupKey(file: File): String {
        val canonical = runCatching { file.canonicalPath }.getOrDefault(file.absolutePath)
        return if (file.exists()) canonical else canonical.lowercase(Locale.ROOT)
    }

    private fun pathKey(file: File): String = saveDirDedupKey(file)

    /** 递归定位游戏内容根（含 index.html / app.asar 的目录），与 engine 入口探测同序。 */
    private fun locateContentRoot(dir: File, depth: Int = 0): File? {
        if (!dir.isDirectory) return null
        dir.resolve("app.asar").takeIf { it.isFile }?.let { return dir }
        dir.resolve("resources/app.asar").takeIf { it.isFile }?.let { return dir }
        dir.resolve("app.asar").takeIf { it.isDirectory && it.resolve("index.html").isFile }?.let { return it }
        dir.resolve("resources/app.asar").takeIf { it.isDirectory && it.resolve("index.html").isFile }?.let { return it }
        dir.resolve("index.html").takeIf { it.isFile }?.let { return dir }
        if (depth >= MAX_ENTRY_SEARCH_DEPTH) return null
        for (name in WEB_ENTRY_SUBDIRS) {
            val sub = dir.resolve(name)
            if (!sub.isDirectory) continue
            locateContentRoot(sub, depth + 1)?.let { return it }
        }
        return null
    }

    // ===== 检测 =====

    /**
     * 探测游戏根下的标准格式存档与哈希存档（非独立存档布局，容忍历史大小写 `Savedata`）。
     * 仅扫各目录直接子文件（不递归），因此 `original/` 留底不会重复触发；按规范化路径去重。
     *
     * 注意：独立存档开启时引擎实际读写外部目录，检测/转化应改用 [detectInDirs] 传入生效目录。
     */
    fun detect(gameRoot: File, engine: EngineType): Detection =
        detectInDirs(listOf(saveDirectory(gameRoot), File(gameRoot, "Savedata")), engine)

    /**
     * 跨多个候选存档目录检测标准格式存档与哈希存档，按规范化路径去重、路径排序。
     * 第一个目录应为引擎生效的存档目录（独立存档开关决定），其余为兼容扫描目录。
     */
    fun detectInDirs(dirs: List<File>, engine: EngineType): Detection {
        if (standardExtension(engine) == null) return Detection(emptyList(), 0)
        val seen = mutableSetOf<String>()
        val files = mutableListOf<File>()
        var hashed = 0
        dirs.forEach { root ->
            if (!seen.add(pathKey(root))) return@forEach
            val detection = detectIn(root, engine)
            files += detection.standardFiles
            hashed += detection.hashedCount
        }
        files.sortBy { it.absolutePath.lowercase(Locale.ROOT) }
        return Detection(files, hashed)
    }

    /** 在单个目录直接子文件中检测标准格式存档与哈希存档。 */
    fun detectIn(saveDir: File, engine: EngineType): Detection {
        if (standardExtension(engine) == null || !saveDir.isDirectory) return Detection(emptyList(), 0)
        val standard = mutableListOf<File>()
        var hashed = 0
        saveDir.listFiles().orEmpty().forEach { child ->
            if (!child.isFile) return@forEach
            when {
                isHashedTyranorName(child.name) -> hashed++
                isStandardName(child.name, engine) -> standard += child
            }
        }
        standard.sortBy { it.name.lowercase(Locale.ROOT) }
        return Detection(standard, hashed)
    }

    // ===== 名称映射 =====

    /** 标准文件名判定（`global|config|fileN` + 引擎扩展名 + MV 可带 `.bak`）。 */
    fun isStandardName(name: String, engine: EngineType): Boolean {
        val ext = standardExtension(engine) ?: return false
        val lower = name.lowercase(Locale.ROOT)
        val backupSuffix = "$ext.bak"
        if (lower.endsWith(backupSuffix)) {
            if (!supportsBackup(engine)) return false
            return isStandardStem(lower.removeSuffix(backupSuffix))
        }
        if (!lower.endsWith(ext)) return false
        return isStandardStem(lower.removeSuffix(ext))
    }

    private fun isStandardStem(stem: String): Boolean =
        stem == "global" || stem == "config" || Regex("^file\\d+$").matches(stem)

    /** 标准文件名 → Tyranor 文件名；不匹配返回 null。 */
    fun standardToTyranor(name: String, engine: EngineType): String? {
        val ext = standardExtension(engine) ?: return null
        val lower = name.lowercase(Locale.ROOT)
        val backupSuffix = "$ext.bak"
        val isBackup = lower.endsWith(backupSuffix)
        if (isBackup && !supportsBackup(engine)) return null
        val stem = when {
            isBackup -> lower.removeSuffix(backupSuffix)
            lower.endsWith(ext) -> lower.removeSuffix(ext)
            else -> return null
        }
        if (!isStandardStem(stem)) return null
        val base = tyranorBase(stem, engine) ?: return null
        return base + (if (isBackup) "bak" else "") + ".bin"
    }

    /** Tyranor 文件名 → 标准文件名；不匹配返回 null。 */
    fun tyranorToStandard(name: String, engine: EngineType): String? {
        val ext = standardExtension(engine) ?: return null
        val match = tyranorPattern(engine)?.matchEntire(name) ?: return null
        val key = match.groupValues[1].lowercase(Locale.ROOT)
        val id = match.groupValues.getOrNull(2).orEmpty()
        val isBackup = match.groupValues.getOrNull(3).orEmpty().isNotEmpty()
        if (isBackup && !supportsBackup(engine)) return null
        val stem = when {
            key == "global" -> "global"
            key == "config" -> "config"
            else -> "file$id"
        }
        return stem + ext + (if (isBackup) ".bak" else "")
    }

    private fun tyranorBase(standardStem: String, engine: EngineType): String? {
        val mv = engine == EngineType.RPG_MV
        return when {
            standardStem == "global" -> if (mv) "RPG Global" else "global"
            standardStem == "config" -> if (mv) "RPG Config" else "config"
            standardStem.startsWith("file") -> {
                val id = standardStem.removePrefix("file")
                if (mv) "RPG File$id" else "file$id"
            }
            else -> null
        }
    }

    /**
     * 引擎 `RpgMakerStorage.resolveFile` 实际固定的落盘名（转化/互通导入时写入的名字）。
     *
     * - **MV**：键形如 `RPG File3`（含空格），不匹配 `directFileKey`，且 legacy 名通常不存在，
     *   因此引擎统一按确定性哈希映射为 `key_<sha256(键)>.bin`。转化按此写入，引擎读到的正是该文件。
     * - **MZ**：键形如 `file3`（纯 ASCII），匹配 `directFileKey`，引擎固定读写 `file3.bin`；
     *   若改成哈希名引擎将永远读不到，故 MZ 保持原名。
     */
    private fun tyranorAppliedName(legacyName: String, engine: EngineType): String {
        if (engine != EngineType.RPG_MV) return legacyName
        // 与引擎**同一实现**（RpgSaveKeyMapping）：MV 键形如 `RPG File3`（含空格）→
        // 不匹配 directFileKey → 确定性哈希名。此前这里是独立实现，仅靠「MV 键必含空格」
        // 与引擎保持等价；改为共用后不存在漂移空间。
        val key = legacyName.removeSuffix(".bin")
        val clean = RpgSaveKeyMapping.sanitizeKey(key) ?: return legacyName
        return RpgSaveKeyMapping.canonicalFileName(clean, ".bin")
    }

    /** 标准文件名 → 转化后实际落盘的 Tyranor 文件名；不匹配返回 null。 */
    fun tyranorFileNameForStandard(standardName: String, engine: EngineType): String? {
        val legacy = standardToTyranor(standardName, engine) ?: return null
        return tyranorAppliedName(legacy, engine)
    }

    // ===== 槽位键（同步用）=====
    // 槽位键 = 归一化存档位标识：`global` / `config` / `fileN`，MV 备份追加 `.bak`。
    // 两侧文件名都可映射到同一槽位键，便于判断「同一个存档位」是否两边都存在。

    private fun normalizeSlotStem(stem: String): String? =
        if (stem == "global" || stem == "config" || Regex("^file\\d+$").matches(stem)) stem else null

    /** 标准文件名 → 槽位键；不匹配返回 null。 */
    fun standardSlot(name: String, engine: EngineType): String? {
        val ext = standardExtension(engine) ?: return null
        val lower = name.lowercase(Locale.ROOT)
        val backupSuffix = "$ext.bak"
        val isBackup = lower.endsWith(backupSuffix)
        if (isBackup && !supportsBackup(engine)) return null
        val stem = when {
            isBackup -> lower.removeSuffix(backupSuffix)
            lower.endsWith(ext) -> lower.removeSuffix(ext)
            else -> return null
        }
        if (normalizeSlotStem(stem) == null) return null
        return stem + (if (isBackup) ".bak" else "")
    }

    /** Tyranor 文件名（含哈希名反解）→ 槽位键；无法还原返回 null。 */
    fun tyranorSlot(name: String, engine: EngineType): String? {
        val standard = tyranorToStandard(name, engine) ?: hashedToStandardName(name, engine) ?: return null
        return standardSlot(standard, engine)
    }

    /** 槽位键 → 标准文件名。 */
    fun standardNameForSlot(slot: String, engine: EngineType): String? {
        val ext = standardExtension(engine) ?: return null
        val isBackup = slot.endsWith(".bak")
        if (isBackup && !supportsBackup(engine)) return null
        val stem = if (isBackup) slot.removeSuffix(".bak") else slot
        if (normalizeSlotStem(stem) == null) return null
        return stem + ext + (if (isBackup) ".bak" else "")
    }

    /** 槽位键 → 转化后实际落盘的 Tyranor 文件名（MV 为哈希名，MZ 为原名）。 */
    fun tyranorNameForSlot(slot: String, engine: EngineType): String? {
        val isBackup = slot.endsWith(".bak")
        if (isBackup && !supportsBackup(engine)) return null
        val stem = if (isBackup) slot.removeSuffix(".bak") else slot
        val base = tyranorBase(stem, engine) ?: return null
        val legacy = base + (if (isBackup) "bak" else "") + ".bin"
        return tyranorAppliedName(legacy, engine)
    }

    /** 哈希存档名（key_<sha256>.bin）判定。 */
    fun isHashedTyranorName(name: String): Boolean = RpgSaveKeyMapping.hashFromFileName(name) != null

    /**
     * 哈希存档名反解为标准文件名：查预建的「sha256(键) → 标准名」索引（键空间有限，
     * 见 [buildHashedIndex]）。命中即返回标准名；无法还原（插件自定义键）返回 null。
     */
    fun hashedToStandardName(name: String, engine: EngineType): String? {
        val hash = RpgSaveKeyMapping.hashFromFileName(name) ?: return null
        return when (engine) {
            EngineType.RPG_MV -> mvHashedIndex[hash]
            EngineType.RPG_MZ -> mzHashedIndex[hash]
            else -> null
        }
    }

    /** MV 哈希键索引，首次使用时构建（`by lazy` 线程安全）。 */
    private val mvHashedIndex: Map<String, String> by lazy { buildHashedIndex(EngineType.RPG_MV) }

    /** MZ 哈希键索引，首次使用时构建。 */
    private val mzHashedIndex: Map<String, String> by lazy { buildHashedIndex(EngineType.RPG_MZ) }

    /**
     * 枚举引擎可能用到的存档键（`global`/`config`/`fileN`，MV 另含 `bak`）并预计算其
     * `sha256(键) → 标准文件名` 映射。索引只建一次，避免每次导出为「标准模式」都逐文件
     * 重算约 2000 次哈希（n 个哈希存档 ⇒ O(n×2000)）。
     */
    private fun buildHashedIndex(engine: EngineType): Map<String, String> {
        val ext = standardExtension(engine) ?: return emptyMap()
        val mv = engine == EngineType.RPG_MV
        val index = HashMap<String, String>((MAX_SAVE_SLOT + 2) * 2)
        fun put(key: String, stem: String, backup: Boolean) {
            index[sha256(key)] = stem + ext + (if (backup) ".bak" else "")
        }
        put(if (mv) "RPG Global" else "global", "global", backup = false)
        put(if (mv) "RPG Config" else "config", "config", backup = false)
        if (mv) {
            put("RPG Globalbak", "global", backup = true)
            put("RPG Configbak", "config", backup = true)
        }
        for (slot in 1..MAX_SAVE_SLOT) {
            put(if (mv) "RPG File$slot" else "file$slot", "file$slot", backup = false)
            if (mv) put("RPG File${slot}bak", "file$slot", backup = true)
        }
        return index
    }

    private fun sha256(value: String): String = RpgSaveKeyMapping.sha256Hex(value)

    private const val MAX_ENTRY_SEARCH_DEPTH = 2
    private val WEB_ENTRY_SUBDIRS = arrayOf(
        "www", "resources", "app.asar", "app", "tyrano", "data", "scenario", "system", "game",
    )
}
