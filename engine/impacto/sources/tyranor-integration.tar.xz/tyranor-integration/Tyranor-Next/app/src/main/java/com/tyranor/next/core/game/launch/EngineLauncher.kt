package com.tyranor.next.core.game.launch

import android.Manifest
import android.app.ActivityManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.Settings
import android.util.Log
import androidx.documentfile.provider.DocumentFile
import bridge.KrSafMirror
import bridge.PrimaryStorageRoot
import com.akira.tyranoemu.remote.ArtemisActivityClean
import com.akira.tyranoemu.remote.Kirikiroid134
import com.akira.tyranoemu.remote.Kirikiroid139
import com.core.cmvs.CmvsActivity
import com.core.engine.ArtemisVersion
import com.core.engine.EnginePrefs
import com.core.engine.EngineSessionRegistry
import com.core.engine.KrkrStartupDialogPolicy
import com.core.engine.LaunchContract
import com.tyranor.next.core.i18n.AppLocaleController
import com.tyranor.next.core.engine.external.EmulatorLaunchStyle
import com.tyranor.next.core.engine.external.EmulatorTarget as ExternalEmulatorTarget
import com.core.fvp.FvpActivity
import com.core.games.FramebufferGameActivity
import com.core.impacto.ImpactoActivity
import com.core.impacto.ImpactoLaunchPreparation
import com.core.impacto.ImpactoPreparationException
import com.core.krkrsdl3.Krkrsdl3Activity
import com.core.nativeplugin.NativePluginConstants
import com.core.nativeplugin.NativeRuntimePack
import com.core.rpgmaker.RpgMakerActivity
import com.core.siglus.SiglusActivity
import com.core.tyrano.TyranoActivity
import com.core.xsys35.Xs35Activity
import com.core.xsys4.Xs4Activity
import com.tyranor.next.core.engine.graphics.GraphicsLaunchPolicy
import com.tyranor.next.core.engine.graphics.putDisabledGraphicsRequest
import com.tyranor.next.core.engine.graphics.putGraphicsExtras
import com.tyranor.next.core.engine.EngineType
import com.tyranor.next.core.engine.external.ExternalEmulatorLauncher
import com.tyranor.next.core.engine.external.ExternalEmulatorRegistry
import com.tyranor.next.core.engine.external.ExternalEngineErrorCode
import com.tyranor.next.core.engine.external.ExternalEngineLaunchRequest
import com.tyranor.next.core.engine.external.ExternalEngineLaunchResult
import com.tyranor.next.core.engine.external.ExternalEngineLauncher
import com.tyranor.next.core.engine.external.WinlatorContract
import com.tyranor.next.core.engine.external.ExternalEngineModuleRegistry
import com.tyranor.next.core.engine.plugin.EnginePluginBootstrap
import com.tyranor.next.core.engine.runtime.RuntimeModuleBindings
import com.tyranor.next.core.engine.runtime.RuntimeModuleDiscoveryResult
import com.tyranor.next.core.engine.runtime.RuntimeModuleLauncher
import com.tyranor.next.core.engine.runtime.RuntimeModuleLaunchResult
import com.tyranor.next.core.engine.runtime.RuntimeModuleRegistry
import com.tyranor.next.core.game.manual.AndroidAppGames
import com.tyranor.next.core.game.model.GamePathUtils
import com.tyranor.next.core.game.model.EthornellPaths
import com.tyranor.next.core.game.model.ScanGame
import com.tyranor.next.core.game.scan.ImpactoDescriptor
import com.tyranor.next.core.game.storage.SystemNnnCopyStore
import com.tyranor.next.core.game.storage.SystemNnnGameDirectory
import com.tyranor.runtime.systemnnn.SystemNnnHost
import com.tyranor.next.core.game.model.Xs35Paths
import com.tyranor.next.core.game.model.Xs4Paths
import com.tyranor.next.core.game.save.GameSaveException
import com.tyranor.next.core.game.save.GameSaveManager
import com.tyranor.next.core.game.save.RpgSaveFormat
import com.tyranor.next.core.game.save.RpgSaveFormatConverter
import com.tyranor.next.core.game.save.RpgSavePendingStore
import com.tyranor.next.core.game.save.SaveErrorCode
import com.tyranor.next.core.game.save.RpgSaveSync
import com.tyranor.next.core.game.save.RpgSaveSyncState
import com.tyranor.next.core.game.save.sync.SAVE_DIRECTORY_KEY_PREFIX
import com.tyranor.next.core.game.save.sync.SaveSyncLaunchAdmission
import com.tyranor.next.core.game.save.sync.SaveSyncLocks
import com.tyranor.next.core.game.save.sync.SaveSyncRuntime
import com.tyranor.next.core.game.save.sync.SaveSyncException
import com.tyranor.next.core.game.save.sync.SaveSyncError
import com.tyranor.next.core.game.save.sync.withSaveSyncLaunchAdmission
import com.tyranor.next.core.game.scan.EngineScanner
import com.tyranor.next.core.game.storage.GameLibraryFacade
import com.tyranor.next.core.game.storage.EngineDetectionRepository
import com.tyranor.next.core.game.scan.GameDirFingerprint
import com.tyranor.next.core.settings.GraphicsCapabilities
import com.tyranor.next.core.settings.GraphicsFamily
import com.tyranor.next.core.settings.GraphicsSettings
import com.tyranor.next.core.input.InputRemapRepository
import com.tyranor.next.core.settings.EffectiveEngineSettings
import com.tyranor.next.core.settings.EngineSettingsResolver
import com.tyranor.next.core.settings.EngineSettingsStore
import com.tyranor.next.core.settings.PerGameSettingsStore
import com.tyranor.next.core.settings.ResolvedEngineSettings
import com.tyranor.next.core.theme.ThemeColorPayload
import com.tyranor.next.core.theme.ThemeColorPayloadStore
import com.tyranor.next.core.unpack.ArtemisPfsUnpacker
import com.yuri.onscripter.ONScripter
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.nio.charset.Charset
import java.nio.file.Files
import java.util.Collections
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * 游戏引擎启动器：根据 [EngineType] 把扫描到的游戏目录交给对应引擎宿主 Activity。
 * 直接集成（非模块化）。引擎均使用 AndroidManifest 中的内部 Activity，
 * intent 契约与 RinneMobile 保持一致。
 */
object EngineLauncher {
    private const val TAG = "EngineLauncher"
    private const val KR_LEGACY_PATCH_MARKER = "// TYRANOR_NEXT_KRKR_LEGACY_PATCH_V1"
    private const val KR_FBF_STEAM_STUB_MARKER = "// TYRANOR_NEXT_FBF_STEAM_STUB_V1"
    private const val EXTERNAL_STORAGE_AUTHORITY = "com.android.externalstorage.documents"

    /** 承载输入重映射（虚拟按键 + 手柄映射）的 Web 系引擎：旧触屏手柄数据迁移仅对这些引擎触发。 */
    private val WEB_INPUT_ENGINES = setOf(
        EngineType.RPG_MV, EngineType.RPG_MZ, EngineType.TYRANO,
        EngineType.VN, EngineType.WEB_OTHER,
    )

    // 前台兜底回写：引擎 finish 后约 500ms 才杀进程，轮询等待其退出的间隔与上限
    private const val SESSION_EXIT_POLL_MS = 400L
    private const val SESSION_EXIT_MAX_ATTEMPTS = 8
    private val ARTEMIS_DEFAULT_FALLBACK_CHAIN = listOf(
        EngineSettingsStore.ART_ENGINE_V2,
        EngineSettingsStore.ART_ENGINE_V1,
        EngineSettingsStore.ART_ENGINE_V6,
    )

    /** 支持的引擎列表（用于引擎页展示）。按名称长度从大到小排列。 */
    val supportedEngines: List<EngineType> = listOf(
        EngineType.KIRIKIRI,
        EngineType.ONS,
        EngineType.TYRANO,
        EngineType.RPGMAKER,
        EngineType.RPG_MV,
        EngineType.RPG_MZ,
        EngineType.VN,
        EngineType.WEB_OTHER,
        EngineType.ARTEMIS,
        EngineType.SIGLUS,
        EngineType.REALLIVE,
        EngineType.AVG32,
        EngineType.XSYS35,
        EngineType.XSYS4,
        EngineType.SYSTEMNNN,
        EngineType.UK2,
        EngineType.FVP,
        EngineType.ETHORNELL,
        EngineType.IMPACTO,
        EngineType.CMVS,
        EngineType.RENPY,
        EngineType.RUFFLE,
        // YURIS / CatSystem2 / PC 由外置 Winlator 承载（GAL 分组），引擎页条目点击进入引擎专属弹窗
        EngineType.YURIS,
        EngineType.CATSYSTEM2,
        EngineType.PC,
        // PSP/Switch 不参与内置/外置 APK 链路，仅用于引擎页「主机系列」展示与外置模拟器跳转
        EngineType.PSP,
        EngineType.NINTENDO_SWITCH,
        // ANDROID_APP 为手动添加的直接跳转条目（无运行时/设置/存档），故不收录、不出现在引擎页
    ).sortedByDescending { it.displayName.length }

    /** Artemis 补丁确认弹窗的用户选择：
     *  本次 = 仅当次应用；总是 = 记住为全局 auto；不再 = 记住为全局 off。 */
    enum class ArtemisPatchChoice { ONCE, ALWAYS, NEVER }

    /** 尝试启动游戏。返回类型化结果（P0-6）；[LaunchResult.Success] 表示成功发起。
     *  [patchChoice] 为 Artemis 补丁确认弹窗（见 [needsArtemisPatchConfirm]）的选择结果。
     *  全链路（SAF 查询/文件扫描/patch 与 Steam overlay 写盘/PFS 解包）均为重 IO，
     *  统一切到 IO 线程执行，避免大游戏目录/慢存储上阻塞调用方主线程导致 ANR。 */
    suspend fun launch(
        context: Context,
        game: ScanGame,
        patchChoice: ArtemisPatchChoice? = null,
    ): LaunchResult =
        withContext(Dispatchers.IO) {
            val entry = RuntimeModuleBindings.builtInSystemNnn(game)
            suspend fun launchAdmitted(): LaunchResult? = withSaveSyncLaunchAdmission(
                resolve = { SaveSyncRuntime.launchAdmission(context, entry) },
                managed = { admission -> launchManaged(context, entry, patchChoice, admission) },
                unmanaged = { recoverSystemNnnSaves(context, entry) ?: launchInternal(context, entry, patchChoice) },
            )
            var result: LaunchResult?
            do {
                currentCoroutineContext().ensureActive()
                result = if (entry.engine == EngineType.SYSTEMNNN) {
                    restoreSystemNnn(context, entry)?.let { return@withContext it }
                    prepareSystemNnnResources(context, entry)?.let { return@withContext it }
                    // A source-to-copy rebind also writes the URI's version checkpoint.
                    SaveSyncLocks.versions(entry.uri) { launchAdmitted() }
                } else launchAdmitted()
            } while (result == null)
            result
        }

    /** Known directories share the operation fence; unknown directories hold it exclusively. */
    private suspend fun launchManaged(
        context: Context,
        game: ScanGame,
        patchChoice: ArtemisPatchChoice?,
        admission: SaveSyncLaunchAdmission.Directory?,
    ): LaunchResult? {
        val directoryKey = admission?.key
        try {
            // A pending selection owns this directory even in manual/pull-only mode.
            // Keep this outside prepareLaunch's best-effort bookkeeping error handler.
            directoryKey?.let { SaveSyncRuntime.requireLaunchAvailable(context, it) }
        } catch (failure: SaveSyncException) {
            return LaunchResult.Failure.SavePreparationFailed(failure.code)
        }
        if (game.engine == EngineType.SYSTEMNNN &&
            SystemNnnGameDirectory.accessible(context, game.uri)?.let(SystemNnnCopyStore::resourcesEvicted) == true
        ) {
            // Cleanup won after the initial resource check. Restage outside the save fence.
            return null
        }
        recoverSystemNnnSaves(context, game)?.let { return it }
        var ticket: SaveSyncRuntime.LaunchTicket? = null
        var grace: String? = null
        var dispatched = false
        try {
            ticket = try {
                admission?.let { SaveSyncRuntime.prepareLaunch(context, game, it.key, it.exclusiveMutation) }
            } catch (failure: SaveSyncException) {
                return LaunchResult.Failure.SavePreparationFailed(failure.code)
            }
            // Optional persistence may fail; every actual start still needs a protected handoff.
            grace = SaveSyncRuntime.prepareOptionalLaunchGrace(context, game, directoryKey)
            return launchInternal(context, game, patchChoice) {
                dispatched = true
                SaveSyncRuntime.optionalLaunchDispatched(context, game, grace, directoryKey)
            }
        } finally {
            try {
                SaveSyncRuntime.finishLaunch(context, game, ticket, dispatched)
            } finally {
                SaveSyncRuntime.finishOptionalLaunchGrace(context, game, grace, dispatched)
            }
        }
    }

    private fun completeLaunch(context: Context, game: ScanGame, onDispatched: () -> Unit): LaunchResult =
        completeDispatchedGameLaunch(onDispatched, { GameLibraryFacade.recordRecentGame(context, game) }) {
            Log.w(TAG, "Could not record a dispatched game launch", it)
        }

    /**
     * 直接打开内置原生 Kirikiroid2 界面（`originMode`，不携带游戏路径）。
     *
     * 与 Tyranor 原版设置页「启动 Kirikiroid2 v1.3.9」一致：固定使用 1.3.9 宿主
     * （Kirikiroid139）展示原生 KR2 壳的文件浏览器；引擎侧命中 [LaunchContract.ORIGIN_MODE]
     * 后会跳过游戏启动分支（无 Loading 遮罩、不解析 path）。
     */
    suspend fun launchNativeKirikiroidUi(context: Context): LaunchResult = withContext(Dispatchers.IO) {
        val app = context.applicationContext
        // 原生界面同样需要「所有文件访问」才能浏览共享存储中的游戏目录
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !Environment.isExternalStorageManager()) {
            val opened = runCatching {
                app.startActivity(
                    Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${app.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                )
            }.recoverCatching {
                app.startActivity(
                    Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                )
            }.isSuccess
            return@withContext if (opened) {
                LaunchResult.Failure.AllFilesAccessRequested
            } else {
                LaunchResult.Failure.AllFilesAccessMissing
            }
        }
        EnginePluginBootstrap.ensureForLaunch(app, EngineType.KIRIKIRI)?.let {
            return@withContext LaunchResult.Failure.PluginBootstrapFailed(it)
        }
        return@withContext try {
            app.startActivity(
                Intent(app, Kirikiroid139::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    putExtra(LaunchContract.ORIGIN_MODE, true)
                    putExtra(LaunchContract.UI_LANGUAGE_TAG, AppLocaleController.engineUiLanguageTag(app))
                    putGraphicsSettings(
                        EngineSettingsStore.getGraphicsSettings(app, GraphicsFamily.KR),
                        GraphicsCapabilities.forRuntime(GraphicsFamily.KR, EngineSettingsStore.KERNEL_KIRIKIRI2),
                    )
                    putExtra(LaunchContract.ORIENTATION, 6)
                    putExtra(LaunchContract.FOCUS, "true")
                },
            )
            LaunchResult.Success
        } catch (t: Throwable) {
            LaunchResult.Failure.StartFailed(t.message)
        }
    }

    /**
     * 正在执行启动流程的 game.uri 集合（覆盖启动前同步到 startActivity 的全过程）。
     * 单飞协调：前台回写在同步前检查此集合——「会话已退出但同一游戏正被拉起」的窗口内
     * 引擎即将开始写存档，回写此时插入会与引擎写入交错（进程内锁约束不了引擎进程）。
     * 登记在启动最前、finally 移除，保证启动失败/取消也恢复一致状态。
     */
    private val launchingUris: MutableSet<String> =
        Collections.newSetFromMap(ConcurrentHashMap<String, Boolean>())

    private suspend fun launchInternal(context: Context, game: ScanGame, patchChoice: ArtemisPatchChoice?, onDispatched: () -> Unit = {}): LaunchResult {
        if (game.engine == EngineType.ETHORNELL) {
            return EthornellOperationGate.exclusive {
                try {
                    launchTracked(context, game, patchChoice, onDispatched)
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (_: java.io.IOException) {
                    LaunchResult.Failure.EthornellPrepareFailed(EthornellPrepareError.SESSION_BUSY)
                } catch (_: SecurityException) {
                    LaunchResult.Failure.EthornellPrepareFailed(EthornellPrepareError.SESSION_BUSY)
                }
            }
        }
        return launchTracked(context, game, patchChoice, onDispatched)
    }

    private suspend fun launchTracked(context: Context, game: ScanGame, patchChoice: ArtemisPatchChoice?, onDispatched: () -> Unit): LaunchResult {
        launchingUris.add(game.uri)
        try {
            return launchInternalChecked(context, game, patchChoice, onDispatched)
        } finally {
            launchingUris.remove(game.uri)
        }
    }

    private suspend fun launchInternalChecked(context: Context, game: ScanGame, patchChoice: ArtemisPatchChoice?, onDispatched: () -> Unit): LaunchResult {
        // 未知引擎（含第三方运行时模块卸载/禁用后的降级条目）不再落入 Tyrano 宿主兜底；请用户重新扫描。
        if (game.engine == EngineType.UNKNOWN) return LaunchResult.Failure.EngineUnknown
        if (game.engine == EngineType.IMPACTO) {
            impactoEnvironmentFailure(context)?.let { return LaunchResult.Failure.ImpactoPrepareFailed(it) }
        }
        if (game.engine == EngineType.ETHORNELL) {
            currentCoroutineContext().ensureActive()
            val live = EngineSessionRegistry.currentLiveGame(context, EngineSessionRegistry.HOST_ETHORNELL)
            val alive = EngineSessionRegistry.isHostAlive(context, EngineSessionRegistry.HOST_ETHORNELL)
            val busy = EthornellOperationGate.isBusy(context)
            when (EthornellLaunchPolicy.decide(game.uri, live, alive)) {
                EthornellLaunchPolicy.Action.RESTORE_EXISTING -> return restoreEthornell(context, game).also { if (it == LaunchResult.Success) onDispatched() }
                EthornellLaunchPolicy.Action.BUSY -> return LaunchResult.Failure.EthornellPrepareFailed(EthornellPrepareError.SESSION_BUSY)
                EthornellLaunchPolicy.Action.START_NEW -> if (busy) {
                    return LaunchResult.Failure.EthornellPrepareFailed(EthornellPrepareError.SESSION_BUSY)
                }
            }
        }
        // 手动添加的安卓游戏：无引擎会话/存档/权限前置，按包名直接跳转（必须在目录解析之前分流）
        if (AndroidAppGames.isAndroidApp(game)) {
            return launchAndroidApp(context, game).also { if (it == LaunchResult.Success) onDispatched() }
        }
        // 第三方 APK 运行时模块：按包名交给显式组件启动，不进入目录解析/设置/插件链
        if (game.engine == EngineType.RUNTIME_MODULE) {
            return launchRuntimeModule(context, game, onDispatched)
        }
        // 外置模拟器跳转：PSP / Switch 为 ROM 文件型（不解析目录），
        // YURIS 为 Windows 游戏（目录 + 主 exe，经 Winlator 外置启动协议挂载目录）
        ExternalEmulatorRegistry.forEngine(game.engine)?.let { target ->
            currentCoroutineContext().ensureActive()
            if (target.launchStyle == EmulatorLaunchStyle.WINLATOR_EXTERNAL) {
                return launchWindowsViaWinlator(context, game, target, onDispatched)
            }
            // PSP：按三级设置的「PPSSPP 版本」解析标准版/黄金版目标；其余目标（Eden）固定
            val resolvedTarget = if (target.supports(EngineType.PSP)) {
                ExternalEmulatorRegistry.ppssppTarget(
                    EngineSettingsResolver.resolve(context, game, null).ppssppVersion,
                )
            } else {
                target
            }
            val result = ExternalEmulatorLauncher.launch(context, resolvedTarget, game.uri)
            if (result.success) {
                return completeLaunch(context, game, onDispatched)
            }
            return LaunchResult.Failure.ExternalEmulatorFailed(result)
        }
        // 外置模块先于内置目录解析确定路径：文件型入口（SWF）取所在目录，其余保持目录解析
        val defaultModule = ExternalEngineModuleRegistry.moduleForEngine(game.engine)
        val path = if (defaultModule?.launchEntryIsFile == true) {
            resolveLaunchEntryDirectory(context, game) ?: return LaunchResult.Failure.GameDirUnresolved
        } else {
            resolveGameDirectory(context, game)
        }
        // 三级设置（应用级 + 单游戏覆盖）一次性解析，后续 Intent 组装只消费生效值（P0-3）
        val settings = EngineSettingsResolver.resolve(context, game, path)
        defaultModule?.let { defaultModule ->
            val module = ExternalEngineModuleRegistry.resolveModule(
                game.engine,
                if (game.engine == EngineType.RENPY) settings.renpyVersion else null,
                detectedRenpyVersion = game.detectedRenpyVersion,
            ) ?: defaultModule
            // 先确认模块已安装，再走目录/权限门禁：否则未安装时会把用户先送去「所有文件访问」，
            // 真正的缺失原因（应安装模块）反而看不到。
            if (!ExternalEngineLauncher.isPackageInstalled(context, module)) {
                return LaunchResult.Failure.ExternalModuleFailed(
                    ExternalEngineLaunchResult.failure(
                        ExternalEngineErrorCode.PACKAGE_NOT_INSTALLED,
                        moduleNameRes = module.displayNameRes,
                        moduleNameFallback = module.displayName,
                        engineName = game.engine.displayName,
                        installUrl = module.installUrl,
                    ),
                )
            }
            if (module.requiresGameDirectoryPath && path == null) {
                return LaunchResult.Failure.GameDirUnresolved
            }
            // 需要目录解析的外置引擎同样要「所有文件访问」权限才能读取游戏目录（SAF 授权对外置 APK 无效）
            if (module.requiresGameDirectoryPath && path != null) {
                requestAllFilesAccessIfNeeded(context, game, path)?.let { return it }
            }
            // 与内置引擎路径一致：真正拉起外置引擎前确认未取消，避免取消后仍执行启动副作用
            currentCoroutineContext().ensureActive()
            val result = ExternalEngineLauncher.launch(
                context,
                module,
                ExternalEngineLaunchRequest(
                    game = game,
                    gameDirectoryPath = path.orEmpty(),
                    launchTarget = game.launchTarget,
                    resolvedSettings = settings,
                ),
            )
            if (result.success) {
                return completeLaunch(context, game, onDispatched)
            }
            return LaunchResult.Failure.ExternalModuleFailed(result)
        }
        if (path == null) {
            return LaunchResult.Failure.GameDirUnresolved
        }
        // SystemNNN already admitted its selected root; an app-private imported copy needs no broad grant.
        if (game.engine != EngineType.SYSTEMNNN) requestAllFilesAccessIfNeeded(context, game, path)?.let { return it }
        if (game.engine == EngineType.IMPACTO) {
            return launchImpacto(context, game, path, settings, onDispatched)
        }
        if (game.engine == EngineType.ETHORNELL) {
            prepareEthornell(context, game, path, settings)?.let { return it }
        }
        EnginePluginBootstrap.ensureForLaunch(context, game.engine)?.let {
            return LaunchResult.Failure.PluginBootstrapFailed(it)
        }
        // MV/MZ 存档互通开启时：登记待回写，并在同一游戏的引擎会话未运行时先同步一次
        // （补上次回写 + 本次导入）。登记与同步结果无关——即使本次同步失败/推迟，退出后仍要回写。
        if (isRpgSaveInteropEnabled(context, game)) {
            recordPendingSaveSync(context, game.uri)
            try {
                synchronized(perGameLock(game.uri)) {
                    // 同一游戏的旧会话仍在写入 savedata 时绝不复制（进程内锁约束不了独立引擎进程），
                    // 半写入文件会被当成有效存档。此时保留 pending，交给前台兜底在会话退出后同步。
                    if (isEngineSessionRunning(context, game, path)) {
                        Log.i(TAG, "rpg save interop sync deferred (session running) uri=${game.uri}")
                    } else {
                        val result = syncRpgSavesForDirectory(context, game, File(path))
                        if (result == null) {
                            // 独立存档目录不可用：跳过本轮，绝不回退游戏根目录（H4）
                            Log.i(TAG, "rpg save interop sync deferred (scoped save dir unavailable) uri=${game.uri}")
                        } else {
                            Log.i(
                                TAG,
                                "rpg save interop sync uri=${game.uri} imported=${result.imported} exported=${result.exported} " +
                                    "toTyranor=${result.toTyranor} toStandard=${result.toStandard} deleted=${result.movedToDeleted} failed=${result.failed}",
                            )
                        }
                    }
                }
            } catch (ce: CancellationException) {
                throw ce
            } catch (t: Throwable) {
                Log.w(TAG, "rpg save interop sync failed uri=${game.uri}", t)
            }
        }
        val krSafMirror = if (
            game.engine == EngineType.KIRIKIRI && GamePathUtils.isRemovableStoragePath(path)
        ) {
            try {
                withContext(Dispatchers.IO) {
                    KrSafMirror.prepare(context.applicationContext, game.uri, path)
                }
            } catch (ce: CancellationException) {
                throw ce // 取消不是启动失败，原样传播给调用方
            } catch (t: Throwable) {
                Log.e(TAG, "prepare KRKR SAF mirror failed uri=${game.uri}", t)
                // 只把类型化阶段交给 UI：底层异常 message 是给日志的排查线索，
                // 不该当作界面文案（AGENTS.md 错误协议）。
                // 非 PrepareException 的未知异常一律按「创建失败」上报（名称留空，
                // UI 回落到「未知路径」），因为此时连失败发生在哪一步都无法断言
                val failure = t as? KrSafMirror.PrepareException
                return LaunchResult.Failure.KrkrMirrorPrepareFailed(
                    stage = when (failure?.stage) {
                        KrSafMirror.Stage.SOURCE_UNRESOLVED -> MirrorPrepareStage.SOURCE_UNRESOLVED
                        KrSafMirror.Stage.EMPTY_MIRROR -> MirrorPrepareStage.EMPTY_MIRROR
                        else -> MirrorPrepareStage.CREATE_FAILED
                    },
                    name = failure?.name,
                )
            }
        } else {
            null
        }
        if (game.engine == EngineType.KIRIKIRI) {
            if (krSafMirror != null) {
                val saveDir = File(krSafMirror.mirrorRoot, "savedata")
                if (!saveDir.isDirectory && !saveDir.mkdirs()) {
                    return LaunchResult.Failure.KrkrMirrorSaveDirFailed(saveDir.absolutePath)
                }
            } else {
                ensureKrSaveDir(context, game, path, settings)?.let { return it }
            }
        }
        // System35（xsystem35）：独立存档目录缺失时预创建，失败即类型化返回（不回退游戏根）
        if (game.engine == EngineType.XSYS35) {
            ensureXs35SaveDir(context, path, settings)?.let { return it }
        }
        // System4（xsystem4）：预检（入口 ini / GLES 3.0）先于存档目录副作用；同款预创建，不回退游戏根
        if (game.engine == EngineType.XSYS4) {
            preflightXs4(context, path)?.let { return it }
            ensureXs4SaveDir(context, path, settings)?.let { return it }
        }
        // CMVS（cmvs-rs）：NativeActivity + loader；启动前固定顶层 launch.cfg，禁止旧实例复用
        if (game.engine == EngineType.CMVS) {
            if (CmvsLaunchFiles.isRunning(context)) {
                return LaunchResult.Failure.CmvsAlreadyRunning
            }
            val cmvsFont = CmvsLaunchFiles.ensureFont(context, settings.cmvsFont)
            val cmvsFace = settings.cmvsFontFace
            CmvsPreflight.check(context, game, File(path), cmvsFont, cmvsFace)?.let { return it }
            if (cmvsFont == null) return LaunchResult.Failure.CmvsFontUnavailable
            val token = java.util.UUID.randomUUID().toString()
            cmvsLaunchToken = token
            if (!CmvsLaunchFiles.write(context, game, File(path), cmvsFont, cmvsFace, token)) {
                return LaunchResult.Failure.CmvsLaunchConfigUnavailable
            }
        }
        // “总是/不再”持久化为全局补丁策略；“本次”不落盘，仅本次按 auto 生效
        if (game.engine == EngineType.ARTEMIS) {
            when (patchChoice) {
                ArtemisPatchChoice.ALWAYS ->
                    EngineSettingsStore.setArtAutoPatch(context, EngineSettingsStore.AUTO_PATCH_AUTO)
                ArtemisPatchChoice.NEVER ->
                    EngineSettingsStore.setArtAutoPatch(context, EngineSettingsStore.AUTO_PATCH_OFF)
                else -> Unit
            }
        }
        // 输入重映射：旧 __touch_pad.js 布局/预设 → 新方案文件（幂等；仅 Web 系引擎有旧数据）
        if (game.engine in WEB_INPUT_ENGINES) {
            // 取消必须原样传播（AGENTS.md 错误协议）：不用 runCatching 一把吞，
            // 否则取消会被当成迁移失败只记日志、启动继续走下去
            try {
                InputRemapRepository.migrateLegacyIfNeeded(context.applicationContext, game.uri)
            } catch (ce: CancellationException) {
                throw ce
            } catch (t: Throwable) {
                Log.w(TAG, "input legacy migration failed uri=${game.uri}", t)
            }
        }
        // 阻塞准备（镜像/overlay/PFS）完成后统一检查取消：已取消则不执行任何启动副作用
        currentCoroutineContext().ensureActive()
        // 大体积引擎运行库（siglus / fvp / ethornell / krkrsdl3 / ijk / xsystem）首启从 assets 解压到应用私有目录；
        // IJK 只服务视频覆盖层（OnsIjkVideoView / VideoViewActivity 自带「视频失败不影响游戏本体」的
        // 降级路径），解压失败只记日志继续启动；其余分片是引擎本体依赖，失败即类型化返回。
        // 复用 launch() 的 IO 调度，宿主进程只按绝对路径加载已解压的 .so。
        for (packId in engineRuntimePacksFor(game.engine, settings)) {
            if (NativeRuntimePack.ensure(context.applicationContext, packId)) continue
            if (packId == NativeRuntimePack.PACK_IJK) {
                Log.w(TAG, "IJK runtime pack unavailable, launching without video overlay uri=${game.uri}")
                continue
            }
            Log.w(TAG, "engine runtime pack unavailable pack=$packId uri=${game.uri}")
            return LaunchResult.Failure.EngineLibraryPackFailed(packId)
        }
        return try {
            val intent = buildIntent(context, game.engine, path, game, patchChoice, krSafMirror, settings)
                .putExtra(LaunchContract.ROOT_URI, game.uri)
            // Intent 组装后、真正拉起引擎前最后一次确认，取消后不 startActivity
            currentCoroutineContext().ensureActive()
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (game.engine == EngineType.ETHORNELL) {
                intent.putExtra(LaunchContract.ETHORNELL_DISPATCH_TOKEN, EthornellOperationGate.issue(context, game.uri))
            }
            File(context.filesDir, "launch-error.txt").delete()
            context.startActivity(intent)
            if (game.engine == EngineType.CMVS) {
                // 宿主进程与 App 解耦；即使用户离开本页/启动协程被取消，也要把失败送到常驻 UI。
                val code = kotlinx.coroutines.withContext(kotlinx.coroutines.NonCancellable) {
                    kotlinx.coroutines.delay(1800)
                    runCatching {
                        File(context.filesDir, "launch-error.txt").takeIf { it.isFile }
                            ?.readLines()
                            ?.firstOrNull { it.startsWith("code=") }
                            ?.substringAfter("code=")?.trim()
                    }.getOrNull()
                }
                if (!code.isNullOrEmpty()) {
                    val failure = LaunchResult.Failure.CmvsInitFailed(code)
                    LaunchFailureBus.publish(failure)
                    return failure
                }
            }
            completeLaunch(context, game, onDispatched)
        } catch (ce: CancellationException) {
            throw ce // 取消不是启动失败，原样传播给调用方
        } catch (e: Exception) {
            LaunchResult.Failure.StartFailed(e.message)
        }
    }

    /**
     * 第三方 APK 运行时模块：先刷新发现结果（缓存可能早于模块安装/卸载/更新），再把游戏文件夹
     * 绝对路径交给模块的显式组件。`Dispatched` 只代表 Intent 已交棒，不承诺游戏运行成功。
     *
     * [RuntimeModuleLaunchResult.ModuleMissing] / [ModuleDisabled] 会把游戏降级为 UNKNOWN；
     * [RuntimeModuleLaunchResult.PathUnresolved] 不请求「所有文件访问」——模块自己负责存储权限。
     */
    private suspend fun launchRuntimeModule(context: Context, game: ScanGame, onDispatched: () -> Unit): LaunchResult {
        // 发现查询失败不是「模块缺失」：直接上报通用失败，避免把全部绑定误降级。
        when (val discovery = RuntimeModuleRegistry.refresh(context)) {
            is RuntimeModuleDiscoveryResult.Failure ->
                return LaunchResult.Failure.RuntimeModuleFailed(
                    RuntimeModuleLaunchResult.StartFailed(discovery.detail),
                )

            is RuntimeModuleDiscoveryResult.Success -> Unit
        }
        // 没有包名就没有可保留的绑定，但仍把条目降级，避免 UI 提示与状态不一致。
        val packageName = game.runtimeModulePackage?.takeIf { it.isNotBlank() }
        if (packageName == null) {
            degradeRuntimeModuleGame(context, game, null)
            return LaunchResult.Failure.RuntimeModuleFailed(RuntimeModuleLaunchResult.ModuleMissing)
        }
        val module = RuntimeModuleRegistry.find(packageName)
        if (module == null) {
            degradeRuntimeModuleGame(context, game, packageName)
            return LaunchResult.Failure.RuntimeModuleFailed(RuntimeModuleLaunchResult.ModuleMissing)
        }
        if (!module.enabled) {
            degradeRuntimeModuleGame(context, game, packageName)
            return LaunchResult.Failure.RuntimeModuleFailed(RuntimeModuleLaunchResult.ModuleDisabled)
        }
        // 先做词法映射：模块自己校验目录是否存在/可读，主 App 不要求“所有文件访问”。
        val path = GamePathUtils.safUriToPath(game.uri)
            ?: resolveGameDirectory(context, game)
            ?: return LaunchResult.Failure.RuntimeModuleFailed(RuntimeModuleLaunchResult.PathUnresolved)
        currentCoroutineContext().ensureActive()
        return when (val result = RuntimeModuleLauncher.launch(context, module, game, path)) {
            RuntimeModuleLaunchResult.Dispatched -> completeLaunch(context, game, onDispatched)

            RuntimeModuleLaunchResult.ModuleMissing,
            RuntimeModuleLaunchResult.ModuleDisabled,
            RuntimeModuleLaunchResult.EntryMissing -> {
                degradeRuntimeModuleGame(context, game, packageName)
                LaunchResult.Failure.RuntimeModuleFailed(result)
            }

            else -> LaunchResult.Failure.RuntimeModuleFailed(result)
        }
    }

    /** 模块缺失/禁用后的绑定清理；清理失败只记日志，不改变本次启动失败的既定结果。 */
    private fun degradeRuntimeModuleGame(context: Context, game: ScanGame, expectedPackage: String?) {
        try {
            RuntimeModuleBindings.degradeGame(context, game.uri, expectedPackage)
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (t: Throwable) {
            Log.w(TAG, "degrade runtime module game failed uri=${game.uri}", t)
        }
    }

    /**
     * Artemis 补丁确认弹窗的触发条件：补丁策略为“启动时询问”（单游戏覆盖 > 全局）
     * 且该游戏确实需要 PFS 基础补丁（缺 system.ini 且存在 .pfs）。
     * UI 层据此弹窗，用户选择经 [launch] 的 [patchChoice] 传入。
     * 含 runBlocking 的设置读取与目录枚举，切 IO 执行。
     */
    suspend fun needsArtemisPatchConfirm(context: Context, game: ScanGame): Boolean =
        withContext(Dispatchers.IO) {
            if (game.engine != EngineType.ARTEMIS) return@withContext false
            // 单游戏覆盖值走白名单校验：损坏/历史遗留的非法值回退全局，防止静默改变补丁行为
            val settings = EngineSettingsResolver.resolve(context, game, null)
            // 自研内核不做 PFS/system.ini 补丁，无需询问
            if (settings.artKernel == EngineSettingsStore.ART_KERNEL_CLEAN) return@withContext false
            val strategy = settings.artAutoPatch
            if (strategy != EngineSettingsStore.AUTO_PATCH_ASK) return@withContext false
            val path = resolveGameDirectory(context, game) ?: return@withContext false
            ArtemisPfsUnpacker.needsBasePatch(path)
        }

    /**
     * RPG Maker MV/MZ 存档格式确认弹窗的触发条件：**引擎生效的存档目录**（独立存档开启时为
     * 外部目录，否则 `<游戏根>/savedata`，另兼容历史 `Savedata/`）内存在标准格式存档时，
     * 返回检测结果供弹窗展示；无待转化项或目录不可用返回 null。
     * 含目录枚举的 IO，切 IO 执行。
     */
    suspend fun rpgSaveFormatPending(context: Context, game: ScanGame): RpgSaveFormat.Detection? =
        withContext(Dispatchers.IO) {
            // 仅 MV/MZ 需要检测/转化；其他引擎（含手动安卓游戏）直接短路，避免无意义的目录解析
            if (!RpgSaveFormat.isRpgWebEngine(game.engine)) return@withContext null
            val root = resolveGameDirectory(context, game) ?: return@withContext null
            val dirs = effectiveRpgSaveScanDirs(context, game, root) ?: return@withContext null
            RpgSaveFormat.detectInDirs(dirs, game.engine).takeIf { it.convertibleCount > 0 }
        }

    /**
     * 手动同步/转化入口的类型化结果（PR 审查：手动入口必须感知会话状态）。
     * [Busy] 表示同一游戏的引擎会话仍在运行或启动流程正在进行——此时**未触碰任何存档**，
     * UI 应提示用户先退出游戏；[SaveDirUnavailable] 表示独立存档目录不可用。
     */
    sealed interface RpgSaveOpResult<out T> {
        /** 操作已完成，携带底层结果。 */
        data class Done<T>(val value: T) : RpgSaveOpResult<T>

        /** 同一游戏引擎会话运行中/启动中：拒绝操作且不修改存档。 */
        data object Busy : RpgSaveOpResult<Nothing>

        /** 生效存档目录不可用（独立存档开启但外部存储未挂载）。 */
        data object SaveDirUnavailable : RpgSaveOpResult<Nothing>
    }

    /**
     * 按 game.uri 的互斥协调：手动同步/转化、启动前同步、前台回写共用同一把锁，
     * 保证「忙碌判定 + 存档操作」整体原子，杜绝与运行中引擎写入交错的窗口。
     * 锁序恒为 perGameLock → INTEROP_LOCK（[RpgSaveSync] 内部），无死锁环。
     */
    private val perGameLocks = ConcurrentHashMap<String, Any>()

    // 不做淘汰（审查跟进 #3）：锁对象被占用时移除会导致同一 URI 出现两把锁、互斥失效；
    // 条目数以游戏库规模为上界（每条仅一个空对象引用），内存代价可忽略，常驻换取正确性。

    private fun perGameLock(gameUri: String): Any = perGameLocks.computeIfAbsent(gameUri) { Any() }

    /** 该游戏当前是否忙碌（引擎会话运行中或启动流程进行中）；忙碌时禁止一切存档修改。 */
    private fun isRpgGameBusy(context: Context, game: ScanGame, gameDirPath: String?): Boolean =
        launchingUris.contains(game.uri) || isEngineSessionRunning(context, game, gameDirPath)

    /**
     * 执行 MV/MZ 存档格式转化（标准 → Tyranor），输出到引擎生效存档目录。
     * 会话忙碌时返回 [RpgSaveOpResult.Busy] 且不修改任何存档。
     * @throws GameSaveException 游戏目录不可用时抛出（类型化错误码）。
     */
    suspend fun convertRpgSaveFormat(context: Context, game: ScanGame): RpgSaveOpResult<RpgSaveFormat.ConvertResult> =
        withContext(Dispatchers.IO) {
            val root = resolveGameDirectory(context, game)?.let(::File)
                ?: throw GameSaveException(SaveErrorCode.RESOLVE_SAVE_DIR_FAILED, detail = game.uri)
            synchronized(perGameLock(game.uri)) {
                if (isRpgGameBusy(context, game, root.absolutePath)) {
                    return@synchronized RpgSaveOpResult.Busy
                }
                val dirs = effectiveRpgSaveScanDirs(context, game, root.absolutePath)
                    ?: return@synchronized RpgSaveOpResult.SaveDirUnavailable
                RpgSaveOpResult.Done(
                    RpgSaveFormatConverter.convert(outputDir = dirs.first(), sourceDirs = dirs, engine = game.engine),
                )
            }
        }

    /**
     * MV/MZ 检测/转化的目录组：首选引擎生效存档目录（独立存档开关决定，与同步侧一致，
     * GameSaveManager.resolveSaveLocation 同源），并附加兼容扫描目录：
     * - 非独立存档：历史 `Savedata/`；
     * - 独立存档：游戏根 `savedata/` + `Savedata/`（用户从非独立切到独立后，旧标准档
     *   仍能被检测/转化进生效目录——引擎只读外部目录，转化是唯一的迁移通道）。
     * 独立存档开启但外部目录不可用（存储未挂载）时返回 null——绝不能把游戏根当生效目录：
     * 引擎根本不读那里，转化会写进永远不被读取的位置（PR 审查 B1）。
     */
    private fun effectiveRpgSaveScanDirs(context: Context, game: ScanGame, rootPath: String): List<File>? {
        if (!RpgSaveFormat.isRpgWebEngine(game.engine)) return null
        val settings = EngineSettingsResolver.resolve(context, game, rootPath)
        val effective = GameSaveManager(context).effectiveTyranoFamilySaveDirectory(
            game.uri,
            rootPath,
            settings.webScopedSaveDir,
        ) ?: return null
        return buildRpgSaveScanDirs(rootPath, effective, settings.webScopedSaveDir)
    }

    /**
     * 组装检测/转化目录组（纯函数，供单测直接校验）：**首个元素是引擎生效目录 = 转化输出落点**，
     * 其余元素仅供扫描。包含三类：
     * - 兼容目录：非独立存档的历史 `Savedata/`；独立存档时另含游戏根 `savedata/`（用户从非独立
     *   切到独立后，旧标准档仍能被检测/转化进生效目录——引擎只读外部目录）；
     * - 标准侧（JoiPlay/PC）目录：`<内容根>/save`（MV 常见 `<游戏根>/www/save`，MZ 无 www 时为
     *   `<游戏根>/save`），兼容 `Save/` 拼写。标准格式存档实际就放在这里，不纳入扫描范围就
     *   永远检测不到，转化形同不生效。
     */
    internal fun buildRpgSaveScanDirs(rootPath: String, effectiveDir: File, scoped: Boolean): List<File> {
        val compatible = if (scoped) {
            listOf(File(rootPath, "savedata"), File(rootPath, "Savedata"))
        } else {
            listOf(File(rootPath, "Savedata"))
        }
        val standard = RpgSaveFormat.standardSaveDirectories(File(rootPath))
        val seen = mutableSetOf<String>()
        return (listOf(effectiveDir) + compatible + standard).filter { dir ->
            // 与 RpgSaveFormat 共用同一去重规则：此前此处无条件小写归一，
            // 会把区分大小写文件系统上的 `Savedata/`（历史兼容目录）误判为与生效目录
            // `savedata/` 相同而丢弃，只放在 Savedata/ 的旧存档因此漏检、漏转化。
            seen.add(RpgSaveFormat.saveDirDedupKey(dir))
        }
    }

    /**
     * MV/MZ 存档互通生效值：单游戏覆盖 > 全局（经 [EngineSettingsResolver] 统一合并，M3），
     * 非 RPG 引擎恒 false。读取单游戏覆盖会命中 DB，故挂起并在 IO 线程执行，
     * 避免 UI 主线程协程被阻塞。
     */
    suspend fun isRpgSaveInteropEnabled(context: Context, game: ScanGame): Boolean {
        if (!RpgSaveFormat.isRpgWebEngine(game.engine)) return false
        return withContext(Dispatchers.IO) {
            EngineSettingsResolver.resolve(context, game, null).rpgSaveInterop
        }
    }

    /**
     * 执行一次 MV/MZ 存档互通双向同步（标准侧 `<内容根>/save` ⇄ Tyranor 侧有效存档目录）。
     * 手动入口：会话忙碌时返回 [RpgSaveOpResult.Busy] 且不修改任何存档；非 RPG 引擎返回空结果。
     * 含文件 IO，切 IO 执行。
     */
    suspend fun syncRpgSaves(context: Context, game: ScanGame): RpgSaveOpResult<RpgSaveSync.Result> =
        withContext(Dispatchers.IO) {
            if (!RpgSaveFormat.isRpgWebEngine(game.engine)) {
                return@withContext RpgSaveOpResult.Done(RpgSaveSync.Result())
            }
            val gameDir = resolveGameDirectory(context, game)?.let(::File)
                ?: throw GameSaveException(SaveErrorCode.RESOLVE_SAVE_DIR_FAILED, detail = game.uri)
            synchronized(perGameLock(game.uri)) {
                if (isRpgGameBusy(context, game, gameDir.absolutePath)) {
                    return@synchronized RpgSaveOpResult.Busy
                }
                when (val result = syncRpgSavesForDirectory(context, game, gameDir)) {
                    null -> RpgSaveOpResult.SaveDirUnavailable
                    else -> RpgSaveOpResult.Done(result)
                }
            }
        }

    /**
     * 同步核心（供启动/前台兜底/手动入口共用）。
     * 返回 null = Tyranor 侧生效存档目录不可用（独立存档开启但外部存储未挂载）——此时
     * **跳过本轮同步**，绝不回退游戏根目录：回退会把空目录当 Tyranor 侧，清单里
     * tyranorExists 的槽位全部误走「已删除」分支，标准侧存档被错误隔离（PR 审查 H4）。
     * 上一轮调用方应保留 pending，待目录恢复后重试。
     */
    private fun syncRpgSavesForDirectory(
        context: Context,
        game: ScanGame,
        gameDir: File,
    ): RpgSaveSync.Result? {
        val settings = EngineSettingsResolver.resolve(context, game, gameDir.absolutePath)
        val tyranorDir = GameSaveManager(context).effectiveTyranoFamilySaveDirectory(
            game.uri,
            gameDir.absolutePath,
            settings.webScopedSaveDir,
        ) ?: return null
        // 标准侧兼容 save / Save 两种拼写；首选写入目录为已存在的小写 save（默认）
        val standardDirs = RpgSaveFormat.standardSaveDirectories(gameDir)
        val state = RpgSaveSyncState.forContext(context)
        return RpgSaveSync.syncWithManualSelection(
            standardDirs = standardDirs,
            tyranorDir = tyranorDir,
            engine = game.engine,
            stateStore = state,
            gameKey = game.uri,
        )
    }

    /** 记录待回写的游戏（应用回到前台时对已退出会话补一次同步）；写入失败如实记日志。 */
    fun recordPendingSaveSync(context: Context, gameUri: String) {
        if (gameUri.isBlank()) return
        if (!RpgSavePendingStore.add(context, gameUri)) {
            Log.w(TAG, "record pending save sync failed uri=$gameUri")
        }
    }

    /**
     * 应用回到前台时调用：对每个待回写游戏，等待其引擎会话进程退出后补一次同步并清除记录。
     *
     * 引擎 finish 后约 500ms 才 killProcess（且强杀无回调），回到前台时进程往往仍在，
     * 因此这里按 [SESSION_EXIT_POLL_MS] 轮询等待其退出（上限 [SESSION_EXIT_MAX_ATTEMPTS] 次）；
     * 超时仍存活视为「后台会话」本次不回写，避免与运行中的引擎并发读写。正常 finish 场景下
     * registry 在 onDestroy 已清空、判定立即通过——此时引擎已结束交互、不再写存档，
     * 立即同步是安全的；轮询真正覆盖的是「后台会话仍运行」的场景。
     *
     * 只有「确认游戏已从库中删除」「不再是 RPG 引擎」「互通开关已关闭」或「本次同步完全成功
     * （failed == 0）」才移除 pending；临时性失败（游戏库读取异常、SAF 权限失效、存储未挂载
     * 导致目录解析失败、逐槽失败、清单损坏/提交失败、目录不可用）一律保留记录，留待下次前台重试。
     */
    suspend fun flushPendingSaveSync(context: Context): Int = withContext(Dispatchers.IO) {
        val pending = RpgSavePendingStore.all(context)
        if (pending.isEmpty()) return@withContext 0
        // 一次性读取游戏库快照：逐个 pending 重复全量读取是 O(N×库)（审查 L6）
        val games = try {
            GameLibraryFacade.loadGames(context)
        } catch (ce: CancellationException) {
            throw ce
        } catch (t: Throwable) {
            Log.w(TAG, "rpg save interop flush: loadGames failed, keep all pending", t)
            return@withContext 0
        }
        val gamesByUri = games.associateBy { it.uri }
        var synced = 0
        pending.forEach { gameUri ->
            val game = gamesByUri[gameUri]
            if (game == null || !RpgSaveFormat.isRpgWebEngine(game.engine)) {
                // 已确认游戏不存在或非 RPG 引擎：记录无意义，移除
                RpgSavePendingStore.remove(context, gameUri)
                return@forEach
            }
            // 开关关闭后不再回写（也可能是本次登记后用户关掉了互通）
            if (!isRpgSaveInteropEnabled(context, game)) {
                RpgSavePendingStore.remove(context, gameUri)
                return@forEach
            }
            // 目录暂时解析不到（SAF 权限失效/存储未挂载/IO 异常）：保留记录待下次重试
            val gameDir = try {
                resolveGameDirectory(context, game)?.let(::File)
            } catch (ce: CancellationException) {
                throw ce
            } catch (t: Throwable) {
                Log.w(TAG, "rpg save interop flush: resolve dir failed, keep pending uri=$gameUri", t)
                return@forEach
            }
            if (gameDir == null) {
                Log.i(TAG, "rpg save interop flush: game dir unavailable, keep pending uri=$gameUri")
                return@forEach
            }
            val gameDirPath = gameDir.absolutePath
            var attempts = 0
            while (isEngineSessionRunning(context, game, gameDirPath) && attempts < SESSION_EXIT_MAX_ATTEMPTS) {
                delay(SESSION_EXIT_POLL_MS)
                attempts++
            }
            if (isEngineSessionRunning(context, game, gameDirPath)) return@forEach
            try {
                // 与启动前同步、手动同步/转化共用同一把 per-URI 锁：忙碌判定 + 同步整体原子
                synchronized(perGameLock(gameUri)) {
                    if (isRpgGameBusy(context, game, gameDirPath)) {
                        // 该游戏的引擎会话仍在/启动流程正在进行：保留 pending，由启动流程的同步覆盖本次
                        Log.i(TAG, "rpg save interop flush deferred (busy), keep pending uri=$gameUri")
                        return@synchronized
                    }
                    val result = syncRpgSavesForDirectory(context, game, gameDir)
                    when {
                        // 目录不可用：本轮跳过，保留 pending（绝不套用删除语义，H4）
                        result == null ->
                            Log.i(TAG, "rpg save interop flush deferred (scoped save dir unavailable), keep pending uri=$gameUri")
                        // 同步有失败项：如实保留 pending，下次前台重试（H1——failed 也可能来自
                        // 清单损坏/提交失败，直接移除会让刚玩完的回写永久丢失）
                        result.failed > 0 ->
                            Log.w(TAG, "rpg save interop flush incomplete (failed=${result.failed}), keep pending uri=$gameUri")
                        else -> {
                            synced++
                            RpgSavePendingStore.remove(context, gameUri)
                        }
                    }
                }
            } catch (ce: CancellationException) {
                throw ce
            } catch (t: Throwable) {
                // 同步抛错保留 pending，下次前台重试
                Log.w(TAG, "rpg save interop flush failed, keep pending uri=$gameUri", t)
            }
        }
        synced
    }

    /**
     * 对应 host 进程是否正运行**同一游戏**的会话。仅按进程后缀判断会把「任意后台
     * Tyrano 游戏」误判为本游戏在跑，导致本游戏的回写被永久跳过；故先看
     * [EngineSessionRegistry] 登记的当前游戏目录是否与本游戏一致，再用进程存活兜底
     * （登记在宿主被强杀时可能残留，进程不在了就不算运行）。
     */
    private fun isEngineSessionRunning(context: Context, game: ScanGame, gameDirPath: String?): Boolean {
        if (gameDirPath.isNullOrBlank()) return false
        val hosts = if (game.engine == EngineType.RPG_MV || game.engine == EngineType.RPG_MZ) {
            // v1/v2 跑在 :rpgmaker，v0 跑在 :tyrano；两者任一在跑同一游戏都视为运行中
            listOf(EngineSessionRegistry.HOST_RPGMAKER to ":rpgmaker", EngineSessionRegistry.HOST_TYRANO to ":tyrano")
        } else {
            listOf(EngineSessionRegistry.HOST_TYRANO to ":tyrano")
        }
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return false
        val running = am.runningAppProcesses.orEmpty()
        return hosts.any { (host, suffix) ->
            if (running.none { proc -> proc.processName.endsWith(suffix) }) return@any false
            val registered = EngineSessionRegistry.currentGame(context, host) ?: return@any false
            samePath(registered, gameDirPath)
        }
    }

    /** 目录等价判定：优先 canonicalPath，失败退回字符串比较（与 stopOppositeRpgHost 同策略）。 */
    private fun samePath(a: String, b: String): Boolean = try {
        File(a).canonicalPath == File(b).canonicalPath
    } catch (_: Throwable) {
        a == b
    }

    /**
     * Native engines receive a real /storage path, so SAF tree grants are not enough on Android 11+.
     * Match RinneMobile's requirement: ask the user to enable "Manage all files" before launching.
     */
    private fun requestAllFilesAccessIfNeeded(context: Context, game: ScanGame, path: String): LaunchResult.Failure? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return null
        if (Environment.isExternalStorageManager()) return null
        // A persisted SAF tree grant is sufficient for the mirror itself. Direct
        // directory/MediaStore supplementation remains best-effort on restricted ROMs.
        if (game.engine == EngineType.KIRIKIRI && GamePathUtils.isRemovableStoragePath(path)) return null
        if (!needsAllFilesAccess(path)) return null

        val app = context.applicationContext
        val packageUri = Uri.parse("package:${app.packageName}")
        val opened = runCatching {
            app.startActivity(
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, packageUri)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        }.recoverCatching {
            app.startActivity(
                Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        }.isSuccess

        return if (opened) {
            LaunchResult.Failure.AllFilesAccessRequested
        } else {
            LaunchResult.Failure.AllFilesAccessMissing
        }
    }

    /** Resuming a verified live player must not re-enter save recovery or start a second Activity. */
    private suspend fun restoreSystemNnn(context: Context, game: ScanGame): LaunchResult? {
        return try {
            val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return null
            val root = SystemNnnGameDirectory.committed(context, game.uri) ?: SystemNnnGameDirectory.resolve(game.uri)
            if (root?.let(SystemNnnCopyStore::resourcesEvicted) == true) return null
            val player = android.content.ComponentName(context.packageName, "com.tyranor.runtime.systemnnn.PlayerActivity")
            val task = manager.appTasks.firstOrNull { candidate ->
                val info = candidate.taskInfo ?: return@firstOrNull false
                val base = info.baseIntent
                val baseUri = base.getStringExtra(LaunchContract.ROOT_URI)
                @Suppress("DEPRECATION")
                val id = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) info.taskId else info.id
                id >= 0 && info.numActivities > 0 &&
                    ((base.component == player && (baseUri == null || baseUri == game.uri)) || info.topActivity == player) &&
                    SystemNnnHost.isLivePlayerTask(context, id, game.uri, root)
            } ?: return null
            currentCoroutineContext().ensureActive()
            task.moveToFront()
            completeLaunch(context, game) {}
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (failure: Exception) {
            Log.w(TAG, "Could not restore the SystemNNN task; attempting a new launch", failure)
            null
        }
    }

    /**
     * SystemNNN opens the game directory in place. A directory that the engine cannot read or write
     * is reported as a typed failure; the app never copies the game elsewhere.
     *
     * Copies committed by older builds stay readable so their saves are not stranded, but they are
     * never created or rehydrated anymore.
     */
    private suspend fun prepareSystemNnnResources(
        context: Context,
        game: ScanGame,
    ): LaunchResult.Failure? {
        fun failed(error: SystemNnnResourceError) = LaunchResult.Failure.SystemNnnResourcesFailed(error)
        try {
            val copy = SystemNnnGameDirectory.committed(context, game.uri)
            if (copy != null) {
                // Legacy copy from a build that still created them; direct access is not required.
                if (!SystemNnnCopyStore.readableBootstrap(copy)) return failed(SystemNnnResourceError.CORRUPT_COPY)
                return if (systemNnnSavesWritable(context, copy)) null else failed(SystemNnnResourceError.SAVE_NOT_WRITABLE)
            }
            val path = SystemNnnGameDirectory.resolve(game.uri) ?: return LaunchResult.Failure.GameDirUnresolved
            requestSystemNnnStorage(context, game, path.absolutePath)?.let { return it }
            val root = SystemNnnGameDirectory.accessible(game.uri, path) ?: return failed(when {
                Files.notExists(path.toPath()) -> SystemNnnResourceError.SOURCE_MISSING
                Files.isRegularFile(path.toPath()) -> SystemNnnResourceError.INVALID_SOURCE
                else -> SystemNnnResourceError.STORAGE_RESTRICTED
            })
            if (!SystemNnnCopyStore.readableBootstrap(root)) return failed(SystemNnnResourceError.INVALID_SOURCE)
            return if (systemNnnSavesWritable(context, root)) null else failed(SystemNnnResourceError.SAVE_NOT_WRITABLE)
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (failure: SaveSyncException) {
            return LaunchResult.Failure.SavePreparationFailed(failure.code)
        } catch (failure: SystemNnnCopyStore.Failure) {
            return failed(when (failure.reason) {
                SystemNnnCopyStore.Reason.SOURCE_MISSING -> SystemNnnResourceError.SOURCE_MISSING
                SystemNnnCopyStore.Reason.INVALID_SOURCE -> SystemNnnResourceError.INVALID_SOURCE
                SystemNnnCopyStore.Reason.BUSY -> SystemNnnResourceError.SOURCE_BUSY
                SystemNnnCopyStore.Reason.CORRUPT_COPY -> SystemNnnResourceError.CORRUPT_COPY
                SystemNnnCopyStore.Reason.NO_GRANT,
                SystemNnnCopyStore.Reason.COPY_FAILED,
                -> SystemNnnResourceError.STORAGE_RESTRICTED
            })
        } catch (_: IOException) {
            return failed(SystemNnnResourceError.STORAGE_RESTRICTED)
        } catch (_: SecurityException) {
            return failed(SystemNnnResourceError.STORAGE_RESTRICTED)
        }
    }

    private fun systemNnnSavesWritable(context: Context, root: File): Boolean = try {
        val saves = SystemNnnHost.saveDirectory(context, root)
        (if (saves.exists()) saves else root).canWrite()
    } catch (_: IOException) {
        false
    } catch (_: SecurityException) {
        false
    }

    private fun requestSystemNnnStorage(context: Context, game: ScanGame, path: String): LaunchResult.Failure? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) return requestAllFilesAccessIfNeeded(context, game, path)
        if (!needsAllFilesAccess(path) && !path.startsWith("/storage/")) return null
        val app = context.applicationContext
        if (app.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED &&
            app.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        ) return null
        val opened = runCatching {
            app.startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        }.isSuccess
        return if (opened) LaunchResult.Failure.StorageAccessRequested else LaunchResult.Failure.StorageAccessMissing
    }

    private fun recoverSystemNnnSaves(context: Context, game: ScanGame): LaunchResult.Failure? {
        if (game.engine != EngineType.SYSTEMNNN) return null
        return try {
            GameSaveManager(context).recoverSystemNnnSavesForLaunch(game)
            null
        } catch (failure: GameSaveException) {
            LaunchResult.Failure.SavePreparationFailed(
                if (failure.code == SaveErrorCode.ENGINE_RUNNING) SaveSyncError.GAME_RUNNING else SaveSyncError.SAVE_UNAVAILABLE,
            )
        }
    }

    /** 判断路径是否位于共享存储（原生引擎无法仅凭 SAF 授权读取），供启动前与手动添加目录共用。 */
    internal fun needsAllFilesAccess(path: String): Boolean {
        val normalized = path.replace('\\', '/')
        val primaryRoot = PrimaryStorageRoot.get()
        return normalized == "/sdcard" ||
            normalized.startsWith("/sdcard/") ||
            normalized == primaryRoot ||
            normalized.startsWith("$primaryRoot/") ||
            GamePathUtils.isRemovableStoragePath(normalized)
    }

    /** 引擎 → 随包运行库分片；空表示该引擎的运行库仍直接放在 APK `lib/` 内。 */
    private fun engineRuntimePacksFor(
        engine: EngineType,
        settings: ResolvedEngineSettings,
    ): List<String> = buildList {
        when (engine) {
            EngineType.SIGLUS,
            EngineType.REALLIVE,
            EngineType.AVG32,
            EngineType.UK2 -> add(NativeRuntimePack.PACK_SIGLUS)

            EngineType.FVP -> add(NativeRuntimePack.PACK_FVP)

            EngineType.ETHORNELL -> add(NativeRuntimePack.PACK_ETHORNELL)
            EngineType.IMPACTO -> add(NativeRuntimePack.PACK_IMPACTO)

            EngineType.CMVS -> add(NativeRuntimePack.PACK_CMVS)
            EngineType.SYSTEMNNN -> add(NativeRuntimePack.PACK_SYSTEMNNN)

            // 视频播放（ONS 覆盖层 / Artemis VideoView）依赖 IJK 三件套。
            EngineType.ONS,
            EngineType.ARTEMIS -> add(NativeRuntimePack.PACK_IJK)

            EngineType.XSYS35,
            EngineType.XSYS4 -> add(NativeRuntimePack.PACK_XSYSTEM)

            EngineType.KIRIKIRI -> if (settings.krKernel == EngineSettingsStore.KERNEL_KRKRSDL3) {
                add(NativeRuntimePack.PACK_KRKRSDL3)
            }

            else -> Unit
        }
    }

    /** 构建引擎 Intent；path 为真实文件路径。
     *  字体偏好契约：`default_font`（空串=引擎按所有权标记清理残留）与
     *  `force_default_font`（false 写 "0"）**必须无条件注入**——引擎侧
     *  applyFontPreferences 仅在 hasExtra 时执行写入/清理，缺省会让
     *  引擎配置里的旧值永久残留（issue #74）。 */
    private fun buildIntent(
        context: Context,
        engine: EngineType,
        path: String,
        game: ScanGame,
        patchChoice: ArtemisPatchChoice? = null,
        krSafMirror: KrSafMirror.Prepared? = null,
        settings: ResolvedEngineSettings,
        impacto: ImpactoLaunchPreparation.PreparedLaunch? = null,
    ): Intent {
        val intent = when (engine) {
            EngineType.KIRIKIRI ->
                buildKirikiriIntent(context, path, game, krSafMirror, settings)

            EngineType.ONS -> {
                val ons = settings.ons
                val args = ArrayList<String>()
                args.add("--root")
                args.add(path)
                args.add("--font")
                args.add(if (path.endsWith("/")) "${path}default.ttf" else "$path/default.ttf")
                args.add(if (ons.stretchFull) "--fullscreen2" else "--fullscreen")
                if (ons.disableVideo) args.add("--no-video")
                args.add("--enc:" + EngineSettingsStore.normalizeEncoding(ons.encoding))
                val saveDir = if (ons.scopedSaveDir) {
                    val external = context.getExternalFilesDir(null) ?: context.filesDir
                    File(File(external, "save"), File(path).name)
                } else {
                    File(path, "save")
                }
                val saveDirReady = saveDir.isDirectory ||
                    saveDir.mkdirs() ||
                    (!ons.scopedSaveDir && createSafDirectoryForStoragePath(context, saveDir.absolutePath))
                if (!saveDirReady) {
                    Log.w(TAG, "ONS save dir not created before launch, still passing --save-dir=${saveDir.absolutePath}")
                }
                args.add("--save-dir")
                args.add(saveDir.absolutePath)
                Log.i(TAG, "ONS launch scopedSaveDir=${ons.scopedSaveDir} saveDir=${saveDir.absolutePath} ready=$saveDirReady")
                if (ons.sharpness) {
                    args.add("--sharpness")
                    args.add(safeSharpnessValue(ons.sharpnessValue))
                }
                Intent(context, ONScripter::class.java).apply {
                    putStringArrayListExtra(LaunchContract.GAME_ARGS, args)
                    putExtra(LaunchContract.GAME_URI, Uri.fromFile(java.io.File(path)).toString())
                    putExtra(LaunchContract.PATH, path)
                    putExtra(LaunchContract.GAME_PATH, path)
                    putExtra(LaunchContract.ROOT_URI, game.uri)
                    putExtra(LaunchContract.LAUNCH_TARGET, game.launchTarget)
                    putExtra(LaunchContract.LAUNCH_MODE, LaunchContract.LAUNCH_MODE_ONS)
                    putExtra(LaunchContract.IGNORE_CUTOUT, ons.ignoreCutout)
                }
            }

            EngineType.TYRANO,
            EngineType.RPG_MV,
            EngineType.RPG_MZ,
            EngineType.VN,
            EngineType.WEB_OTHER -> buildWebIntent(context, path, game, settings)

            EngineType.ARTEMIS -> buildArtemisIntent(context, path, game, patchChoice, settings)

            EngineType.SIGLUS -> buildSiglusIntent(context, path, game, settings)

            EngineType.REALLIVE,
            EngineType.AVG32,
            EngineType.UK2 -> buildFramebufferIntent(context, path, game, settings)

            EngineType.XSYS35 -> buildXs35Intent(context, path, game, settings)

            EngineType.XSYS4 -> buildXs4Intent(context, path, game, settings)
            EngineType.SYSTEMNNN -> SystemNnnHost.createLaunchIntent(context, File(path), game.title).apply {
                // The engine keeps no copy identity; pass the original directory as the legacy key.
                SystemNnnGameDirectory.resolve(game.uri)?.absolutePath?.let {
                    putExtra(LaunchContract.RUNTIME_MODULE_SOURCE_IDENTITY_PATH, it)
                }
            }

            EngineType.FVP -> buildFvpIntent(context, path, game, settings)
            EngineType.ETHORNELL -> buildEthornellIntent(context, path, game, settings)
            EngineType.IMPACTO -> {
                val prepared = requireNotNull(impacto) { "impacto requires a prepared private launch" }
                Intent(context, ImpactoActivity::class.java).apply {
                    putExtra(LaunchContract.PATH, path)
                    putExtra(LaunchContract.ROOT_URI, game.uri)
                    putExtra(LaunchContract.IMPACTO_PROFILE, prepared.profileId)
                    putExtra(LaunchContract.IMPACTO_LAUNCH_DIR, prepared.launchDirectory.absolutePath)
                }
            }
            EngineType.CMVS -> buildCmvsIntent(context, path, game)

            EngineType.RPGMAKER,
            EngineType.RENPY,
            EngineType.RUFFLE -> error("${engine.displayName} is handled by external engine launcher")

            EngineType.RUNTIME_MODULE -> error("${engine.displayName} is handled by RuntimeModuleLauncher")

            // YURIS / CatSystem2 / PC 由外置 Winlator 承载，在 launchInternalChecked 前置分流，不会走到这里
            EngineType.YURIS,
            EngineType.CATSYSTEM2,
            EngineType.PC -> error("${engine.displayName} is handled by ExternalEmulatorLauncher")

            // PSP / Switch 由外置模拟器跳转承载，在 launchInternalChecked 前置分流，不会走到这里
            EngineType.PSP,
            EngineType.NINTENDO_SWITCH -> error("${engine.displayName} is handled by ExternalEmulatorLauncher")

            // 手动添加的安卓应用按包名直接跳转，在 launchInternalChecked 前置分流，不会走到这里
            EngineType.ANDROID_APP -> error("${engine.displayName} is handled by Android app launch")

            EngineType.UNKNOWN -> Intent(context, TyranoActivity::class.java).apply {
                putExtra(LaunchContract.PATH, path)
                putExtra(LaunchContract.GAME_PATH, path)
                putExtra(LaunchContract.ROOT_URI, game.uri)
                putExtra(LaunchContract.LAUNCH_TARGET, game.launchTarget)
                putExtra(LaunchContract.TYPE, "Tyrano")
                // 输入重映射的逐游戏开关按 gameId 查询；不传会让宿主回落到目录路径，
                // 与本游戏的单游戏设置（键为 uri）对不上而始终取全局值
                putExtra(LaunchContract.RPG_MAKER_MOD_GAME_ID, game.uri)
            }
        }
        if (!intent.hasExtra(LaunchContract.GRAPHICS_FILTER_CHAIN)) intent.putDisabledGraphicsRequest()
        intent.putExtra(LaunchContract.UI_LANGUAGE_TAG, AppLocaleController.engineUiLanguageTag(context))
        // 注入 App 统一主题色与深浅色：引擎壳自绘 UI（确认/输入弹窗按钮等）经
        // EngineThemeColors.fromIntent / KrDialogStyle 读取，缺失时回落默认绿。
        // 主题色来自 ui 层写入的纯数据快照（ThemeColorPayloadStore），core 不反向依赖 theme。
        val theme = ThemeColorPayloadStore.current ?: ThemeColorPayload.DEFAULT
        intent.putExtra(LaunchContract.DARK_MODE, theme.darkMode)
        intent.putExtra(LaunchContract.PRIMARY_COLOR, theme.primaryArgb)
        intent.putExtra(LaunchContract.THEME_COLOR_PRIMARY, theme.primaryArgb)
        intent.putExtra(LaunchContract.THEME_COLOR_ON_PRIMARY, theme.onPrimaryArgb)
        intent.putExtra(LaunchContract.THEME_COLOR_CARD, theme.cardArgb)
        intent.putExtra(LaunchContract.THEME_COLOR_TEXT, theme.textArgb)
        intent.putExtra(LaunchContract.THEME_COLOR_TEXT_MUTED, theme.mutedArgb)
        return intent
    }

    /** Reject unsupported hardware and source-only builds before requesting game storage access. */
    private fun impactoEnvironmentFailure(context: Context): ImpactoPrepareError? {
        val gles = context.getSystemService(ActivityManager::class.java)?.deviceConfigurationInfo?.reqGlEsVersion
        ImpactoPreflight.check(Build.VERSION.SDK_INT, Build.SUPPORTED_ABIS.toList(), gles)?.let { return it }
        return if (ImpactoLaunchPreparation.isRuntimeBundled(context)) null else ImpactoPrepareError.RUNTIME
    }

    /** Resource installation and private launch admission never modify the original game directory. */
    private suspend fun launchImpacto(
        context: Context,
        game: ScanGame,
        path: String,
        settings: ResolvedEngineSettings,
        onDispatched: () -> Unit,
    ): LaunchResult {
        val descriptor = ImpactoDescriptor.read(File(path))
            ?: return LaunchResult.Failure.ImpactoPrepareFailed(ImpactoPrepareError.DESCRIPTOR)
        val prepared = try {
            prepareImpactoAfterRuntime(
                ensureRuntime = {
                    NativeRuntimePack.ensure(context.applicationContext, NativeRuntimePack.PACK_IMPACTO)
                },
                prepare = {
                    ImpactoLaunchPreparation.prepare(context, File(path).canonicalFile, game.uri, descriptor.profile)
                },
            ) ?: return LaunchResult.Failure.EngineLibraryPackFailed(NativeRuntimePack.PACK_IMPACTO)
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (failure: ImpactoPreparationException) {
            val reason = when (failure.reason) {
                ImpactoPreparationException.Reason.INVALID_PROFILE -> ImpactoPrepareError.PROFILE
                ImpactoPreparationException.Reason.GAME_LAYOUT -> ImpactoPrepareError.GAME_LAYOUT
                ImpactoPreparationException.Reason.RESOURCES -> ImpactoPrepareError.RESOURCES
                ImpactoPreparationException.Reason.USER_DATA -> ImpactoPrepareError.USER_DATA
                ImpactoPreparationException.Reason.SESSION_BUSY -> ImpactoPrepareError.SESSION_BUSY
                ImpactoPreparationException.Reason.PREPARATION -> ImpactoPrepareError.PREPARATION
            }
            Log.w(TAG, "impacto preparation failed reason=$reason", failure)
            return LaunchResult.Failure.ImpactoPrepareFailed(reason)
        } catch (failure: Exception) {
            Log.w(TAG, "impacto preparation failed", failure)
            return LaunchResult.Failure.ImpactoPrepareFailed(ImpactoPrepareError.PREPARATION)
        }
        try {
            currentCoroutineContext().ensureActive()
            // Slow installation is already complete; keep the remaining leased handoff bounded.
            // Do not dispatch a different profile if the declaration changed during preparation.
            if (ImpactoDescriptor.read(File(path)) != descriptor) {
                return LaunchResult.Failure.ImpactoPrepareFailed(ImpactoPrepareError.DESCRIPTOR)
            }
            val intent = buildIntent(
                context, EngineType.IMPACTO, File(path).canonicalPath, game,
                settings = settings, impacto = prepared,
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            currentCoroutineContext().ensureActive()
            context.startActivity(intent)
            prepared.markDispatched()
            return completeLaunch(context, game, onDispatched)
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (failure: Exception) {
            Log.w(TAG, "impacto dispatch failed", failure)
            return LaunchResult.Failure.StartFailed(null)
        } finally {
            // Revokes only an unclaimed, undispatched preparation. A dispatched host owns its lease.
            runCatching { prepared.close() }.onFailure { Log.w(TAG, "impacto launch cleanup failed", it) }
        }
    }

    /**
     * 手动添加的安卓游戏：按 `launchTarget` 承载的包名取启动 Intent 直接跳转；
     * 未安装 / 无启动入口 / 启动入口失效 → [LaunchResult.Failure.AndroidAppMissing]。
     * 与内置引擎路径同语义：启动前确认未取消，取消原样传播；最近记录失败不影响启动结果。
     */
    private suspend fun launchAndroidApp(context: Context, game: ScanGame): LaunchResult {
        val packageName = AndroidAppGames.packageNameOf(game)
            ?: return LaunchResult.Failure.AndroidAppMissing
        // PackageManager 查询本身也可能抛 binder 异常，统一折叠为「应用不可用」
        val intent = runCatching { context.packageManager.getLaunchIntentForPackage(packageName) }
            .getOrNull()
            ?: return LaunchResult.Failure.AndroidAppMissing
        return try {
            currentCoroutineContext().ensureActive()
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            intent.putDisabledGraphicsRequest()
            context.startActivity(intent)
            // 应用已拉起即成功；最近记录写失败不改变启动结果（独立兜底）
            runCatching { GameLibraryFacade.recordRecentGame(context, game) }
                .onFailure { Log.w(TAG, "record recent android app failed uri=${game.uri}", it) }
            LaunchResult.Success
        } catch (ce: CancellationException) {
            throw ce
        } catch (e: ActivityNotFoundException) {
            // 解析后应用被卸载/入口被移除的竞态
            LaunchResult.Failure.AndroidAppMissing
        } catch (e: SecurityException) {
            // 应用被禁用等可见性变化
            LaunchResult.Failure.AndroidAppMissing
        } catch (e: Exception) {
            LaunchResult.Failure.StartFailed(e.message)
        }
    }

    /**
     * Windows 游戏（YU-RIS / 手动添加的 PC）经外置 Winlator 启动：解析游戏目录真实路径 →
     * 解析主 exe（`launchFile` 优先）→ 交给 Winlator 挂载目录（自动空闲盘符）并按相对文件名启动。
     * 运行参数由 Winlator 管理，主 App 只负责识别与跳转。
     */
    private suspend fun launchWindowsViaWinlator(
        context: Context,
        game: ScanGame,
        target: ExternalEmulatorTarget,
        onDispatched: () -> Unit,
    ): LaunchResult {
        val path = resolveGameDirectory(context, game) ?: return LaunchResult.Failure.GameDirUnresolved
        requestAllFilesAccessIfNeeded(context, game, path)?.let { return it }
        val exeName = YurisLaunchFiles.resolveExeName(game, path)
            ?: return LaunchResult.Failure.YurisExeMissing
        currentCoroutineContext().ensureActive()
        val winlator = EngineSettingsResolver.resolve(context, game, path).winlator
        val result = ExternalEmulatorLauncher.launchWinlator(
            context = context,
            target = target,
            dirPath = path,
            exeName = exeName,
            launchId = game.uri,
            options = WinlatorContract.LaunchOptions(
                containerId = winlator.containerId,
                containerName = winlator.containerName,
                graphicsDriver = winlator.graphicsDriver,
                dxwrapper = winlator.dxwrapper,
                screenSize = winlator.screenSize,
                lcAll = winlator.lcAll,
                tz = winlator.tz,
                box64Preset = winlator.box64Preset,
                save = winlator.save,
            ),
        )
        if (result.success) {
            return completeLaunch(context, game, onDispatched)
        }
        return LaunchResult.Failure.ExternalEmulatorFailed(result)
    }

    /**
     * Siglus 启动：真实路径 + 语言覆盖 + 标题回写定位哈希。
     * 存档目录由引擎固定为 `<游戏根>/savedata`（一期不支持独立存档）。
     */
    private fun buildSiglusIntent(
        context: Context,
        path: String,
        game: ScanGame,
        settings: ResolvedEngineSettings,
    ): Intent = Intent(context, SiglusActivity::class.java).apply {
        putGraphicsSettings(settings.siglusGraphics, GraphicsCapabilities.forRuntime(GraphicsFamily.SIGLUS))
        putExtra(LaunchContract.PATH, path)
        putExtra(LaunchContract.GAME_PATH, path)
        putExtra(LaunchContract.PROJECT_ROOT, path)
        putExtra(LaunchContract.GAME_DIR, path)
        putExtra(LaunchContract.ROOT_URI, game.uri)
        putExtra(LaunchContract.LAUNCH_TARGET, game.launchTarget)
        putExtra(LaunchContract.LAUNCH_MODE, LaunchContract.LAUNCH_MODE_SIGLUS)
        val language = settings.siglusLanguage
        if (!language.isNullOrBlank() && language != EngineSettingsStore.SIGLUS_LANGUAGE_AUTO) {
            putExtra(LaunchContract.SIGLUS_LANGUAGE, language)
        }
        val pathHash = Integer.toHexString(path.hashCode())
        putExtra(LaunchContract.SIGLUS_PATH_HASH, pathHash)
        // 标题回写登记：宿主写 GAMENAME，app 侧导入时需要 uri 与目录名（判断是否用户改过名）
        context.applicationContext
            .getSharedPreferences(EnginePrefs.APP_PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(EnginePrefs.KEY_SIGLUS_URI_PREFIX + pathHash, game.uri)
            .putString(EnginePrefs.KEY_SIGLUS_DEFAULT_TITLE_PREFIX + pathHash, File(path).name)
            .apply()
    }

    /**
     * RealLive / AVG32 / UK2 启动：真实路径 + 引擎 id + 文本编码。
     * 存档目录由引擎固定写入游戏目录（AVG32 = `SAVE.INI`；RealLive = `savedata_rs`；
     * UK2 = `FLAGnn.DAT`），一期不支持独立存档。
     */
    private fun buildFramebufferIntent(
        context: Context,
        path: String,
        game: ScanGame,
        settings: ResolvedEngineSettings,
    ): Intent = Intent(context, FramebufferGameActivity::class.java).apply {
        putExtra(LaunchContract.PATH, path)
        putExtra(LaunchContract.GAME_PATH, path)
        putExtra(LaunchContract.PROJECT_ROOT, path)
        putExtra(LaunchContract.GAME_DIR, path)
        putExtra(LaunchContract.ROOT_URI, game.uri)
        putExtra(LaunchContract.LAUNCH_TARGET, game.launchTarget)
        putExtra(LaunchContract.LAUNCH_MODE, LaunchContract.LAUNCH_MODE_FRAMEBUFFER)
        putExtra(LaunchContract.GAMES_ENGINE, framebufferEngineId(game.engine))
        val nls = settings.fbNls
        if (nls.isNotBlank() && nls != EngineSettingsStore.FB_NLS_AUTO) {
            putExtra(LaunchContract.GAMES_NLS, nls)
        }
        putExtra(LaunchContract.GAMES_TITLE, game.title)
    }

    /** EngineType → 上游 `game_fb_open` 的 engine id（未知/歧义时交给引擎按内容自动探测）。 */
    private fun framebufferEngineId(engine: EngineType): String? = when (engine) {
        EngineType.REALLIVE -> "reallive"
        EngineType.AVG32 -> "avg32"
        EngineType.UK2 -> "uk2"
        else -> null
    }

    /** Restore a live task without re-reading changed settings/resources or sending a new game payload. */
    private fun restoreEthornell(context: Context, game: ScanGame): LaunchResult {
        return try {
            val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            val task = manager?.appTasks?.firstOrNull { candidate ->
                val base = candidate.taskInfo?.baseIntent ?: return@firstOrNull false
                base.component?.packageName == context.packageName &&
                    base.component?.className == "com.core.ethornell.EthornellActivity" &&
                    base.getStringExtra(LaunchContract.ROOT_URI) == game.uri
            } ?: return LaunchResult.Failure.EthornellPrepareFailed(EthornellPrepareError.SESSION_BUSY)
            // moveToFront cannot create a new Activity or deliver a mismatched onNewIntent payload.
            task.moveToFront()
            runCatching { GameLibraryFacade.recordRecentGame(context, game) }
            LaunchResult.Success
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (error: Exception) {
            LaunchResult.Failure.StartFailed(error.message)
        }
    }

    /** Ethornell preflight never writes to the resource root or guesses a save subdirectory. */
    private fun ethornellStorageRoot(path: String): File? {
        val primaryRoot = PrimaryStorageRoot.get()
        if (path == primaryRoot || path.startsWith("$primaryRoot/")) return File(primaryRoot)
        if (path == "/storage/emulated/0" || path.startsWith("/storage/emulated/0/")) return File("/storage/emulated/0")
        if (!path.startsWith("/storage/")) return null
        val volume = path.removePrefix("/storage/").substringBefore('/')
        if (!Regex("[A-Za-z0-9_-]+").matches(volume)) return null
        return File("/storage/$volume")
    }

    private fun prepareEthornell(
        context: Context, game: ScanGame, path: String, settings: ResolvedEngineSettings,
    ): LaunchResult.Failure? {
        fun failed(error: EthornellPrepareError) = LaunchResult.Failure.EthornellPrepareFailed(error)
        var stage = EthornellPrepareError.RESOURCE_ROOT
        return try {
            val root = File(path).canonicalFile
            if (Uri.parse(game.uri).scheme == "content") {
                val allowed = ethornellStorageRoot(path)?.canonicalFile ?: return failed(EthornellPrepareError.RESOURCE_ROOT)
                if (!root.toPath().startsWith(allowed.toPath())) return failed(EthornellPrepareError.RESOURCE_ROOT)
            }
            if (!root.isDirectory || !root.canRead()) return failed(EthornellPrepareError.RESOURCE_ROOT)
            if (EngineScanner.detectEngine(root).engine != EngineType.ETHORNELL) return failed(EthornellPrepareError.BOOTSTRAP)
            stage = EthornellPrepareError.FONT
            if (EthornellPaths.validatedFont(context.filesDir, settings.ethornellFont) == null) {
                return failed(EthornellPrepareError.FONT)
            }
            stage = EthornellPrepareError.USER_DATA
            com.tyranor.next.core.game.save.EthornellSaveStore(context.filesDir, game.uri).recoverForLaunch()
            val dir = EthornellPaths.userDataDir(context.filesDir, game.uri)
            EthornellPaths.validateUserDataDir(context.filesDir, game.uri, dir.absolutePath)
            if ((!dir.isDirectory && !dir.mkdirs()) || !dir.canWrite() ||
                !dir.canonicalFile.toPath().startsWith(context.filesDir.canonicalFile.toPath())) {
                return failed(EthornellPrepareError.USER_DATA)
            }
            null
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: java.io.IOException) {
            failed(stage)
        } catch (_: SecurityException) {
            failed(stage)
        }
    }

    private var cmvsLaunchToken: String? = null

    private fun buildCmvsIntent(
        context: Context,
        path: String,
        game: ScanGame,
    ): Intent = Intent(context, CmvsActivity::class.java).apply {
        putExtra(LaunchContract.PATH, path)
        putExtra(LaunchContract.GAME_PATH, path)
        putExtra(LaunchContract.PROJECT_ROOT, path)
        putExtra(LaunchContract.GAME_DIR, path)
        putExtra(LaunchContract.ROOT_URI, game.uri)
        putExtra(LaunchContract.LAUNCH_TARGET, game.launchTarget)
        putExtra(LaunchContract.LAUNCH_MODE, LaunchContract.LAUNCH_MODE_CMVS)
        cmvsLaunchToken?.let { putExtra(LaunchContract.CMVS_LAUNCH_TOKEN, it) }
    }

    private fun buildEthornellIntent(
        context: Context, path: String, game: ScanGame, settings: ResolvedEngineSettings,
    ): Intent = Intent().setClassName(context, "com.core.ethornell.EthornellActivity").apply {
        putExtra(LaunchContract.PATH, File(path).canonicalPath)
        putExtra(LaunchContract.GAME_PATH, File(path).canonicalPath)
        putExtra(LaunchContract.ROOT_URI, game.uri)
        putExtra(LaunchContract.LAUNCH_MODE, LaunchContract.LAUNCH_MODE_ETHORNELL)
        putExtra(LaunchContract.ETHORNELL_NLS, settings.ethornellNls)
        putExtra(LaunchContract.ETHORNELL_FONT_PATH, EthornellPaths.validatedFont(context.filesDir, settings.ethornellFont))
        putExtra(LaunchContract.ETHORNELL_USER_DATA_DIR, EthornellPaths.userDataDir(context.filesDir, game.uri).absolutePath)
        putExtra(LaunchContract.UI_LANGUAGE_TAG, com.tyranor.next.core.i18n.AppLocaleController.wrap(context).resources.configuration.locales[0].toLanguageTag())
    }

    /** FVP uses its own fixed `<resource root>/save` protocol. */
    private fun buildFvpIntent(
        context: Context,
        path: String,
        game: ScanGame,
        settings: ResolvedEngineSettings,
    ): Intent = Intent(context, FvpActivity::class.java).apply {
        putExtra(LaunchContract.PATH, path)
        putExtra(LaunchContract.GAME_PATH, path)
        putExtra(LaunchContract.PROJECT_ROOT, path)
        putExtra(LaunchContract.GAME_DIR, path)
        putExtra(LaunchContract.ROOT_URI, game.uri)
        putExtra(LaunchContract.LAUNCH_TARGET, game.launchTarget)
        putExtra(LaunchContract.LAUNCH_MODE, LaunchContract.LAUNCH_MODE_FVP)
        putExtra(LaunchContract.FVP_NLS, settings.fvpNls)
        putExtra(LaunchContract.FVP_SYSTEM_FONT, settings.fvpSystemFont)
        putExtra(LaunchContract.FVP_TEXT_HIDPI, settings.fvpTextHidpi)
        if (settings.fvpFont.isNotBlank()) {
            putExtra(LaunchContract.FVP_FONT_PATH, settings.fvpFont)
        }
    }

    /**
     * System35（xsystem35）启动：`-gamedir` 指向含场景档的实际游戏目录（普通形态 = 游戏根，
     * `GAMEDATA/` 形态 = 该子目录），存档目录按「独立存档」生效值解析（与存档镜像同源，
     * 见 [Xs35Paths.scopedSaveDir] / [Xs35Paths.gameDirSaveDir]）。
     * 标题回写登记复用 Siglus 协议：宿主写 `xsys35_title.<pathHash>`，库加载时条件导入。
     */
    private fun buildXs35Intent(
        context: Context,
        path: String,
        game: ScanGame,
        settings: ResolvedEngineSettings,
    ): Intent {
        val effectiveDir = Xs35Paths.effectiveGameDir(File(path))
        // ensureXs35SaveDir 已在上游保证独立存档开启时外部存储可用；此处为不可达分支：
        // 不复用 filesDir 兜底（审核 1-S1/2-S4/3-IMPORTANT-3），由 launch 外层 try/catch 收口为 StartFailed。
        val saveDir = resolveXs35SaveDir(context, path, settings)
            ?: throw IllegalStateException("xs35 scoped save dir unavailable after ensure")
        val pathHash = Integer.toHexString(path.hashCode())
        // 标题回写登记：宿主按同一 hash 写标题，app 侧导入时需要 uri 与目录名（判断是否用户改过名）
        context.applicationContext
            .getSharedPreferences(EnginePrefs.APP_PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(EnginePrefs.KEY_XSYS35_URI_PREFIX + pathHash, game.uri)
            .putString(EnginePrefs.KEY_XSYS35_DEFAULT_TITLE_PREFIX + pathHash, File(path).name)
            .apply()
        return Intent(context, Xs35Activity::class.java).apply {
            putExtra(LaunchContract.PATH, effectiveDir.absolutePath)
            putExtra(LaunchContract.GAME_PATH, effectiveDir.absolutePath)
            putExtra(LaunchContract.PROJECT_ROOT, effectiveDir.absolutePath)
            putExtra(LaunchContract.GAME_DIR, effectiveDir.absolutePath)
            putExtra(LaunchContract.ROOT_URI, game.uri)
            putExtra(LaunchContract.LAUNCH_TARGET, game.launchTarget)
            putExtra(LaunchContract.LAUNCH_MODE, LaunchContract.LAUNCH_MODE_XSYS35)
            putExtra(LaunchContract.XS35_PATH_HASH, pathHash)
            putExtra(LaunchContract.XS35_SAVE_DIR, saveDir.absolutePath)
            putExtra(LaunchContract.XS35_SCOPED_SAVE_DIR, settings.xs35ScopedSaveDir)
            if (settings.xs35Renderer != EngineSettingsStore.XSYS35_RENDERER_AUTO) {
                putExtra(LaunchContract.XS35_RENDERER, settings.xs35Renderer)
            }
            putExtra(LaunchContract.XS35_INTEGER_SCALE, settings.xs35IntegerScale)
            putExtra(LaunchContract.XS35_MUTE_UNFOCUS, settings.xs35MuteUnfocus)
            // 契约保留（对齐 krkrsdl3）：XSys35 宿主朝向由 manifest 的 sensorLandscape 固定，
            // 不消费该 extra；下发仅为统一启动契约形态。
            putExtra(LaunchContract.ORIENTATION, 6)
        }
    }

    /**
     * System35 生效存档目录（与 [ensureXs35SaveDir]、`GameSaveManager.resolveSaveLocation` 同源，
     * 推导只在 [Xs35Paths]）：独立存档开 = 外部存档目录，外部存储不可用返回 null（调用方按
     * 类型化失败处理，绝不回退游戏根）；关闭 = `<生效游戏目录>/save`。
     */
    private fun resolveXs35SaveDir(context: Context, path: String, settings: ResolvedEngineSettings): File? {
        if (settings.xs35ScopedSaveDir) {
            val external = context.getExternalFilesDir(null) ?: return null
            return Xs35Paths.scopedSaveDir(external, path)
        }
        return Xs35Paths.gameDirSaveDir(Xs35Paths.effectiveGameDir(File(path)))
    }

    /**
     * System35 存档目录预创建（仿 [ensureKrSaveDir]，**不回退游戏根**）：
     * 独立存档开（默认）= 应用外部存档目录，外部存储不可用即类型化失败（path = null）；
     * 关闭 = `<生效游戏目录>/save`（`GAMEDATA/` 形态即该子目录内）。
     */
    private fun ensureXs35SaveDir(
        context: Context,
        path: String,
        settings: ResolvedEngineSettings,
    ): LaunchResult.Failure? {
        val saveDir = resolveXs35SaveDir(context, path, settings)
            ?: return LaunchResult.Failure.Xs35SaveDirUnavailable(path = null)
        if (saveDir.isDirectory) return null
        if (saveDir.exists()) return LaunchResult.Failure.Xs35SavePathNotDirectory(saveDir.absolutePath)
        if (saveDir.mkdirs() || saveDir.isDirectory) return null
        return LaunchResult.Failure.Xs35SaveDirUnavailable(saveDir.absolutePath)
    }

    /**
     * System4（xsystem4）启动：游戏根经 PATH 系列下发，入口 ini 由宿主大小写不敏感解析（见 `Xs4Paths.resolveIniFile`）；
     * 存档目录按「独立存档」生效值解析（与存档镜像同源，推导只在 [Xs4Paths]）；
     * 字体仅下发用户设置且存在的绝对路径，内置映射（按编码）由 engine 侧 `Xs4Fonts` 负责。
     */
    private fun buildXs4Intent(
        context: Context,
        path: String,
        game: ScanGame,
        settings: ResolvedEngineSettings,
    ): Intent {
        // ensureXs4SaveDir 已在上游保证独立存档开启时外部存储可用；此处为不可达分支：
        // 不复用游戏根兜底，由 launch 外层 try/catch 收口为 StartFailed。
        val saveDir = resolveXs4SaveDir(context, path, settings)
            ?: throw IllegalStateException("xs4 scoped save dir unavailable after ensure")
        return Intent(context, Xs4Activity::class.java).apply {
            putExtra(LaunchContract.PATH, path)
            putExtra(LaunchContract.GAME_PATH, path)
            putExtra(LaunchContract.PROJECT_ROOT, path)
            putExtra(LaunchContract.GAME_DIR, path)
            putExtra(LaunchContract.ROOT_URI, game.uri)
            putExtra(LaunchContract.LAUNCH_TARGET, game.launchTarget)
            putExtra(LaunchContract.LAUNCH_MODE, LaunchContract.LAUNCH_MODE_XSYS4)
            putExtra(LaunchContract.XS4_SAVE_DIR, saveDir.absolutePath)
            putExtra(LaunchContract.XS4_SCOPED_SAVE_DIR, settings.xs4ScopedSaveDir)
            putExtra(LaunchContract.XS4_ENCODING, settings.xs4Encoding)
            xs4CustomFontPath(settings.xs4FontGothicPath)?.let { putExtra(LaunchContract.XS4_FONT_GOTHIC_PATH, it) }
            xs4CustomFontPath(settings.xs4FontMinchoPath)?.let { putExtra(LaunchContract.XS4_FONT_MINCHO_PATH, it) }
            if (settings.xs4Joypad != EngineSettingsStore.XSYS4_JOYPAD_AUTO) {
                putExtra(LaunchContract.XS4_JOYPAD, settings.xs4Joypad)
            }
            if (settings.xs4MsgskipDelay > 0) {
                putExtra(LaunchContract.XS4_MSGSKIP_DELAY, settings.xs4MsgskipDelay)
            }
            // 契约保留（对齐 System35）：朝向由 manifest 的 sensorLandscape 固定，不消费该 extra。
            putExtra(LaunchContract.ORIENTATION, 6)
        }
    }

    /** System4 自定义字体：仅用户设置了路径且文件存在时下发；否则宿主回落内置映射。 */
    private fun xs4CustomFontPath(raw: String): String? =
        raw.takeIf { it.isNotBlank() && File(it).isFile }

    /**
     * System4 生效存档目录（与 [ensureXs4SaveDir]、`GameSaveManager.resolveSaveLocation` 同源，
     * 推导只在 [Xs4Paths]）：独立存档开 = 外部存档目录，外部存储不可用返回 null（调用方按
     * 类型化失败处理，绝不回退游戏根）；关闭 = `<游戏根>/<SaveFolder>`。
     */
    private fun resolveXs4SaveDir(context: Context, path: String, settings: ResolvedEngineSettings): File? {
        if (settings.xs4ScopedSaveDir) {
            val external = context.getExternalFilesDir(null) ?: return null
            return Xs4Paths.scopedSaveDir(external, path)
        }
        return Xs4Paths.gameDirSaveDir(File(path))
    }

    /** System4 启动预检（IO 线程）：入口 ini 大小写不敏感查找 + GLES 3.0；判定见 [Xs4Preflight]。 */
    private fun preflightXs4(context: Context, path: String): LaunchResult.Failure? {
        val reqGlEsVersion = context.getSystemService(ActivityManager::class.java)
            ?.deviceConfigurationInfo?.reqGlEsVersion
        return Xs4Preflight.check(
            iniFound = Xs4Paths.resolveIniFile(File(path)) != null,
            reqGlEsVersion = reqGlEsVersion,
        )
    }

    /**
     * System4 存档目录预创建（仿 [ensureXs35SaveDir]，**不回退游戏根**）：
     * 独立存档开（默认）= 应用外部存档目录，外部存储不可用即类型化失败（path = null）；
     * 关闭 = `<游戏根>/<SaveFolder>`。
     */
    private fun ensureXs4SaveDir(
        context: Context,
        path: String,
        settings: ResolvedEngineSettings,
    ): LaunchResult.Failure? {
        val saveDir = resolveXs4SaveDir(context, path, settings)
            ?: return LaunchResult.Failure.Xs4SaveDirUnavailable(path = null)
        if (saveDir.isDirectory) return null
        if (saveDir.exists()) return LaunchResult.Failure.Xs4SavePathNotDirectory(saveDir.absolutePath)
        if (saveDir.mkdirs() || saveDir.isDirectory) return null
        return LaunchResult.Failure.Xs4SaveDirUnavailable(saveDir.absolutePath)
    }

    /**
     * KRKR 启动：按设置页选择的内核（krkrsdl3 / 吉里吉里2）与引擎版本（auto/1.3.9/1.3.4）
     * 路由到对应引擎宿主，并注入字体、独立存档与渲染/内存偏好。
     */
    private fun buildKirikiriIntent(
        context: Context,
        path: String,
        game: ScanGame,
        safMirror: KrSafMirror.Prepared?,
        settings: ResolvedEngineSettings,
    ): Intent {
        val gid = game.uri
        val needsSafFallback = GamePathUtils.isRemovableStoragePath(path)
        val kernel = settings.krKernel
        val skipStartupDialogs = settings.krSkipStartupDialogs
        val engineRoot = safMirror?.mirrorRoot?.absolutePath ?: path
        val pickedLaunchEntry = pickKrActivateEntry(engineRoot, game)
        if (kernel == EngineSettingsStore.KERNEL_KRKRSDL3) {
            val args = buildKrkrsdl3Args(context, path, pickedLaunchEntry, settings)
            Log.i(TAG, "krkrsdl3 launch root=$path entry=$pickedLaunchEntry args=$args")
            // krkrsdl3 内核：gameargs 首项为启动文件绝对路径，后续为 TVP 命令行参数
            return Intent(context, Krkrsdl3Activity::class.java).apply {
                putGraphicsSettings(settings.krGraphics, GraphicsCapabilities.forRuntime(GraphicsFamily.KR, kernel, settings.krEngineVersion, settings.krRenderer))
                putStringArrayListExtra(LaunchContract.GAME_ARGS, args)
                putExtra(LaunchContract.PATH, path)
                putExtra(LaunchContract.GAME_PATH, pickedLaunchEntry)
                putExtra(LaunchContract.PROJECT_ROOT, path)
                putExtra(LaunchContract.GAME_DIR, path)
                putExtra(LaunchContract.ROOT_URI, game.uri)
                putExtra(LaunchContract.LAUNCH_TARGET, game.launchTarget)
                putExtra(LaunchContract.LAUNCH_MODE, LaunchContract.LAUNCH_MODE_KRKRSDL3)
                putExtra(KrkrStartupDialogPolicy.EXTRA_ENABLED, skipStartupDialogs)
                putExtra(LaunchContract.ORIENTATION, 6)
                putExtra(LaunchContract.FOCUS, "true")
            }
        }
        val version = settings.krEngineVersion
        val activity = when (version) {
            EngineSettingsStore.KR_134 -> Kirikiroid134::class.java
            else -> Kirikiroid139::class.java
        }
        val launchEntry = pickedLaunchEntry
        val scoped = settings.krScopedSaveDir
        val actualSaveRoot = safMirror?.let { File(it.mirrorRoot, "savedata") }
            ?: resolveKrSaveDir(context, path, kernel, scoped)
        val effectiveScoped = scoped || safMirror != null
        val defaultFont = settings.krDefaultFont
        val forceFont = settings.krForceDefaultFont
        val mirrorOverlayReader = if (settings.krPatchOverlayMode == EngineSettingsStore.KR_PATCH_OVERLAY_OFF) {
            null
        } else {
            safMirror?.let { createKrMirrorOverlayReader(context, it) }
        }
        val patchOverlay = prepareKrPatchOverlay(context, engineRoot, settings.krPatchOverlayMode, mirrorOverlayReader, isMirror = safMirror != null)
        val steamConfigOverlay = prepareKrSteamConfigOverlay(context, engineRoot, settings.krPatchOverlayMode, mirrorOverlayReader)
        return Intent(context, activity).apply {
            // KR2 引擎把 path 视为“启动条目”，gamedir = path 的父目录。
            putExtra(LaunchContract.PATH, launchEntry)
            putExtra(LaunchContract.GAME_PATH, launchEntry)
            putExtra(LaunchContract.PROJECT_ROOT, engineRoot)
            putExtra(LaunchContract.GAME_DIR, engineRoot)
            putExtra(LaunchContract.ORIGINAL_PROJECT_ROOT, path)
            putExtra(LaunchContract.GAME_SAVE_ROOT, actualSaveRoot.absolutePath)
            putExtra(LaunchContract.ROOT_URI, game.uri)
            putExtra(LaunchContract.LAUNCH_TARGET, game.launchTarget)
            putExtra(LaunchContract.LAUNCH_MODE, LaunchContract.LAUNCH_MODE_KIRIKIROID2)
            putExtra(KrkrStartupDialogPolicy.EXTRA_ENABLED, skipStartupDialogs)
            putExtra(LaunchContract.SAF_FILE_FALLBACK, needsSafFallback)
            patchOverlay?.let {
                putExtra(LaunchContract.KR_PATCH_OVERLAY_TARGET, it.targetPatch.absolutePath)
                putExtra(LaunchContract.KR_PATCH_OVERLAY_PATH, it.overlayPatch.absolutePath)
                putExtra(LaunchContract.KR_PATCH_OVERLAY_MODE, it.mode)
            }
            steamConfigOverlay?.let {
                putExtra(LaunchContract.KR_STEAM_CONFIG_OVERLAY_TARGET, it.targetConfig.absolutePath)
                putExtra(LaunchContract.KR_STEAM_CONFIG_OVERLAY_PATH, it.overlayConfig.absolutePath)
            }
            safMirror?.let {
                putExtra(LaunchContract.BASE_DOC, game.uri)
                putExtra(LaunchContract.SAF_MIRROR_ROOT, it.mirrorRoot.absolutePath)
                putExtra(LaunchContract.SAF_MIRROR_INDEX, it.indexFile.absolutePath)
                putExtra(LaunchContract.SAF_MIRROR_FILES, it.fileCount)
                // 诊断汇总由 engine 侧 prepare 输出一次（审查第十轮 #21），不再重复打印
            }
            putExtra(LaunchContract.ORIENTATION, 6)
            putExtra(LaunchContract.SCOPED_SAVE_DIR, effectiveScoped)
            if (effectiveScoped) {
                putExtra(LaunchContract.SCOPED_SAVE_ROOT, actualSaveRoot.absolutePath)
            }
            putExtra(LaunchContract.FOCUS, "true")
            // 引擎版本
            putExtra(LaunchContract.KR_ENGINE_VERSION, when (version) {
                EngineSettingsStore.KR_134 -> "1.3.4"
                else -> "1.3.9"
            })
            // 字体偏好：两个 extra 必须无条件注入。引擎侧 applyFontPreferences 仅在
            // hasExtra 时执行写入/按所有权标记清理——若仅在非空/为真时注入，用户关闭
            // 强制或清空字体后引擎 XML 里的旧值会永久残留（issue #74「换字体无法生效」
            // 的根因：残留的 force_default_font=1 一直压住新设置的字体）。
            putExtra(LaunchContract.DEFAULT_FONT, defaultFont)
            putExtra(LaunchContract.FORCE_DEFAULT_FONT, forceFont)
            putGraphicsSettings(settings.krGraphics, GraphicsCapabilities.forRuntime(GraphicsFamily.KR, kernel, settings.krEngineVersion, settings.krRenderer))
            // 渲染/内存偏好 JSON：单游戏覆盖 与 全局 逐键合并；字段映射由 KrRenderPrefs 单一来源提供
            runCatching {
                putExtra(LaunchContract.KR_ENGINE_PREFS, EngineSettingsStore.buildKrEnginePrefsJson(context) { pref ->
                    PerGameSettingsStore.getStr(context, gid, pref.overrideField)?.trim()
                })
            }.onFailure { android.util.Log.w("EngineLauncher", "build krkr_engine_prefs failed", it) }
        }
    }

    private fun buildKrkrsdl3Args(
        context: Context,
        path: String,
        launchEntry: String,
        settings: ResolvedEngineSettings,
    ): ArrayList<String> {
        val args = arrayListOf(launchEntry)
        args.add("-render=${normalizeKrkrsdl3Renderer(settings.krRenderer)}")
        val saveDir = resolveKrSaveDir(context, path, EngineSettingsStore.KERNEL_KRKRSDL3, settings.krScopedSaveDir)
        if (saveDir.exists() || saveDir.mkdirs()) {
            args.add("-savedir=${saveDir.absolutePath}")
        }
        return args
    }

    private fun resolveKrSaveDir(context: Context, path: String, kernel: String, scoped: Boolean): File {
        if (!scoped) return File(path, "savedata")
        return if (kernel == EngineSettingsStore.KERNEL_KRKRSDL3) {
            val baseDir = context.getExternalFilesDir(null) ?: context.filesDir
            File(File(baseDir, "save"), GamePathUtils.safeSaveName(path))
        } else {
            File(File(File(context.filesDir, "krkr_mirror"), GamePathUtils.safeSaveName(path)), "savedata")
        }
    }

    private fun ensureKrSaveDir(
        context: Context,
        game: ScanGame,
        path: String,
        settings: ResolvedEngineSettings,
    ): LaunchResult.Failure? {
        val scoped = settings.krScopedSaveDir
        val kernel = settings.krKernel
        val saveDir = resolveKrSaveDir(context, path, kernel, scoped)
        if (saveDir.isDirectory) return null
        if (saveDir.exists()) return LaunchResult.Failure.KrkrSavePathNotDirectory(saveDir.absolutePath)
        if (saveDir.mkdirs() || saveDir.isDirectory) return null
        if (!scoped && ensureKrGameSaveDirViaSaf(context, game, path)) return null
        return LaunchResult.Failure.KrkrSaveDirUnavailable(saveDir.absolutePath, scoped)
    }

    private fun ensureKrGameSaveDirViaSaf(context: Context, game: ScanGame, path: String): Boolean {
        return try {
            val saveDir = DocumentFile.fromTreeUri(context.applicationContext, Uri.parse(game.uri))
                ?.takeIf { it.isDirectory }
                ?.findFile("savedata")
                ?: DocumentFile.fromTreeUri(context.applicationContext, Uri.parse(game.uri))
                    ?.takeIf { it.isDirectory }
                    ?.createDirectory("savedata")
            if (saveDir?.isDirectory == true) return true
            createSafDirectoryForStoragePath(context, "$path/savedata")
        } catch (_: Throwable) {
            createSafDirectoryForStoragePath(context, "$path/savedata")
        }
    }

    private fun createSafDirectoryForStoragePath(context: Context, storagePath: String): Boolean {
        val normalized = storagePath.replace('\\', '/').trimEnd('/')
        val parsed = parseStoragePath(normalized) ?: return false
        val (volume, relative) = parsed
        val resolver = context.contentResolver
        for (perm in resolver.persistedUriPermissions) {
            val tree = perm.uri ?: continue
            val treeId = runCatching { DocumentsContract.getTreeDocumentId(tree) }.getOrNull() ?: continue
            val decodedTreeId = Uri.decode(treeId)
            if (!decodedTreeId.startsWith("$volume:", ignoreCase = true)) continue
            val treeRel = decodedTreeId.substringAfter(':', "")
            if (treeRel.isNotEmpty() && relative != treeRel && !relative.startsWith("$treeRel/")) continue
            var current = DocumentFile.fromTreeUri(context.applicationContext, tree) ?: continue
            val localRel = if (treeRel.isNotEmpty() && relative.startsWith("$treeRel/")) {
                relative.substring(treeRel.length + 1)
            } else {
                relative
            }
            var ok = true
            for (segment in localRel.split('/').filter { it.isNotBlank() }) {
                val next = current.findFile(segment)?.takeIf { it.isDirectory }
                    ?: current.createDirectory(segment)
                if (next == null || !next.isDirectory) {
                    ok = false
                    break
                }
                current = next
            }
            if (ok && current.name.equals("savedata", ignoreCase = true) && current.isDirectory) return true
        }
        return false
    }

    private fun parseStoragePath(path: String): Pair<String, String>? {
        // 主存储根按进程视角解析（安全文件夹内为 emulated/<uid>）；emulated/0 分支保留以兼容既有记录
        val primaryRoot = PrimaryStorageRoot.get()
        return when {
            path == primaryRoot -> "primary" to ""
            path.startsWith("$primaryRoot/") -> "primary" to path.substring(primaryRoot.length + 1)
            path == "/storage/emulated/0" -> "primary" to ""
            path.startsWith("/storage/emulated/0/") -> "primary" to path.substring("/storage/emulated/0/".length)
            path == "/sdcard" -> "primary" to ""
            path.startsWith("/sdcard/") -> "primary" to path.substring("/sdcard/".length)
            path.startsWith("/storage/") -> {
                val rest = path.substring("/storage/".length)
                val slash = rest.indexOf('/')
                if (slash <= 0) null else rest.substring(0, slash) to rest.substring(slash + 1)
            }
            else -> null
        }
    }

    private fun normalizeKrkrsdl3Renderer(value: String): String =
        when (value.trim().lowercase()) {
            EngineSettingsStore.RENDERER_OPENGL, "gl", "gpu" -> EngineSettingsStore.RENDERER_OPENGL
            EngineSettingsStore.RENDERER_SOFTWARE, "sw" -> EngineSettingsStore.RENDERER_SOFTWARE
            else -> EngineSettingsStore.RENDERER_OPENGL
        }

    /**
     * Artemis 启动：手动版本直达；自动版本按历史成功记录与目录/PFS 指纹生成候选链，
     * 再由 ArtemisLauncherBaseActivity 在早退时跨进程尝试下一候选版本。
     * 策略为“启动时询问”时由 UI 层先弹窗确认（needsArtemisPatchConfirm）；
     * [patchChoice] 为弹窗选择，本次/总是按 auto、不再按 off 覆盖生效值（持久化在 launch() 完成）。
     *
     * 自研 clean-room 内核（[EngineSettingsStore.ART_KERNEL_CLEAN]）走独立分支：单库无版本、
     * 不做 PFS/system.ini 补丁、不参与官方回退链（严格自研，失败即退出）。
     */
    private fun buildArtemisIntent(
        context: Context,
        path: String,
        game: ScanGame,
        patchChoice: ArtemisPatchChoice? = null,
        settings: ResolvedEngineSettings,
    ): Intent {
        if (settings.artKernel == EngineSettingsStore.ART_KERNEL_CLEAN) {
            return buildArtemisCleanIntent(context, path, game, settings)
        }
        // 版本/补丁策略的覆盖值已在解析器内走白名单，非法持久化值回退全局（P0-3）
        var version = settings.artVersion
        val rotate = settings.artRotate
        var autoPatch = settings.artAutoPatch
        val androidSettings = ArtemisPfsUnpacker.AndroidSettings(
            resolution = settings.artResolution,
            sideCut = settings.artSideCut,
            surfaceCacheSize = settings.artSurfaceCacheSize,
            fontCacheSize = settings.artFontCacheSize,
            powerSaving = settings.artPowerSaving,
        )
        when (patchChoice) {
            ArtemisPatchChoice.ONCE, ArtemisPatchChoice.ALWAYS -> autoPatch = EngineSettingsStore.AUTO_PATCH_AUTO
            ArtemisPatchChoice.NEVER -> autoPatch = EngineSettingsStore.AUTO_PATCH_OFF
            null -> Unit
        }
        applyArtemisBasePatchIfNeeded(path, autoPatch)
        ArtemisPfsUnpacker.applyAndroidSettings(path, androidSettings)
        // 自动补丁=off 时禁用自动回退；否则 auto 版本启用兼容回退
        val auto = version == EngineSettingsStore.ART_ENGINE_AUTO &&
            autoPatch != EngineSettingsStore.AUTO_PATCH_OFF
        var fallbackVersions = listOf(version)
        var planReason = "manual"
        var stage = 0
        if (auto) {
            // 自动识别缓存（迁移方案阶段 5）：优先命中 DB 记忆（含引擎子进程经 prefs 写回的
            // 成功版本，consume-and-clear 归一）；指纹变化即失效，重走特征识别。
            val pathHash = Integer.toHexString(path.hashCode())
            val fingerprint = GameDirFingerprint.compute(path)
            val remembered = EngineDetectionRepository.lookupArtemisBlocking(context, game.uri, pathHash, fingerprint)
            if (remembered != null) {
                version = remembered
                fallbackVersions = fallbackChainStartingWith(remembered)
                planReason = "history"
                Log.i(TAG, "Artemis auto history hit path=$path version=$version chain=${fallbackVersions.joinToString(",")} fingerprint=$fingerprint")
            } else {
                val plan = ArtemisEngineFingerprintDetector.buildAutoPlan(path)
                version = plan.initialVersion
                fallbackVersions = plan.fallbackVersions
                planReason = plan.reason
                Log.i(TAG, "Artemis auto fingerprint selected path=$path version=$version chain=${fallbackVersions.joinToString(",")} reason=$planReason")
            }
            stage = artemisFallbackStage(version)
        } else {
            stage = artemisFallbackStage(version)
        }
        // 旧库/旧配置可能残留已删除的版本 id（3/4/5）或 legacy id：先归一到当前可用版本，
        // 使下发的 activity/库名/stage/候选链/index 与宿主 ArtemisVersion.find 同一口径。
        version = (ArtemisVersion.requested(version) ?: ArtemisVersion.V1).id
        // 候选链先按当前 ArtemisVersion 可用集合过滤，再在过滤后的列表上定位 index：
        // 宿主 ArtemisLauncherBaseActivity 会丢弃不可用版本却沿用原 index，未过滤时过滤后的
        // 链首（通常是 V2）会被当成「已尝试」而跳过（旧记忆值/缺失版本即触发该问题）。
        val availableFallbacks = fallbackVersions.mapNotNull { ArtemisVersion.find(it)?.id }.distinct()
        val dispatchFallbacks = (listOf(version) + availableFallbacks).distinct()
        val (activity, libName) = artemisActivityAndLib(version)
        val fallbackIndex = dispatchFallbacks.indexOf(version).coerceAtLeast(0)
        return Intent(context, activity).apply {
            putExtra(LaunchContract.PATH, path)
            putExtra(LaunchContract.GAME_PATH, path)
            putExtra(LaunchContract.ROOT_URI, game.uri)
            putExtra(LaunchContract.LAUNCH_TARGET, game.launchTarget)
            putExtra(LaunchContract.LAUNCH_MODE, LaunchContract.LAUNCH_MODE_ARTEMIS)
            putExtra(LaunchContract.ORIENTATION, if (rotate) 8 else 6)
            putExtra(LaunchContract.SCOPED_SAVE_DIR, false)
            // 按实际首选库设置门禁，保留原始请求供后续候选重新判定。
            putArtemisGraphicsSettings(settings, version)
            // artemis_loader 按 "lib<engineLibName>.so" 拼路径，需传库名（不带 lib 前缀）
            putExtra(LaunchContract.ENGINE_LIB_NAME, libName)
            putExtra(LaunchContract.ARTEMIS_AUTO_FALLBACK, auto)
            putExtra(LaunchContract.ARTEMIS_FALLBACK_STAGE, stage)
            putExtra(LaunchContract.ARTEMIS_CURRENT_VERSION, version)
            putExtra(LaunchContract.ARTEMIS_FALLBACK_VERSIONS, dispatchFallbacks.joinToString(","))
            putExtra(LaunchContract.ARTEMIS_FALLBACK_INDEX, fallbackIndex)
            putExtra(LaunchContract.ARTEMIS_AUTO_PLAN_REASON, planReason)
        }
    }

    /**
     * 自研内核启动 Intent：独立 Activity/进程 + `artemis-clean` 库名。
     * 不写 PFS 基础补丁与 system.ini（该内核直接从游戏包内读取配置/资源，散装补丁无意义），
     * 不传回退链（严格自研）。旋转设置仍然生效（由 launcher 基类消费 orientation extra）。
     */
    private fun buildArtemisCleanIntent(
        context: Context,
        path: String,
        game: ScanGame,
        settings: ResolvedEngineSettings,
    ): Intent = Intent(context, ArtemisActivityClean::class.java).apply {
        putExtra(LaunchContract.PATH, path)
        putExtra(LaunchContract.GAME_PATH, path)
        putExtra(LaunchContract.ROOT_URI, game.uri)
        putExtra(LaunchContract.LAUNCH_TARGET, game.launchTarget)
        putExtra(LaunchContract.LAUNCH_MODE, LaunchContract.LAUNCH_MODE_ARTEMIS)
        putExtra(LaunchContract.ORIENTATION, if (settings.artRotate) 8 else 6)
        putExtra(LaunchContract.SCOPED_SAVE_DIR, false)
        // artemis_loader 按 "lib<engineLibName>.so" 拼路径，需传库名（不带 lib 前缀）
        putExtra(LaunchContract.ENGINE_LIB_NAME, NativePluginConstants.ARTEMIS_CLEAN_ENGINE_LIB_NAME)
        putExtra(LaunchContract.ARTEMIS_AUTO_FALLBACK, false)
        putExtra(LaunchContract.ARTEMIS_CURRENT_VERSION, "clean")
    }

    /** 官方内核携带滤镜请求，不通过增强选项隐式改写版本或回退链。 */
    private fun Intent.putArtemisGraphicsSettings(settings: ResolvedEngineSettings, version: String = "") {
        putGraphicsExtras(GraphicsLaunchPolicy.artemisExtras(settings.artGraphics,
            GraphicsCapabilities.forRuntime(GraphicsFamily.ARTEMIS, settings.artKernel, version)))
    }

    private fun Intent.putGraphicsSettings(settings: GraphicsSettings, capability: GraphicsCapabilities) {
        putGraphicsExtras(GraphicsLaunchPolicy.extras(settings, capability))
    }

    private fun fallbackChainStartingWith(version: String): List<String> =
        (listOf(version) + ARTEMIS_DEFAULT_FALLBACK_CHAIN.filterNot { it == version }).distinct()

    private fun artemisFallbackStage(version: String): Int =
        (ArtemisVersion.requested(version) ?: ArtemisVersion.V1).fallbackStage()

    private fun artemisActivityAndLib(version: String): Pair<Class<*>, String> =
        (ArtemisVersion.requested(version) ?: ArtemisVersion.V1).let { it.activityClass to it.engineLibraryName }

    private fun buildWebIntent(
        context: Context,
        path: String,
        game: ScanGame,
        settings: ResolvedEngineSettings,
    ): Intent {
        // Tyrano 与 RPG Maker Web 共用同一组 WebView 宿主设置。
        val scoped = settings.webScopedSaveDir
        val rpgMakerModEnabled = settings.rpgMakerModEnabled
        val scopedSaveRoot = if (scoped) {
            context.getExternalFilesDir(null)?.let { external ->
                File(File(File(external, "save"), "tyrano"), GamePathUtils.safeSaveName(path)).absolutePath
            }
        } else {
            null
        }
        // v1/v2 由独立 rpgmaker 运行时（:rpgmaker 进程）承载；v0 与 MZ v1（占位版本）
        // 沿用原 tyrano 宿主的 v0 链路，不传版本 extras，行为与历史版本完全一致。
        // 版本/legacy 读取仅在 RPG 会话进行，Tyrano/VN/WebOther 启动路径零新增开销。
        val rpgSession = game.engine == EngineType.RPG_MV || game.engine == EngineType.RPG_MZ
        val rpgMakerVersion = when (game.engine) {
            EngineType.RPG_MV -> settings.rpgMvVersion
            EngineType.RPG_MZ -> settings.rpgMzVersion
            else -> null
        }
        val rpgLegacyRenderer = if (rpgSession) settings.rpgLegacyRenderer else false
        val useRpgMakerRuntime = when (game.engine) {
            EngineType.RPG_MV -> rpgMakerVersion == EngineSettingsStore.RPG_MV_V1 ||
                rpgMakerVersion == EngineSettingsStore.RPG_MV_V2
            EngineType.RPG_MZ -> rpgMakerVersion == EngineSettingsStore.RPG_MZ_V2
            else -> false
        }
        if (rpgSession) {
            // 与宿主侧 resolveGameDir 同型归一：目录（游戏路径为文件时取其父目录）
            val sessionGameDir = File(path).let { f -> (if (f.isFile) f.parentFile else f)?.absolutePath }
            stopOppositeRpgHost(context, useRpgMakerRuntime, sessionGameDir)
        }
        val target = if (useRpgMakerRuntime) RpgMakerActivity::class.java else TyranoActivity::class.java
        return Intent(context, target).apply {
            putExtra(LaunchContract.PATH, path)
            putExtra(LaunchContract.GAME_PATH, path)
            putExtra(LaunchContract.PROJECT_ROOT, path)
            putExtra(LaunchContract.GAME_DIR, path)
            putExtra(LaunchContract.ROOT_URI, game.uri)
            putExtra(LaunchContract.LAUNCH_TARGET, game.launchTarget)
            val webType = when (game.engine) {
                EngineType.RPG_MV -> "RPG"
                EngineType.RPG_MZ -> "RMMZ"
                EngineType.VN -> "VN"
                EngineType.WEB_OTHER -> "WebOther"
                else -> "Tyrano"
            }
            putExtra(LaunchContract.TYPE, webType)
            putExtra(LaunchContract.LAUNCH_MODE, "internal.${webType.lowercase()}")
            // Tyrano / WebOther / VN：固定端口（WebView 存储按 origin 隔离，随机会丢存档）
            if (game.engine == EngineType.TYRANO || game.engine == EngineType.WEB_OTHER || game.engine == EngineType.VN) {
                putExtra(LaunchContract.WEB_SHELL_PORT, settings.webShellPort)
            }
            putExtra(LaunchContract.ORIENTATION, 6)
            putExtra(LaunchContract.SCOPED_SAVE_DIR, scoped)
            scopedSaveRoot?.let { putExtra(LaunchContract.SCOPED_SAVE_ROOT, it) }
            putExtra(LaunchContract.RPG_MAKER_MOD_ENABLED, rpgMakerModEnabled)
            putExtra(LaunchContract.RPG_MAKER_MOD_GAME_ID, game.uri)
            if (useRpgMakerRuntime) {
                rpgMakerVersion?.let { putExtra(LaunchContract.RPG_MAKER_VERSION, it) }
                putExtra(LaunchContract.RPG_LEGACY_RENDERER, rpgLegacyRenderer)
            }
        }
    }

    /**
     * 仅当会话登记表显示另一宿主正运行【同一游戏】时才回收对方进程（PR review 意见：
     * 按进程后缀终止会误杀后台无关的 Tyrano/RPG 会话并可能丢失未存档进度）。
     * 会话登记由各宿主 onCreate/onDestroy 经 EngineSessionRegistry 维护（跨进程文件，
     * 主进程读取始终为最新值）；getRunningAppProcesses 仅返回本应用（同 uid）进程。
     */
    private fun stopOppositeRpgHost(context: Context, targetIsRpgMaker: Boolean, sessionGameDir: String?) {
        if (sessionGameDir.isNullOrBlank()) return
        val oppositeHost = if (targetIsRpgMaker) EngineSessionRegistry.HOST_TYRANO else EngineSessionRegistry.HOST_RPGMAKER
        val registered = EngineSessionRegistry.currentGame(context, oppositeHost) ?: return
        val matches = try {
            File(registered).canonicalPath == File(sessionGameDir).canonicalPath
        } catch (_: Throwable) {
            registered == sessionGameDir
        }
        if (!matches) return
        val oppositeSuffix = if (targetIsRpgMaker) ":tyrano" else ":rpgmaker"
        runCatching {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            am?.runningAppProcesses
                ?.filter { it.processName.endsWith(oppositeSuffix) }
                ?.forEach { processInfo ->
                    runCatching { android.os.Process.killProcess(processInfo.pid) }
                }
        }
    }

    /** 单游戏手动补丁结果（UI 层映射本地化文案）。 */
    enum class ArtemisManualPatchResult { SUCCESS, FAILED, GAME_DIR_UNRESOLVED, PERMISSION_REQUIRED }

    /** 手动「添加基础补丁」：强制重新解出 system.ini 等启动文件并应用 Android 化改写。 */
    suspend fun applyArtemisBasePatchManually(context: Context, game: ScanGame): ArtemisManualPatchResult =
        applyArtemisPatchManually(context, game) { path ->
            ArtemisPfsUnpacker.applyBasePatch(path, force = true)
        }

    /** 手动「添加Windows环境补丁」：解出 system.lua/init.lua 并把 game.os 强制为 windows。 */
    suspend fun applyArtemisWindowsEnvPatchManually(context: Context, game: ScanGame): ArtemisManualPatchResult =
        applyArtemisPatchManually(context, game) { path ->
            ArtemisPfsUnpacker.applyWindowsEnvPatch(path)
        }

    private suspend fun applyArtemisPatchManually(
        context: Context,
        game: ScanGame,
        action: (String) -> Boolean,
    ): ArtemisManualPatchResult = withContext(Dispatchers.IO) {
        if (game.engine != EngineType.ARTEMIS) return@withContext ArtemisManualPatchResult.FAILED
        val path = resolveGameDirectory(context, game)
            ?: return@withContext ArtemisManualPatchResult.GAME_DIR_UNRESOLVED
        requestAllFilesAccessIfNeeded(context, game, path)?.let {
            return@withContext ArtemisManualPatchResult.PERMISSION_REQUIRED
        }
        if (action(path)) ArtemisManualPatchResult.SUCCESS else ArtemisManualPatchResult.FAILED
    }

    /**
     * RinneMobile 的 Artemis 启动链路会在启动前补齐部分 PFS 打包游戏所需的基础文件。
     * “启动时询问”策略已由 UI 层弹窗确认（needsArtemisPatchConfirm），到达这里时
     * ask 已按弹窗结果改写为 auto/off：auto（含 ask 遗留路径）幂等自动补丁，off 跳过。
     */
    private fun applyArtemisBasePatchIfNeeded(path: String, strategy: String) {
        if (strategy == EngineSettingsStore.AUTO_PATCH_OFF) return
        if (!ArtemisPfsUnpacker.needsBasePatch(path)) return
        ArtemisPfsUnpacker.applyBasePatch(path)
    }

    /**
     * 为 KR2 挑选“启动条目”路径（让 gamedir = path 的父目录 = 游戏目录）。优先：launchTarget
     * 指定的 xp3 → 目录内 data.xp3/startup.tjs 等常见启动条目 → 任意一个 xp3 → 目录本身。
     */
    private fun pickKrActivateEntry(path: String, game: ScanGame): String {
        val files = java.io.File(path).listFiles()
            ?.filter { it.isFile }
            .orEmpty()

        // 用户通过“启动文件”手动指定的入口优先（文件不存在时回退自动逻辑）
        game.launchFile?.takeIf { it.isNotBlank() }?.let { manual ->
            val exact = java.io.File(path, manual)
            val f = if (exact.isFile) exact else java.io.File(path, manual.lowercase(Locale.ROOT))
            if (f.isFile) return f.absolutePath
        }

        // 脚本/主启动归档优先（此类 xp3 内含 start.ks / FirstConductor 等启动脚本），
        // 避开 bgimage/bgm/video/voice 等纯素材档。
        LaunchFileCandidates.KR_PREFERRED_NAMES.forEach { name ->
            files.firstOrNull { it.name.equals(name, ignoreCase = true) }?.let { return it.absolutePath }
        }

        // launchTarget 若存在且非素材档，作为候选用
        val target = game.launchTarget.takeIf { LaunchFileCandidates.isLaunchTargetCandidate(it) }
        if (target != null) {
            val exact = java.io.File(path, target)
            val f = if (exact.isFile) exact else java.io.File(path, target.lowercase(Locale.ROOT))
            if (f.isFile) return f.absolutePath
        }

        // 兜底：任意非 bg* 的 xp3
        files.firstOrNull {
            it.name.lowercase().endsWith(".xp3") && !it.name.lowercase().startsWith("bg")
        }?.let { return it.absolutePath }

        return path
    }

    private data class KrPatchCleanupResult(
        val patchFile: File,
        val bytes: ByteArray,
        val hadUserContent: Boolean,
        val cleanedManagedBlock: Boolean,
        val hadManagedMarker: Boolean,
        /** 镜像占位的 patch.tjs 经 SAF 读取失败：真实内容不可判定，必须跳过 overlay 合成。 */
        val mirrorReadFailed: Boolean = false,
    )

    private data class KrPatchOverlay(
        val targetPatch: File,
        val overlayPatch: File,
        val mode: String,
    )

    private data class KrSteamConfigOverlay(
        val targetConfig: File,
        val overlayConfig: File,
    )

    /**
     * 生成 KRKR 虚拟 patch.tjs overlay。
     *
     * 不再直接向用户游戏目录写入兼容脚本；只在 app 私有目录生成合成 patch.tjs，
     * 再由 KRKR 文件 hook 在读取游戏 patch.tjs 时做只读重定向。
     *
     * SD 卡镜像游戏的本体 patch.tjs 在镜像里是 0 字节占位：用户 patch 检测必须经
     * SAF 索引读真实内容，否则会把游戏自带的 patch.tjs（含插件引导）误判为不存在、
     * 用基础 overlay 顶掉，游戏插件链失效（issue #129 的 GamepadPort 崩溃）。
     */
    private fun prepareKrPatchOverlay(context: Context, engineRoot: String, mode: String, mirrorReader: KrMirrorOverlayReader?, isMirror: Boolean): KrPatchOverlay? {
        if (mode == EngineSettingsStore.KR_PATCH_OVERLAY_OFF) {
            // Preserve legacy local managed-block cleanup when overlays are disabled.
            // Mirror placeholders must never be inspected as source patch contents here.
            if (!isMirror) cleanupTyranorManagedKrPatchScript(File(engineRoot), null)
            return null
        }
        val root = File(engineRoot)
        if (!root.isDirectory || engineRoot.startsWith("content://")) return null
        val cleanup = cleanupTyranorManagedKrPatchScript(root, mirrorReader)
        if (cleanup?.mirrorReadFailed == true) {
            Log.i(TAG, "KRKR patch overlay skipped: mirror patch.tjs unreadable via SAF root=$engineRoot")
            return null
        }
        val hasSteamPlugin = rootContainsFbfSteamPlugin(root)
        val force = mode == EngineSettingsStore.KR_PATCH_OVERLAY_FORCE
        val includeBasicPatch = force || cleanup?.hadUserContent != true
        val includeSteamStub = hasSteamPlugin && (force || mode == EngineSettingsStore.KR_PATCH_OVERLAY_AUTO)
        if (!includeBasicPatch && !includeSteamStub) {
            Log.i(TAG, "KRKR patch overlay skipped root=$engineRoot mode=$mode userPatch=true steam=false")
            return null
        }

        val additionsText = buildString {
            if (includeBasicPatch) append(krBasicPatchOverlayScript())
            if (includeSteamStub) append(krFbfSteamStubScript())
        }
        val baseBytes = if (force || includeSteamStub) cleanup?.bytes ?: ByteArray(0) else ByteArray(0)
        val patchCharset = detectKrPatchCharset(baseBytes)
        val additions = additionsText.toByteArray(patchCharset)
        if (additions.isEmpty()) return null

        val output = ByteArrayOutputStream(baseBytes.size + additions.size + 4).apply {
            if (baseBytes.isNotEmpty()) {
                write(baseBytes)
                write("\n".toByteArray(patchCharset))
            }
            write(additions)
        }.toByteArray()

        return runCatching {
            val overlayDir = File(File(context.filesDir, "krkr_patch_overlay"), GamePathUtils.safeSaveName(engineRoot))
            if (!overlayDir.isDirectory && !overlayDir.mkdirs()) {
                Log.w(TAG, "KRKR patch overlay directory unavailable root=$engineRoot dir=${overlayDir.absolutePath}")
                return null
            }
            val overlay = File(overlayDir, "patch.tjs")
            overlay.writeBytes(output)
            val target = File(root, "patch.tjs")
            Log.i(
                TAG,
                "KRKR patch overlay prepared root=$engineRoot mode=$mode basic=$includeBasicPatch steam=$includeSteamStub userPatch=${cleanup?.hadUserContent == true} bytes=${output.size}",
            )
            KrPatchOverlay(target, overlay, mode)
        }.onFailure { error ->
            if (error is CancellationException) throw error
            Log.w(TAG, "KRKR patch overlay prepare failed root=$engineRoot", error)
        }.getOrNull()
    }

    /**
     * 部分 Windows Steam 版 KRKR 移植包会带 ds.ini，并用 Language=xxx 决定 UI 语言。
     * 不直接修改用户游戏目录，只在 app 私有目录生成 schinese 版本并由 NativeBridge 只读映射。
     * SD 镜像下 ds.ini 是 0 字节占位：经 SAF 索引读真实内容做基底；读不到真实内容时
     * 不生成 overlay（最小配置会顶掉真实 ds.ini 的其余配置，比没有更糟）。
     */
    private fun prepareKrSteamConfigOverlay(
        context: Context,
        engineRoot: String,
        mode: String,
        mirrorReader: KrMirrorOverlayReader?,
    ): KrSteamConfigOverlay? {
        val root = File(engineRoot)
        if (!root.isDirectory || engineRoot.startsWith("content://") || !rootContainsFbfSteamPlugin(root)) return null
        if (mode == EngineSettingsStore.KR_PATCH_OVERLAY_OFF) return null

        val config = File(root, "ds.ini")
        if (!config.isFile && mirrorReader == null) return null
        return runCatching {
            val localSize = if (config.isFile) config.length() else 0L
            val mirrored = if (localSize == 0L && mirrorReader != null) {
                mirrorReader.read("ds.ini", 1024 * 1024)
            } else {
                null
            }
            when (mirrored) {
                KrMirrorOverlayReader.Result.Absent -> return null
                KrMirrorOverlayReader.Result.Unavailable -> {
                    Log.w(TAG, "KRKR ds.ini source unreadable, skipping steam config overlay root=$engineRoot")
                    return null
                }
                else -> Unit
            }
            val bytes = (mirrored as? KrMirrorOverlayReader.Result.Content)?.bytes ?: config.readBytes()
            val charset = detectKrPatchCharset(bytes)
            val text = bytes.toString(charset)
            val languageRegex = Regex("(?im)^(\\s*Language\\s*=\\s*)[^\\r\\n]*")
            val patched = if (languageRegex.containsMatchIn(text)) {
                languageRegex.replace(text) { match ->
                    "${match.groupValues[1]}schinese"
                }
            } else {
                text.trimEnd() + "\nLanguage=schinese\n"
            }
            if (patched == text) return null
            val overlayDir = File(File(context.filesDir, "krkr_config_overlay"), GamePathUtils.safeSaveName(engineRoot))
            if (!overlayDir.isDirectory && !overlayDir.mkdirs()) {
                Log.w(TAG, "KRKR Steam config overlay directory unavailable root=$engineRoot dir=${overlayDir.absolutePath}")
                return null
            }
            val overlay = File(overlayDir, "ds.ini")
            overlay.writeText(patched, charset)
            Log.i(
                TAG,
                "KRKR Steam config overlay prepared root=$engineRoot target=${config.absolutePath} overlay=${overlay.absolutePath}",
            )
            KrSteamConfigOverlay(config, overlay)
        }.onFailure { error ->
            if (error is CancellationException) throw error
            Log.w(TAG, "KRKR Steam config overlay prepare failed root=${root.absolutePath}", error)
        }.getOrNull()
    }

    /**
     * PR 44b6be2 曾在启动时向游戏目录 patch.tjs 自动追加 Tyranor Next 兼容脚本。
     * 这里只清理历史版本写入的精确托管块，并返回清理后的原始 patch 内容供 overlay 合成。
     */
    private fun cleanupTyranorManagedKrPatchScript(root: File, mirrorReader: KrMirrorOverlayReader?): KrPatchCleanupResult? {
        val patch = File(root, "patch.tjs")
        if (!patch.isFile && mirrorReader == null) return null
        return runCatching {
            // A missing placeholder is not proof that the source bootstrap is absent.
            // Only a successful SAF absence probe permits synthesis of the basic patch.
            val localSize = if (patch.isFile) patch.length() else 0L
            val mirrored = if (localSize == 0L && mirrorReader != null) {
                mirrorReader.read("patch.tjs", 4 * 1024 * 1024)
            } else {
                null
            }
            if (mirrored == KrMirrorOverlayReader.Result.Absent) return null
            if (mirrored == KrMirrorOverlayReader.Result.Unavailable) {
                Log.w(TAG, "KRKR patch.tjs source unreadable, skipping overlay synthesis root=${root.absolutePath}")
                return KrPatchCleanupResult(
                    patchFile = patch,
                    bytes = ByteArray(0),
                    hadUserContent = false,
                    cleanedManagedBlock = false,
                    hadManagedMarker = false,
                    mirrorReadFailed = true,
                )
            }
            val safBytes = (mirrored as? KrMirrorOverlayReader.Result.Content)?.bytes
            val original = safBytes ?: patch.readBytes()
            val blocks = listOf(
                krLegacyPatchScript(fontScale = 1.0f),
                krFbfSteamStubScript(),
            )
            var cleaned = original
            blocks.forEach { block ->
                cleaned = removeAllByteSequences(cleaned, block.toByteArray(Charsets.UTF_8))
                cleaned = removeAllByteSequences(cleaned, block.toByteArray(Charsets.UTF_16LE))
            }
            if (safBytes == null && !cleaned.contentEquals(original)) {
                patch.writeBytes(cleaned)
                Log.i(TAG, "KRKR managed patch.tjs block cleaned root=${root.absolutePath} bytes=${original.size - cleaned.size}")
            } else if (
                original.containsByteSequence(KR_LEGACY_PATCH_MARKER.toByteArray(Charsets.UTF_8)) ||
                original.containsByteSequence(KR_FBF_STEAM_STUB_MARKER.toByteArray(Charsets.UTF_8)) ||
                original.containsByteSequence(KR_LEGACY_PATCH_MARKER.toByteArray(Charsets.UTF_16LE)) ||
                original.containsByteSequence(KR_FBF_STEAM_STUB_MARKER.toByteArray(Charsets.UTF_16LE))
            ) {
                Log.w(TAG, "KRKR managed patch.tjs marker found but exact block did not match; left untouched root=${root.absolutePath}")
            }
            KrPatchCleanupResult(
                patchFile = patch,
                bytes = cleaned,
                hadUserContent = hasMeaningfulPatchContent(cleaned),
                cleanedManagedBlock = !cleaned.contentEquals(original),
                hadManagedMarker = original.containsByteSequence(KR_LEGACY_PATCH_MARKER.toByteArray(Charsets.UTF_8)) ||
                    original.containsByteSequence(KR_FBF_STEAM_STUB_MARKER.toByteArray(Charsets.UTF_8)) ||
                    original.containsByteSequence(KR_LEGACY_PATCH_MARKER.toByteArray(Charsets.UTF_16LE)) ||
                    original.containsByteSequence(KR_FBF_STEAM_STUB_MARKER.toByteArray(Charsets.UTF_16LE)),
            )
        }.onFailure { error ->
            if (error is CancellationException) throw error
            Log.w(TAG, "KRKR managed patch.tjs cleanup failed root=${root.absolutePath}", error)
        }.getOrNull()
    }

    /** Build the bounded reader from the engine payload without reparsing the resource index. */
    private fun createKrMirrorOverlayReader(context: Context, prepared: KrSafMirror.Prepared): KrMirrorOverlayReader =
        KrMirrorOverlayReader.fromPrepared(prepared) { uri -> context.contentResolver.openInputStream(Uri.parse(uri)) }

    private fun rootContainsFbfSteamPlugin(root: File): Boolean {
        val files = root.listFiles() ?: return false
        return files.any { file ->
            file.isFile && file.name.equals("FBFSteamPlugin.dll", ignoreCase = true)
        }
    }

    private fun krBasicPatchOverlayScript(): String = """
        |
        |
        |// TYRANOR_NEXT_KRKR_PATCH_OVERLAY_V1
        |System.setArgument("-debugwin","no");
        |Plugins.link("kirikiroid2.dll");
        |
    """.trimMargin()

    private fun krLegacyPatchScript(fontScale: Float): String = """
        |
        |
        |$KR_LEGACY_PATCH_MARKER
        |System.setArgument("-debugwin","no");
        |Plugins.link("kirikiroid2.dll");
        |with(Font) {
        |global._origFontHeightProp = &.height;
        |property hook_font_height {
        |setter(v) { global._origFontHeightProp = v * $fontScale; }
        |getter { return global._origFontHeightProp; }
        |}
        |&.height = &(hook_font_height incontextof null);
        |}
        |
    """.trimMargin()

    internal fun hasMeaningfulPatchContent(bytes: ByteArray): Boolean =
        bytes.any { byte ->
            val value = byte.toInt() and 0xFF
            value > 0x20 && value != 0xFE && value != 0xFF
        }

    private fun detectKrPatchCharset(bytes: ByteArray): Charset {
        if (bytes.size >= 2) {
            val b0 = bytes[0].toInt() and 0xFF
            val b1 = bytes[1].toInt() and 0xFF
            if (b0 == 0xFF && b1 == 0xFE) return Charsets.UTF_16LE
            if (b0 == 0xFE && b1 == 0xFF) return Charsets.UTF_16BE
        }
        val sampleSize = bytes.size.coerceAtMost(512)
        if (sampleSize >= 16) {
            var evenZeros = 0
            var oddZeros = 0
            for (i in 0 until sampleSize) {
                if (bytes[i].toInt() == 0) {
                    if (i % 2 == 0) evenZeros++ else oddZeros++
                }
            }
            if (oddZeros > sampleSize / 4 && oddZeros > evenZeros * 2) return Charsets.UTF_16LE
            if (evenZeros > sampleSize / 4 && evenZeros > oddZeros * 2) return Charsets.UTF_16BE
        }
        return Charsets.UTF_8
    }

    private fun krFbfSteamStubScript(): String = """
        |
        |
        |$KR_FBF_STEAM_STUB_MARKER
        |class CFBFSteam {
        |function CFBFSteam() {}
        |function finalize() {}
        |function Init() { return true; }
        |function Shutdown() { return true; }
        |function RestartAppIfNecessary(appId) { return false; }
        |function IsSteamRunning() { return true; }
        |function IsSubscribed() { return true; }
        |function IsSubscribedApp(appId) { return true; }
        |function IsDLCInstalled(appId) { return true; }
        |function GetUserLanguage() { return "schinese"; }
        |function GetCurrentGameLanguage() { return "schinese"; }
        |function GetAvailableGameLanguages() { return "schinese,english,japanese"; }
        |function GetPersonaName() { return "Tyranor"; }
        |function GetAppID() { return 0; }
        |function GetSteamID() { return "0"; }
        |function SetAchievement(name) { return true; }
        |function ClearAchievement(name) { return true; }
        |function GetAchievement(name) { return false; }
        |function IndicateAchievementProgress(name, current, max) { return true; }
        |function StoreStats() { return true; }
        |function ResetAllStats(achievementsToo) { return true; }
        |function SetStat(name, value) { return true; }
        |function GetStat(name) { return 0; }
        |function IsOverlayEnabled() { return false; }
        |function ActivateGameOverlay(dialog) { return false; }
        |function ActivateGameOverlayToWebPage(url) { return false; }
        |}
        |global.FBFSteam = new CFBFSteam();
        |
    """.trimMargin()

    private fun removeAllByteSequences(source: ByteArray, needle: ByteArray): ByteArray {
        if (source.isEmpty() || needle.isEmpty()) return source
        var index = source.indexOfByteSequence(needle, startIndex = 0)
        if (index < 0) return source
        val out = ByteArrayOutputStream(source.size)
        var cursor = 0
        while (index >= 0) {
            out.write(source, cursor, index - cursor)
            cursor = index + needle.size
            index = source.indexOfByteSequence(needle, startIndex = cursor)
        }
        out.write(source, cursor, source.size - cursor)
        return out.toByteArray()
    }

    private fun ByteArray.containsByteSequence(needle: ByteArray): Boolean =
        indexOfByteSequence(needle, startIndex = 0) >= 0

    private fun ByteArray.indexOfByteSequence(needle: ByteArray, startIndex: Int): Int {
        if (needle.isEmpty()) return startIndex.coerceIn(0, size)
        val max = size - needle.size
        var i = startIndex.coerceAtLeast(0)
        while (i <= max) {
            var j = 0
            while (j < needle.size && this[i + j] == needle[j]) j++
            if (j == needle.size) return i
            i++
        }
        return -1
    }

    /**
     * 「启动文件」选择器数据：候选文件名列表 + 当前生效项，一次读取供弹窗展示。
     *
     * 目录枚举分两级：真实路径 File 直读（内置存储 / 已授予“所有文件访问”）；不可用
     * （SD 卡未授权时 `listFiles` 静默返回空）则回退 SAF 子项查询。确认仍只写
     * [ScanGame.launchFile]：启动侧 SD 卡经 SAF 镜像读取，不依赖真实路径可枚举。
     */
    internal fun launchFileOptions(context: Context, game: ScanGame): LaunchFileOptions {
        val path = resolveGameDirectory(context, game)
        val entries = readLaunchFileEntries(context, game, path)
        return when (game.engine) {
            // YU-RIS / CatSystem2 / 手动添加的 PC 共用 Windows exe 候选（过滤干扰项并按可信度排序）；
            // CatSystem2 额外接受 .bin（Runtime 可能被改名/改扩展名）并优先 cs2.exe
            EngineType.YURIS, EngineType.CATSYSTEM2, EngineType.PC -> {
                val allowBin = game.engine == EngineType.CATSYSTEM2
                val candidates = YurisLaunchFiles.candidatesOf(
                    entries.map { YurisLaunchFiles.ExeCandidate(it.name, it.size) },
                    launchFileDirName(path, game.title),
                    allowBin = allowBin,
                    preferCs2Runtime = game.engine == EngineType.CATSYSTEM2,
                )
                LaunchFileOptions(
                    names = candidates.map { it.name },
                    current = LaunchFileCandidates.windowsCurrentName(candidates, game.launchFile, allowBin),
                )
            }
            else -> LaunchFileOptions(
                names = LaunchFileCandidates.krkrNames(entries),
                current = LaunchFileCandidates.krkrCurrentName(entries, game),
            )
        }
    }

    /** 候选目录枚举：真实路径优先；File 直读不可用（null 或空）时回退 SAF（SD 卡常见）。 */
    private fun readLaunchFileEntries(
        context: Context,
        game: ScanGame,
        path: String?,
    ): List<LaunchFileCandidates.Entry> {
        if (path != null) {
            val files = runCatching { File(path).listFiles() }.getOrNull()
            if (!files.isNullOrEmpty()) {
                return files.filter { it.isFile }.map { LaunchFileCandidates.Entry(it.name, it.length()) }
            }
        }
        return readSafLaunchFileEntries(context, game.uri)
    }

    /** 经 SAF 查询游戏目录子项；查询失败返回空列表（弹窗按空态提示，不阻断其它功能）。 */
    private fun readSafLaunchFileEntries(context: Context, uriText: String): List<LaunchFileCandidates.Entry> {
        val uri = runCatching { Uri.parse(uriText) }.getOrNull() ?: return emptyList()
        if (!uri.scheme.equals("content", ignoreCase = true)) return emptyList()
        return runCatching {
            // 扫描保存的是树内子文档 URI；纯树 URI（如手动添加 PC 的目录授权）退回树根文档 id
            val documentId = runCatching { DocumentsContract.getDocumentId(uri) }.getOrNull()
                ?: DocumentsContract.getTreeDocumentId(uri)
            val childrenUri = if (DocumentsContract.isTreeUri(uri)) {
                DocumentsContract.buildChildDocumentsUriUsingTree(uri, documentId)
            } else {
                DocumentsContract.buildChildDocumentsUri(uri.authority, documentId)
            }
            val projection = arrayOf(
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_SIZE,
            )
            buildList {
                context.contentResolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
                    while (cursor.moveToNext()) {
                        val name = cursor.getString(0) ?: continue
                        if (cursor.getString(1) == DocumentsContract.Document.MIME_TYPE_DIR) continue
                        add(LaunchFileCandidates.Entry(name, if (cursor.isNull(2)) 0L else cursor.getLong(2)))
                    }
                }
            }
        }.onFailure { error ->
            Log.w(TAG, "SAF launch file query failed uri=$uriText", error)
        }.getOrDefault(emptyList())
    }

    /** 候选排序用的目录名：真实路径可用时取目录名，否则回退游戏标题（扫描/手动添加默认均为目录名）。 */
    private fun launchFileDirName(path: String?, title: String): String =
        path?.let { runCatching { File(it).name }.getOrNull() }?.takeIf { it.isNotBlank() } ?: title

    /** 与 OnsSettings.safeSharpness 一致：只接受 0.1~10.0 的数字，否则回退 "2"。 */
    private fun safeSharpnessValue(value: String): String {
        val v = value.trim()
        if (v.isEmpty()) return "2"
        val parsed = v.toDoubleOrNull() ?: return "2"
        if (parsed.isNaN() || parsed.isInfinite()) return "2"
        if (parsed < 0.1 || parsed > 10.0) return "2"
        return v
    }

    /**
     * 文件型外置入口（SWF）→ 入口所在目录。用于 [ExternalEngineModule.launchEntryIsFile]：
     * 游戏记录 uri 指向文件本身，插件需要 `folder` 目录 + `execFile` 文件名。
     *
     * 路径来源按 provider 区分：
     * - `com.android.externalstorage.documents`：优先 SAF documentId 映射，失败再用 `_data`；
     * - 其它 `content://`（Downloads / 媒体库等）：`documentId` 不是真实路径，**禁止**
     *   经 [GamePathUtils.safUriToPath] 拼成 `/storage/<docid>`，只信任 `_data`；
     * - `file://` / 绝对路径：直接使用。
     *
     * 空白或相对 URI 没有可靠的真实路径语义，直接拒绝。
     */
    private fun resolveLaunchEntryDirectory(context: Context, game: ScanGame): String? {
        val uriText = game.uri.trim()
        if (uriText.isEmpty()) return null
        val uri = runCatching { Uri.parse(uriText) }.getOrNull() ?: return null
        val scheme = uri.scheme?.lowercase(Locale.ROOT)
        if (scheme == null && !uriText.startsWith('/')) return null
        val isContent = scheme == "content"
        val isExternalStorage = isContent && uri.authority == EXTERNAL_STORAGE_AUTHORITY
        // 只有外部存储 provider 的 documentId 能安全映射为真实路径。
        val safMapped = if (isExternalStorage) GamePathUtils.safUriToPath(uriText) else null
        // 其它 provider 或外部存储映射失败时才查 `_data`（provider 自己报告的真实路径）。
        val dataPath = if (isContent && (safMapped == null || !isExternalStorage)) {
            queryDocumentDataPath(context, uriText)
        } else {
            null
        }
        return resolveLaunchEntryPath(uriText, safMapped, dataPath, game.launchTarget)
    }

    /**
     * 入口 URI → 目录的纯决策函数（无 Android 依赖，供 JVM 单测）。
     *
     * [safMappedPath] 仅对 `com.android.externalstorage.documents` 有效；[dataPath] 为
     * provider `_data` 查询结果。两者都不可用或映射结果不是绝对路径时返回 null。
     */
    internal fun resolveLaunchEntryPath(
        uriText: String,
        safMappedPath: String?,
        dataPath: String?,
        launchTarget: String,
    ): String? {
        val text = uriText.trim()
        if (text.isEmpty()) return null
        val lower = text.lowercase(Locale.ROOT)
        val mapped = when {
            text.startsWith('/') -> text
            lower.startsWith("file:") -> runCatching { java.net.URI(text).path }.getOrNull()
            lower.startsWith("content://") -> {
                if (isExternalStorageDocumentUri(text)) safMappedPath ?: dataPath else dataPath
            }
            else -> null
        }?.trim().orEmpty()
        if (mapped.isEmpty() || !mapped.startsWith('/')) return null
        val entry = File(mapped)
        // 纯 tree URI（无 /document/ 段）映射的是目录；带 /document/ 的混合 URI 仍是文件文档，
        // 不能因为路径里出现过 /tree/ 就当成目录。
        val isPureTreeUri = text.contains("/tree/") && !text.contains("/document/")
        // 包装目录记录（uri=目录、launchTarget=目录内 SWF）与单文件记录（uri=SWF）都会带
        // .swf 的 launchTarget；只有映射路径本身就是该入口文件时才取父目录，否则目录会丢一级。
        val launchName = launchTarget.substringAfterLast('/').trim()
        val mappedIsEntryFile = mapped.endsWith(".swf", ignoreCase = true) ||
            (launchName.endsWith(".swf", ignoreCase = true) && entry.name.equals(launchName, ignoreCase = true))
        // 刻意在确认文件存在之前返回目录：缺少「所有文件访问」权限时 File.isDirectory/isFile
        // 都会失败，若在此提前返回 null，权限门禁（requestAllFilesAccessIfNeeded）就没机会运行。
        return when {
            isPureTreeUri -> mapped
            entry.isDirectory -> entry.absolutePath
            entry.isFile -> entry.parentFile?.absolutePath
            mappedIsEntryFile -> entry.parentFile?.absolutePath
            else -> mapped
        }
    }

    private fun isExternalStorageDocumentUri(uriText: String): Boolean =
        uriText.substringAfter("://", "").substringBefore('/')
            .equals(EXTERNAL_STORAGE_AUTHORITY, ignoreCase = true)

    /** `_data` 兜底查询（文件型入口用；目录解析仍走 [resolveGameDirectory] 的既有逻辑）。 */
    private fun queryDocumentDataPath(context: Context, uriText: String): String? {
        return try {
            val uri = Uri.parse(uriText) ?: return null
            context.contentResolver.query(uri, arrayOf("_data"), null, null, null)?.use { cursor ->
                if (!cursor.moveToFirst()) return@use null
                val dataIdx = cursor.getColumnIndex("_data")
                if (dataIdx >= 0) cursor.getString(dataIdx) else null
            }
        } catch (_: Exception) {
            null
        }
    }

    /**
     * 将游戏 URI 解析为真实文件路径。优先按 SAF documentId 映射（主存储→进程视角挂载根，
     * 见 [PrimaryStorageRoot]；安全文件夹等隔离 user 下不是 emulated/0），
     * 映射失败再用 _data 查询兜底（该列在隔离 user 下可能为 null）。引擎 native 需要真实文件路径。
     */
    private fun resolveGameDirectory(context: Context, game: ScanGame): String? {
        val uriText = game.uri
        if (game.engine == EngineType.SYSTEMNNN) return SystemNnnGameDirectory.accessible(context, uriText)?.absolutePath
        if (game.engine == EngineType.ETHORNELL) {
            return try {
                val uri = Uri.parse(uriText)
                if (uri.scheme == "content" && uri.authority != "com.android.externalstorage.documents") return null
                val mapped = GamePathUtils.safUriToPath(uriText) ?: return null
                val file = File(mapped)
                // Resolve identity/provider/containment first. Actual access is tested only after
                // requestAllFilesAccessIfNeeded, so an unreadable directory can reach the grant UI.
                if (!file.isAbsolute) return null
                // Provider/path validation is lexical until the storage permission gate. Canonical
                // containment and actual readability are checked in prepareEthornell afterwards.
                if (uri.scheme == "content") {
                    val allowed = ethornellStorageRoot(mapped) ?: return null
                    if (!file.toPath().normalize().startsWith(allowed.toPath())) return null
                }
                file.absolutePath
            } catch (_: java.io.IOException) {
                null
            } catch (_: SecurityException) {
                null
            } catch (_: IllegalArgumentException) {
                null
            }
        }

        // 1) 首选 SAF documentId → 文件路径映射（兼容 child 子目录 document uri）
        GamePathUtils.safUriToPath(uriText)?.let { mapped ->
            val f = java.io.File(mapped)
            if (f.isDirectory) return f.absolutePath
            if (game.engine == EngineType.KIRIKIRI && GamePathUtils.isRemovableStoragePath(mapped)) {
                val readableBySaf = runCatching {
                    DocumentFile.fromTreeUri(context.applicationContext, Uri.parse(uriText))?.isDirectory == true
                }.getOrDefault(false)
                if (readableBySaf) return f.absolutePath
            }
        }

        val uri = Uri.parse(uriText) ?: return null
        if (uri.scheme == "file") return uri.path

        // 2) 兜底：尝试 _data 直查
        return try {
            val doc = DocumentFile.fromTreeUri(context, uri)
            if (doc == null || !doc.exists()) return null
            queryDocumentDataPath(context, uriText)
        } catch (e: Exception) {
            null
        }
    }
}

/** 「启动文件」选择器数据（见 [EngineLauncher.launchFileOptions]）：候选名 + 当前生效项。 */
internal data class LaunchFileOptions(
    val names: List<String>,
    val current: String?,
)

internal fun effectiveRpgMakerModEnabled(
    engine: EngineType,
    perGameOverride: Boolean?,
    globalDefault: Boolean,
): Boolean = EffectiveEngineSettings.resolveRpgMakerModEnabled(engine, perGameOverride, globalDefault)
