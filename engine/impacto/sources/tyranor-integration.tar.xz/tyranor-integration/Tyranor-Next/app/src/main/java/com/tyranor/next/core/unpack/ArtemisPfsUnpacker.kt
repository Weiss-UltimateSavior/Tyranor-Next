package com.tyranor.next.core.unpack

import android.util.Log
import java.io.EOFException
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.charset.Charset
import java.security.MessageDigest
import java.util.Locale
import kotlin.text.Charsets.UTF_8

/**
 * Artemis base patcher for titles whose required startup files are packed in .pfs archives.
 *
 * Some Artemis games ship without loose Android startup files. The native engine expects a few
 * bootstrap entries such as system.ini and the BOOT script to exist on disk, so we extract only
 * those small required entries and let the engine continue streaming the rest from the archive.
 */
object ArtemisPfsUnpacker {
    private const val TAG = "ArtemisPfsUnpacker"

    /** 条目表长度上限（表本身很小，50MB 足够）。 */
    private const val MAX_ENTRY_BYTES = 50L * 1024 * 1024

    /** 单条目数据上限：原版补丁无上限，OP 视频常见 300MB~1GB；保留 3GB 兜底防损坏封包。 */
    private const val MAX_ENTRY_DATA_BYTES = 3L * 1024 * 1024 * 1024

    /** 单次补丁写出总量上限：视频全部解出可能到数 GB（原版无限制）。 */
    private const val MAX_TOTAL_BYTES = 8L * 1024 * 1024 * 1024
    private const val MAX_ENTRY_COUNT = 10_000
    private const val MAX_NAME_BYTES = 4096

    /** 流式解包缓冲：大视频不再整块进内存，避免 OOM。 */
    private const val COPY_BUFFER_BYTES = 1 * 1024 * 1024
    private val GAME_OS_LINE_RE = Regex("""[\t\s]+?game\.os[\s\t]+?=[^=].+""")

    private const val MANAGED_BLOCK_BEGIN = "; TYRANOR_NEXT_ARTEMIS_SETTINGS_BEGIN"
    private const val MANAGED_BLOCK_END = "; TYRANOR_NEXT_ARTEMIS_SETTINGS_END"
    private val MANAGED_ANDROID_KEYS = setOf(
        "WIDTH",
        "HEIGHT",
        "SIDECUT",
        "SURFACE_CACHE_SIZE",
        "FONT_CACHE_SIZE",
        "POWER_SAVING",
    )
    private val MANAGED_RESOLUTIONS = setOf(1920 to 1080, 1280 to 720, 960 to 540)
    private val MANAGED_SURFACE_CACHE_VALUES = setOf("67108864", "134217728", "268435456")
    private val MANAGED_FONT_CACHE_VALUES = setOf("8388608", "16777216", "33554432", "67108864")

    data class AndroidSettings(
        val resolution: String = "",
        val sideCut: String = "",
        val surfaceCacheSize: String = "",
        val fontCacheSize: String = "",
        val powerSaving: String = "",
    ) {
        fun hasOverrides(): Boolean =
            resolution.isNotBlank() ||
                sideCut.isNotBlank() ||
                surfaceCacheSize.isNotBlank() ||
                fontCacheSize.isNotBlank() ||
                powerSaving.isNotBlank()
    }

    fun needsBasePatch(rootPath: String?): Boolean {
        if (rootPath.isNullOrBlank() || rootPath.startsWith("content://")) return false
        val dir = File(rootPath)
        if (!dir.isDirectory) return false
        val pfsFiles = listPfsFiles(dir)
        if (pfsFiles.isEmpty()) return false
        val systemIni = File(dir, "system.ini")
        if (!systemIni.isFile) return true
        return hasMissingStartupFile(dir, systemIni)
    }

    fun applyBasePatch(rootPath: String?, force: Boolean = false): Boolean {
        if (!force && !needsBasePatch(rootPath)) return true
        val dir = File(rootPath.orEmpty())
        var totalBytes = 0L
        return try {
            for (pfs in listPfsFiles(dir)) {
                totalBytes += unpackPfs(dir, pfs)
                if (totalBytes > MAX_TOTAL_BYTES) {
                    logWarn("base patch total bytes exceed limit, abort")
                    return false
                }
            }
            ensureSystemIni(dir)
            ensureBootFileAvailable(dir)
            true
        } catch (error: Exception) {
            logWarn("apply base patch failed root=$rootPath", error)
            false
        }
    }

    /**
     * Windows 环境补丁（对齐原版 Tyranor `F.K`）：从 PFS 解出 `system.lua`/`init.lua`，
     * 并把其中 `game.os = ...` 行强制改写为 `game.os = "windows"`（幂等：已改写行不再命中）。
     *
     * 无 PFS 封包（已解包目录）时，对目录内既有的同名 lua 文件做兜底改写。
     */
    fun applyWindowsEnvPatch(rootPath: String?): Boolean {
        if (rootPath.isNullOrBlank() || rootPath.startsWith("content://")) return false
        val dir = File(rootPath)
        if (!dir.isDirectory) return false
        return try {
            for (pfs in listPfsFiles(dir)) {
                unpackPfs(dir, pfs, ::shouldExtractWindowsEnvEntry, rewriteWindowsEnv = true)
            }
            for (file in windowsEnvCandidateFiles(dir)) {
                forceGameOsWindows(file)
            }
            true
        } catch (error: Exception) {
            logWarn("apply Windows env patch failed root=$rootPath", error)
            false
        }
    }

    private fun shouldExtractWindowsEnvEntry(relPath: String): Boolean {
        val lower = relPath.lowercase(Locale.ROOT)
        return lower.contains("system.lua") || lower.contains("init.lua")
    }

    /** 无封包场景的兜底位置（目录直放 / system 子目录）。 */
    private fun windowsEnvCandidateFiles(dir: File): List<File> = listOf(
        File(dir, "system.lua"),
        File(dir, "init.lua"),
        File(dir, "system/system.lua"),
        File(dir, "system/init.lua"),
    )

    /** 原版正则：整行匹配 `[\t\s]+?game\.os[\s\t]+?=[^=].+`，命中即整行替换。 */
    private fun forceGameOsWindows(file: File): Boolean {
        if (!file.isFile) return false
        return try {
            val original = file.readText(Charsets.UTF_8)
            val lines = original.split('\n')
            val rewritten = buildString {
                lines.forEachIndexed { index, line ->
                    append(if (GAME_OS_LINE_RE.matches(line)) "game.os = \"windows\"" else line)
                    if (index != lines.lastIndex) append('\n')
                }
            }
            if (rewritten == original) return false
            file.writeText(rewritten, Charsets.UTF_8)
            logInfo("patched Windows env ${file.path}")
            true
        } catch (error: Exception) {
            logWarn("patch Windows env failed ${file.path}", error)
            false
        }
    }

    fun applyAndroidSettings(rootPath: String?, settings: AndroidSettings): Boolean {
        if (rootPath.isNullOrBlank() || rootPath.startsWith("content://")) return false
        val dir = File(rootPath)
        if (!dir.isDirectory) return false
        val systemIni = File(dir, "system.ini")
        if (!systemIni.isFile) {
            if (!settings.hasOverrides()) return true
            if (!extractSystemIniIfMissing(dir)) {
                logWarn("skip Artemis Android settings: system.ini missing root=$rootPath")
                return false
            }
        }
        return runCatching {
            val bytes = systemIni.readBytes()
            val charset = detectSystemIniCharset(bytes)
            val text = String(bytes, charset)
            val patched = if (settings.hasOverrides()) {
                ensureAndroidCompatibilityDefaults(patchAndroidSection(text, settings))
            } else {
                restoreAndroidSectionDefaults(text)
            }
            if (patched != text) {
                systemIni.writeText(patched, charset)
                logInfo("applied Artemis Android settings root=$rootPath settings=$settings")
            }
            true
        }.getOrElse { error ->
            logWarn("apply Artemis Android settings failed root=$rootPath", error)
            false
        }
    }

    private fun extractSystemIniIfMissing(dir: File): Boolean {
        val systemIni = File(dir, "system.ini")
        if (systemIni.isFile) return true
        return runCatching {
            for (pfs in listPfsFiles(dir)) {
                val written = unpackPfs(
                    gameDir = dir,
                    pfs = pfs,
                    shouldExtractEntry = { relPath -> relPath.equals("system.ini", ignoreCase = true) },
                )
                if (written > 0 && systemIni.isFile) {
                    logInfo("extracted system.ini from ${pfs.name}")
                    return true
                }
            }
            systemIni.isFile
        }.getOrElse { error ->
            logWarn("extract system.ini failed dir=${dir.path}", error)
            false
        }
    }

    private fun listPfsFiles(dir: File): List<File> {
        val files = runCatching { dir.listFiles()?.filter { it.isFile && isPfsName(it.name) } }
            .getOrNull() ?: return emptyList()
        return files.sortedBy { it.name.lowercase(Locale.ROOT) }
    }

    private fun isPfsName(name: String): Boolean {
        val lower = name.lowercase(Locale.ROOT)
        return lower.endsWith(".pfs") || Regex("^[^.]+\\.pfs\\.\\d{3}$").matches(lower)
    }

    private fun unpackPfs(
        gameDir: File,
        pfs: File,
        shouldExtractEntry: (String) -> Boolean = ::shouldExtract,
        rewriteWindowsEnv: Boolean = false,
    ): Long {
        var written = 0L
        var entries = 0
        RandomAccessFile(pfs, "r").use { raf ->
            if (raf.read() != 0x70 || raf.read() != 0x66) {
                return written
            }
            // 第 3 字节是版本字符（'8' 等）：原版以版本号 >= 8 判定数据是否 XOR 加密
            val versionChar = raf.read()
            val version = if (versionChar in '0'.code..'9'.code) versionChar - '0'.code else 8
            val encryptedData = version >= 8
            val tableLen = readM(raf)
            if (tableLen <= 0 || tableLen > MAX_ENTRY_BYTES) {
                logWarn("invalid pfs table length $tableLen")
                return written
            }
            val tableStart = raf.filePointer
            val table = ByteArray(tableLen)
            raf.readFully(table)
            val key = MessageDigest.getInstance("SHA-1").digest(table)
            raf.seek(tableStart)
            val entryCount = readM(raf)
            if (entryCount < 0 || entryCount > MAX_ENTRY_COUNT) {
                logWarn("invalid pfs entry count $entryCount")
                return written
            }
            val fileLength = raf.length()
            for (i in 0 until entryCount) {
                val nameLen = readM(raf)
                if (nameLen < 0 || nameLen > MAX_NAME_BYTES) {
                    logWarn("invalid pfs entry name length $nameLen")
                    return written
                }
                val nameBytes = ByteArray(nameLen)
                raf.readFully(nameBytes)
                val rawName = String(nameBytes, UTF_8)
                readM(raf)
                val offset = readM(raf).toLong()
                val dataLen = readM(raf).toLong()
                val relPath = rawName.replace('\\', '/')
                if (!shouldExtractEntry(relPath)) continue
                if (offset < 0 || dataLen < 0 || offset + dataLen > fileLength || dataLen > MAX_ENTRY_DATA_BYTES) {
                    logWarn("invalid pfs entry bounds name=$rawName offset=$offset len=$dataLen")
                    continue
                }
                val target = safeTarget(gameDir, relPath) ?: continue
                val writtenBytes = writeEntryStream(raf, offset, dataLen, key, encryptedData, target) ?: continue
                written += writtenBytes
                entries++
                postProcessEntry(target, relPath, rewriteWindowsEnv)
            }
        }
        logInfo("unpacked ${pfs.name}: entries=$entries bytes=$written")
        return written
    }

    private fun shouldExtract(relPath: String): Boolean {
        val lower = relPath.lowercase(Locale.ROOT)
        if (lower == "system.ini") return true
        if (isArtemisStartupSystemFile(lower)) return true
        if (!lower.contains("movie")) return false
        return lower.endsWith(".dat") || lower.endsWith(".mp4") || lower.endsWith(".ogv") ||
            lower.endsWith(".wmv") || lower.endsWith(".mpg") || lower.endsWith(".webm")
    }

    private fun isArtemisStartupSystemFile(lowerRelPath: String): Boolean {
        if (!lowerRelPath.startsWith("system/")) return false
        if (lowerRelPath.contains("/../")) return false
        return lowerRelPath.endsWith(".iet") ||
            lowerRelPath.endsWith(".lua") ||
            lowerRelPath.endsWith(".asb") ||
            lowerRelPath.endsWith(".tbl") ||
            lowerRelPath.endsWith(".glsl") ||
            lowerRelPath.endsWith(".ini") ||
            lowerRelPath.endsWith(".json") ||
            lowerRelPath.endsWith(".txt")
    }

    /**
     * 流式解出条目到目标文件：按 [COPY_BUFFER_BYTES] 分块读 + XOR（index 为条目内绝对偏移），
     * 避免大视频（数百 MB）一次性分配内存导致 OOM。返回写出字节数；失败返回 null。
     */
    private fun writeEntryStream(
        raf: RandomAccessFile,
        offset: Long,
        dataLen: Long,
        key: ByteArray,
        encrypted: Boolean,
        target: File,
    ): Long? {
        val parent = target.parentFile ?: return null
        if (!parent.exists() && !parent.mkdirs()) {
            logWarn("cannot create directory ${parent.path}")
            return null
        }
        val saved = raf.filePointer
        return try {
            raf.seek(offset)
            var remaining = dataLen
            var index = 0L
            FileOutputStream(target).use { out ->
                val buffer = ByteArray(COPY_BUFFER_BYTES)
                while (remaining > 0) {
                    val toRead = minOf(remaining, buffer.size.toLong()).toInt()
                    val read = raf.read(buffer, 0, toRead)
                    if (read <= 0) {
                        logWarn("unexpected EOF while extracting ${target.name}")
                        return null
                    }
                    if (encrypted) {
                        for (i in 0 until read) {
                            buffer[i] = (buffer[i].toInt() xor key[((index + i) % key.size).toInt()].toInt()).toByte()
                        }
                    }
                    out.write(buffer, 0, read)
                    index += read
                    remaining -= read
                }
            }
            dataLen
        } catch (error: Exception) {
            logWarn("write entry failed ${target.path}", error)
            null
        } finally {
            raf.seek(saved)
        }
    }

    private fun safeTarget(gameDir: File, relPath: String): File? {
        if (relPath.isBlank()) return null
        val root = runCatching { gameDir.canonicalFile }.getOrElse { gameDir.absoluteFile }
        val target = File(root, relPath)
        val canonical = runCatching { target.canonicalFile }.getOrElse { return null }
        if (canonical != root && !canonical.path.startsWith(root.path + File.separator)) {
            logWarn("blocked path traversal entry=$relPath")
            return null
        }
        return canonical
    }

    private fun postProcessEntry(target: File, relPath: String, rewriteWindowsEnv: Boolean) {
        val lower = relPath.lowercase(Locale.ROOT)
        when {
            lower.contains("system.ini") -> patchSystemIni(target)
            lower.contains("list_windows") -> renameListWindows(target)
            rewriteWindowsEnv && (lower.contains("system.lua") || lower.contains("init.lua")) ->
                forceGameOsWindows(target)
        }
    }

    /**
     * 基础补丁的 system.ini 处理：对齐原版 `F.J` —— **整体重写**为最小 `[ANDROID]` 段
     * （丢弃原文件其余段与注释），WIDTH/HEIGHT 继承 `[WINDOWS]`（缺省 1280x720），
     * 原文件出现过 CHARSET 才输出 `CHARSET = UTF-8`。
     * 引擎设置中的分辨率/裁切等覆盖由启动链的 [applyAndroidSettings] 再次注入。
     */
    private fun patchSystemIni(file: File) {
        try {
            val bytes = file.readBytes()
            val charset = detectSystemIniCharset(bytes)
            val text = String(bytes, charset)
            val rewritten = buildAndroidOnlySystemIni(text)
            file.writeText(rewritten, Charsets.UTF_8)
            logInfo("patched system.ini (Android-only) ${file.path}")
        } catch (error: Exception) {
            logWarn("patch system.ini failed ${file.path}", error)
        }
    }

    private fun buildAndroidOnlySystemIni(text: String): String {
        var hasCharset = false
        var inWindowsSection = false
        var widthLine = "WIDTH = 1280"
        var heightLine = "HEIGHT = 720"
        for (raw in text.split('\n')) {
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith(";")) continue
            if (line.startsWith("[") && line.endsWith("]")) {
                inWindowsSection = line.substring(1, line.length - 1).trim().equals("WINDOWS", ignoreCase = true)
                continue
            }
            if (line.contains("CHARSET", ignoreCase = true)) hasCharset = true
            if (inWindowsSection) {
                if (line.startsWith("WIDTH", ignoreCase = true)) widthLine = line
                if (line.startsWith("HEIGHT", ignoreCase = true)) heightLine = line
            }
        }
        return buildString {
            append("[ANDROID]\n")
            append(widthLine).append('\n')
            append(heightLine).append('\n')
            append("SIDECUT = 0\n")
            append("BOOT = system/first.iet\n")
            append("FONT_CACHE_SIZE = 8388608")
            if (hasCharset) append("\nCHARSET = UTF-8")
        }
    }

    /**
     * 对齐原版：`list_windows*` → `list_android*`，目标已存在时**覆盖**（原版为 rename 覆盖语义）；
     * 重命名后的 `list_android.tbl` 再翻转 tablet 开关。
     */
    private fun renameListWindows(file: File) {
        try {
            val target = File(file.parentFile, file.name.replace("list_windows", "list_android"))
            if (target.exists()) target.delete()
            if (file.exists() && file.renameTo(target)) {
                logInfo("renamed ${file.name} -> ${target.name} (overwrite)")
                if (target.name.equals("list_android.tbl", ignoreCase = true)) {
                    flipListAndroidTblConfig(target)
                }
            }
        } catch (error: Exception) {
            logWarn("rename list_windows failed ${file.path}", error)
        }
    }

    private fun flipListAndroidTblConfig(file: File) {
        try {
            val out = buildString {
                file.readLines(UTF_8).forEach { raw ->
                    val key = raw.trim().lowercase(Locale.ROOT)
                    when {
                        key.contains("config_tablet=0") -> append("config_tablet=1,\n")
                        key.contains("config_tabletui=0") -> append("config_tabletui=1,\n")
                        else -> {
                            append(raw)
                            append("\n")
                        }
                    }
                }
            }
            file.writeText(out, UTF_8)
        } catch (error: Exception) {
            logWarn("flip list_android.tbl config failed ${file.path}", error)
        }
    }

    private fun ensureSystemIni(dir: File) {
        val file = File(dir, "system.ini")
        if (file.exists()) return
        try {
            file.writeText(
                buildString {
                    appendLine("[SYSTEM]")
                    appendLine("WIDTH = 1280")
                    appendLine("HEIGHT = 720")
                    appendLine("CHARSET = UTF-8")
                    appendLine()
                    appendLine("[ANDROID]")
                    appendLine("SIDECUT = 0")
                    appendLine("BOOT = system/first.iet")
                    appendLine("FONT_CACHE_SIZE = 8388608")
                },
                UTF_8,
            )
            logInfo("generated fallback system.ini at ${file.path}")
        } catch (error: Exception) {
            logWarn("generate system.ini failed ${file.path}", error)
        }
    }

    private fun ensureBootFileAvailable(dir: File) {
        val systemIni = File(dir, "system.ini")
        val bootPath = readBootPath(systemIni) ?: DEFAULT_ANDROID_BOOT
        val bootFile = safeTarget(dir, bootPath)
        if (bootFile?.isFile == true) return
        logWarn("Artemis BOOT script still missing after base patch: $bootPath")
    }

    private fun hasMissingStartupFile(dir: File, systemIni: File): Boolean {
        val bootPath = readBootPath(systemIni) ?: DEFAULT_ANDROID_BOOT
        val bootFile = safeTarget(dir, bootPath)
        if (bootFile?.isFile != true) return true

        // Android Artemis 启动脚本通常立刻 include system/init.lua，随后 init.lua 再挂载
        // system/adv、system/ui、system/table 等基础系统脚本/表。若这些仍留在 PFS 内，
        // 部分 native revision 首屏会只完成窗口初始化但无法进入标题画面。
        if (!File(dir, "system/init.lua").isFile) return true
        if (!File(dir, "system/table/list_android.tbl").isFile &&
            !File(dir, "system/table/list_android_ja.tbl").isFile
        ) return true
        return false
    }

    private fun readBootPath(systemIni: File): String? {
        if (!systemIni.isFile) return null
        val lines = runCatching { systemIni.readLines(UTF_8) }
            .getOrElse {
                runCatching { systemIni.readLines(Charsets.ISO_8859_1) }.getOrNull()
            }
            ?: return null
        var section = ""
        var androidBoot: String? = null
        var firstBoot: String? = null
        for (raw in lines) {
            val line = raw.substringBefore(';').trim()
            if (line.isEmpty()) continue
            if (line.startsWith("[") && line.endsWith("]")) {
                section = line.substring(1, line.length - 1).trim().uppercase(Locale.ROOT)
                continue
            }
            val equals = line.indexOf('=')
            if (equals <= 0) continue
            val key = line.substring(0, equals).trim().uppercase(Locale.ROOT)
            if (key != "BOOT") continue
            val value = line.substring(equals + 1)
                .trim()
                .trim('"')
                .replace('\\', '/')
                .takeIf { it.isNotBlank() }
                ?: continue
            if (firstBoot == null) firstBoot = value
            if (section == "ANDROID") androidBoot = value
        }
        return androidBoot ?: firstBoot
    }

    private fun ensureAndroidCompatibilityDefaults(text: String): String {
        val lines = text.split('\n').toMutableList()
        var androidBounds = findSectionBounds(lines, "ANDROID")
        if (androidBounds == null) {
            if (lines.isNotEmpty() && lines.last().isNotEmpty()) lines += ""
            lines += "[ANDROID]"
            androidBounds = findSectionBounds(lines, "ANDROID") ?: return text
        }

        val androidRange = androidBounds.contentStart until androidBounds.contentEndExclusive
        val updates = linkedMapOf<String, String>()
        val inheritedResolution = readResolutionFromSections(
            lines,
            listOf("ANDROID", "SYSTEM", "WINDOWS", "IOS", "WASM"),
        ) ?: (1280 to 720)
        if (readSectionValue(lines, androidRange, "WIDTH").isNullOrBlank()) {
            updates["WIDTH"] = inheritedResolution.first.toString()
        }
        if (readSectionValue(lines, androidRange, "HEIGHT").isNullOrBlank()) {
            updates["HEIGHT"] = inheritedResolution.second.toString()
        }
        if (readSectionValue(lines, androidRange, "SIDECUT").isNullOrBlank()) {
            updates["SIDECUT"] = "0"
        }
        if (readSectionValue(lines, androidRange, "BOOT").isNullOrBlank()) {
            updates["BOOT"] = readFirstValueFromSections(
                lines,
                listOf("ANDROID", "SYSTEM", "WINDOWS", "IOS", "WASM"),
                "BOOT",
            ) ?: DEFAULT_ANDROID_BOOT
        }
        if (readSectionValue(lines, androidRange, "FONT_CACHE_SIZE").isNullOrBlank()) {
            updates["FONT_CACHE_SIZE"] = "8388608"
        }
        if (updates.isEmpty()) return text

        val insertion = updates.map { (key, value) -> "$key = $value" }
        lines.addAll(androidBounds.contentEndExclusive, insertion)
        return lines.joinToString("\n")
    }

    private fun patchAndroidSection(text: String, settings: AndroidSettings): String {
        val updates = linkedMapOf<String, String>()
        parseResolution(settings.resolution)?.let { (width, height) ->
            updates["WIDTH"] = width.toString()
            updates["HEIGHT"] = height.toString()
        }
        if (settings.sideCut.isNotBlank()) updates["SIDECUT"] = settings.sideCut
        if (settings.surfaceCacheSize.isNotBlank()) updates["SURFACE_CACHE_SIZE"] = settings.surfaceCacheSize
        if (settings.fontCacheSize.isNotBlank()) updates["FONT_CACHE_SIZE"] = settings.fontCacheSize
        if (settings.powerSaving.isNotBlank()) updates["POWER_SAVING"] = settings.powerSaving
        if (updates.isEmpty()) return text

        val lines = removeLegacyManagedAndroidLines(removeManagedAndroidBlock(text.split('\n'))).toMutableList()
        var androidStart = -1
        var androidEnd = lines.size
        for (i in lines.indices) {
            val section = lines[i].substringBefore(';').trim()
            if (!section.startsWith("[") || !section.endsWith("]")) continue
            val name = section.substring(1, section.length - 1).trim().uppercase(Locale.ROOT)
            if (name == "ANDROID") {
                androidStart = i
                androidEnd = lines.size
            } else if (androidStart >= 0) {
                androidEnd = i
                break
            }
        }
        if (androidStart < 0) {
            if (lines.isNotEmpty() && lines.last().isNotEmpty()) lines += ""
            lines += "[ANDROID]"
            androidStart = lines.lastIndex
            androidEnd = lines.size
        }

        val block = buildList {
            add(MANAGED_BLOCK_BEGIN)
            updates.forEach { (key, value) -> add("$key = $value") }
            add(MANAGED_BLOCK_END)
        }
        lines.addAll(androidEnd, block)
        return lines.joinToString("\n")
    }

    private fun restoreAndroidSectionDefaults(text: String): String {
        val originalLines = text.split('\n')
        val withoutBlock = removeManagedAndroidBlock(originalLines)
        return ensureAndroidCompatibilityDefaults(
            removeLegacyManagedAndroidLines(withoutBlock).joinToString("\n"),
        )
    }

    private fun removeManagedAndroidBlock(lines: List<String>): List<String> {
        val out = mutableListOf<String>()
        var inBlock = false
        for (line in lines) {
            when (line.trim()) {
                MANAGED_BLOCK_BEGIN -> inBlock = true
                MANAGED_BLOCK_END -> inBlock = false
                else -> if (!inBlock) out += line
            }
        }
        return out
    }

    private fun removeLegacyManagedAndroidLines(lines: List<String>): List<String> {
        val androidRange = findAndroidSectionRange(lines) ?: return lines
        val width = readSectionValue(lines, androidRange, "WIDTH")?.toIntOrNull()
        val height = readSectionValue(lines, androidRange, "HEIGHT")?.toIntOrNull()
        val legacyResolution = width != null && height != null && (width to height) in MANAGED_RESOLUTIONS
        return lines.filterIndexed { index, line ->
            if (index !in androidRange) return@filterIndexed true
            val parsed = parseIniAssignment(line) ?: return@filterIndexed true
            val (key, value) = parsed
            if (key !in MANAGED_ANDROID_KEYS) return@filterIndexed true
            !isLegacyManagedValue(key, value, legacyResolution)
        }
    }

    private fun findAndroidSectionRange(lines: List<String>): IntRange? {
        val bounds = findSectionBounds(lines, "ANDROID") ?: return null
        return bounds.contentStart until bounds.contentEndExclusive
    }

    private data class SectionBounds(
        val headerIndex: Int,
        val contentStart: Int,
        val contentEndExclusive: Int,
    )

    private fun findSectionBounds(lines: List<String>, sectionName: String): SectionBounds? {
        var headerIndex = -1
        var contentStart = -1
        var contentEndExclusive = lines.size
        val wanted = sectionName.uppercase(Locale.ROOT)
        for (i in lines.indices) {
            val section = lines[i].substringBefore(';').trim()
            if (!section.startsWith("[") || !section.endsWith("]")) continue
            val name = section.substring(1, section.length - 1).trim().uppercase(Locale.ROOT)
            if (name == wanted) {
                headerIndex = i
                contentStart = i + 1
                contentEndExclusive = lines.size
            } else if (headerIndex >= 0) {
                contentEndExclusive = i
                break
            }
        }
        return if (headerIndex >= 0) {
            SectionBounds(headerIndex, contentStart, contentEndExclusive)
        } else {
            null
        }
    }

    private fun readSectionValue(lines: List<String>, range: IntRange, key: String): String? {
        for (i in range) {
            val parsed = parseIniAssignment(lines[i]) ?: continue
            if (parsed.first == key) return parsed.second
        }
        return null
    }

    private fun readFirstValueFromSections(lines: List<String>, sections: List<String>, key: String): String? {
        for (section in sections) {
            val bounds = findSectionBounds(lines, section) ?: continue
            val value = readSectionValue(lines, bounds.contentStart until bounds.contentEndExclusive, key)
            if (!value.isNullOrBlank()) return value
        }
        return null
    }

    private fun readResolutionFromSections(lines: List<String>, sections: List<String>): Pair<Int, Int>? {
        for (section in sections) {
            val bounds = findSectionBounds(lines, section) ?: continue
            val range = bounds.contentStart until bounds.contentEndExclusive
            val width = readSectionValue(lines, range, "WIDTH")?.toIntOrNull()
            val height = readSectionValue(lines, range, "HEIGHT")?.toIntOrNull()
            if (width != null && height != null) return width to height
        }
        return null
    }

    private fun parseIniAssignment(line: String): Pair<String, String>? {
        val withoutComment = line.substringBefore(';')
        val equals = withoutComment.indexOf('=')
        if (equals <= 0) return null
        val key = withoutComment.substring(0, equals).trim().uppercase(Locale.ROOT)
        val value = withoutComment.substring(equals + 1).trim().trim('"')
        return key to value
    }

    private fun isLegacyManagedValue(key: String, value: String, legacyResolution: Boolean): Boolean =
        when (key) {
            "WIDTH", "HEIGHT" -> legacyResolution
            "SIDECUT", "POWER_SAVING" -> value == "0" || value == "1"
            "SURFACE_CACHE_SIZE" -> value in MANAGED_SURFACE_CACHE_VALUES
            "FONT_CACHE_SIZE" -> value in MANAGED_FONT_CACHE_VALUES
            else -> false
        }

    private fun parseResolution(value: String): Pair<Int, Int>? {
        val parts = value.lowercase(Locale.ROOT).split('x')
        if (parts.size != 2) return null
        val width = parts[0].trim().toIntOrNull() ?: return null
        val height = parts[1].trim().toIntOrNull() ?: return null
        if (width !in 320..4096 || height !in 240..2160) return null
        return width to height
    }

    private fun detectSystemIniCharset(bytes: ByteArray): Charset {
        if (bytes.size >= 3 &&
            bytes[0] == 0xEF.toByte() &&
            bytes[1] == 0xBB.toByte() &&
            bytes[2] == 0xBF.toByte()
        ) {
            return UTF_8
        }
        val utf8 = runCatching { String(bytes, UTF_8) }.getOrNull()
        if (utf8 != null && Regex("(?im)^\\s*CHARSET\\s*=\\s*UTF-?8\\s*$").containsMatchIn(utf8)) {
            return UTF_8
        }
        return runCatching { Charset.forName("Shift_JIS") }.getOrDefault(UTF_8)
    }

    private fun readM(raf: RandomAccessFile): Int {
        val b0 = raf.read()
        val b1 = raf.read()
        val b2 = raf.read()
        val b3 = raf.read()
        if (b0 < 0 || b1 < 0 || b2 < 0 || b3 < 0) throw EOFException("pfs truncated")
        return ((b3 shl 24) or (b2 shl 16) or (b1 shl 8) or b0) and 0x7fffffff
    }

    private fun logInfo(message: String) {
        runCatching { Log.i(TAG, message) }
    }

    private fun logWarn(message: String, error: Throwable? = null) {
        runCatching { if (error == null) Log.w(TAG, message) else Log.w(TAG, message, error) }
    }

    private const val DEFAULT_ANDROID_BOOT = "system/first.iet"
}
