package com.tyranor.next.ui.common

import android.content.Context
import com.tyranor.next.R
import com.tyranor.next.core.engine.external.ExternalEngineErrorCode
import com.tyranor.next.core.engine.plugin.EnginePluginBootstrap
import com.tyranor.next.core.engine.runtime.RuntimeModuleLaunchResult
import com.tyranor.next.core.game.launch.LaunchResult
import com.tyranor.next.core.game.launch.ImpactoPrepareError
import com.tyranor.next.core.game.launch.EthornellPrepareError
import com.tyranor.next.core.game.launch.SystemNnnResourceError
import com.tyranor.next.core.game.launch.MirrorPrepareStage
import com.tyranor.next.core.i18n.AppLocaleController

/**
 * 启动结果 → 用户文案映射（P0-6）：core 只返回 [LaunchResult] 类型，
 * 本地化文案统一在 UI 层组装，调用点无需自行 when 分支。
 */

/** 成功返回 null；失败返回可直接展示的本地化文案。 */
fun LaunchResult.userMessage(context: Context): String? = when (this) {
    LaunchResult.Success -> null
    is LaunchResult.Failure -> toUserMessage(context)
}

private fun LaunchResult.Failure.toUserMessage(context: Context): String {
    val localized = AppLocaleController.wrap(context)
    return when (this) {
        LaunchResult.Failure.GameDirUnresolved ->
            localized.getString(R.string.launch_resolve_local_dir_failed)

        is LaunchResult.Failure.SavePreparationFailed -> localized.getString(error.syncErrorResource())

        is LaunchResult.Failure.SystemNnnResourcesFailed -> localized.getString(when (error) {
            SystemNnnResourceError.SOURCE_MISSING -> R.string.launch_systemnnn_source_missing
            SystemNnnResourceError.STORAGE_RESTRICTED -> R.string.launch_systemnnn_storage_restricted
            SystemNnnResourceError.INVALID_SOURCE -> R.string.launch_systemnnn_invalid_source
            SystemNnnResourceError.SOURCE_BUSY -> R.string.launch_systemnnn_source_busy
            SystemNnnResourceError.CORRUPT_COPY -> R.string.launch_systemnnn_corrupt_copy
            SystemNnnResourceError.SAVE_NOT_WRITABLE -> R.string.launch_systemnnn_save_not_writable
        })

        is LaunchResult.Failure.ImpactoPrepareFailed -> localized.getString(when (error) {
            ImpactoPrepareError.ANDROID_VERSION -> R.string.impacto_error_android
            ImpactoPrepareError.ABI -> R.string.impacto_error_abi
            ImpactoPrepareError.GLES -> R.string.impacto_error_gles
            ImpactoPrepareError.DESCRIPTOR -> R.string.impacto_error_descriptor
            ImpactoPrepareError.PROFILE -> R.string.impacto_error_profile
            ImpactoPrepareError.GAME_LAYOUT -> R.string.impacto_error_game_layout
            ImpactoPrepareError.RESOURCES -> R.string.impacto_error_resources
            ImpactoPrepareError.USER_DATA -> R.string.impacto_error_user_data
            ImpactoPrepareError.SESSION_BUSY -> R.string.impacto_error_busy
            ImpactoPrepareError.PREPARATION -> R.string.impacto_error_preparation
            ImpactoPrepareError.RUNTIME -> R.string.impacto_runtime_not_bundled
        })

        is LaunchResult.Failure.EthornellPrepareFailed -> localized.getString(when (error) {
            EthornellPrepareError.RESOURCE_ROOT -> R.string.ethornell_error_root
            EthornellPrepareError.BOOTSTRAP -> R.string.ethornell_error_bootstrap
            EthornellPrepareError.FONT -> R.string.ethornell_error_font
            EthornellPrepareError.USER_DATA -> R.string.ethornell_error_userdata
            EthornellPrepareError.SESSION_BUSY -> R.string.ethornell_error_session_busy
        })

        LaunchResult.Failure.AllFilesAccessRequested ->
            localized.getString(R.string.launch_all_files_access_request)

        LaunchResult.Failure.AllFilesAccessMissing ->
            localized.getString(R.string.launch_all_files_access_missing)

        LaunchResult.Failure.StorageAccessRequested ->
            localized.getString(R.string.launch_storage_access_request)

        LaunchResult.Failure.StorageAccessMissing ->
            localized.getString(R.string.launch_storage_access_missing)

        is LaunchResult.Failure.PluginBootstrapFailed -> when (val reason = reason) {
            is EnginePluginBootstrap.Failure.UnknownEngine ->
                localized.getString(R.string.plugin_unknown_engine, reason.engineId)
            EnginePluginBootstrap.Failure.InstallFailed ->
                localized.getString(R.string.plugin_install_failed)
        }

        is LaunchResult.Failure.EngineLibraryPackFailed ->
            localized.getString(R.string.launch_engine_library_pack_failed)

        // 镜像准备失败的文案按类型化阶段映射：底层异常 message 是日志线索，
        // 不同失败原因给用户的处置方式不同（重新授权 vs 清理存储空间）
        is LaunchResult.Failure.KrkrMirrorPrepareFailed -> when (stage) {
            MirrorPrepareStage.SOURCE_UNRESOLVED ->
                localized.getString(R.string.launch_prepare_krkr_sd_mirror_failed)

            MirrorPrepareStage.EMPTY_MIRROR ->
                localized.getString(R.string.launch_empty_krkr_sd_mirror)

            MirrorPrepareStage.CREATE_FAILED -> localized.getString(
                R.string.launch_create_krkr_mirror_failed,
                name ?: localized.getString(R.string.launch_create_krkr_mirror_unknown_path),
            )
        }

        is LaunchResult.Failure.KrkrSavePathNotDirectory ->
            localized.getString(R.string.launch_krkr_save_path_not_dir, path)

        is LaunchResult.Failure.KrkrSaveDirUnavailable ->
            if (scoped) {
                localized.getString(R.string.launch_create_krkr_scoped_save_failed, path)
            } else {
                localized.getString(R.string.launch_create_krkr_save_failed, path)
            }

        is LaunchResult.Failure.KrkrMirrorSaveDirFailed ->
            localized.getString(R.string.launch_create_krkr_mirror_save_failed)

        is LaunchResult.Failure.Xs35SavePathNotDirectory ->
            localized.getString(R.string.launch_error_xs35_save_path_not_directory, path)

        is LaunchResult.Failure.Xs35SaveDirUnavailable ->
            if (path == null || path.isEmpty()) {
                localized.getString(R.string.launch_error_xs35_external_unavailable)
            } else {
                localized.getString(R.string.launch_error_xs35_save_dir_unavailable, path)
            }

        is LaunchResult.Failure.Xs4SavePathNotDirectory ->
            localized.getString(R.string.launch_error_xs4_save_path_not_directory, path)

        is LaunchResult.Failure.Xs4SaveDirUnavailable ->
            if (path == null || path.isEmpty()) {
                localized.getString(R.string.launch_error_xs4_external_unavailable)
            } else {
                localized.getString(R.string.launch_error_xs4_save_dir_unavailable, path)
            }

        LaunchResult.Failure.Xs4IniMissing ->
            localized.getString(R.string.launch_error_xs4_ini_missing)

        LaunchResult.Failure.Xs4Gles3Required ->
            localized.getString(R.string.launch_error_xs4_gles3_required)

        is LaunchResult.Failure.ExternalModuleFailed -> {
            val moduleName = result.moduleNameRes?.let { localized.getString(it) }
                ?: result.moduleNameFallback.orEmpty()
            when (result.error) {
                ExternalEngineErrorCode.INVALID_GAME_PATH ->
                    localized.getString(R.string.external_engine_resolve_dir_failed, result.engineName.orEmpty())

                ExternalEngineErrorCode.PACKAGE_NOT_INSTALLED ->
                    localized.getString(R.string.external_engine_module_missing, moduleName)

                ExternalEngineErrorCode.PREPARE_FAILED ->
                    result.messageRes?.let { localized.getString(it) }
                        ?: result.detail
                        ?: localized.getString(R.string.external_engine_launch_failed, moduleName)

                ExternalEngineErrorCode.ACTIVITY_NOT_FOUND ->
                    localized.getString(R.string.external_engine_no_activity, moduleName)

                ExternalEngineErrorCode.SECURITY_EXCEPTION ->
                    localized.getString(R.string.external_engine_denied, moduleName)

                ExternalEngineErrorCode.LAUNCH_EXCEPTION, null ->
                    result.detail ?: localized.getString(R.string.external_engine_launch_failed, moduleName)
            }
        }

        is LaunchResult.Failure.ExternalEmulatorFailed -> {
            val targetName = localized.getString(result.target.displayNameRes)
            when (result.code) {
                "package_not_installed" ->
                    localized.getString(R.string.launch_emulator_missing, targetName)

                "activity_not_found" ->
                    localized.getString(R.string.launch_emulator_no_activity, targetName)

                // 已安装但不支持外置启动的旧版 Winlator（缺少导出入口）
                "external_launch_unsupported" ->
                    localized.getString(R.string.launch_emulator_unsupported, targetName)

                "security_exception" ->
                    localized.getString(R.string.launch_emulator_denied, targetName)

                else ->
                    localized.getString(R.string.launch_emulator_failed, targetName)
            }
        }

        LaunchResult.Failure.YurisExeMissing ->
            localized.getString(R.string.launch_yuris_exe_missing)

        // 第三方运行时模块：文案按模块层类型化结果映射；StartFailed 的 detail 仅在非空时优先。
        is LaunchResult.Failure.RuntimeModuleFailed -> when (val outcome = result) {
            RuntimeModuleLaunchResult.ModuleMissing ->
                localized.getString(R.string.launch_runtime_module_missing)

            RuntimeModuleLaunchResult.ModuleDisabled ->
                localized.getString(R.string.launch_runtime_module_disabled)

            RuntimeModuleLaunchResult.EntryMissing ->
                localized.getString(R.string.launch_runtime_module_entry_missing)

            RuntimeModuleLaunchResult.PathUnresolved ->
                localized.getString(R.string.launch_runtime_module_path_unresolved)

            RuntimeModuleLaunchResult.SecurityDenied ->
                localized.getString(R.string.launch_runtime_module_denied)

            is RuntimeModuleLaunchResult.StartFailed -> {
                android.util.Log.w("LaunchErrorMessages", "runtime module start failed: ${outcome.detail.orEmpty()}")
                localized.getString(R.string.launch_runtime_module_failed)
            }

            // Dispatched 不应作为失败出现：给通用失败文案兜底。
            RuntimeModuleLaunchResult.Dispatched ->
                localized.getString(R.string.launch_runtime_module_failed)
        }

        LaunchResult.Failure.CmvsGameLayoutInvalid ->
            localized.getString(R.string.launch_cmvs_layout_invalid)

        LaunchResult.Failure.CmvsUserDataDirUnavailable ->
            localized.getString(R.string.launch_cmvs_user_data_unavailable)

        LaunchResult.Failure.CmvsLaunchConfigUnavailable ->
            localized.getString(R.string.launch_cmvs_launch_config_unavailable)

        is LaunchResult.Failure.CmvsInitFailed -> localized.getString(
            when ((this as LaunchResult.Failure.CmvsInitFailed).code) {
                "unregistered" -> R.string.launch_cmvs_unregistered
                "audio" -> R.string.launch_cmvs_audio_unavailable
                "vulkan" -> R.string.launch_cmvs_vulkan_unavailable
                "font" -> R.string.launch_cmvs_font_unavailable
                else -> R.string.launch_cmvs_init_failed
            },
        )

        LaunchResult.Failure.CmvsFontUnavailable ->
            localized.getString(R.string.launch_cmvs_font_unavailable)

        LaunchResult.Failure.CmvsVulkanUnavailable ->
            localized.getString(R.string.launch_cmvs_vulkan_unavailable)

        LaunchResult.Failure.CmvsAlreadyRunning ->
            localized.getString(R.string.launch_cmvs_already_running)

        LaunchResult.Failure.AndroidAppMissing ->
            localized.getString(R.string.launch_android_app_missing)

        LaunchResult.Failure.EngineUnknown ->
            localized.getString(R.string.launch_engine_unknown)

        is LaunchResult.Failure.StartFailed ->
            detail ?: localized.getString(R.string.launch_failed)
    }
}
