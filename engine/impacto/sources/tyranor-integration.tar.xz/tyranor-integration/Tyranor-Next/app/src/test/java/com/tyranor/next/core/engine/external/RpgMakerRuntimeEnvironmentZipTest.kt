package com.tyranor.next.core.engine.external

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

/**
 * RTP 导入的 ZIP 解压上限回归。
 *
 * 重点覆盖「被过滤条目」这条绕过通道：`__MACOSX/` 与 `.DS_Store` 条目会被跳过，
 * 而 ZipInputStream 是顺序流——跳过必须读掉该条目的全部数据，`closeEntry()` 会把
 * DEFLATED 条目**完整解压**（实测 255KB 的 zip、条目解压后 256MB，光 closeEntry()
 * 就耗时 586ms）。因此跳过分支若不做有界读取，就能绕过单条目与总量上限。
 * 又因为流式 zip 的 `entry.size` 恒为 -1，声明大小检查在此类 zip 上完全失效，
 * 必须靠读取时的计数兜底——这也是本测试注入小上限即可复现的原因。
 */
class RpgMakerRuntimeEnvironmentZipTest {

    @get:Rule
    val temporaryFolder = TemporaryFolder()

    /** 构造 zip：`entries` 为 名字 → 字节数（用于制造高压缩比的重复数据）。 */
    private fun buildZip(entries: List<Triple<String, Int, ByteArray?>>): ByteArray {
        val bos = ByteArrayOutputStream()
        ZipOutputStream(bos).use { zip ->
            entries.forEach { (name, size, literal) ->
                zip.putNextEntry(ZipEntry(name))
                if (literal != null) {
                    zip.write(literal)
                } else {
                    val chunk = ByteArray(64 * 1024)
                    var remaining = size
                    while (remaining > 0) {
                        val n = minOf(chunk.size, remaining)
                        zip.write(chunk, 0, n)
                        remaining -= n
                    }
                }
                zip.closeEntry()
            }
        }
        return bos.toByteArray()
    }

    /** 返回类型化拒绝原因（null = 成功）；断言统一走真值判定。 */
    private fun run(zipBytes: ByteArray, dest: File, maxEntries: Int = 20_000,
                    maxEntry: Long = 256L * 1024 * 1024, maxTotal: Long = 1024L * 1024 * 1024): RtpImportRejection? =
        RpgMakerRuntimeEnvironment.extractZipStream(
            ByteArrayInputStream(zipBytes), dest, maxEntries, maxEntry, maxTotal,
        )

    @Test
    fun filteredMacosxEntryIsBoundedByPerEntryLimit() {
        val dest = temporaryFolder.newFolder("rtp1")
        // 被过滤的条目超过单条目上限：必须中止，而不能靠 closeEntry() 无界排空
        val zip = buildZip(
            listOf(
                Triple("__MACOSX/big.bin", 4 * 1024 * 1024, null),
                Triple("ok.txt", 0, "ok".toByteArray()),
            ),
        )
        assertNotNull("被过滤的超大条目必须中止导入", run(zip, dest, maxEntry = 1024 * 1024))
    }

    @Test
    fun filteredDsStoreEntryIsBoundedByTotalLimit() {
        val dest = temporaryFolder.newFolder("rtp2")
        // 多个被过滤条目累计超总量：必须中止
        val zip = buildZip(
            listOf(
                Triple("a/.DS_Store", 1024 * 1024, null),
                Triple("b/.DS_Store", 1024 * 1024, null),
                Triple("c/.DS_Store", 1024 * 1024, null),
            ),
        )
        assertNotNull(
            "被过滤条目累计超总量必须中止",
            run(zip, dest, maxEntry = 10 * 1024 * 1024, maxTotal = 2 * 1024 * 1024),
        )
    }

    @Test
    fun outOfRootEntryIsAlsoBounded() {
        val dest = temporaryFolder.newFolder("rtp3")
        // 越界条目走另一个跳过分支，同样必须有界
        val zip = buildZip(
            listOf(
                Triple("../escape/evil.bin", 4 * 1024 * 1024, null),
                Triple("ok.txt", 0, "ok".toByteArray()),
            ),
        )
        assertNotNull("越界条目也必须受限", run(zip, dest, maxEntry = 1024 * 1024))
        assertFalse(
            "越界条目不得写出到 dest 之外",
            File(dest.parentFile, "escape/evil.bin").exists(),
        )
    }

    @Test
    fun normalZipWithFilteredMetadataStillSucceeds() {
        val dest = temporaryFolder.newFolder("rtp4")
        // 真实场景：macOS 打出的包带 __MACOSX 与 .DS_Store，内容很小，应正常导入
        val zip = buildZip(
            listOf(
                Triple("__MACOSX/._file", 0, ByteArray(128)),
                Triple(".DS_Store", 0, ByteArray(64)),
                Triple("app/data.txt", 0, "hello".toByteArray()),
                Triple("app/sub/nested.txt", 0, "nested".toByteArray()),
            ),
        )
        assertNull("正常包应导入成功", run(zip, dest))
        assertEquals("hello", File(dest, "app/data.txt").readText())
        assertEquals("nested", File(dest, "app/sub/nested.txt").readText())
        assertFalse("过滤条目不应落盘", File(dest, ".DS_Store").exists())
        assertFalse("__MACOSX 不应落盘", File(dest, "__MACOSX").exists())
    }

    @Test
    fun entryCountLimitCoversFilteredEntries() {
        val dest = temporaryFolder.newFolder("rtp5")
        // 大量被过滤条目：条目数上限必须在跳过**之前**生效（上一轮已修，这里回归锁定）
        val zip = buildZip(List(20) { Triple("__MACOSX/f$it", 0, ByteArray(8)) })
        assertNotNull("被过滤条目也要计入条目数上限", run(zip, dest, maxEntries = 10))
    }

    @Test
    fun normalEntryOverLimitIsRejected() {
        val dest = temporaryFolder.newFolder("rtp6")
        val zip = buildZip(listOf(Triple("app/big.bin", 4 * 1024 * 1024, null)))
        assertNotNull(run(zip, dest, maxEntry = 1024 * 1024))
        assertFalse("超限条目不应留下文件", File(dest, "app/big.bin").exists())
    }

    // ---------- 拒绝原因协议（类型 + 数值必须与触发原因一致） ----------

    @Test
    fun filteredOversizeEntryReportsEntrySizeNotTotal() {
        // 被过滤条目超单条目上限：必须报 EntrySizeExceeded，且数值是**该条目**的解压量。
        // 合并成 TotalSizeExceeded 会带上前置累计值（此例为 0），产出
        // 「解压总量超过上限（0 B > 1.0 MiB）」这类自相矛盾的提示。
        val dest = temporaryFolder.newFolder("reason1")
        val zip = buildZip(listOf(Triple("__MACOSX/big.bin", 4 * 1024 * 1024, null)))

        val reason = run(zip, dest, maxEntry = 1024 * 1024)
        assertTrue("应报单条目超限，实际：$reason", reason is RtpImportRejection.EntrySizeExceeded)
        val exceeded = reason as RtpImportRejection.EntrySizeExceeded
        assertEquals(1024L * 1024L, exceeded.limit)
        assertTrue("数值应是该条目真实解压量，实际 ${exceeded.size}", exceeded.size > exceeded.limit)
    }

    @Test
    fun cumulativeOversizeReportsTotalSize() {
        // 多条被过滤条目累计超总量：报 TotalSizeExceeded，数值为触发时的实际累计值
        val dest = temporaryFolder.newFolder("reason2")
        val zip = buildZip(
            listOf(
                Triple("a/.DS_Store", 1024 * 1024, null),
                Triple("b/.DS_Store", 1024 * 1024, null),
                Triple("c/.DS_Store", 1024 * 1024, null),
            ),
        )

        val reason = run(zip, dest, maxEntry = 10 * 1024 * 1024, maxTotal = 2 * 1024 * 1024)
        assertTrue("应报累计超限，实际：$reason", reason is RtpImportRejection.TotalSizeExceeded)
        val exceeded = reason as RtpImportRejection.TotalSizeExceeded
        assertEquals(2L * 1024L * 1024L, exceeded.limit)
        assertTrue("数值应超过上限，实际 ${exceeded.size}", exceeded.size > exceeded.limit)
    }

    @Test
    fun entryCountLimitReportsEntryCount() {
        val dest = temporaryFolder.newFolder("reason3")
        val zip = buildZip(List(20) { Triple("__MACOSX/f$it", 0, ByteArray(8)) })

        val reason = run(zip, dest, maxEntries = 10)
        assertTrue("应报条目数超限，实际：$reason", reason is RtpImportRejection.EntryCountExceeded)
        val exceeded = reason as RtpImportRejection.EntryCountExceeded
        assertEquals(10, exceeded.limit)
        assertTrue(exceeded.count > exceeded.limit)
    }

    @Test
    fun reasonIsReturnedPerCallNotFromGlobalState() {
        // 每次调用各自返回原因：上一次的失败不得残留到本次结果上
        // （旧的全局 lastRejectReason 槽在并发/连续导入下会把原因串台）
        val bad = buildZip(listOf(Triple("__MACOSX/big.bin", 4 * 1024 * 1024, null)))
        val first = run(bad, temporaryFolder.newFolder("reason4"), maxEntry = 1024 * 1024)
        assertTrue(first is RtpImportRejection.EntrySizeExceeded)

        val good = buildZip(listOf(Triple("app/data.txt", 0, "ok".toByteArray())))
        assertNull("成功后必须返回 null", run(good, temporaryFolder.newFolder("reason4ok")))

        // 本次是「条目数超限」：返回的原因必须是本次的，而不是上次的单条目超限
        val many = buildZip(List(20) { Triple("app/f$it", 0, ByteArray(8)) })
        val reason = run(many, temporaryFolder.newFolder("reason5b"), maxEntries = 5)
        assertTrue("原因必须是本次失败的原因，实际：$reason", reason is RtpImportRejection.EntryCountExceeded)
    }

    @Test
    fun emptyZipReportsEmptyArchive() {
        // 空 zip 此前只返回 false 且无原因：用户看到「导入失败」无从判断是选错了包
        val dest = temporaryFolder.newFolder("empty1")
        assertEquals(RtpImportRejection.EmptyArchive, run(buildZip(emptyList()), dest))
    }

    @Test
    fun onlyFilteredEntriesReportsEmptyArchive() {
        // 全是元数据条目：过滤后无内容，同样属于「来源里没有可导入的内容」
        val dest = temporaryFolder.newFolder("empty2")
        val zip = buildZip(
            listOf(
                Triple("__MACOSX/._file", 0, ByteArray(16)),
                Triple(".DS_Store", 0, ByteArray(16)),
            ),
        )
        assertEquals(RtpImportRejection.EmptyArchive, run(zip, dest))
    }
}
