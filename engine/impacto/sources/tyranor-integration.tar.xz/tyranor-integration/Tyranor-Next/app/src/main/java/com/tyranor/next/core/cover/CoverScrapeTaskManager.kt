package com.tyranor.next.core.cover

import android.content.Context
import android.util.Log
import com.tyranor.next.core.game.model.ScanGame
import com.tyranor.next.core.game.storage.GameLibraryFacade
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

data class CoverScrapeTaskState(
    val running: Boolean = false,
    val result: CoverScrapeResult? = null,
    /** 错误码而非文案；本地化由 UI 映射（`ui/cover/CoverErrorMessages.kt`）。 */
    val error: CoverErrorCode? = null,
    val eventId: Long = 0L,
)

object CoverScrapeTaskManager {
    private const val TAG = "CoverScrapeTask"

    private val _state = MutableStateFlow(CoverScrapeTaskState())
    val state: StateFlow<CoverScrapeTaskState> = _state.asStateFlow()
    private val _gameUpdates = MutableSharedFlow<ScanGame>()
    val gameUpdates: SharedFlow<ScanGame> = _gameUpdates.asSharedFlow()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val lock = Any()
    private var job: Job? = null
    private var nextEventId = 0L

    fun start(context: Context, games: List<ScanGame>? = null): Boolean {
        val appContext = context.applicationContext
        synchronized(lock) {
            if (job?.isActive == true) return false
            _state.value = CoverScrapeTaskState(running = true)
            job = scope.launch {
                try {
                    val input = games ?: GameLibraryFacade.loadGames(appContext)
                    val result = CoverScraperService.scrapeLibraryCovers(appContext, input) { original, scraped ->
                        val persisted = withContext(NonCancellable + Dispatchers.IO) {
                            persistScrapedCover(appContext, original, scraped)
                        }
                        persisted?.let { _gameUpdates.emit(it) }
                    }
                    // 每张封面已通过 updateGameCover 单行落库（迁移方案阶段 2），
                    // 这里只读最新库作为结果快照，不再触发整库重写。
                    val mergedGames = withContext(NonCancellable + Dispatchers.IO) {
                        GameLibraryFacade.loadGames(appContext)
                    }
                    postFinished(result = result.copy(games = mergedGames), error = null)
                } catch (e: CancellationException) {
                    postFinished(result = null, error = CoverErrorCode.CANCELLED)
                    throw e
                } catch (e: Exception) {
                    // 底层 message 只作日志线索，不外泄给 UI（AGENTS.md 错误处理协议）
                    Log.w(TAG, "cover scrape task failed", e)
                    postFinished(result = null, error = CoverErrorCode.UNKNOWN)
                } finally {
                    synchronized(lock) {
                        job = null
                    }
                }
            }
        }
        return true
    }

    fun clearFinished(eventId: Long) {
        val current = _state.value
        if (!current.running && current.eventId == eventId) {
            _state.value = current.copy(result = null, error = null)
        }
    }

    private fun persistScrapedCover(context: Context, original: ScanGame, scraped: ScanGame): ScanGame? =
        GameLibraryFacade.updateGameCover(context, original.uri) { current ->
            mergeScrapedCover(current, original, scraped)
        }?.also { updated ->
            // 换封面成功后清理被替换的旧图。mergeScrapedCover 仅在 current 与任务快照一致时生效，
            // 因此此时 original.coverUri 就是落库前的旧封面；deleteCachedCover 只在 covers_remote
            // 目录内删除，并自动跳过与新封面相同的文件（重复刮削同一 URL 时新旧为同一文件）。
            CoverImageCache.deleteCachedCover(context, original.coverUri, exceptUri = updated.coverUri)
        }

    private suspend fun postFinished(result: CoverScrapeResult?, error: CoverErrorCode?) {
        val eventId = synchronized(lock) {
            nextEventId += 1
            nextEventId
        }
        // NonCancellable：取消路径也要把终态写入，否则 running 永久停留在 true
        withContext(NonCancellable + Dispatchers.Main.immediate) {
            _state.value = CoverScrapeTaskState(
                running = false,
                result = result,
                error = error,
                eventId = eventId,
            )
        }
    }
}

/** 只在封面仍与任务启动快照一致时应用结果，避免覆盖用户同时进行的手动换封面。 */
internal fun mergeScrapedCover(current: ScanGame, original: ScanGame, scraped: ScanGame): ScanGame =
    if (current.coverUri == original.coverUri && current.coverSource == original.coverSource) {
        current.copy(
            coverUri = scraped.coverUri,
            coverSource = scraped.coverSource,
            // VNDB 元数据随封面结果一并合并（空串不得覆盖已有值）
            vndbId = scraped.vndbId?.takeIf { it.isNotBlank() } ?: current.vndbId,
            metadataTitle = scraped.metadataTitle?.takeIf { it.isNotBlank() } ?: current.metadataTitle,
        )
    } else {
        current
    }
