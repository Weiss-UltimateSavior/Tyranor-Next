package com.tyranor.next.core.game.save

import com.tyranor.next.core.engine.EngineType
import kotlinx.coroutines.CancellationException
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.security.MessageDigest

/**
 * MV/MZ 存档互通：在「标准侧」与「Tyranor 侧」之间双向同步存档。
 *
 * 两侧内容字节级一致，仅文件名不同（映射见 [RpgSaveFormat]），同步 = 按文件名映射复制。
 * 标准侧始终保留，供 JoiPlay/PC 使用。
 *
 * 判定规则（逐槽位，槽位 = `global`/`config`/`fileN`，MV 备份 `.bak`）：
 * - 两侧都有：修改时间不同则**较新者覆盖较旧者**（复制后把目标 mtime 设为源 mtime，保证下一轮幂等）；
 *   相同则必须内容哈希一致才跳过（mtime 可被外部改写，不能只信时间戳）。
 * - 仅标准侧有：清单显示该槽位曾在 Tyranor 存在 ⇒ 判为「Tyranor 侧已删除」→
 *   把标准文件移入 `<标准侧>/deleted/`；否则视为新 PC 存档 → 导入 Tyranor。
 * - 仅 Tyranor 侧有：清单显示标准侧曾存在 ⇒（外部删除标准档）按既定策略**保留 Tyranor 并重新导出**，
 *   不删手机存档；否则视为 Tyranor 新存档 → 导出标准侧。
 *
 * `preferTyranor = true`（用户在云端/ZIP 里**显式选中**某个存档版本，见
 * [RpgSaveSyncState.markManualSelection]）时改为「以 Tyranor 侧为准」，不再按 mtime 判新旧：
 * - 两侧都有：Tyranor 内容覆盖标准侧（字节已一致则跳过），被替换的标准侧副本**一律留底**
 *   （`deleted/`），不受「已建立槽位不重复留底」的节流约束；
 * - 仅标准侧有：归入 `deleted/`（保留文件），**不导入** Tyranor——用户没选它；
 * - 仅 Tyranor 侧有：照常导出。
 * 常规双向同步的判定与计数语义完全不受此标记影响。
 *
 * 两侧都不存在的槽位不记录，避免「删档后被再次导入」。
 */
object RpgSaveSync {

    /** 删除归置子目录（位于标准存档目录内）。 */
    const val DELETED_DIR = "deleted"

    /**
     * 进程级互斥：启动前同步、前台兜底回写、存档管理页「立即同步」可能并发触发，
     * 交错复制会破坏「较新者胜」的 mtime 判定并让同步清单互相覆盖。所有同步入口在此
     * 串行化，并与清单、手动选择标记及导入/删除共用 [RpgSaveSyncState.INTEROP_LOCK]。
     * 调用方均在 IO 线程，锁内是阻塞文件 IO，串行不会阻塞主线程。
     */
    private val syncLock: Any = RpgSaveSyncState.INTEROP_LOCK

    /** 内容比对时的读取缓冲（64 KiB）。 */
    private const val SYNC_HASH_BUFFER_BYTES = 64 * 1024

    data class Result(
        /** 新 PC 存档导入到 Tyranor 的文件数。 */
        val imported: Int = 0,
        /** Tyranor 存档导出到标准侧的文件数。 */
        val exported: Int = 0,
        /** 两侧都有、标准侧较新而覆盖 Tyranor 的文件数。 */
        val toTyranor: Int = 0,
        /** 两侧都有、Tyranor 较新而覆盖标准侧的文件数。 */
        val toStandard: Int = 0,
        /** Tyranor 侧已删除、标准侧对应文件归入 `deleted/` 的数量。 */
        val movedToDeleted: Int = 0,
        /** 两侧一致、无需处理的数量。 */
        val skipped: Int = 0,
        /** Tyranor 侧无法反解的哈希名数量（插件自定义键，保留原名，仅报告）。 */
        val unmapped: Int = 0,
        /** 处理失败数（源文件保留，计入下次重试）。 */
        val failed: Int = 0,
    ) {
        val changed: Int get() = imported + exported + toTyranor + toStandard + movedToDeleted
    }

    /** 单个槽位同步后的落盘状态（存在标记 + mtime），见 [RpgSaveSyncState.SlotState]。 */
    private fun slotState(
        stdMtime: Long,
        tyrMtime: Long,
        stdExists: Boolean,
        tyrExists: Boolean,
    ): RpgSaveSyncState.SlotState = RpgSaveSyncState.SlotState(
        standardMtime = stdMtime,
        tyranorMtime = tyrMtime,
        standardExists = stdExists,
        tyranorExists = tyrExists,
    )

    /**
     * 执行一次双向同步。
     *
     * @param standardDir 标准侧目录（`<内容根>/save`）。
     * @param tyranorDir Tyranor 侧有效存档目录（`<游戏根>/savedata`，或开启独立存档时的外部目录）。
     * @param stateStore 同步清单（区分「新建」与「已删除」）。
     * @param gameKey 清单键（用 game.uri 即可）。
     * @param preferTyranor 用户显式选中 Tyranor 侧版本时置真：以 Tyranor 为准覆盖标准侧，
     *   详见文件头「`preferTyranor`」段与 [RpgSaveSyncState.markManualSelection]。默认 false，
     *   常规 mtime 判定不变。
     */
    fun sync(
        standardDir: File,
        tyranorDir: File,
        engine: EngineType,
        stateStore: RpgSaveSyncState,
        gameKey: String,
        preferTyranor: Boolean = false,
    ): Result = sync(listOf(standardDir), tyranorDir, engine, stateStore, gameKey, preferTyranor)

    /**
     * @param standardDirs 标准侧候选目录，第一个为默认写入目录（兼容 `save` / `Save`）；
     *   某个槽位若已存在于非首选目录，则就地更新，避免产生重复文件。
     * @param preferTyranor 见单目录重载：为真时本轮「以 Tyranor 侧为准」，标准侧一律服从 Tyranor 内容。
     */
    fun sync(
        standardDirs: List<File>,
        tyranorDir: File,
        engine: EngineType,
        stateStore: RpgSaveSyncState,
        gameKey: String,
        preferTyranor: Boolean = false,
    ): Result = synchronized(syncLock) {
        syncLocked(standardDirs, tyranorDir, engine, stateStore, gameKey, preferTyranor)
    }

    /**
     * 在同一共享锁内读取并消费手动选择标记，再执行同步；失败时保留标记。
     * 异常（含取消）原样传播。
     */
    internal fun syncWithManualSelection(
        standardDirs: List<File>,
        tyranorDir: File,
        engine: EngineType,
        stateStore: RpgSaveSyncState,
        gameKey: String,
    ): Result = synchronized(syncLock) {
        val preferTyranor = stateStore.hasManualSelection(gameKey, tyranorDir)
        val result = syncLocked(
            standardDirs = standardDirs,
            tyranorDir = tyranorDir,
            engine = engine,
            stateStore = stateStore,
            gameKey = gameKey,
            preferTyranor = preferTyranor,
        )
        if (preferTyranor && result.failed == 0 && !stateStore.clearManualSelection(gameKey)) {
            result.copy(failed = result.failed + 1)
        } else {
            result
        }
    }

    /** [sync] 的实际实现；进入前已持有共享 INTEROP_LOCK，故可安全读写清单与两侧文件。 */
    private fun syncLocked(
        standardDirs: List<File>,
        tyranorDir: File,
        engine: EngineType,
        stateStore: RpgSaveSyncState,
        gameKey: String,
        preferTyranor: Boolean,
    ): Result {
        if (!RpgSaveFormat.isRpgWebEngine(engine)) return Result()
        if (standardDirs.isEmpty()) return Result()

        // 清单验证必须先行：collectStandard 的冲突隔离会移动文件，「失败不做任何文件改动」
        // 的契约要求清单 Unreadable 时在任何文件操作前中止本轮同步
        val previous: Map<String, RpgSaveSyncState.SlotState> = when (val loaded = stateStore.load(gameKey)) {
            is RpgSaveSyncState.LoadResult.Loaded -> loaded.slots
            is RpgSaveSyncState.LoadResult.Missing -> emptyMap()
            is RpgSaveSyncState.LoadResult.Unreadable -> {
                // core 层不做日志（保持纯 File 依赖、单测可跑）：失败计数由调用方上报
                return Result(failed = 1)
            }
        }

        val preferredStandardDir = standardDirs.first()
        val standardScan = collectStandard(standardDirs, engine)
        val standardFiles = standardScan.selected
        val quarantinedDuplicates = standardScan.quarantined
        val tyranorFiles = collectTyranor(tyranorDir, engine)

        var imported = 0
        var exported = 0
        var toTyranor = 0
        var toStandard = 0
        var movedToDeleted = quarantinedDuplicates
        var skipped = 0
        var failed = 0
        val nextState = mutableMapOf<String, RpgSaveSyncState.SlotState>()

        /** 槽位处理失败（内联或异常）：沿用上一次的清单条目，避免「已删除」被误判为「新建」而复活。 */
        fun keepPrevious(slot: String) {
            previous[slot]?.let { nextState[slot] = it }
        }

        for (slot in (standardFiles.keys + tyranorFiles.keys).sorted()) {
            val std = standardFiles[slot]
            val tyr = tyranorFiles[slot]
            val hadPrevious = previous.containsKey(slot)
            // 显式存在标记（而非 mtime>0 反推）：mtime 为 0 的存档不应被当成「从未存在」
            val existedOnTyranor = previous[slot]?.tyranorExists == true
            var stdMtime = std?.lastModified() ?: 0L
            var tyrMtime = tyr?.lastModified() ?: 0L
            // 显式存在标记：不能用 mtime>0 反推（mtime 为 0 的存档会被误判为不存在）。
            // 注意必须随分支更新——导入/导出后对侧文件是新建的，不能沿用同步前的引用判断。
            var stdExistsNow = std != null
            var tyrExistsNow = tyr != null
            var record = true
            try {
                when {
                    std != null && tyr != null && preferTyranor -> {
                        // 用户显式选了 Tyranor 侧版本：不看 mtime，标准侧一律服从 Tyranor 内容。
                        // 被替换的标准副本**必须留底**（mustPreserve 恒真）——这份 PC 侧存档可能
                        // 是唯一一份较旧进度，覆盖前不留底就再也找不回。
                        // 同槽位在 save/ 与 Save/ 里的所有副本都要一并对齐：只刷新首选目录那份，
                        // 另一份留在原地会在后续轮次被选中并把用户刚否定的旧内容带回（复活）。
                        val copies = standardScan.copies[slot].orEmpty().ifEmpty { listOf(std) }
                        if (alignStandardCopies(tyr, copies, preferredStandardDir) > 0) {
                            toStandard++
                        } else {
                            skipped++
                        }
                        // 清单记实际落盘 mtime（对齐后应与 Tyranor 侧一致），下一轮才能干净跳过
                        stdMtime = copies.firstOrNull { it.isFile }?.lastModified() ?: tyrMtime
                    }
                    std != null && tyr != null -> {
                        val s = std.lastModified()
                        val t = tyr.lastModified()
                        when {
                            s == t -> {
                                // mtime 相同也必须比内容：内容可以在 mtime/长度都不变的情况下被改
                                // （外部编辑器改写后回设时间戳等）。跳过与否只能以内容哈希为准。
                                if (sameContent(std, tyr)) {
                                    skipped++
                                } else {
                                    // 无法判定新旧：以标准侧为准，且**无条件**把 Tyranor 侧留底——
                                    // 平局下较旧一方未知，留底才能保证不丢任何一份
                                    writeTyranorSide(
                                        winner = std,
                                        existingTyranor = tyr,
                                        slot = slot,
                                        tyranorDir = tyranorDir,
                                        engine = engine,
                                        mustPreserveTarget = true,
                                    )
                                    toTyranor++; tyrMtime = s; tyrExistsNow = true
                                }
                            }
                            s > t -> {
                                // 首次同步该槽位时较旧一方无历史记录，先留底再覆盖，避免误删唯一副本；
                                // 留底失败则中止本次覆盖（两侧原样保留、计入 failed、下轮重试），绝不先毁后写
                                writeTyranorSide(
                                    winner = std,
                                    existingTyranor = tyr,
                                    slot = slot,
                                    tyranorDir = tyranorDir,
                                    engine = engine,
                                    mustPreserveTarget = !hadPrevious,
                                )
                                toTyranor++; tyrMtime = s; tyrExistsNow = true
                            }
                            else -> {
                                overwriteWithPreserve(
                                    winner = tyr,
                                    loser = std,
                                    loserDir = std.parentFile ?: preferredStandardDir,
                                    preserveLoserSide = true,
                                    mustPreserve = !hadPrevious,
                                )
                                toStandard++; stdMtime = t
                            }
                        }
                    }
                    std != null -> {
                        if (preferTyranor) {
                            // 仅标准侧有 ⇒ 用户没选它：不导入 Tyranor，否则下一轮引擎读到的还是
                            // 被否定的版本。文件归入 deleted/ 保留，绝不删除。
                            // 与「Tyranor 侧已删除」同款语义，但这里不依赖清单：手动选择本身就是
                            // 「标准侧这一份不要」的明示。同槽位的所有副本都要移走——漏掉任何一份，
                            // 它下一轮都会被当成「新 PC 存档」导回 Tyranor，把已删槽位复活。
                            val copies = standardScan.copies[slot].orEmpty().ifEmpty { listOf(std) }
                            val moved = copies.count { candidate ->
                                candidate.isFile &&
                                    moveToDeleted(candidate, candidate.parentFile ?: preferredStandardDir)
                            }
                            if (moved == copies.size) {
                                movedToDeleted += moved
                                stdMtime = 0L
                                stdExistsNow = false
                            } else {
                                failed++
                                record = false
                                keepPrevious(slot)
                            }
                        } else if (existedOnTyranor) {
                            // Tyranor 侧已删除该槽位 → 标准文件归入 deleted/，不再导回
                            if (moveToDeleted(std, std.parentFile ?: preferredStandardDir)) {
                                movedToDeleted++; stdMtime = 0L; stdExistsNow = false
                            } else {
                                failed++; record = false; keepPrevious(slot)
                            }
                        } else {
                            if (RpgSaveFormat.tyranorNameForSlot(slot, engine) == null) {
                                failed++; record = false; keepPrevious(slot)
                            } else {
                                writeTyranorSide(
                                    winner = std,
                                    existingTyranor = null,
                                    slot = slot,
                                    tyranorDir = tyranorDir,
                                    engine = engine,
                                    mustPreserveTarget = false,
                                )
                                imported++; tyrMtime = stdMtime; tyrExistsNow = true
                            }
                        }
                    }
                    tyr != null -> {
                        val name = RpgSaveFormat.standardNameForSlot(slot, engine)
                        if (name == null) {
                            failed++; record = false; keepPrevious(slot)
                        } else {
                            // 标准侧缺失：无论外部删除还是 Tyranor 新建，都导出到标准侧（首选目录）
                            val target = File(preferredStandardDir, name)
                            copyOverwrite(tyr, target); exported++; stdMtime = tyrMtime
                            stdExistsNow = true
                        }
                    }
                }
            } catch (cancelled: CancellationException) {
                // 取消必须原样传播，不能被当作单个槽位失败吞掉
                throw cancelled
            } catch (_: IOException) {
                // 仅收敛预期的文件异常（IO/权限）：失败不丢历史，沿用上一次的清单条目
                failed++
                record = false
                keepPrevious(slot)
            } catch (_: SecurityException) {
                // SAF 权限中途失效等：同样按单槽位失败处理，不得中断整轮（审查 M5）
                failed++
                record = false
                keepPrevious(slot)
            }
            if (record) {
                // 两侧都不存在的槽位不记录，避免「删档后被再次导入」
                if (stdExistsNow || tyrExistsNow) {
                    nextState[slot] = slotState(stdMtime, tyrMtime, stdExistsNow, tyrExistsNow)
                }
            }
        }

        // 清单提交失败必须如实上报：否则「同步成功」却丢了下一次的新建/已删除判定依据
        if (!stateStore.save(gameKey, nextState)) {
            failed++
        }
        return Result(
            imported = imported,
            exported = exported,
            toTyranor = toTyranor,
            toStandard = toStandard,
            movedToDeleted = movedToDeleted,
            skipped = skipped,
            unmapped = tyranorUnmappedCount(tyranorDir, engine),
            failed = failed,
        )
    }

    /**
     * 枚举多个标准侧目录（`save`/`Save`）。
     *
     * 同一槽位出现在多个目录时不再静默取先者：内容一致视为等价副本（任取其一）；
     * 内容不一致则把**未选中的副本**隔离进其所在目录的 `deleted/`（保留数据、避免旧副本
     * 长期分叉），再以首选目录的文件为同步源。返回值第二项为隔离数量（映射到结果里的
     * movedToDeleted）；隔离失败则保留原位、以首选目录为准继续同步。
     */
    private fun collectStandard(dirs: List<File>, engine: EngineType): StandardScan {
        val out = mutableMapOf<String, File>()
        // 每个槽位在标准侧的全部存活副本（含等价副本，按目录顺序）：手动选择模式下必须逐份对齐，
        // 否则留在次要目录里的旧副本会在后续轮次被选中，把用户已经否定的内容带回（复活）
        val all = linkedMapOf<String, MutableList<File>>()
        var quarantined = 0
        dirs.forEach { dir ->
            if (!dir.isDirectory) return@forEach
            dir.listFiles().orEmpty().forEach { file ->
                if (!file.isFile) return@forEach
                val slot = RpgSaveFormat.standardSlot(file.name, engine) ?: return@forEach
                val copies = all.getOrPut(slot) { mutableListOf() }
                val existing = out[slot]
                if (existing == null) {
                    // 首选目录在前：先出现者胜
                    out[slot] = file
                    copies += file
                    return@forEach
                }
                // 同一文件（大小写不敏感 FS 上 save==Save）不算重复
                if (samePath(existing, file)) return@forEach
                if (sameContent(existing, file)) {
                    // 等价副本：不算冲突、不隔离，但仍要登记，供手动选择模式一并刷新/移入 deleted/
                    copies += file
                    return@forEach
                }
                // 冲突副本：隔离到 deleted/ 留证，同步以首选目录文件为准
                if (moveToDeleted(file, file.parentFile ?: dir)) {
                    quarantined++
                } else {
                    // 隔离失败：副本仍在原位，同样登记为待对齐对象（下一轮还会重试隔离）
                    copies += file
                }
            }
        }
        return StandardScan(out, all.mapValues { it.value.toList() }, quarantined)
    }

    /**
     * 标准侧扫描结果。
     *
     * [selected] 沿用「首选目录先出现者胜」的同步源；[copies] 给出同槽位的全部存活副本，
     * 仅手动选择模式（`preferTyranor`）需要逐份处理；[quarantined] 为内容冲突副本被隔离的数量。
     */
    private data class StandardScan(
        val selected: Map<String, File>,
        val copies: Map<String, List<File>>,
        val quarantined: Int,
    )

    /** 路径等价判定：优先 canonicalPath，失败退回大小写不敏感字符串比较。 */
    private fun samePath(a: File, b: File): Boolean = try {
        a.canonicalPath == b.canonicalPath
    } catch (_: Throwable) {
        a.absolutePath.equals(b.absolutePath, ignoreCase = true)
    }

    /**
     * 手动选择模式（`preferTyranor`）下将标准侧同槽位的**全部副本**对齐到 [winner]（Tyranor 侧内容）。
     *
     * 为什么必须逐份处理：常规同步把内容一致的 `save`/`Save` 副本视为等价、只留一份在活动目录，
     * 而本模式的目的正是「让用户选定的内容压过标准侧较新的 mtime」。只刷新首选目录那一份，另一份
     * 旧副本会在标记清除后的下一轮按 mtime 被选中，把用户已经否定的内容重新带回 Tyranor 侧（复活）。
     *
     * 逐份规则：内容已一致 ⇒ 不重复写盘，只把 mtime 对齐到 [winner]（否则标记清除后下一轮仍会按
     * 标准侧较新时间戳反向覆盖）；内容不同 ⇒ 走 [overwriteWithPreserve]，**mustPreserve 恒真**，
     * 被替换的 PC 侧副本一律进 `deleted/` 留底——这里不能沿用常规「已建立槽位不再留底」的节流，
     * 因为用户选定的内容与标准侧不同，标准侧那份就是唯一的一份旧进度。
     *
     * @return 内容被改写（原先与 [winner] 不一致）的副本数；0 表示所有副本已经一致。
     * @throws IOException 任一副本留底或替换失败：由调用方按单槽位失败处理（保留清单历史、
     *   下一轮重试），绝不允许留底失败后继续覆盖。
     */
    @Throws(IOException::class)
    private fun alignStandardCopies(
        winner: File,
        copies: List<File>,
        preferredStandardDir: File,
    ): Int {
        val winnerMtime = winner.lastModified()
        var rewritten = 0
        copies.forEach { copy ->
            if (!copy.isFile) return@forEach
            if (sameContent(winner, copy)) {
                // 字节一致：只对齐时间戳，避免下一轮无谓反向覆盖
                if (copy.lastModified() != winnerMtime) copy.setLastModified(winnerMtime)
                return@forEach
            }
            overwriteWithPreserve(
                winner = winner,
                loser = copy,
                loserDir = copy.parentFile ?: preferredStandardDir,
                preserveLoserSide = true,
                mustPreserve = true,
            )
            rewritten++
        }
        return rewritten
    }

    private fun collectTyranor(dir: File, engine: EngineType): Map<String, File> {
        if (!dir.isDirectory) return emptyMap()
        val out = mutableMapOf<String, File>()
        dir.listFiles().orEmpty().forEach { file ->
            if (!file.isFile) return@forEach
            val slot = RpgSaveFormat.tyranorSlot(file.name, engine) ?: return@forEach
            val existing = out[slot]
            if (existing == null) {
                out[slot] = file
            } else {
                // 同槽位多文件（如 RPG File3.bin 与 key_<hash>.bin 并存）：优先非哈希的规范名
                if (RpgSaveFormat.isHashedTyranorName(existing.name) && !RpgSaveFormat.isHashedTyranorName(file.name)) {
                    out[slot] = file
                }
            }
        }
        return out
    }

    /** 统计无法反解为槽位的哈希存档（插件自定义键）：保留原位，仅报告。 */
    private fun tyranorUnmappedCount(dir: File, engine: EngineType): Int {
        if (!dir.isDirectory) return 0
        return dir.listFiles().orEmpty().count { file ->
            file.isFile && RpgSaveFormat.isHashedTyranorName(file.name) &&
                RpgSaveFormat.tyranorSlot(file.name, engine) == null
        }
    }

    /**
     * mtime 相同时判断两侧内容是否一致：先比长度（廉价，能挡掉多数差异），长度相同再比 SHA-256。
     * 读取失败时返回 false（视为不同）——后续走原子复制，不会截断损坏任一副本。
     */
    private fun sameContent(a: File, b: File): Boolean = runCatching {
        a.length() == b.length() && sha256(a) == sha256(b)
    }.getOrDefault(false)

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered().use { input ->
            val buffer = ByteArray(SYNC_HASH_BUFFER_BYTES)
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    /**
     * 把标准侧文件 [winner] 写入 Tyranor 侧槽位的**规范落盘名**（MV 为 `key_<sha256(键)>.bin`，MZ 为原名），
     * 并保证该槽位在 Tyranor 侧**只留一个文件**。
     *
     * 为何不能沿用「写进输家原路径」：MV 引擎读档时**优先 legacy 名**（`RPG *.bin`），若保留旧名文件，
     * 新写入的哈希文件会被遮蔽、且同槽位出现两份（同步不再幂等）。因此：
     * - 目标名与既有文件不同名 ⇒ 先把旧名文件移入 `original/`（内容不丢），再写规范名；
     * - [mustPreserveTarget] 为真且规范名目标已存在 ⇒ 同样先留底（首次同步/平局，较旧一方未知）。
     *
     * 任一步失败即抛 [IOException]，由调用方按单槽位失败处理（两侧原样保留，下轮重试），绝不先毁后写。
     */
    @Throws(IOException::class)
    private fun writeTyranorSide(
        winner: File,
        existingTyranor: File?,
        slot: String,
        tyranorDir: File,
        engine: EngineType,
        mustPreserveTarget: Boolean,
    ) {
        val name = RpgSaveFormat.tyranorNameForSlot(slot, engine)
            ?: throw IOException("no tyranor name for slot $slot")
        val target = File(tyranorDir, name)
        // 与目标**不同名**的既有文件（历史 legacy 名、或插件自定义名的同槽位文件）
        val legacy = existingTyranor?.takeIf { it.exists() && !samePath(it, target) }

        // 顺序即安全性（与 overwriteWithPreserve 同款「先写临时文件 → 留底 → 原子替换 → 失败回滚」）：
        //   1) 先把赢家内容写进目标同目录临时文件——此刻未触碰任何既有文件；
        //   2) 不同名旧文件让位留底，否则引擎优先读 legacy 名而遮蔽新数据、且同槽位留两份；
        //   3) 目标存在时需要留底（平局/首同步必留，或步骤 2 已让位时兜底），再原子替换；
        //   4) 任一步失败：回滚已完成的留底，恢复「两侧至少各留一份」。
        //
        // 修复两处缺陷：
        //   - 规范名目标已存在时（本改动后的常态）旧实现因 sameAsTarget 跳过留底，直接
        //     原地覆盖 —— 平局/首同步下无 original/ 备份，与「留底才能保证不丢任何一份」矛盾；
        //   - 旧实现先把 legacy 移走再写目标，写失败后该槽位在 Tyranor 侧没有任何活动文件，
        //     下一轮还会把标准档移入 deleted/，导致槽位两侧都不再可见。
        val tmp = writeTmpCopy(winner, target)
        var legacyBackup: File? = null
        var targetBackup: File? = null
        try {
            if (legacy != null) {
                legacyBackup = preserveLoser(legacy, tyranorDir, standardSide = false)
            }
            if (target.exists() && (mustPreserveTarget || legacy != null)) {
                targetBackup = preserveLoser(target, tyranorDir, standardSide = false)
            }
            replaceAtomically(tmp, target, winner)
        } catch (t: Throwable) {
            restorePreserved(targetBackup, target)
            restorePreserved(legacyBackup, legacy)
            throw t
        } finally {
            discardTmp(tmp)
        }
    }

    /**
     * 回滚留底：把文件从 `original/` 放回原位。失败时不抛错——数据仍在留底目录（未丢失），
     * 由调用方 keepPrevious 保住清单历史、下一轮重试。
     */
    private fun restorePreserved(backup: File?, original: File?) {
        if (backup == null || original == null) return
        runCatching {
            if (!backup.renameTo(original)) {
                backup.copyTo(original, overwrite = true)
                backup.delete()
            }
        }
    }

    /**
     * 覆盖较旧一方：**先**把赢家内容写入目标同目录临时文件，**再**留底输家，**最后**原子替换。
     *
     * 顺序即安全性（PR 审查：失败路径绝不允许出现无法恢复的「目标缺失」）：
     * - 临时文件写入失败 → 输家与目标都原样保留；
     * - 留底失败（[mustPreserve] 时抛错）→ 临时文件清理、目标原样保留；
     * - 原子替换失败 → 留底**回滚**（备份移回原位，恢复「目标在原位」的不变量；
     *   回滚也失败时数据仍在留底目录，配合调用方 keepPrevious 保住清单历史，下一轮重试）。
     * 注意留底之后、替换成功之前，输家数据在留底目录而非目标路径——故替换失败必须回滚，
     * 不能假定目标路径仍有旧内容（审查跟进 #5）。
     */
    @Throws(IOException::class)
    private fun overwriteWithPreserve(
        winner: File,
        loser: File,
        loserDir: File,
        preserveLoserSide: Boolean,
        mustPreserve: Boolean,
    ) {
        // 1. 先写临时文件（此刻还未碰输家与目标）
        val tmp = writeTmpCopy(winner, loser)
        try {
            // 2. 留底输家（失败且必须留底时中止，目标原样保留）
            val backup = if (mustPreserve) preserveLoser(loser, loserDir, standardSide = preserveLoserSide) else null
            try {
                // 3. 原子替换（绝不先删目标）
                replaceAtomically(tmp, loser, winner)
            } catch (t: Throwable) {
                // 替换失败：把留底放回原位，恢复「目标在原位」的不变量（此时输家原路径为空）
                if (backup != null) {
                    runCatching {
                        if (!backup.renameTo(loser)) {
                            backup.copyTo(loser, overwrite = true)
                            backup.delete()
                        }
                    }
                }
                throw t
            }
        } finally {
            discardTmp(tmp)
        }
    }

    /** 把源内容写入目标同目录临时文件并 fsync；失败时清理半成品后原样抛出。 */
    @Throws(IOException::class)
    private fun writeTmpCopy(source: File, target: File): File {
        val parent = target.parentFile ?: throw IOException("no parent for ${target.absolutePath}")
        if (!parent.isDirectory && !parent.mkdirs() && !parent.isDirectory) {
            throw IOException("cannot create ${parent.absolutePath}")
        }
        val tmp = File(parent, target.name + ".sync_tmp." + System.nanoTime())
        try {
            source.inputStream().buffered().use { input ->
                FileOutputStream(tmp).use { out ->
                    input.copyTo(out)
                    out.fd.sync()
                }
            }
        } catch (t: Throwable) {
            runCatching { tmp.delete() }
            throw t
        }
        return tmp
    }

    /**
     * 原子替换目标并同步 mtime：Files.move(REPLACE_EXISTING)，ATOMIC_MOVE 优先。
     * 绝不先删目标——替换失败时目标保持旧内容，源与留底均完好，不存在「两侧都丢」的窗口。
     * （不能用 File.renameTo：Windows 上它不能替换已存在目标。）
     */
    @Throws(IOException::class)
    private fun replaceAtomically(tmp: File, target: File, source: File) {
        try {
            java.nio.file.Files.move(
                tmp.toPath(),
                target.toPath(),
                java.nio.file.StandardCopyOption.ATOMIC_MOVE,
                java.nio.file.StandardCopyOption.REPLACE_EXISTING,
            )
        } catch (_: java.nio.file.AtomicMoveNotSupportedException) {
            java.nio.file.Files.move(
                tmp.toPath(),
                target.toPath(),
                java.nio.file.StandardCopyOption.REPLACE_EXISTING,
            )
        }
        // mtime 同步：失败会使目标 mtime 变成「现在」，可能引发下一轮反向覆盖（乒乓）。
        // 失败时把源 mtime 对齐到目标实际值，保持两侧一致、避免乒乓。
        if (!target.setLastModified(source.lastModified())) {
            val actual = target.lastModified()
            if (actual > 0L) source.setLastModified(actual)
        }
    }

    /** 清理临时文件（替换成功后已不存在）；仅删除匹配临时名模式的文件，防误删。 */
    private fun discardTmp(tmp: File) {
        if (tmp.exists() && tmp.name.contains(".sync_tmp.")) tmp.delete()
    }

    /**
     * 复制覆盖目标（无留底需求的新建/导出路径）：临时文件 + 原子替换，失败时目标原样保留。
     */
    @Throws(IOException::class)
    private fun copyOverwrite(source: File, target: File) {
        val tmp = writeTmpCopy(source, target)
        try {
            replaceAtomically(tmp, target, source)
        } finally {
            discardTmp(tmp)
        }
    }

    /**
     * 首次同步某槽位、需要覆盖较旧一方前，把较旧文件留底，避免因标准侧 mtime 被复制/导入
     * 刷新成「较新」而误删唯一的手机存档。standardSide=true 归入 `<标准侧>/deleted/`，
     * 否则归入 Tyranor 侧 `original/`。
     *
     * @return 留底文件（供替换失败时回滚）；输家不存在（无留底必要）返回 null；
     *   留底失败抛 [IOException]，由调用方中止覆盖——绝不覆盖未留底的较旧副本。
     */
    @Throws(IOException::class)
    private fun preserveLoser(loser: File, sideDir: File, standardSide: Boolean): File? {
        if (!loser.exists()) return null
        val dir = if (standardSide) File(sideDir, DELETED_DIR) else File(sideDir, RpgSaveFormat.ORIGINAL_DIR)
        if (!dir.isDirectory && !dir.mkdirs() && !dir.isDirectory) {
            throw IOException("cannot create backup dir ${dir.absolutePath}")
        }
        var target = File(dir, loser.name)
        var index = 1
        while (target.exists()) {
            val name = loser.name
            val dot = name.lastIndexOf('.')
            target = File(dir, if (dot > 0) name.substring(0, dot) + "_" + index + name.substring(dot) else name + "_" + index)
            index++
        }
        if (loser.renameTo(target)) return target
        // 跨设备/被占用时退回复制；必须确认副本完整落盘（存在且字节数一致）且源已移走才算成功
        val copied = runCatching {
            loser.copyTo(target, overwrite = false)
            target.isFile && target.length() == loser.length() && loser.delete()
        }.getOrDefault(false)
        if (!copied) {
            runCatching { target.delete() }
            throw IOException("cannot preserve ${loser.absolutePath} into ${dir.absolutePath}")
        }
        return target
    }

    /** 把标准文件移入 `<standardDir>/deleted/`；重名追加 `_1`/`_2`…。仅当源确实已移走才算成功。 */
    private fun moveToDeleted(source: File, standardDir: File): Boolean {
        val dir = File(standardDir, DELETED_DIR)
        if (!dir.isDirectory && !dir.mkdirs() && !dir.isDirectory) return false
        var target = File(dir, source.name)
        var index = 1
        while (target.exists()) {
            val name = source.name
            val dot = name.lastIndexOf('.')
            val candidate = if (dot > 0) {
                name.substring(0, dot) + "_" + index + name.substring(dot)
            } else {
                name + "_" + index
            }
            target = File(dir, candidate)
            index++
        }
        if (source.renameTo(target)) return true
        // 跨设备/被占用时退回复制；必须确认源已删除，否则视为失败（避免「已删」误判后复活）
        runCatching {
            source.copyTo(target, overwrite = false)
            source.delete()
        }
        return !source.exists()
    }
}
