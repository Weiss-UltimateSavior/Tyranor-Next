package com.tyranor.next.core.cover

import android.content.Context
import android.net.Uri
import com.tyranor.next.core.game.model.ScanGame
import com.tyranor.next.core.settings.AppSettingsStore
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets

data class VndbCandidate(
    val id: String,
    val title: String,
    val originalTitle: String,
    val developer: String,
    val released: String,
    /** 按「VNDB 封面大图」开关解析后的下载地址：开=原图 image.url，关=缩略图 image.thumbnail。 */
    val coverUrl: String,
    /** 始终为缩略图（image.thumbnail），供搜索预览省流量使用。 */
    val thumbnailUrl: String,
)

object VndbCoverService {
    private const val ENDPOINT = "https://api.vndb.org/kana/vn"
    private const val FIELDS =
        "title,alttitle,titles.lang,titles.title,titles.latin,titles.official,titles.main,released,image.url,image.thumbnail,developers.name,developers.original"
    /** 限流：与未萌 NextMoe 共用 RequestThrottle（都属「单机串行 + 服务端限流」来源）。 */
    private val throttle = RequestThrottle(1100L)

    fun fetchBestCover(context: Context, game: ScanGame): ScanGame? {
        if (!game.coverUri.isNullOrBlank()) return game
        val candidate = searchCandidates(context, game.title, 1).firstOrNull() ?: return null
        val cover = CoverImageCache.download(
            context,
            candidate.coverUrl,
            "vndb_${stableKey(game.uri)}",
            source = AppSettingsStore.COVER_SOURCE_VNDB,
        ) ?: return null
        return game.copy(
            coverUri = cover,
            coverSource = AppSettingsStore.COVER_SOURCE_VNDB,
            // 空串不得覆盖库中已有元数据（异常响应可能给出空 id/标题）
            vndbId = candidate.id.takeIf { it.isNotBlank() } ?: game.vndbId,
            metadataTitle = candidate.displayTitle().takeIf { it.isNotBlank() } ?: game.metadataTitle,
        )
    }

    fun bindCandidate(context: Context, game: ScanGame, candidate: VndbCandidate): ScanGame? {
        val cover = CoverImageCache.download(
            context,
            candidate.coverUrl,
            "vndb_${stableKey(game.uri)}",
            source = AppSettingsStore.COVER_SOURCE_VNDB,
        ) ?: return null
        CoverImageCache.deleteCachedCover(context, game.coverUri, exceptUri = cover)
        return game.copy(
            coverUri = cover,
            coverSource = AppSettingsStore.COVER_SOURCE_VNDB,
            vndbId = candidate.id.takeIf { it.isNotBlank() } ?: game.vndbId,
            metadataTitle = candidate.displayTitle().takeIf { it.isNotBlank() } ?: game.metadataTitle,
        )
    }

    /** 将用户从相册选择的图片保存为该游戏的自定义封面，返回更新后的游戏（失败返回 null）。 */
    fun saveCustomCover(context: Context, game: ScanGame, pickedUri: Uri): ScanGame? {
        val dir = persistentCoverDir(context)
        if (!dir.exists() && !dir.mkdirs()) return null
        val ext = when (context.contentResolver.getType(pickedUri)?.lowercase()?.substringAfterLast('/')) {
            "png" -> "png"
            "webp" -> "webp"
            "gif" -> "gif"
            else -> "jpg"
        }
        val target = File(dir, "custom_${stableKey(game.uri)}.$ext")
        return try {
            context.contentResolver.openInputStream(pickedUri)?.use { input ->
                FileOutputStream(target).use { output -> input.copyTo(output) }
            } ?: return null
            val targetUri = Uri.fromFile(target).toString()
            CoverImageCache.deleteCachedCover(context, game.coverUri, exceptUri = targetUri)
            game.copy(coverUri = targetUri, coverSource = AppSettingsStore.COVER_SOURCE_CUSTOM)
        } catch (_: Exception) {
            target.delete()
            null
        }
    }

    fun searchCandidates(context: Context, keyword: String, limit: Int): List<VndbCandidate> {
        val query = cleanTitle(keyword)
        if (query.isBlank()) return emptyList()

        val body = JSONObject()
            .put("filters", JSONArray().put("search").put("=").put(query))
            .put("fields", FIELDS)
            .put("sort", "searchrank")
            .put("results", limit.coerceIn(1, 10))

        throttle.await()

        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(ENDPOINT).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15000
                readTimeout = 20000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("Accept", "application/json")
                setRequestProperty("User-Agent", "TyranorNext/1.0")
            }
            conn.outputStream.use { it.write(body.toString().toByteArray(StandardCharsets.UTF_8)) }
            if (conn.responseCode !in 200..299) throw CoverSearchException(CoverErrorCode.VNDB_NETWORK)
            val text = conn.inputStream.bufferedReader(StandardCharsets.UTF_8).use { it.readText() }
            val results = JSONObject(text).optJSONArray("results") ?: return emptyList()
            val preferLarge = AppSettingsStore.isVndbLargeCover(context)
            buildList {
                for (i in 0 until results.length()) {
                    results.optJSONObject(i)?.let { add(parseCandidate(it, preferLarge)) }
                }
            }
        } catch (e: CoverSearchException) {
            throw e
        } catch (_: Exception) {
            throw CoverSearchException(CoverErrorCode.VNDB_NETWORK)
        } finally {
            conn?.disconnect()
        }
    }

    private fun parseCandidate(o: JSONObject, preferLarge: Boolean): VndbCandidate {
        var chineseTitle = ""
        var originalTitle = o.optString("alttitle", "")
        o.optJSONArray("titles")?.let { titles ->
            for (i in 0 until titles.length()) {
                val t = titles.optJSONObject(i) ?: continue
                val lang = t.optString("lang", "")
                val title = t.optString("title", "")
                if ((lang == "zh-Hans" || lang == "zh-Hant" || lang == "zh") && chineseTitle.isEmpty()) {
                    chineseTitle = title
                }
                if (t.optBoolean("main", false) && originalTitle.isEmpty()) originalTitle = title
            }
        }
        val image = o.optJSONObject("image")
        // image.url 为原图（实测 v17 1080×1529），image.thumbnail 仅 256×362；
        // 大图开关关闭时沿用缩略图，避免额外流量。
        val largeUrl = image?.optString("url", "").orEmpty()
        val thumbnailUrl = firstNonEmpty(image?.optString("thumbnail", ""), largeUrl)
        val devs = o.optJSONArray("developers")
        val developers = buildList {
            if (devs != null) {
                for (i in 0 until devs.length()) {
                    if (size >= 3) break
                    val d = devs.optJSONObject(i) ?: continue
                    val name = firstNonEmpty(d.optString("original", ""), d.optString("name", ""))
                    if (name.isNotBlank()) add(name)
                }
            }
        }.joinToString(" / ")
        return VndbCandidate(
            id = o.optString("id", ""),
            title = firstNonEmpty(chineseTitle, o.optString("title", "")),
            originalTitle = firstNonEmpty(originalTitle, o.optString("title", "")),
            developer = developers,
            released = o.optString("released", ""),
            coverUrl = if (preferLarge) firstNonEmpty(largeUrl, thumbnailUrl) else thumbnailUrl,
            thumbnailUrl = thumbnailUrl,
        )
    }

    private fun VndbCandidate.displayTitle(): String =
        firstNonEmpty(title, originalTitle).trim()
}
