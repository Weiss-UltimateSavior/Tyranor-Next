# Architecture

本文说明 Tyranor Next 当前实现的模块职责、运行边界与数据流。功能行为见 [SPEC.md](SPEC.md)，开发约束见 [AGENTS.md](AGENTS.md)，术语见 [CONTEXT.md](CONTEXT.md)。

## 1. 系统范围与模块

Tyranor Next 是 Android 多引擎视觉小说聚合启动器。它管理游戏库、启动编排与应用侧工具，并通过内置宿主、JoiPlay 外置 APK 引擎模块、第三方 APK 运行时模块或外置模拟器运行游戏；识别到引擎不代表兼容性已经验收。

| 位置 | 职责与依赖边界 |
| --- | --- |
| `app/src/main/java/com/tyranor/next/ui/` | Compose 页面、输入交互、导航、状态展示与错误文案；经 core 调用引擎能力 |
| `app/src/main/java/com/tyranor/next/core/` | 扫描、游戏库、启动、设置、封面、存档、补丁、拆封包、授权、更新与第三方 APK 运行时模块发现/启用/交棒；可依赖 engine，禁止 Compose/UI 依赖 |
| `app/src/main/java/com/tyranor/next/theme/` | Material/Miuix 主题与视觉状态，属于表现层 |
| `engine/` | 引擎宿主、Java/Kotlin 桥、Web 脚本、JNI、预编译运行库与输入/图形基础能力；不依赖 App 页面 |
| `buildSrc/` | 图形贡献目录生成、资源归属及来源校验；独立构建逻辑，不是第三个业务模块 |
| `tools/`、`.github/workflows/` | 离线检查/生成工具与 CI/发布流水线 |

Gradle 仅包含 `:app` 与 `:engine`，`app` 通过 `implementation(project(":engine"))` 依赖后者；core 是 app 内部包边界，并非独立模块。

```mermaid
flowchart TD
    UI["app: ui / theme"] --> Core["app: core"]
    Core --> Engine["engine: 宿主 / 输入 / Web / JNI"]
    Core --> DB["Room / prefs / 文件"]
    Core --> External["外置模块 / 模拟器 / Android 应用"]
    Core --> RuntimeModules["第三方 APK 运行时模块（PackageManager）"]
    Core --> Network["封面 / OAuth / 补丁 / 更新 / 存档同步（WebDAV）"]
    Engine --> Native["预编译运行库与本地编译桥"]
```

## 2. 应用启动与界面状态

- [TyranorNextApplication.kt](app/src/main/java/com/tyranor/next/TyranorNextApplication.kt) 在主进程偏好迁移之前经 `AppSettingsStore` 初始化首次引导标记；标记写入失败不阻断启动，而由 `OnboardingPreferences` 保留本次安装判定的内存快照，并写入不参与存量安装判断的应用私有重试快照，后续启动或完成引导时继续重试落盘，避免迁移标记或空数据库改变首次判定。随后迁移共享 prefs 名称、配置 WebView profile，并在应用进入后台时安排更新检查；前后台切换同时驱动存档同步（WebDAV）的打开拉取与会话兜底（`core/game/save/sync/SaveSyncRuntime`）。主进程游戏库在启动阶段通过幂等入口触发预热，通常早于首帧组合但不保证初始化已完成，保证真实主页教练层及保存后的 Activity 重建都能复用同一入口。
- [MainActivity.kt](app/src/main/java/com/tyranor/next/MainActivity.kt) 在语言、主题与背景内门控首次引导；未完成时仍创建真实主导航，在其上叠加 `OnboardingCoachOverlay` 的聚焦框、连接线与气泡，并通过 `coachPage` 驱动游戏/引擎/设置页面切换。各真实控件在对应页面处于前台时通过 `onGloballyPositioned` 上报 root 坐标；首页首帧尚未测量时允许 `coachFallbackRect` 做比例回退，其余步骤等待真实锚点后再绘制，避免把暂时不可用的坐标误当作真实位置。完成标记落盘后仅移除覆盖层并请求通知权限，复用同一主导航组合，不重建四页或重置页面状态。覆盖层使用独立的模态无障碍语义组，外围拦截区消费误触，真实高亮控件仍保留语义与触摸入口。完成标记由 core 的 `AppSettingsStore` / `OnboardingPreferences` 管理；`ui/common/OnboardingCoachAnchor.kt` 提供跨页面共享的锚点映射与测量修饰符；[MainScreen.kt](app/src/main/java/com/tyranor/next/ui/main/MainScreen.kt) 组合首页、游戏、引擎、设置四页。四页常驻，切换用水平位移与 alpha，避免重建列表。
- [MainLibraryViewModel.kt](app/src/main/java/com/tyranor/next/ui/main/MainLibraryViewModel.kt) 通过 `StateFlow<MainLibraryUiState>` 发布游戏库快照，Channel 串行处理扫描/删除/刷新等命令；搜索防抖并拒绝过期结果。
- 二级页通常复用 [AppScreen.kt](app/src/main/java/com/tyranor/next/ui/common/AppScreen.kt) 中的 `AppScreenActivity` / `AppScreenScaffold`，统一语言、主题、系统栏、背景与转场；正文由 `setAppScreenContent` 提供，主题包裹依次经过 `ProvideAppLocale`、`TyranorNextTheme` 与 `GlassBackground`。全屏按键编辑器保留明文例外。

主线程负责 UI。扫描、持久化和启动准备通常转入 IO；现有同步兼容门面仍可能阻塞，不能将本仓库描述为完全没有主线程 I/O。

## 3. 游戏库与持久化

[GameLibraryDatabase.kt](app/src/main/java/com/tyranor/next/core/game/storage/GameLibraryDatabase.kt) 定义主进程专用 Room 数据库 `game_library.db`，当前 schema v3：

| 表 | 内容 |
| --- | --- |
| `games` | 游戏身份、引擎、启动目标、第三方运行时模块包名、封面/标题元数据与最近打开时间 |
| `scan_roots` | 扫描根目录 |
| `quick_launch` | 有序快捷启动关系 |
| `game_overrides` | 单游戏设置覆盖 |
| `engine_detection_cache` | 可重建的引擎识别缓存 |

数据写入链为 UI 命令队列 → [GameLibraryFacade](app/src/main/java/com/tyranor/next/core/game/storage/GameLibraryFacade.kt) 缓存与修订号 → [GameLibraryRepository](app/src/main/java/com/tyranor/next/core/game/storage/GameLibraryRepository.kt) 单线程 FIFO + mutex → Room。封面更新只修改对应字段；一致性搜索先等待已排队写入，避免旧结果覆盖新状态。

旧 `game_scanner` prefs 仍作为幂等迁移来源和恢复镜像，不能删除为“无用缓存”。应用/引擎偏好及引擎进程读取的单游戏 blob 仍保留 prefs；Room 不是所有状态的唯一介质，也不能把普通 SharedPreferences 当成实时跨进程消息总线。

Schema 导出到 `app/schemas/`。v1→v2 及降级仍允许破坏性恢复并从镜像修复；v2→v3 通过显式 `Migration(2,3)` 新增 `games.runtime_module_package` 列及索引，schema v3 的 `3.json` 已导出。后续版本必须显式注册 `Migration`，不能扩大全局破坏性回退。当前数据库、加密凭据、存档同步状态与备份边界统一见 [持久化数据清单](docs/应用持久化数据清单.md)；清单分别说明 v1 破坏性重建与 v2→v3 显式迁移；专题验收记录仍只对各自标注的版本有效。

## 4. 扫描与启动编排

1. [EngineScanner](app/src/main/java/com/tyranor/next/core/game/scan/EngineScanner.kt) 遍历已授权根目录，利用真实路径或 SAF 会话读取目录特征，按优先链识别引擎并产出 `ScanGame`；重扫合并保留手动添加记录。
2. UI 处理 Artemis 补丁与 MV/MZ 存档转化等用户确认，调用 [EngineLauncher](app/src/main/java/com/tyranor/next/core/game/launch/EngineLauncher.kt)。
3. Android 应用、第三方 APK 运行时模块与外部跳转优先分流：安卓游戏按包名直接跳转；`RUNTIME_MODULE` 按 `runtimeModulePackage` 交给显式组件；Windows 游戏交 Winlator；PSP / Nintendo Switch 交外置模拟器；Ren'Py / RPG Maker RGSS / Ruffle（SWF / Flash）交 JoiPlay 外置 APK 模块。它们的权限、目录载荷与错误协议各有契约，不统一伪装成内置宿主。Ruffle 属文件型入口（`launchEntryIsFile`）：文件记录保存 SWF 文件 URI、包装目录记录保存目录 URI，启动前统一解析出 SWF 所在目录，再以 `game` 的 `folder` + `execFile` 交给模块；运行时与存档由插件自行承担，主 App 不接管。
4. 内置启动解析真实目录及生效设置，检查权限、插件、存档位置和适用补丁；Kirikiri 的 SAF 镜像等特殊路径由 core 负责准备。SD 卡镜像（`KrSafMirror.prepare`，engine 内 `bridge/`）产出 0 字节占位树 + v2 索引 + 类型化 bootstrap/诊断载荷，经 Intent extras（`SAF_MIRROR_INDEX`/`SAF_MIRROR_ROOT`）传给 `:kirikiri2` 宿主；宿主 `NativeBridge.configureSafMirror` 装载会话快照，libc（open/fopen/freopen/stat/rename 等）GOT 钩子按「相对路径改基 → scoped 存档重定向 → 镜像路由（只读 SAF / 写 copy-up，`KrMirrorOpenRouter`）→ libc 原实现」分流，所有权标记与分片锁由 `KrMirrorLocalFiles` 维护，失败以哨兵（-2→EIO）或类型化阶段（`PrepareException`）回传 core/UI。
5. App 与宿主使用 [LaunchContract.kt](engine/src/main/java/com/core/engine/LaunchContract.kt) 的常量传递 Intent extras。启动结果为 `LaunchResult`；`Success` 表示已发起启动，不代表游戏已显示首帧或能够通关。

大体积引擎运行库（`libsiglus.so`、`librfvp.so`、`libethornell.so`、`libkrkrsdl3.so`、`libcmvs_android.so`、IJK 三件套、System35/4 与 `libSDL2x.so`、`libsystemnnn.so`）不随 `lib/` 在安装期解压：构建期打成 `assets/engine-runtime/<pack>.zip.xz`，`EngineLauncher` 在拉起对应引擎前于 IO 线程调用 `NativeRuntimePack.ensure` 解压到 `files/engine_runtime/<pack>/`（以 APK `lastUpdateTime:versionName` 判定是否重新解压），宿主进程再按绝对路径 `dlopen`；除 IJK 仅服务视频覆盖层、解压失败只记日志继续启动外，其余分片失败返回 `LaunchResult.Failure.EngineLibraryPackFailed`。`libSDL3.so`、`libSDL2_mixer_xs35.so` 仍留在 `lib/` 作为依赖；CMVS 另在 `lib/` 保留 `libcmvs_loader.so`（NativeActivity `android.app.lib_name`），由 loader 从 `files/engine_runtime/cmvs/` dlopen 真实库并转发 `ANativeActivity_onCreate`。这与 native plugin（Kirikiroid2 / ONS / Artemis）的资产形态一致，但分片按引擎家族划分，为后续单独下载留出入口。

- SystemNNN 在读取游戏文件前解析真实路径并完成共享存储授权。支持绝对路径、文件 URI 及系统外部存储文档 URI。私有 `:systemnnn` 宿主通过显式 Intent 启动，原 Emberfall 独立 APK 的绑定迁为内置类型。游戏目录一律原地读写，不做整目录复制；原目录不可访问即返回类型化启动错误。旧版本遗留的副本由 App 的 `SystemNnnCopyStore` 只读识别与回收，引擎只接收绝对路径，不持久化游戏路径或副本清单；待回收项由 App 侧持久队列保存并在启动时续做。

### 第三方 APK 运行时模块

`core/engine/runtime` 是独立于 JoiPlay 外置模块注册表与模拟器注册表的子系统，只使用 Android Framework 与 Kotlin；不进入 `engine/`、不走 JNI、不经过 `EnginePluginBootstrap`。数据流如下：

1. `RuntimeModuleDiscovery` 通过 Manifest `<queries>` 声明的 `com.tyranor.runtime.action.LAUNCH` 查询可见应用，只保留 `com.tyranor.runtime.` 前缀；每个包选择一个入口 Activity，并容错读取 `com.tyranor.runtime.MANIFEST` 指向的 `res/raw` JSON（`RuntimeModuleDescriptor` / `RuntimeModuleScanSpec`）。不申请 `QUERY_ALL_PACKAGES`，不校验签名或版本。
2. `RuntimeModuleRegistry` 保存发现快照与 `AppSettingsStore.KEY_RUNTIME_MODULE_ENABLED`（StringSet，默认空集），经 `StateFlow` 提供给 `ui/runtime/EngineModuleManagementScreen`；刷新、启用/禁用与扫描索引构建在同一互斥区内串行。新模块默认关闭，启用只写开关。
3. 扫描开始时 `EngineScanner` 取 `RuntimeModuleIndex`（已发现 + 已启用 + 有扫描描述），仅在 `UNKNOWN` / `WEB_OTHER` 等弱结果上调用 `RuntimeModuleMatcher` 匹配 `extensions` / `markers`；命中写入 `ScanGame.runtimeModulePackage`。多模块按 `all` > `any` → marker 数 → 包名排序，旧 URI 绑定优先；扫描是唯一入库入口。
4. `EngineLauncher` 对 `RUNTIME_MODULE` 直接调用 `RuntimeModuleLauncher`：显式 `ComponentName` + 文件夹绝对路径/标题/协议版本；`Dispatched` 只表示交棒，`ModuleMissing` / `ModuleDisabled` 触发 `RuntimeModuleBindings.degradeGame`。
5. `RuntimeModuleBindings.reconcile` 在重扫前与应用回前台等时机核对绑定：模块未发现、未启用或包名为空 → `EngineType.UNKNOWN`（保留最后已知 `runtimeModulePackage` 供重扫合并），保留其它字段；发现查询失败时跳过第三方绑定的降级。旧 Emberfall 内置身份的迁移独立进行。
6. 绑定经 `ScanGame` → `GameEntity.runtime_module_package`（Room v3）→ `GameRecordCodec` prefs 镜像传播；v2→v3 使用显式 `Migration(2,3)`。

[EngineSettingsResolver](app/src/main/java/com/tyranor/next/core/settings/EngineSettingsResolver.kt) 统一读取引擎全局与单游戏覆盖，`EffectiveEngineSettings` 处理归一化与回退。启动和存档消费同一份生效规则，页面不得另写优先级逻辑。

## 5. 引擎进程与生命周期

以 [engine Manifest](engine/src/main/AndroidManifest.xml) 为准，内置宿主均为 `exported=false`，主要分为 `:kirikiri2`、`:krkrsdl3`、`:ons`、多档 `:artemis*`、`:siglus`、`:fbgames`、`:fvp`、`:ethornell`、`:cmvs`、`:systemnnn`、`:xsys35`、`:xsys4`、`:tyrano`、`:rpgmaker`。进程隔离用于控制原生库、全局状态与符号冲突；不提供通用跨引擎热切换保证。第三方 APK 运行时模块运行在用户安装的独立 APK 进程中，不属于上述宿主，也不由 App 建立 JNI 会话。

- FVP、Framebuffer 及 Siglus 关闭滤镜的路径仍由主线程 `Choreographer` 同步驱动原生调用。
- Siglus 有效滤镜链才启用专用 engine owner 与 GLES consumer；关闭、空链或无效链沿用 SurfaceView 原路径。两种路径共享原生实例准入，不能同时启动第二个 owner。
- Ethornell 由专用 owner 线程管理 JNI 会话，Surface 世代、会话 token、退出 ACK 与存档操作门禁独立约束。宿主已对齐上游 `0cfff1d` 的 ABI v1 接口面：15 个导出（含 `request_payload`）、Event kind 5 输入对话框与 JSON 回答；kind 5 的 payload 只在 owner 线程两段式读取，UI 线程只持有已解析字符串。随包库当前带 1 个已记录的本地补丁（收敛启动期双重 `bgi-resource` 前缀，并放行顶层 `BGI.gdb` / `BGI####.cad` 到私有 user-root；provenance `dirty=true`）；`--local-static` 通过，严格来源审计要求 clean/已发布源码，见 §6。`EthornellPauseDeviceTest` 已重写为多 stage/step 模型并 3/3 通过；暂停/恢复与 Surface 通过，但精确 guest tick/held 序列不在该夹具覆盖范围。
- `Surface` 消失、Activity `finish()`、原生销毁完成与进程退出是不同事件。修改宿主必须维护线程归属、资源租约、回调世代和释放时序，不能用强杀结果冒充正常退出。
- SystemNNN 的播放器在最终存档写入和目录锁释放后撤销任务记录。相同游戏快速重开时，工作线程有界等待上一会话释放存档。只读校验服务运行在单独的 `:systemnnn_validator`，不登记播放器会话。

WebView 数据目录另行隔离：API 28+ 主进程用 `home` 后缀，`:tyrano` 保留历史默认目录，`:rpgmaker` 自设后缀。更改 profile 或本地 HTTP 端口会影响历史网页存储作用域，须同时评估存档兼容。

### impacto 宿主边界

`IMPACTO` 通过 App core 的严格描述文件解析和硬件/路径预检，调用 engine 层 `ImpactoLaunchPreparation` 准备资源与独立会话配置；UI 只通过 core 门面获知真实运行库是否随包。游戏身份仍按枚举名称持久化，不新增 Room 字段。

`ImpactoActivity` 是非导出的独立 `:impacto` SDL 宿主，绝对路径加载 `libimpacto.so`。静态链接的私有 SDL 3.4.10 对应 `org.libsdl.impacto`，不使用或替换既有 SDL3 3.4.12。上游会直接退出进程，因此会话锁必须覆盖真实原生写入寿命，不能把 Activity 销毁视为写入完成。

原生 `.so` 仍使用 `NativeRuntimePack`；独立 `impacto-runtime/` 资源包使用带大小/SHA-256 清单的版本化原子安装器，不复用仅 `.so` 的提取器。可信配置只运行随包 profile，精确重映射 VFS 的 `Path`/`Order` 与存档字段。补丁显式设置可信资源 CWD，并关闭缺失参数时向无关 Lua 的回退。用户配置与存档不在资源升级目录内。来源、构建及验收门槛见 [impacto 接入说明](docs/impacto-engine.md)。

## 6. 资源与原生构建链

| 源头 | 生成/消费方式 |
| --- | --- |
| `engine/src/main/assets/` | Web 注入脚本、字体与运行资源；选定的五个共享 JS 同步到 `app/build/generated/assets/engine/` |
| `engine/src/main/nativeplugins/` + `app/src/main/nativeplugins/` | 合并共享 `.so` 与 App manifest，重名失败；先打未压缩 zip 容器，再压成 `app/build/generated/assets/nativeplugins/{kirikiroid2,ons,artemis}.zip.xz`（LZMA2 共享字典，运行时解压安装到私有目录） |
| `app/src/main/assets/` | App 自有资源，当前主要为 `rtp/`；不在此手工保存生成插件 zip |
| `engine/src/main/jniLibs/arm64-v8a/` | 随 APK 分发的预编译运行库；`libsiglus.so`、`librfvp.so`、`libethornell.so`、`libkrkrsdl3.so`、`libcmvs_android.so`、IJK 三件套、System35/4（含 `libSDL2x.so`）与 `libsystemnnn.so` 只作为运行库包源，打进 `app/build/generated/assets/engine-runtime/{siglus,fvp,ethornell,krkrsdl3,cmvs,ijk,xsystem,systemnnn}.zip.xz`（CMVS 另有 `libcmvs_loader.so` 留在 `lib/`，由 NativeActivity `lib_name` 加载并转发），不再进 APK 的 `lib/`（首次启动该引擎时由 `NativeRuntimePack` 解压到 `files/engine_runtime/<pack>/`，JNI 桥按绝对路径 dlopen） |
| `engine/src/main/cpp/` | CMake 现场编译 JNI/图形桥，动态连接既有运行库 |
| `engine/src/main/graphicsfilters/*.json`、`engine/patches/*.json` | 描述滤镜贡献与固定来源；buildSrc 生成目录并校验资源、许可与相关库哈希。滤镜资产按描述符声明顶左/底左行序契约（见 docs/graphics-filter-coordinates.md）；`asset: null` 的条目为纯重采样节点（Bilinear/Bicubic/Lanczos），不加载卷积着色器 |

普通 Gradle 构建不会重编大部分引擎，也不会执行 Rust 构建：

- XP3 源码与固定依赖在 [engine/rust](engine/rust/Cargo.toml)；`build-archives.sh` 先运行宿主测试，再用 cargo-ndk 生成 `libarchive_xp3_core.so`。JNI panic 防护依赖 unwind，不改为 `panic=abort`。
- System35/4 的固定来源构建脚本位于 `engine/xsystem35/scripts/`、`engine/xsystem4/scripts/`；共享 `libSDL2x.so` / `org.libsdl.app32`，与 ONS 的 `libSDL2.so` / `org.libsdl.app` 分开维护。
- Siglus 保留已固定的原始运行库，来源与哈希见 [说明](engine/patches/siglus/README.md)；当前 CI 不重编其 Rust 源码。
- SystemNNN 从 `assets/engine-runtime/systemnnn.zip.xz` 解压运行库。播放器和校验进程各自核对当前 APK 标记，再按绝对路径调用 `System.load`。CI 核对固定来源、大小、SHA-256、JNI 导出及实际 APK 的分包。Emberfall 自行生成默认碎裂网格，自有代码按 GPL-2.0-only 分发。 [运行库来源](engine/src/main/assets/licenses/systemnnn/ffmpeg-source.txt) · [归属与许可](engine/src/main/assets/licenses/systemnnn/upstream-source.txt)
- Emberfall `2150bab` 的分包曾在 Android 11（API 30）`sdk_gphone_x86_64` 模拟器通过 ARM64 转译运行《死终Ω神盾》简体版开场并进入标题。该版设备 ZIP 测试确认有效全局进度可导入，损坏包被拒绝且原存档字节保持一致，主进程没有加载 SystemNNN 原生库。
- Emberfall `d017074` 的独立版与 TYN 测试包均在 Android 11 ARM64 转译模拟器安装成功。TYN 在设备解压后的运行库与 APK 分包一致。新默认网格的全屏转场与图层碎裂在 Host 上通过 800×600 和 1280×720 的渲染检查。
- 旧版 APK 在 Android 11（API 30）`sdk_gphone_x86_64` 模拟器上通过 ARM64 转译运行《死终Ω神盾》简体版。TYN 从游戏库扫描并启动，读取独立版的自动档，推进一条台词、写入同目录的快存并返回标题。临时用普通文件占用 `sav` 路径时，TYN 在启动播放器前显示写入失败。
- 同一模拟器验证了独立版的全局进度主备恢复。有效主档配损坏备份时隔离备份，损坏主档配有效备份时恢复进度并保留原文件。两次检查都保留扩展和剧情存档。用游戏原片头临时开启不可跳过，切后台暂停，回前台恢复音频焦点并在播放完成后进入标题。
- Android 8、Android 10、ARM64 真机和真实 WebDAV 服务的设备验收待执行。存档替换与锁冲突另有 JVM 回归。
- Ethornell `.so`、provenance JSON 与 ABI header 必须成套核对。当前随包库为 `043fef05…`（27,259,224 B；`0cfff1d` + 1 个已记录的本地补丁 `77b99d93…`，`dirty=true`），补丁同时收敛双重 `bgi-resource` 的 `UserData` 前缀，并把顶层 `BGI.gdb` / `BGI####.cad` 全局数据映射到私有 user-root；发布门禁使用的 `--local-static` 已在本轮校验来源记录和产物字节并通过，但严格源码审计要求 clean/已发布源码，dirty 本地补丁产物不能通过（`release_ready=false`），也不等价于可复现构建。

预编译源码归属决策见 [ADR 0002](docs/adr/0002-prebuilt-engine-libs-source-in-fork.md)。所有生成目录禁止手工维护；共享字体保持不压缩，并兼顾 System35、System4 与 ONS。

## 7. 其它功能边界

- SystemNNN 在同一 `sav` 目录中通过 `emberfall.lock` 与独立播放器协调存档访问。TYN 只替换自身格式的白名单文件，目录、锁及 PC 数据原地保留。中断恢复材料保存在 `emberfall.migrate/tyn-restore`，独立播放器会拒绝打开该未完成事务，TYN 在持锁时恢复。清理旧副本资源时同时持有来源锁和游戏存档锁，并写入逐出标记；带标记的副本不再启动，由用户删除并从可访问的原目录重新添加。存档管理与同步在此期间仍使用同一 `sav`。
- SystemNNN 不再创建 SAF 副本；`SystemNnnCopyStore` 仅保留旧副本的识别与资源回收。ZIP 恢复和删档在同一来源锁内解析并锁定当前 `sav`。
- SystemNNN 的 ZIP 导入在私有 `:systemnnn_validator` 进程通过绑定服务校验。主进程只传应用缓存中的暂存目录名及校验条件，服务只返回结果。服务死亡、校验超时或快照无效时不会替换活动存档。WebDAV 对已核对同源的副本迁移会话基线和已提交的恢复记录，仍有待提交的恢复事务时返回类型化错误。

- 封面：`CoverScraperService` 聚合在线来源，`CoverScrapeTaskManager` 管理应用级批量任务；UI 使用缩略图缓存，不在重组期同步抓取/解码。
- 存档：`GameSaveManager` 解析位置并导入/导出 ZIP；MV/MZ 的格式转化与互通独立于存档镜像，均采用同源目录解析。Ethornell 存档管理已按 capability 开放（`DEVICE_SAVE_IO_VERIFIED=true` 与 `HOST_DISPATCH_PROTOCOL_VERIFIED=true`）；范围仅 App 私有 user-root 的备份/恢复/删除，ZIP 单个文件上限 64 MiB（与 native 原子写一致），总量 1 GiB 预算不等于该上限；不自动导入资源根 `UserData`，不承诺商业游戏内槽位兼容或 PC 格式互通。
- 存档变更门禁按规范化目录的父子相交关系互斥，运行证据与待切换 owner 也使用同一范围；相关目录的 revision 参与传输 epoch，父目录切换后内层旧传输与会话失效。不相交的已知目录共享准入并可并行执行哈希、导出与启动；无法解析目录的启动仍独占变更准入。移除游戏只清理已获得门禁的当前应用专属存档目录与事务副本，保留旧独立目录、镜像父目录及索引。删除等锁可取消且有时限，进入必要清理后才不可取消；先推进传输 revision，子项失败保留身份和索引供重试。
- 存档同步（WebDAV）：`core/game/save/sync/SaveSyncService` 在既有 ZIP 导出/导入能力之上管理不可变历史，按相对路径和内容字节计算 SHA-256；网络串行锁与本地历史锁按 URI 区分，活动存档锁按规范化实际目录区分，重叠 SAF 根共享写入门禁。`SaveDirectoryActivationStore` 在 `noBackupFilesDir/save_sync/directory_selections` 持久化该目录的 owner URI/token 与 revision；导入前写入，所有 alias 在恢复及 session/baseline 清理成功前拒绝同步启动与捕获，清理按持久 `activeKey` 扫描而不依赖当前 alias 是否可解析，完成后保留 revision 使旧 pinned transfer 失效。网络等待不持有本地锁，上传固定私有 ZIP 副本，选择/身份/清理通过 revision 使旧传输收尾失效。默认关闭、启用后默认手动；`SaveSnapshotStore` 负责每游戏 5 版与临时文件维护，`WebDavClient` 负责 WebDAV 传输与旧布局读取，10/20/无上限的独立保留策略由 `SaveSyncService` 执行。每次拉取只取该游戏当前最新云端版本并写入本地历史，不批量下载或直接恢复远端历史；手动激活版本才导入活动存档。旧版本 S 激活后继续保存出的 N 仍沿同一恢复链发布，并用 N 替换云端旧 S。旧保留量值、v1 云端布局和早期 Debug 本地选择标记均保留迁移/读取路径。
  目录 owner 会保留到 journal 清理成功；删除 journal 前先持久化 `completionCommitted`，因此 journal 已删除而 owner 残留时仍能按已知结果完成释放。未提交的 abort 以持久 false 结果恢复 `previousRevision`；旧 token 的 `resume` 只接受自己的当前 epoch 或没有 revision 的 legacy 空 epoch，不能回退较新的 alias。`WebDavClient` 为每轮传输安装事务准入回调；每个顶层及嵌套 DAV exchange 在发出前都复核持久 generation、session/current 条件和已固定的 revision/activeKey，准入检查与请求入队在同一短临界区内完成，网络响应等待不持有本地版本/目录锁。
  `SaveSyncRuntime` 在 App 侧协调游戏会话结束后的补写上传；engine 的 `SiglusEngineAdmission.hasActiveOwner()` 仅提供只读 owner 状态，实际销毁确认前保持对应 URI 的宿主 busy，owner 释放后先持久化最终宿主记录再发退出信号，写入失败保持保守并重试。WorkManager 将打开立即、退出立即、打开 fallback、退出 fallback 保持为四条独立唯一链：四条链均用 `APPEND_OR_REPLACE`，新 fallback 不取消在途传输，已被更新排程取代的旧排队请求跳过 IO；前台、宿主退出/监测和 busy/可重试失败分别排入对应链。Activity 次级进程名从应用清单惰性读取并在进程内缓存成功结果，查询失败不缓存且仍按忙碌处理。`WebDavSettingsStore.setEnabled(false)` 与递增的 `disable_generation` 在同一 `webdav_sync_secure` prefs 提交中持久化；session 保存 `enabledGeneration`，旧 ticket 在 sweep 前及进程重启后都因 generation 不匹配而失效，新 launch 不会继承旧 generation 的 pending baseline。`whileEnabled` 在动作边界复核持久 generation 与 enabled；关闭还会同步捕获旧 session token，异步清理只移除精确捕获值且不受随后重新开启影响。凭据由 AndroidKeyStore 加密并排除备份。UI 的一次性结果观察与文案映射由 `ui/common/SaveSyncFeedback.kt` / `SaveSyncMessages.kt` 承担。
  启动前忙碌探测按当前持久 generation 过滤 session 与启动宽限，避免旧 ticket 阻塞新 epoch；旧快照仍尊重较新的启动宽限，失败启动仅清理匹配 generation/token 的宽限；宿主进程列表、持久 PID 与无法确认身份的进程仍独立保守判忙；持久 PID 已被其它 UID 进程复用（对 App 不可 signal）时按已退出处理。
- 启动与配置代际：`EngineLauncher` 使用类型化 `SaveSyncLaunchAdmission` 区分 Disabled / Unmanaged / Unresolved / Directory。不支持统一文件存档接口的引擎直接启动；受管理游戏在关闭或开关不可读时不解析存档目录，关闭/解析失败的启动仍取得 mutation 门禁并登记启动宽限，与目录写入串行。解析成功时按实际目录锁→mutation 门禁准入；所有等待结束后重读准入，目录或开关类型变化则释放并重新准入，baseline 使用固定目录并在读写前复核。不再通过字符串前缀猜测锁的类型。每次受管理启动即使可选 ticket 记账失败也在实际 dispatch 前取得独立宽限，YURIS 另在 `save_sync/external_launches` 保存与上传模式和 generation 无关的外置 owner 标记；当前进程 prepared 记录保留到 dispatch 或明确失败；已 dispatch 的记录跨前台事件及主进程重建保留，不以旧 owner、年龄、返回或进程重建推断 Winlator 退出。用户退出 Winlator 后，在存档管理页显式确认才按 URI 清除外置标记并允许退出会话收尾；损坏/非普通标记也走定向确认入口，WebDAV 关闭时仍可操作。每 URI 保留多份 token，失败只清自己的宽限，Intent 已发出后的记账失败或取消保留保护。`WebDavConfig` 快照携带独立 `config_revision`；保存或重置配置时 revision 与加密 payload 在同一次 prefs `commit()` 中更新，`SaveSyncService` 的本地事务检查及 `WebDavClient.exchange` 的真实 HTTP enqueue 准入都会复核。配置 revision 不推进 `disable_generation`，因此现有 session、ticket 与启动宽限不被模拟成关闭/重开。
- 版本激活恢复：`SaveActivationJournal` 在 `noBackupFilesDir/save_sync/pending/{records,archives}` 中按游戏最多保留一个记录和一个 staging ZIP。导入前先把校验后的私有 ZIP 移入 journal，并在同一目录锁内调用 `SaveDirectoryActivationStore.begin`；提交后先把所选 S 重新登记到本地版本历史，再捕获规范化后的活动存档。未提交记录只有“当前哈希等于 S 且不同于导入前哈希”才能证明目录提交，导入前已相同的字节不构成证据；`committed` 标记活动目录已切换，持久化的 `completedActivation` token 防止重复登记 promotion。重试只完成目录/元数据收尾并清除 token，不自动再次导入活动存档。
  用户明确放弃中断状态前先保护当前有效数据，恢复入口不依赖 WebDAV 总开关；新的明确选择不会被旧 journal 的待补齐结果冒充成功：同一 S 的旧事务完成时若活动内容已前进到 N，仍重新执行 S 的导入。记录无法解析或其声明哈希与 ZIP 不符时，独立校验 archive 内容后救入历史；恢复事务在五版裁剪中同时保护源 S 和活动存档 N，确认两者均有效才删除 staging。无法救回则保留原件并报错。SDK 数据/存储卷根及已验证别名由 `SaveStorageRoots` 提供，`SavePathSafety` 只 canonical 化可信前缀，根下继续逐段 NOFOLLOW；备份与活动存档删除采用不跟随链接的树删除。导入交换在 staging 内写 token 标记并在相邻事务记录绑定 URI/token/`preservePrevious`；只有 destination 中匹配的标记可证明提交；全零文件导入在交换前把 `preservePrevious` 同写 marker 与事务记录，因此 callback/资源恢复中断后收尾仍会把旧档保留为 orphan。缺少证据的旧 backup 同样改名为 `.import_orphan_<UUID>` 留存，不凭目录存在就删除。每个实际存档目录最多新增三份不同内容的 UUID 恢复副本；按相对路径、目录结构与文件内容 SHA-256 校验相同后才合并副本，提交 marker 不参与内容比较，不追随符号链接。槽位满且备份内容不同则返回存档目录不可用，保留 indexed backup 与事务记录供重试；全零导入会在交换活动目录前检查容量。旧安装已超过三份的不同内容副本不会为达上限而删除，也不再新增。用户须先用具备该目录访问权限的文件/调试工具把恢复目录完整备份到其它位置，核实副本后移走或删除不再需要的一份，再重试；当前没有专门的恢复槽管理 UI。应用数据删除在存储根边界内枚举精确 UUID sidecar，以 NOFOLLOW 树删除清理，不触及游戏目录。
  未上传 session 的空树 baseline 也跨重启继承。启动内容 baseline 与元数据签名持久化在 `noBackupFilesDir/save_sync/baselines`，两者均绑定规范化实际目录 `activeKey`；目录变更或旧会话缺少绑定时保留原任务并以类型化错误暂停，禁止把旧 baseline 用于新目录。前后台标志回写与自动回传都在目录锁内复核原 token。退出仍以内容哈希决定传输。互斥表按各层键统计持有者与等待者，在最后一个引用释放时回收；自动 Worker 使用非计费网络且 fallback 达重试上限即结束本轮，不删除待同步 session。
  staging 损坏/缺失的恢复可采用独立验证的同内容历史 S；清 journal 前仍保护 S/N，并保留同 completed token、同源及时间匹配的有效 promotion，先删除 staging 成功再移除记录，删除失败不丢 token。未提交的不同 token 不因 staging 不匹配而覆盖或清除 older completed S→N。目录 store 仅在首次 begin 保存 `previousRevision`；committed completion 保留新 revision，已证明的 precommit abort 用 `complete(..., committed = false)` 回滚到该值，避免丢弃较早 completed 链的目录 epoch。所有历史新增、维护与恢复淘汰都先保护 journal 的 `selected`、`beforeHash`，以及 `promotionAwaitingChange` 或 legacy/stale `promotionNeedsRecovery` 所需且独立验证有效的 `promotionFromHash` source，再按有效版本上限裁剪。超过五版时才全量校验淘汰候选，把坏 ZIP 改名隔离为 `.corrupt`，不让它占用有效配额；普通列表与未超限维护不全量哈希。会话写入另在目录锁后取得按 URI 哈希关联的 session 锁，目录切换不会产生两把可互相覆盖 token 的会话锁；锁顺序为历史（若需要）→实际目录→mutation（目录替换/回填）→session，网络不持有后三者。自动上传同时绑定本轮已判定的目录与内容哈希，不在 A→B→A 的设置切换中采用 B 的其它内容。`promotionActiveKey` 与 `promotionDirectoryRevision` 共同绑定未消费的 S→N 链；另一 URI 成功推进目录 revision 后，旧 alias promotion 暂停。跨目录、旧 revision 或缺少绑定的 legacy promotion 以 `SAVE_LOCATION_CHANGED` 暂停。completed promotion 的目录或 revision 缺失、为空、与当前目录不匹配时，也通过 `needsSelectionRecovery` 暴露恢复入口：`abandonActivationLocked` 捕获当前活动 N、保留可验证历史 S，清除无法证明归属的 promotion ancestry，不调用 import；恢复后 N 作为普通内容变化同步，不冒充替换远端 S。该恢复路径服务于所有已接入统一存档管理的引擎；MV/MZ 互通仍由独立开关与格式边界约束。当前同版本显式重选仍是可选路径，执行时实际重新导入并建立当前目录/revision 链。
- 清理上限与本地失败边界：每个游戏每个同步轮次中，所有经 `SaveSyncService` 发起的远程 DELETE 合计最多 20 次。超过上限时保留 `needsPrune` / `publicationConfirmed` checkpoint 和 pending session，以 `SaveSyncReport.cleanupPending` 结束本游戏本轮；WorkManager fallback 继续，下一轮先重新确认有效替换再裁剪，已有 S→N 链与同字节待清理意图保持。下载在写盘前检查可用空间，写入、flush、close 或原子替换的本地失败分类为 `STORAGE_FULL` / `LOCAL_IO`，空间不足不进入自动网络重试；上传 pin 复制失败会释放临时文件登记并删除残留。`LOCAL_STATE_CHANGED` 是独立 typed error，不冒充 `GAME_RUNNING`；游戏删除保留原始 `SaveSyncError`，UI 按错误码映射提示。Service 已确认的 `needsPrune` 会在 capture/pin 前重新验证云端档案，active 为空或上传 pin 创建失败仍可继续清理，但验证所需空间与 checkpoint 持久化必须成功、验证失败不得删除旧版本；Runtime 以 pending cleanup 优先于非空 hash 差异判断，20 次 DELETE 预算耗尽时保留 marker，新 M 可在同轮发布并由后续轮次继续清理，临时文件 create/copy 的 ENOSPC 统一为不重试的 `STORAGE_FULL`。 清理报告和失败关联使用 URI；fallback 按打开/退出唯一链名称的稳定哈希在 `save_sync/workers` 保存存储不足 URI 排除集与最新 owner UUID，排程及运行中补写在进程内同一锁下取并集。`APPEND_OR_REPLACE` 保留在途传输，后继总会入队，过时排队请求跳过 IO，旧 owner 的清理不能删除新状态；终止失败记录报告后以成功图节点结束，避免取消后继。下一轮 `flushPending` / `syncAll` 在执行前过滤，身份冲突统计仍包含被跳过的游戏。新立即/手动请求不继承，排除集完成/耗尽/关闭时移除；当前链可长时间等待非计费网络而不失效，旧版 UUID 记录才七天过期。WorkManager Data 仅保存模式布尔量与稳定链名，URI 不塞入 Data。
- WebDAV 本地删除：移除游戏时在本地历史/活动存档锁内清理该 URI 的版本、激活源、检查点、会话与 baseline，不删除云端历史；子项清理失败保留主状态的身份与 checkpointKeys 归属索引，并恢复游戏库条目以提供重试入口。宿主登记为进程级，零 Activity 在 native owner 完成后再经 1.5 秒宽限视为空闲；ActivityManager 空列表/不可用时，仍需宿主证据的有效 native session 保守判忙；无此 session 时改查持久 PID 与 `/proc`，无记录或已证明退出可空闲，未知身份/无效 PID 仍判忙；`/proc` 不可读且 `kill(pid, 0)` 返回 `EPERM`/`EACCES` 时证明该 PID 不属于本应用宿主进程（宿主必与 App 同 UID），按已退出处理，避免陈旧 PID 被复用后永久判忙。hosts 为可重建缓存，坏 JSON 留存原件与隔离副本，逐记录转为未知宿主证据；无法证明退出时持续判忙，不能因隔离后记录缺失而放行。Activity 创建/销毁/恢复/暂停均补写宿主记录，正常重新启动及退出可重建缓存；durable journal/checkpoint 保持严格读取。状态目录本身被普通文件占位时按本地 IO 失败关闭：Windows 会把这种路径的子项读取报成「文件不存在」，不能据此推断该游戏无状态，Unix 与非普通路径检查同样归为 IO 失败。
- 拆封包：`ui/archive` → `core/unpack` → `com.core.archive.Xp3Core` → Rust；SAF 不能映射路径时经 staging 中转。Artemis PFS 补丁解包不走该工具链。
- 第三方运行时模块：`core/engine/runtime` 只负责发现、启用、扫描描述解释与显式组件交棒；存档、输入重映射与引擎/单游戏设置均不接管，由模块自身负责。
- 输入：UI → core 门面 → `engine/com.core.input`，按 canonical 键位注入每宿主的 `InputSink`；布局编辑器复用原生按键层。
- 授权/更新：Hikarinagi OAuth 经 AppAuth 与 Keystore 保护的凭据存储；后台更新由 WorkManager 单次任务驱动，下载后经 FileProvider 交系统安装器。

## 8. 已知架构偏差

当前代码仍有与规范不完全一致的部分：`SaveLocation.description`、授权及在线补丁的部分接口携带本地化文本；旧数据清单和专题验收说明也有历史快照。新增/改动接口须采用类型化错误，修复时连同调用链迁移。
